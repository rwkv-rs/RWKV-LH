"""Same production direct-agent loop for zero/candidate; no target answers in inputs."""
from pathlib import Path
import sys,json,hashlib,shutil,time,urllib.request
from dataclasses import replace
R=Path('/home/chase/GitHub/RWKV-LH');sys.path.insert(0,str(R));P=R/'data/experiments/RWKV_UNIFIED_CORRECTION_TRAIN_R2_20260914';D=P/'evaluation'
from rwkv_lh.read_only_agent import ReadOnlyJob,run_read_only_job
from rwkv_lh.runtime.settings import load_local_env,get_runtime_settings
from rwkv_lh import task_review as v
from unified_eval_budget_train2_20260914 import reserve

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def freeze():
 cp=json.loads((P/'evaluation_service/STATE_PROFILES_SERVING.json').read_text())['profiles'][0]
 cap=json.load(urllib.request.urlopen('http://127.0.0.1:29622/v1/capabilities',timeout=10));assert cap['model']=='rwkv-direct-unified-r2-ctx24576' and cap['recurrent_state']['full_input_token_ids'] and cap['recurrent_state']['resume'];save(D/'CAPABILITIES.json',cap)
 pins={str(p.relative_to(R)):sha(p) for p in (R/'rwkv_lh').rglob('*.py')};reg={'base_url':'http://127.0.0.1:29622/v1','model_name':'rwkv-direct-unified-r2-ctx24576','model_sha256':'559371f5b9aef13189ae54b345ac096af4ad2b689996c05d89de687612b3ae65','profiles':{'zero':{'id':'zero','sha256':'0'*64},'candidate':{'id':cp['id'],'sha256':cp['sha256']}},'source_pins':pins,'script_sha256':sha(Path(__file__)),'evaluation_registration_sha256':sha(D/'EVALUATION_REGISTRATION.json'),'gate_interpretation_sha256':sha(D/'GATE_INTERPRETATION_PRE_RUN.zh-CN.md'),'regression_fingerprint':sha(D/'REGRESSION_REGISTRATION.json'),'project_manifest_sha256':sha(P/'runtime/PROJECT_SOURCE.json'),'serving_registration_sha256':sha(P/'evaluation_service/REGISTRATION.json'),'capabilities_sha256':sha(D/'CAPABILITIES.json'),'order':'repeat1 zero/candidate, repeat2 candidate/zero per task; independent workspace and initial State every run','tool_scope':'files: same production read-only menu for both arms','review_adapter_pins':{n:sha(R/'temp'/n) for n in ('audit_unified_task_traces_train2_20260914.py','review_unified_tasks_train2_20260914.py','unified_observed_coverage_train2_20260914.py','freeze_unified_task_contracts_train2_20260914.py','freeze_unified_coding_contracts_train2_20260914.py','audit_unified_coding_traces_train2_20260914.py','verify_unified_coding_artifacts_train2_20260914.py','run_unified_coding_tasks_train2_20260914.py')},'budget_helper_sha256':sha(R/'temp/unified_eval_budget_train2_20260914.py'),'max_total_generation_calls':400,'max_total_seconds':18000}
 assert not (D/'RUN_REGISTRATION.json').exists();save(D/'RUN_REGISTRATION.json',reg)
def run(phase):
 reg=json.loads((D/'RUN_REGISTRATION.json').read_text());assert sha(Path(__file__))==reg['script_sha256'];assert all(sha(R/'temp'/n)==h for n,h in reg['review_adapter_pins'].items());assert sha(R/'temp/unified_eval_budget_train2_20260914.py')==reg['budget_helper_sha256'];assert all(sha(R/p)==h for p,h in reg['source_pins'].items());assert sha(D/'EVALUATION_REGISTRATION.json')==reg['evaluation_registration_sha256'];assert sha(D/'REGRESSION_REGISTRATION.json')==reg['regression_fingerprint'];assert sha(D/'GATE_INTERPRETATION_PRE_RUN.zh-CN.md')==reg['gate_interpretation_sha256']
 fixed=json.loads((D/'REGRESSION_REGISTRATION.json').read_text());diag=json.loads((D/'EVALUATION_REGISTRATION.json').read_text());load_local_env(R/'.env.local')
 if phase=='confirmation':assert json.loads((D/'DEVELOPMENT_GATE.json').read_text())['passed'] is True
 cases=diag['diagnostic_cases'] if phase=='diagnostic' else [c for c in fixed['cases'] if c['split']==phase]
 out=D/phase;out.mkdir();rows=[];start=time.monotonic()
 for repeat in (1,2):
  for case in cases:
   for arm in (('zero','candidate') if repeat==1 else ('candidate','zero')):
    reserve(6 if phase=='diagnostic' else 4,300 if phase=='diagnostic' else 240)
    profile=reg['profiles'][arm];settings=replace(get_runtime_settings(),base_url=reg['base_url'],model=reg['model_name'],model_sha256=reg['model_sha256'],tool_disclosure_mode='full',return_token_ids=True,state_transport='native_required',state_profile_id=profile['id'],state_profile_sha256=profile['sha256'],read_timeout_seconds=300,max_model_len=24576,default_temperature=diag['sampling']['temperature'],default_top_p=diag['sampling']['top_p'],default_top_k=diag['sampling']['top_k'],default_presence_penalty=diag['sampling']['presence_penalty'],default_frequency_penalty=diag['sampling']['frequency_penalty'],default_penalty_decay=diag['sampling']['penalty_decay'])
    rid=f"{case['id']}-{arm}-r{repeat}";dest=out/rid;workspace=dest/'workspace';source=R/case['workspace_source'];expected=case.get('file_sha256') or case['workspace_sha256'];assert all(sha(source/name)==h for name,h in expected.items())
    workspace.mkdir(parents=True)
    for name in expected:
     p=workspace/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source/name,p)
    result=run_read_only_job(ReadOnlyJob(task_id=rid,request=case['request'],workspace=str(workspace),output_dir=str(dest/'execution'),max_calls=6 if phase=='diagnostic' else 4,max_seconds=300 if phase=='diagnostic' else 240,tool_scope='files'),settings=settings)
    rows.append({'case_id':case['id'],'arm':arm,'repeat':repeat,'result':result});save(out/'RESULTS.json',rows);print(rid,result['termination'],result['generation_started'],flush=True)
if __name__=='__main__':freeze() if sys.argv[1]=='freeze' else run(sys.argv[1])
