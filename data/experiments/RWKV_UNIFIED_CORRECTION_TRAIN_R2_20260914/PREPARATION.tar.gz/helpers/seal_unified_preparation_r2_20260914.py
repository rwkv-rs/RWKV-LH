from pathlib import Path
import json,tarfile,hashlib
R=Path('/home/chase/GitHub/RWKV-LH');D=R/'data/experiments/RWKV_UNIFIED_CORRECTION_TRAIN_R2_20260914';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
with tarfile.open(D/'PREPARATION.tar.gz','w:gz') as t:
 for name in ('AUTHORIZATION.zh-CN.md','REVIEWED_ROWS.json','FREEZE_REGISTRATION.json','SIMILARITY_AUDIT.json','FREEZE_RESULT.json','EVALUATION_REGISTRATION.json','sources','runtime','training/REGISTRATION.json','training/RUNTIME_REUSE.json','training/train.sh','training/LAUNCH.json','training/LAUNCH_R1_FAILED.json','training/LAUNCH_R1_FAILED.py.txt','training/BEFORE_SERVICE_PAUSE.txt','training/RETRY_IDLE.txt'):
  p=D/name
  if p.exists():t.add(p,arcname=name)
 for p in (R/'temp').glob('*20260914.py'):
  if ('train2' in p.name or p.name in ('freeze_unified_corrections_r2_20260914.py','prepare_unified_training_r2_20260914.py','launch_unified_training_r2_20260914.py','retry_unified_training_launch_r2_20260914.py','seal_unified_preparation_r2_20260914.py')):t.add(p,arcname='helpers/'+p.name)
(D/'PREPARATION_SHA256.json').write_text(json.dumps({'PREPARATION.tar.gz':sha(D/'PREPARATION.tar.gz'),'dataset_manifest':sha(R/'data/datasets/rwkv_direct_unified_corrections_v2/manifest.json'),'training_registration':sha(D/'training/REGISTRATION.json'),'evaluation_registration':sha(D/'EVALUATION_REGISTRATION.json')},indent=2)+'\n')
with (R/'docs/HANDOFF.zh-CN.md').open('a') as f:f.write('\n\n优质纠正采集已封存：GC修复后四局部修复0/4，完整51生成仍重复读取，无修改；两个强修复后的工作区验证任务也未独立验证完成。2条强模型原样编辑红→绿，加1条实际失败测试命令，经两审核及fresh执行后在新v2冻结，共57行，最长24455/24576tokens。文本歧义及错审候选未准入，人工误称sqlite_io.py不存在的错误已留痕纠正。详情 RWKV_FOCUSED_CORRECTION_CAMPAIGN_R1_20260914。训练R2从zero计划342步（6epochs，上限400步/4h/80GiB）正在GPU0执行，结果未知；原门槛不变。复用字节相同数值训练源码及24K兼容证明，生产评测用GC修复源码，唯一model_io相同。训练退出自动恢复原服务，GC侧服务暂停待评测后按原launch重建；不要对已停止的transient unit直接start。启动SSH引号错误0步已保留。所有固定评测两臂重新运行，尚不读confirmation/holdout、不push。详见 RWKV_UNIFIED_CORRECTION_TRAIN_R2_20260914/PREPARATION_SHA256.json。\n')
