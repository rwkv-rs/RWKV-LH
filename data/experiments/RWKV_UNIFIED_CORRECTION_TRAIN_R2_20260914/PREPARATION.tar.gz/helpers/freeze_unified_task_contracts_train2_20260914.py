"""Map frozen outcome/rubric to current review contracts without adding model input."""
from pathlib import Path
import json,sys
R=Path('/home/chase/GitHub/RWKV-LH');sys.path.insert(0,str(R));D=R/'data/experiments/RWKV_UNIFIED_CORRECTION_TRAIN_R2_20260914/evaluation'
from rwkv_lh import task_review as v
from rwkv_lh.direct_trace_data import protocol_identity
phase=sys.argv[1];reg=json.loads((D/'RUN_REGISTRATION.json').read_text());fixed=json.loads((D/'REGRESSION_REGISTRATION.json').read_text());policy=json.loads((D/'EVALUATION_REGISTRATION.json').read_text())
if phase=='confirmation':assert json.loads((D/'DEVELOPMENT_GATE.json').read_text())['passed']
cases=policy['diagnostic_cases'] if phase=='diagnostic' else [c for c in fixed['cases'] if c['split']==phase]
identity={'model':reg['model_sha256'],'protocol':protocol_identity()[1],'source':v.digest(reg['source_pins']),'sampling':v.digest(policy['sampling']),'state':v.digest(reg['profiles']),'budget':v.digest({'policy':reg['evaluation_registration_sha256'],'total_calls':400,'total_seconds':18000})}
for c in cases:
 if phase=='diagnostic':
  requirements=[dict(r) for r in c['requirements']]
  for r in requirements:
   if r['id']=='sources':r['user_quote']='列明本次实际工具操作和尚未执行的验证建议'
 else:
  def req(i,q,o):return dict(id=i,user_quote=q,outcome=o,level='essential',missing_effect='主要摘要目标未完整满足，分别报告程度',acceptance='按原冻结维度评分；允许等义表达和不同工具路径',omission_policy='一般实现细节允许省略；原锚点是说明，不要求逐字逐项罗列')
  requirements=[req('subject','总结其主要内容',c['semantic_anchors'][0]),req('central','总结其主要内容',c['semantic_anchors'][1]+'；'+c['semantic_anchors'][2]),req('fidelity','只依据文件中的信息回答，不补充未经文件支持的事实','所有已断言事实由文件或实际工具记录支持；提交答案不等于宣称隐藏评分通过')]
 contract=dict(schema=v.CONTRACT_SCHEMA,task_id=c['id'],user_request=c['request'],kind='task_trial',protocol_error_policy='feedback',execution_identity=identity,requirements=requirements)
 v.freeze_contract(contract,D/'contracts'/phase/(c['id']+'.json'))
v.write_once(D/(phase.upper()+'_CONTRACT_REGISTRATION.json'),{'script_sha256':v.file_digest(Path(__file__)),'original_regression_sha256':v.file_digest(D/'REGRESSION_REGISTRATION.json'),'policy_sha256':v.file_digest(D/'EVALUATION_REGISTRATION.json'),'identity':identity,'contracts':{c['id']:v.file_digest(D/'contracts'/phase/(c['id']+'.json')) for c in cases},'note':'Original rubric and thresholds unchanged; diagnostic sources quote corrected to exact existing request substring for contract API, no semantic criterion added.'})
print('frozen',phase,len(cases))
