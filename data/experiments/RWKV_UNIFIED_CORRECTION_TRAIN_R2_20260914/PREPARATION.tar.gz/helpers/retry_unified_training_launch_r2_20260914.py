from pathlib import Path
import subprocess,json,shlex,hashlib,datetime,shutil,time
R=Path('/home/chase/GitHub/RWKV-LH');D=R/'data/experiments/RWKV_UNIFIED_CORRECTION_TRAIN_R2_20260914/training';remote='/home/chase/GitHub/RWKV-LH-unified-corrections-r1-20260914'
shutil.copyfile(R/'temp/launch_unified_training_r2_20260914.py',D/'LAUNCH_R1_FAILED.py.txt')
(D/'LAUNCH_R1_FAILED.json').write_text(json.dumps({'error':'SSH command string split ExecStopPost property containing spaces: systemd-run tried executable start. No training process or optimizer steps. Original current service restoration attempted successfully; transient GC side unit had been removed on stop, remains paused for evaluation.','fix':'Shell-quote remote argv with shlex.join; no change to training registration/model/dataset.'},indent=2)+'\n')
for attempt in range(30):
 probe=subprocess.run(['ssh','rwkv-8222',"systemctl --user is-active rwkv-lh-native-current.service; curl -fsS http://127.0.0.1:18234/metrics | grep -E '^vllm:num_requests_(running|waiting)'"],capture_output=True,text=True,check=False)
 with (D/'RESTORE_READINESS.jsonl').open('a') as f:f.write(json.dumps({'at':time.time(),'returncode':probe.returncode,'stdout':probe.stdout,'stderr':probe.stderr})+'\n')
 if probe.returncode==0:break
 time.sleep(5)
else:raise RuntimeError('original service not ready after restore; training remains unstarted')
(D/'RETRY_IDLE.txt').write_text(probe.stdout)
lines=[l for l in probe.stdout.splitlines() if l.startswith('vllm:num_requests_')];assert len(lines)>=2 and all(float(l.rsplit(' ',1)[1])==0 for l in lines)
subprocess.run(['ssh','rwkv-8222','systemctl','--user','stop','rwkv-lh-native-current.service'],check=True)
args=['systemd-run','--user','--unit=rwkv-lh-unified-training-r2','--property=RuntimeMaxSec=15100','--property=ExecStopPost=/usr/bin/systemctl --user start rwkv-lh-native-current.service',f'--property=StandardOutput=append:{remote}/training_registration_r2/train.log','--property=StandardError=inherit','bash',remote+'/training_registration_r2/train.sh']
try:subprocess.run(['ssh','rwkv-8222',shlex.join(args)],check=True)
except BaseException:subprocess.run(['ssh','rwkv-8222','systemctl','--user','start','rwkv-lh-native-current.service']);raise
(D/'LAUNCH.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'unit':'rwkv-lh-unified-training-r2','source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'registration_sha256':hashlib.sha256((D/'REGISTRATION.json').read_bytes()).hexdigest(),'expected_steps':342,'gpu':'GPU-1faf7f09-25f4-2515-b707-6e0766aa841d','automatic_restore':'ExecStopPost starts persistent original current service on any training unit termination; transient GC side service paused and must be recreated after evaluation.'},indent=2)+'\n');print('launched')
