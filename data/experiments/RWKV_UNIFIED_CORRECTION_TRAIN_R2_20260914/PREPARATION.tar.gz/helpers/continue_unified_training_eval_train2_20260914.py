from pathlib import Path
import subprocess,json,time,urllib.request,sys
R=Path('/home/chase/GitHub/RWKV-LH');D=R/'data/experiments/RWKV_UNIFIED_CORRECTION_TRAIN_R2_20260914';T=D/'training';remote='/home/chase/GitHub/RWKV-LH-unified-corrections-r1-20260914';start=time.monotonic();last=None

def run(name,*args):
 print('START',name,*args,flush=True);subprocess.run([sys.executable,str(R/'temp'/name),*args],check=True);print('DONE',name,*args,flush=True)
while time.monotonic()-start<15300:
 p=subprocess.run(['scp','-q',f'rwkv-8222:{remote}/training_runs/direct-unified-r2-20260914/RESULT.json',str(T/'PROGRESS.json')],capture_output=True,text=True)
 if p.returncode==0:
  result=json.loads((T/'PROGRESS.json').read_text());key=(result.get('status'),result.get('optimizer_steps',0)//10,result.get('last_event')=='run_finished')
  if key!=last:print(json.dumps({k:result.get(k) for k in ['status','optimizer_steps','last_event','elapsed_seconds','stop_reason','error']}),flush=True);last=key
  if result['status'] not in ('running','candidate'):raise RuntimeError(result)
  if result.get('last_event')=='run_finished':
   assert result['status']=='candidate' and result['serving_loader_verified'] and result['optimizer_steps']==342
   for name in ('RESULT.json','events.jsonl','STATE_PROFILES.json'):subprocess.run(['scp','-q',f'rwkv-8222:{remote}/training_runs/direct-unified-r2-20260914/{name}',str(T/('FINAL_REMOTE_RESULT.json' if name=='RESULT.json' else name))],check=True)
   break
 time.sleep(20)
else:raise TimeoutError('training monitor exhausted')
run('prepare_unified_eval_service_train2_20260914.py')
socket=str(R/'temp/unified_eval_train2_tunnel.sock')
subprocess.run(['ssh','-o','BatchMode=yes','-o','ExitOnForwardFailure=yes','-o','ControlMaster=yes','-o',f'ControlPath={socket}','-o','ControlPersist=no','-fNT','-L','127.0.0.1:29622:127.0.0.1:18248','rwkv-8222'],check=True)
for attempt in range(90):
 try:
  with urllib.request.urlopen('http://127.0.0.1:29622/v1/capabilities',timeout=10) as f:cap=json.load(f)
  assert cap['model']=='rwkv-direct-unified-r2-ctx24576';break
 except (OSError,ValueError):time.sleep(10)
else:raise RuntimeError('evaluation service failed readiness')
run('run_unified_candidate_tasks_train2_20260914.py','freeze')
for phase in ('dev','diagnostic'):run('freeze_unified_task_contracts_train2_20260914.py',phase)
run('run_unified_read_regression_train2_20260914.py','freeze')
for phase in ('dev','diagnostic'):
 run('run_unified_candidate_tasks_train2_20260914.py',phase);run('audit_unified_task_traces_train2_20260914.py',phase);run('review_unified_tasks_train2_20260914.py',phase,'packets')
for arm in ('zero','candidate'):run('run_unified_read_regression_train2_20260914.py',arm)
run('audit_unified_original_read_train2_20260914.py');run('run_unified_coding_tasks_train2_20260914.py');run('audit_unified_coding_traces_train2_20260914.py','coding');run('verify_unified_coding_artifacts_train2_20260914.py')
print('FIXED EXECUTIONS COMPLETE; source-grounded manual semantic review required; no confirmation automatically run',flush=True)
