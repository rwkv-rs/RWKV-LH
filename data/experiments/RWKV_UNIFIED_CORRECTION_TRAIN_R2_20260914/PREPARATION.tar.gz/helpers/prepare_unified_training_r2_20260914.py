from pathlib import Path
import json,hashlib,shutil,subprocess,datetime
R=Path('/home/chase/GitHub/RWKV-LH');D=R/'data/experiments/RWKV_UNIFIED_CORRECTION_TRAIN_R2_20260914';old=R/'data/experiments/RWKV_UNIFIED_CORRECTION_TRAIN_R1_20260914';remote='/home/chase/GitHub/RWKV-LH-unified-corrections-r1-20260914';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
T=D/'training';T.mkdir();(D/'runtime').mkdir();E=D/'evaluation';E.mkdir()
# Only immutable numeric trainer/runtime are reused. Production uses the newer GC source.
files=[]
for pattern in ['rwkv_lh/statetune*.py','rwkv_lh/model_io.py','rwkv_lh/direct_trace_data.py','rwkv_lh/token_budget.py','scripts/run_state_tune.py']:
 for p in R.glob(pattern):
  original=old/'runtime/source'/p.relative_to(R);assert sha(p)==sha(original);files.append({'path':str(p.relative_to(R)),'sha256':sha(p)})
reuse={'numeric_source_manifest_sha256':sha(old/'runtime/PROJECT_SOURCE.json'),'unchanged_training_files':files,'existing_compatibility_result_sha256':sha(old/'training/COMPAT_RESULT.json'),'existing_context_tokens':24576,'new_dataset_max_sequence_tokens':24455,'scope':'Reuse exact unchanged numeric training runtime and its 24576 backward/State-loader proof. No old live session handles reused. Dataset generation used new source-bound generation snapshots; sealed proof/row admission loader is byte-identical. Production evaluation uses GC-fixed source pinned independently; protocol builder remains byte-identical.'}
(T/'RUNTIME_REUSE.json').write_text(json.dumps(reuse,indent=2)+'\n')
shutil.copyfile(R/'data/experiments/RWKV_NATIVE_GC_EMPTY_QUEUE_R1_20260914/deployment/validation/PROJECT_SOURCE.json',D/'runtime/PROJECT_SOURCE.json')
p=json.loads((old/'EVALUATION_REGISTRATION_R2.json').read_text());p.update(round_id=D.name,registered_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),context_tokens=24576,source_manifest_sha256=sha(D/'runtime/PROJECT_SOURCE.json'),dataset_manifest_sha256=sha(R/'data/datasets/rwkv_direct_unified_corrections_v2/manifest.json'))
(D/'EVALUATION_REGISTRATION.json').write_text(json.dumps(p,ensure_ascii=False,indent=2)+'\n');shutil.copyfile(D/'EVALUATION_REGISTRATION.json',E/'EVALUATION_REGISTRATION.json');shutil.copyfile(old/'evaluation/REGRESSION_REGISTRATION.json',E/'REGRESSION_REGISTRATION.json');shutil.copyfile(old/'evaluation/GATE_INTERPRETATION_PRE_RUN.zh-CN.md',E/'GATE_INTERPRETATION_PRE_RUN.zh-CN.md')
reg=json.loads((old/'training/REGISTRATION.json').read_text());reg.update(run_id='direct-unified-r2-20260914');reg['optimizer']['epochs']=6
reg['limits_note']='57 verified rows, 6 epochs = 342 planned State-only steps, zero initialization, GPU0, max400steps/4h/80GiB. Additional edit/test boundaries and longer optimization are combined, not causal attribution. All old task gates remain; no retention based on loss.'
for key,path,dest in [('authorization',D/'AUTHORIZATION.zh-CN.md','AUTHORIZATION.zh-CN.md'),('evaluation_registration',D/'EVALUATION_REGISTRATION.json','EVALUATION_REGISTRATION.json')]:reg[key]={'path':remote+'/training_registration_r2/'+dest,'sha256':sha(path)}
reg['dataset']={'path':remote+'/data/datasets/rwkv_direct_unified_corrections_v2/manifest.json','sha256':sha(R/'data/datasets/rwkv_direct_unified_corrections_v2/manifest.json')}
f=T/'REGISTRATION.json';f.write_text(json.dumps(reg,indent=2)+'\n')
shell=(old/'runtime/validate_r3.sh').read_text().split('exec timeout')[0]+f'exec timeout 15000 /home/chase/GitHub/RWKV-LH/data/runtime/engines/vllm-rwkv-67f0c5996c50/.venv/bin/python -B {remote}/source/scripts/run_state_tune.py train --registration {remote}/training_registration_r2/REGISTRATION.json --registration-sha256 {sha(f)} --output {remote}/training_runs/{reg["run_id"]}\n'
(T/'train.sh').write_text(shell)
subprocess.run(['ssh','rwkv-8222','mkdir','-p',remote+'/training_registration_r2'],check=True)
subprocess.run(['rsync','-a',str(R/'data/datasets/rwkv_direct_unified_corrections_v2'),f'rwkv-8222:{remote}/data/datasets/'],check=True)
subprocess.run(['rsync','-a',str(f),str(T/'train.sh'),str(D/'AUTHORIZATION.zh-CN.md'),str(D/'EVALUATION_REGISTRATION.json'),str(T/'RUNTIME_REUSE.json'),f'rwkv-8222:{remote}/training_registration_r2/'],check=True)
print(json.dumps({'registration_sha256':sha(f),'steps':342,'launch':False}))
