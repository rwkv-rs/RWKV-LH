from pathlib import Path
import json,subprocess,hashlib,urllib.request,datetime
R=Path('/home/chase/GitHub/RWKV-LH');D=R/'data/experiments/RWKV_UNIFIED_CORRECTION_TRAIN_R2_20260914/training';remote='/home/chase/GitHub/RWKV-LH-unified-corrections-r1-20260914'
probe=subprocess.run(['ssh','rwkv-8222',"curl -fsS http://127.0.0.1:18234/metrics | grep -E '^vllm:num_requests_(running|waiting)'; curl -fsS http://127.0.0.1:18247/metrics | grep -E '^vllm:num_requests_(running|waiting)'; nvidia-smi -i 0 --query-gpu=uuid,memory.used,memory.total --format=csv,noheader"],capture_output=True,text=True,check=True)
(D/'BEFORE_SERVICE_PAUSE.txt').write_text(probe.stdout);lines=[l for l in probe.stdout.splitlines() if l.startswith('vllm:num_requests_')];assert len(lines)>=4 and all(float(l.rsplit(' ',1)[1])==0 for l in lines);assert 'GPU-1faf7f09-25f4-2515-b707-6e0766aa841d' in probe.stdout
subprocess.run(['ssh','rwkv-8222','systemctl','--user','stop','rwkv-lh-native-current.service','rwkv-lh-native-gc-r1.service'],check=True)
try:
 subprocess.run(['ssh','rwkv-8222','systemd-run','--user','--unit=rwkv-lh-unified-training-r2','--property=RuntimeMaxSec=15100','--property=ExecStopPost=/usr/bin/systemctl --user start rwkv-lh-native-current.service',f'--property=StandardOutput=append:{remote}/training_registration_r2/train.log','--property=StandardError=inherit','bash',remote+'/training_registration_r2/train.sh'],check=True)
except BaseException:
 subprocess.run(['ssh','rwkv-8222','systemctl','--user','start','rwkv-lh-native-current.service','rwkv-lh-native-gc-r1.service']);raise
(D/'LAUNCH.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'unit':'rwkv-lh-unified-training-r2','source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'registration_sha256':hashlib.sha256((D/'REGISTRATION.json').read_bytes()).hexdigest(),'expected_steps':342,'gpu':'GPU-1faf7f09-25f4-2515-b707-6e0766aa841d','automatic_restore':'ExecStopPost starts original current service on any training unit termination; GC side service remains paused for candidate evaluation and is restored afterward.'},indent=2)+'\n')
print('launched')
