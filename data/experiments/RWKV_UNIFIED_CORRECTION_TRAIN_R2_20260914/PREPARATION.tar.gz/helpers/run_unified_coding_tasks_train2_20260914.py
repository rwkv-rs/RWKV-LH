from pathlib import Path
import sys,json,hashlib,subprocess
from dataclasses import replace
R=Path('/home/chase/GitHub/RWKV-LH');sys.path.insert(0,str(R));D=R/'data/experiments/RWKV_UNIFIED_CORRECTION_TRAIN_R2_20260914/evaluation'
from rwkv_lh.coding_agent import CodingJob,run_coding_job
from rwkv_lh.runtime.settings import get_runtime_settings,load_local_env
from unified_eval_budget_train2_20260914 import reserve
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
reg=json.loads((D/'RUN_REGISTRATION.json').read_text());policy=json.loads((D/'EVALUATION_REGISTRATION.json').read_text());assert all(sha(R/p)==h for p,h in reg['source_pins'].items());assert sha(D/'EVALUATION_REGISTRATION.json')==reg['evaluation_registration_sha256']
assert all(sha(R/'temp'/n)==h for n,h in reg['review_adapter_pins'].items())
subprocess.run([sys.executable,str(R/'temp/freeze_unified_coding_contracts_train2_20260914.py')],check=True)
load_local_env(R/'.env.local');out=D/'coding';out.mkdir();rows=[]
(out/'RUNNER_IDENTITY.json').write_text(json.dumps({'sha256':sha(Path(__file__)),'registered_policy_sha256':sha(D/'EVALUATION_REGISTRATION.json')},indent=2)+'\n')
for repeat in (1,2):
 for case in policy['coding_checks']['jobs']:
  assert all(sha(Path(case['workspace'])/p)==h for p,h in case['source_sha256'].items())
  for arm in (('zero','candidate') if repeat==1 else ('candidate','zero')):
   reserve(case['max_calls'],case['max_seconds']);profile=reg['profiles'][arm]
   settings=replace(get_runtime_settings(),base_url=reg['base_url'],model=reg['model_name'],model_sha256=reg['model_sha256'],max_model_len=24576,tool_disclosure_mode='full',return_token_ids=True,state_transport='native_required',state_profile_id=profile['id'],state_profile_sha256=profile['sha256'],read_timeout_seconds=300,default_temperature=policy['sampling']['temperature'],default_top_p=policy['sampling']['top_p'],default_top_k=policy['sampling']['top_k'],default_presence_penalty=policy['sampling']['presence_penalty'],default_frequency_penalty=policy['sampling']['frequency_penalty'],default_penalty_decay=policy['sampling']['penalty_decay'])
   rid=f"{case['task_id']}-{arm}-r{repeat}";dest=out/rid
   result=run_coding_job(CodingJob(rid,case['request'],case['workspace'],str(dest),case['max_calls'],case['max_seconds']),settings=settings)
   rows.append({'id':rid,'arm':arm,'repeat':repeat,'result':result});(out/'RESULTS.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n');print(rid,result['termination'],result['generation_started'],flush=True)
