"""External public-test execution; results never enter model inputs or change answers."""
from pathlib import Path
import json,hashlib,subprocess,shutil,sys,time
R=Path('/home/chase/GitHub/RWKV-LH');D=R/'data/experiments/RWKV_UNIFIED_CORRECTION_TRAIN_R2_20260914/evaluation';policy=json.loads((D/'EVALUATION_REGISTRATION.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();results=[]
for item in json.loads((D/'coding/RESULTS.json').read_text()):
 root=D/'coding'/item['id'];case=next(c for c in policy['coding_checks']['jobs'] if item['id'].startswith(c['task_id']+'-'));workspace=root/'workspace'
 row={'id':item['id'],'assistance':'rwkv_independent','termination':item['result']['termination'],'changed_files':item['result'].get('changed_files'),'public_test_unchanged':None,'external_test':None}
 if case['task_id']=='fix-query':
  name='test_query_limit.py';row['public_test_unchanged']=(workspace/name).is_file() and sha(workspace/name)==case['source_sha256'][name]
  dest=root/'external_validation';dest.mkdir();copy=dest/'workspace';shutil.copytree(workspace,copy,symlinks=True)
  before=sha(workspace/name) if (workspace/name).is_file() else None;started=time.monotonic()
  try:
   p=subprocess.run([sys.executable,'-B',name],cwd=copy,text=True,capture_output=True,timeout=120)
   row['external_test']={'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'seconds':time.monotonic()-started,'command':[sys.executable,'-B',name],'source_test_sha256':case['source_sha256'][name]}
  except subprocess.TimeoutExpired:row['external_test']={'exit_code':None,'termination':'timeout','seconds':time.monotonic()-started}
  assert before==(sha(workspace/name) if (workspace/name).is_file() else None)
  (dest/'RESULT.json').write_text(json.dumps(row['external_test'],ensure_ascii=False,indent=2)+'\n')
 elif case['task_id']=='run-recursive':row['source_files_unchanged']=all((workspace/p).is_file() and sha(workspace/p)==h for p,h in case['source_sha256'].items())
 (root/'ARTIFACT_CHECK.json').write_text(json.dumps(row,ensure_ascii=False,indent=2)+'\n');results.append(row)
(D/'coding/ARTIFACT_CHECKS.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n');print(json.dumps(results,ensure_ascii=False,indent=2))
