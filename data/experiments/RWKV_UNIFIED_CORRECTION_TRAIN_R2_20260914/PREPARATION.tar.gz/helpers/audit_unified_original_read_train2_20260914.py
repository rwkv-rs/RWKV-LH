"""Audit both profiles' original single-read inputs and real observation handoff."""
from pathlib import Path
import json,sys,hashlib
R=Path('/home/chase/GitHub/RWKV-LH');sys.path.insert(0,str(R));D=R/'data/experiments/RWKV_UNIFIED_CORRECTION_TRAIN_R2_20260914/evaluation'
from rwkv_lh.schema import RunState
from rwkv_lh.model import LongHorizonModel
from rwkv_lh.model_session import ModelSession
from rwkv_lh.runtime.settings import RuntimeSettings
from rwkv_lh.harness import ActionHarness
from rwkv_lh.model_io import render_bootstrap,render_event_append
from rwkv_lh.token_budget import tokenizer
rows=[]
for arm in ('zero','candidate'):
 root=D/('read_'+arm);reg=json.loads((root/'REGISTRATION.json').read_text());profile=reg['profile']
 for p in sorted((root/'runs').iterdir()):
  result=json.loads((p/'RESULT.json').read_text());s=RunState.from_dict(json.loads((p/'state_snapshot.json').read_text()));events=[json.loads(l) for l in (p/'model_trace.jsonl').read_text().splitlines()];gens=[e for e in events if e['type']=='model_session_generation_returned'];starts={e['request_id']:e for e in events if e['type']=='model_session_generation_started'}
  model=LongHorizonModel(ModelSession(client=object(),settings=RuntimeSettings(base_url='http://unused.invalid',api_key='',model='audit',tool_disclosure_mode='full')),harness=ActionHarness())
  initial=RunState(run_id=s.run_id,goal=model.create_literal_goal(s.goal.request,str(p/'workspace'),constraints=s.goal.constraints,runtime_policy=s.goal.runtime_policy));bootstrap=render_bootstrap(model.direct_definitions(),model._assignment(initial,recent_limit=None));inputs=[]
  for e in gens:
   raw=e['raw_generation'];cp=s.model_states[starts[e['request_id']]['input_checkpoint_id']];assert cp.parent_checkpoint_id is None and cp.transcript==bootstrap
   assert raw['prompt_token_ids']==[0]+tokenizer().encode(bootstrap) and raw['input_bos_token_count']==1
   assert starts[e['request_id']]['input_digest']==cp.native_state_digest
   inputs.append({'request_id':e['request_id'],'input_tokens':len(raw['prompt_token_ids']),'output_tokens':len(raw['raw_token_ids']),'input_sha256':hashlib.sha256(bootstrap.encode()).hexdigest(),'input_checkpoint':cp.checkpoint_id,'candidate_checkpoint':e['candidate_checkpoint_id'],'finish_reason':raw['finish_reason']})
   (p/'actual_input.txt').write_text(bootstrap)
  for cp in s.model_states.values():
   assert cp.state_profile_id==profile['id'] and cp.state_profile_sha256==profile['sha256']
   assert cp.native_state_metadata['model_sha256']=='559371f5b9aef13189ae54b345ac096af4ad2b689996c05d89de687612b3ae65'
   if cp.parent_checkpoint_id:assert cp.native_state_metadata['cache_binding']['parent_state_digest']==s.model_states[cp.parent_checkpoint_id].native_state_digest
  handoff=result.get('observation_handoff')
  if handoff:
   child=s.model_states[handoff['child_checkpoint_id']];parent=s.model_states[handoff['parent_checkpoint_id']];eid=handoff['event_id'];event=s.model_events[eid]
   assert child.parent_checkpoint_id==parent.checkpoint_id and set(child.event_ids)-set(parent.event_ids)=={eid}
   assert child.transcript==render_event_append(event,previous_transcript=parent.transcript)
  rows.append({'arm':arm,'id':p.name,'case':result['case'],'repeat':result['repeat'],'diagnostic_pass':result['pass'],'tool_success':result['tool_success'],'protocol_error':result['protocol_error'],'infrastructure_error':result['infrastructure_error'],'inputs':inputs,'handoff':handoff,'mechanical_audit':True,'note':'single-operation task ends after real observation append; no subsequent answer generation required; declared parent/profile audit, not new tensor equivalence proof'})
(D/'READ_MECHANICAL_AUDIT.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n');assert len(rows)==48;print('audited',len(rows),'original read runs')
