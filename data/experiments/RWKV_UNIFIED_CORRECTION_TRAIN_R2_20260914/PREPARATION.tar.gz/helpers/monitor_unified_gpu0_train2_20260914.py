from pathlib import Path
import subprocess,time,json,datetime
D=Path('/home/chase/GitHub/RWKV-LH/data/experiments/RWKV_UNIFIED_CORRECTION_TRAIN_R2_20260914');start=time.monotonic()
while time.monotonic()-start<36000 and not (D/'STOP_TELEMETRY').exists():
 before=time.time();p=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','rwkv-8222','nvidia-smi','-i','0','--query-gpu=uuid,memory.used,utilization.gpu,power.draw,temperature.gpu','--format=csv,noheader,nounits'],capture_output=True,text=True,timeout=20)
 row={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'epoch':before,'query_seconds':time.time()-before,'returncode':p.returncode,'raw':p.stdout.strip(),'error':p.stderr.strip()}
 if p.returncode==0:
  fields=[v.strip() for v in p.stdout.split(',')];assert fields[0]=='GPU-1faf7f09-25f4-2515-b707-6e0766aa841d';row['gpu_uuid']=fields[0]
  for k,v in zip(['memory_mib','utilization_percent','power_w','temperature_c'],fields[1:]):
   try:row[k]=float(v)
   except ValueError:row[k]=None
 with (D/'GPU0_TELEMETRY.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
 time.sleep(30)
