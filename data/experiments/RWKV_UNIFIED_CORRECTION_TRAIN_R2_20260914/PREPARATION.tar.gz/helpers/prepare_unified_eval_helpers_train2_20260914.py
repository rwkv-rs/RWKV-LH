from pathlib import Path
R=Path('/home/chase/GitHub/RWKV-LH')
names=['unified_eval_budget','run_unified_candidate_tasks','freeze_unified_task_contracts','audit_unified_task_traces','review_unified_tasks','unified_observed_coverage','run_unified_read_regression','freeze_unified_coding_contracts','audit_unified_coding_traces','verify_unified_coding_artifacts','run_unified_coding_tasks','audit_unified_original_read']
for name in names:
 old=R/'temp'/(name+('_r2_20260914.py' if name=='audit_unified_coding_traces' else '_r1_20260914.py'))
 s=old.read_text().replace('RWKV_UNIFIED_CORRECTION_TRAIN_R1_20260914','RWKV_UNIFIED_CORRECTION_TRAIN_R2_20260914').replace('29620','29622').replace('rwkv-direct-unified-r1-ctx24576','rwkv-direct-unified-r2-ctx24576')
 for n in names:s=s.replace(n+'_r1_20260914',n+'_train2_20260914')
 target=R/'temp'/(name+'_train2_20260914.py');assert not target.exists();target.write_text(s)
s=(R/'temp/monitor_unified_gpu0_r1_20260914.py').read_text().replace('RWKV_UNIFIED_CORRECTION_TRAIN_R1_20260914','RWKV_UNIFIED_CORRECTION_TRAIN_R2_20260914');(R/'temp/monitor_unified_gpu0_train2_20260914.py').write_text(s)
