#!/bin/bash
set -euo pipefail
export PYTHONPATH=/home/chase/GitHub/RWKV-LH-unified-corrections-r1-20260914/source:/home/chase/GitHub/RWKV-LH-full-trace-runtime-r2-20260911/engine
export PYTHONDONTWRITEBYTECODE=1
export OMP_NUM_THREADS=4
export VLLM_RWKV7_WKV_MODE=fp32io16
export CUDA_DEVICE_ORDER=PCI_BUS_ID
export CUDA_VISIBLE_DEVICES=0
exec timeout 15000 /home/chase/GitHub/RWKV-LH/data/runtime/engines/vllm-rwkv-67f0c5996c50/.venv/bin/python -B /home/chase/GitHub/RWKV-LH-unified-corrections-r1-20260914/source/scripts/run_state_tune.py train --registration /home/chase/GitHub/RWKV-LH-unified-corrections-r1-20260914/training_registration_r2/REGISTRATION.json --registration-sha256 787692fdeb80b7b3affd967e651e81048763e302a41034b4f7a52f693eb63f78 --output /home/chase/GitHub/RWKV-LH-unified-corrections-r1-20260914/training_runs/direct-unified-r2-20260914
