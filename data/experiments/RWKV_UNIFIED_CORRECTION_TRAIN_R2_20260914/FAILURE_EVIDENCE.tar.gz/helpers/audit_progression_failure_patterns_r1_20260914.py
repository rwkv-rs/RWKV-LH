from pathlib import Path
import json,hashlib,sys
R=Path('/home/chase/GitHub/RWKV-LH');sys.path.insert(0,str(R))
from rwkv_lh.direct_trace_data import replay_run
from rwkv_lh import model_io
D=R/'data/experiments/RWKV_GENERATION_BOUNDARY_COLLECTION_R3_20260914';out=[]
for item in json.loads((D/'RESULTS.json').read_text()):
 root=D/'runs'/item['id']/'execution';result=item['result'];replay=list(replay_run(root,'559371f5b9aef13189ae54b345ac096af4ad2b689996c05d89de687612b3ae65').values());bad=[]
 for i,r in enumerate(replay):
  raw=r['raw_generation']['raw_output']
  try:model_io.parse_model_command(raw)
  except Exception as exc:
   nxt=replay[i+1] if i+1<len(replay) else None;valid=False
   if nxt:
    try:model_io.parse_model_command(nxt['raw_generation']['raw_output']);valid=True
    except Exception:pass
   bad.append({'index':i,'request_id':r['request_id'],'input_sha256':hashlib.sha256(r['input_text'].encode()).hexdigest(),'raw_output':raw,'error':str(exc),'next_generation_legal':valid,'next_request_id':nxt['request_id'] if nxt else None})
 out.append({'task':item['id'],'termination':result['termination_reason'],'wall_allowance_exceeded':result['wall_allowance_exceeded'],'max_actual_input_tokens':max(len(r['input_token_ids']) for r in replay),'raw_protocol_errors':bad,'missing_path_calls':[{'request_id':a['request_id'],'arguments':a['arguments'],'error':a['result'].get('error')} for a in result['actions'] if not a['result']['success']],'actual_action_types':list(dict.fromkeys(a['action_type'] for a in result['actions'])),'observed_read_complete':[{'path':a['arguments']['path'],'complete':a['result'].get('metadata',{}).get('complete'),'eof':a['result'].get('metadata',{}).get('eof')} for a in result['actions'] if a['action_type']=='read_file' and a['result']['success']]})
p=R/'data/experiments/RWKV_UNIFIED_CORRECTION_TRAIN_R2_20260914/PRETRAIN_FAILURE_PATTERN_AUDIT.json';assert not p.exists();p.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps([{'task':x['task'],'max_input':x['max_actual_input_tokens'],'protocol_errors':len(x['raw_protocol_errors']),'recoveries':sum(a['next_generation_legal'] for a in x['raw_protocol_errors']),'failed_actions':len(x['missing_path_calls'])} for x in out],indent=2))
