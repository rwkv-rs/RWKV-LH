from pathlib import Path
import json,hashlib,random,subprocess
R=Path('/home/chase/GitHub/RWKV-LH');D=R/'data/experiments/RWKV_UNIFIED_CORRECTION_TRAIN_R2_20260914';T=D/'training';remote='/home/chase/GitHub/RWKV-LH-unified-corrections-r1-20260914'
for name in ('RESULT.json','events.jsonl'):
 subprocess.run(['scp','-q',f'rwkv-8222:{remote}/training_runs/direct-unified-r2-20260914/{name}',str(T/('FINAL_REMOTE_RESULT.json' if name=='RESULT.json' else name))],check=True)
subprocess.run(['scp','-q',f'rwkv-8222:{remote}/training_registration_r2/train.log',str(T/'train.log')],check=True)
reg=json.loads((T/'REGISTRATION.json').read_text());result=json.loads((T/'FINAL_REMOTE_RESULT.json').read_text());rows=list(map(json.loads,(R/'data/datasets/rwkv_direct_unified_corrections_v2/train.jsonl').read_text().splitlines()));rng=random.Random(reg['optimizer']['seed']);order=[]
for epoch in range(reg['optimizer']['epochs']):
 indices=list(range(len(rows)));rng.shuffle(indices);order.extend((epoch+1,rows[i]) for i in indices)
success=[r for r in map(json.loads,(T/'events.jsonl').read_text().splitlines()) if r['event']=='optimizer_step_completed'];tokens=0
for event,(epoch,row) in zip(success,order):
 tokens+=len(row['target_token_ids']);assert tokens==event['target_tokens_seen'] and epoch==event['epoch']
epoch,row=order[result['optimizer_steps']];assert result['samples_seen']==result['optimizer_steps']+1 and result['target_tokens_seen']==tokens+len(row['target_token_ids'])
record={'status':'failed_no_keep','actual_optimizer_steps':result['optimizer_steps'],'failed_sample_ordinal':result['samples_seen'],'epoch':epoch,'sample_id':row['sample_id'],'authority':row['label_authority'],'input_tokens':len(row['input_token_ids']),'target_tokens':len(row['target_token_ids']),'source_id':row['source_id'],'error':result['error'],'peak_allocated_bytes':result['peak_allocated_bytes'],'budget_bytes':reg['optimizer']['max_allocated_bytes'],'first_epoch_completed':result['epochs_completed'],'ordering_verified_by_cumulative_target_tokens':True,'scope':'Optimizer finite-gradient guard rejected sample before update; whether gradient missing or nonfinite and precise originating layer are not in original log. Not a task-accuracy measurement. Last successful loss field is not failed-sample loss.'}
(D/'TRAINING_FAILURE_AUDIT.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2))
p=subprocess.run(['ssh','rwkv-8222','systemctl','--user','show','rwkv-lh-native-current.service','-p','ActiveState','-p','SubState','-p','MainPID'],text=True,capture_output=True);(T/'RESTORE_SERVICE_STATUS.txt').write_text(p.stdout+p.stderr)
(D/'STOP_TELEMETRY').touch()
