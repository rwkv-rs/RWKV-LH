from __future__ import annotations
import hashlib
from pathlib import Path

SUFFIXES = frozenset({'.md', '.txt'})

def normalize(value):
    return value.lower()

def collect(root):
    root = Path(root)
    rows = []
    for path in sorted(root.rglob('*')):
        if path.is_symlink():
            continue
        if not path.is_file():
            continue
        if path.suffix.lower() not in SUFFIXES:
            continue
        content = path.read_bytes()
        text = content.decode('utf-8', errors='replace')
        rows.append({'path': path.relative_to(root).as_posix(), 'content': text,
                     'digest': hashlib.sha256(content).hexdigest(),
                     'search': normalize(text), 'mtime': path.stat().st_mtime_ns})
    return rows
