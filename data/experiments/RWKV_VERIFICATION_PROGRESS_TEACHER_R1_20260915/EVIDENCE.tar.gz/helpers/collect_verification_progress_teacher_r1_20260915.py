from pathlib import Path
from dataclasses import replace
import sys,json,hashlib,time,subprocess
R=Path('/home/chase/GitHub/RWKV-LH');sys.path.insert(0,str(R))
from rwkv_lh.direct_trace_data import replay_run
from rwkv_lh.strong_session import StrongCompletion
from rwkv_lh.supervisor_openai import SupervisorAPISettings
from rwkv_lh.runtime.settings import load_local_env
from rwkv_lh import model_io
from rwkv_lh.usage_accounting import audit_run_usage
D=R/'data/experiments/RWKV_VERIFICATION_PROGRESS_TEACHER_R1_20260915';D.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
load_local_env(R/'.env.local')
settings=replace(SupervisorAPISettings.from_env(),retry_attempts=1,semantic_repair_attempts=0,fallback_models=(),plan_cache_enabled=False,planner_request_options={'thinking':{'type':'disabled'}},read_timeout_seconds=120)
sources=[]
for repeat,selected in (('migration-repeat-backup','CP-8a04eb72069f4e2d'),('index-recursive','CP-8b369958cf904af7')):
 root=R/f'data/experiments/RWKV_CORRECTED_ARTIFACT_VERIFICATION_R1_20260914/runs/{repeat}/execution'
 replay=replay_run(root,'559371f5b9aef13189ae54b345ac096af4ad2b689996c05d89de687612b3ae65')
 cp,actual=selected,replay[selected]
 original=model_io.parse_model_command(actual['raw_generation']['raw_output'])
 assert original.name in ('read_file','list_directory')
 sources.append({'id':repeat,'run_root':str(root),'checkpoint':cp,'actual':actual,'original_tool':original.name,'original_parameters':original.arguments,'source_files':{str(p.relative_to(root)):sha(p) for p in root.rglob('*') if p.is_file() and (p.name in ('RESULT.json','model_trace.jsonl','state_snapshot.json','PARENT_TRACE.jsonl','call.json') or 'before' in p.parts or 'generation_snapshots' in p.parts)}})
save(D/'REGISTRATION.json',{'round':D.name,'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'source_pins':{str(p.relative_to(R)):sha(p) for p in (R/'rwkv_lh').rglob('*.py')},'script_sha256':sha(Path(__file__)),'settings':settings.public_dict(),'budget':{'generation_calls':2,'review_calls':4,'max_output_tokens':4096,'training_steps':0},'selection':'Last returned generation of each of two existing zero-State verification tasks on strong-prepared artifacts, selected before teacher calls. Original exact input only, no future observations, external checker, expected command or reference patch. Corrected artifact is declared in user goal; teacher must not claim its creation as RWKV work. Verification progress is separate from repair. New targets must fit original RWKV output budget as well as total context. No retried sampling to force tests; read/list choices remain legitimate and recorded. Existing two MAINT/train project families, not new independent projects.','gate':'Candidate chooses a legal tool with grounded parameters; if edit, execute unchanged and verify existing public tests red-to-green; if read or test, report actual effect and do not force editing. No automatic parameter/answer repair.','sources':sources})
results=[]
for source in sources:
 folder=D/'runs'/source['id'];folder.mkdir(parents=True)
 save(folder/'INPUT.json',source['actual'])
 completion=StrongCompletion(settings,folder,1);start=time.monotonic()
 record={'id':source['id'],'source_checkpoint':source['checkpoint'],'status':'started'}
 try:
  output=completion.text_completion(source['actual']['input_text'],max_tokens=4096)
  record.update(raw_output=output.content,finish_reason=output.finish_reason,model=output.model,response_id=output.response_id)
  command=model_io.parse_model_command(output.content)
  json.loads(output.content)
  record.update(status='candidate',tool=command.name,arguments=command.arguments)
 except Exception as exc:record.update(status='error',error=type(exc).__name__+': '+str(exc))
 finally:completion.client.close()
 record['elapsed_seconds']=time.monotonic()-start;save(folder/'CANDIDATE.json',record);results.append(record)
 print(source['id'],record['status'],record.get('tool'),flush=True)
save(D/'RESULTS.json',results);save(D/'USAGE.json',audit_run_usage(D))
