"""Bounded diagnostic of existing production direct actor; no generated answers or tool repairs."""
from pathlib import Path
import sys,json,hashlib,shutil,time,traceback,subprocess,urllib.request
from dataclasses import replace
R=Path('/home/chase/GitHub/RWKV-LH');sys.path.insert(0,str(R))
D=R/'data/experiments/RWKV_READ_SUMMARY_BASELINE_R5_20260912'
from rwkv_lh.model import LongHorizonModel
from rwkv_lh.model_session import create_model_session
from rwkv_lh.runtime.settings import get_runtime_settings,load_local_env
from rwkv_lh.harness import ActionHarness
from rwkv_lh.controller import LongHorizonController
from rwkv_lh.store import LongHorizonStore
from rwkv_lh.schema import RunStatus
load_local_env(R/'.env.local')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def inventory(w):return {str(p.relative_to(w)):sha(p) for p in sorted(w.rglob('*')) if p.is_file()}
def freeze():
 old=json.loads((R/'data/experiments/RWKV_READ_PARAMETER_DESCRIPTION_R4_20260912/REGISTRATION.json').read_text())
 cases=[]
 facts=[
 ['这是会议室/设备预约服务的需求合同，要求Python标准库、SQLite持久化HTTP JSON服务，不是已实现功能的证明。','按资源预约，整数UTC分钟、半开区间；同资源confirmed区间不重叠，相接允许。','支持创建、列表/查询和幂等取消，取消释放时段；非法或冲突请求不得改变预约。','并发冲突判断和写入必须原子；重启保留数据和规则。','说明server.py的db/host/port启动参数；公开验证仅健康检查，仍需业务验证。'],
 ['这是SQLite HTTP库存订单服务需求，目标避免重试重复扣减和多行部分扣减，并非实现完成证明。','支持设置/查询SKU库存与创建/查询订单，库存非负整数、数量正整数。','订单要求Idempotency-Key；重复SKU合并并排序，相同key与规范化请求返回同单且不重复扣减，不同请求冲突。','缺SKU或库存不足时整体无写入、不占key，可更正重试。','库存判断、扣减、订单/key登记必须原子，并发不超卖；重启持久，公开健康检查不证明交易正确。'],
 ['这是Python标准库的线程HTTP服务初始入口，README合同尚待完成。','GET /health返回200和JSON ok=true，其他GET返回501和not_implemented。','JSON响应设置Content-Type与Content-Length后写入响应体。','命令行db必填、host默认127.0.0.1、port为必填整数，然后serve_forever；db只解析，代码未使用数据库。'],
 ['这是仅做健康检查的Python冒烟脚本，不验证预约/订单或事务行为。','从命令行HOST和PORT建立HTTP连接，超时5秒，GET /health。','断言HTTP200且JSON ok严格为True，然后关闭连接并打印成功及仍需事务测试提示。']]
 for i,c in enumerate(old['cases'][:4]):
  c=dict(c);assert inventory(R/c['workspace_source'])==c['workspace_sha256']
  text=(R/c['workspace_source']/c['path']).read_text();assert 0<len(text.encode())<4096
  c['request']=f"阅读指定文件 {c['path']}，总结其主要内容。只依据文件中的信息回答，不补充未经文件支持的事实。"
  c['key_facts_external_only']=facts[i];c['file_bytes']=len(text.encode());cases.append(c)
 pins={str(p.relative_to(R)):sha(p) for p in sorted((R/'rwkv_lh').rglob('*')) if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc'}
 pins[str(Path(__file__).relative_to(R))]=sha(Path(__file__))
 pins['temp/run_single_read_diagnostic_r1_20260912.py']=sha(R/'temp/run_single_read_diagnostic_r1_20260912.py')
 reg={'round':D.name,'frozen_at_epoch':time.time(),'cases':cases,'repeats':2,'source_pins':pins,'local_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'model_sha256':'559371f5b9aef13189ae54b345ac096af4ad2b689996c05d89de687612b3ae65','sampling':LongHorizonModel._SAMPLING.to_dict(),'state':'native_required fresh zero per case/repeat; zero SHA; actual action observation appended exactly once; next_command resumes that child; no terminal_answer forcing','max_output_tokens':1800,'max_decisions_per_case':4,'wall_seconds_batch':3600,'read_description':'unchanged retained R4','menu':'production full menu, no eligible_operations, no planner/coordinator/selector; out-of-scope tools terminate failure without execution or replacement; repeated reads execute within budget and count failure','stop':'first valid final_answer, protocol/input-budget error, out-of-scope operation or 4 decision calls; infrastructure errors stop batch; no semantic retry','summary_rubric':'External evidence-based semantic review, allow paraphrase and grouping. All listed key facts must be covered; missing any is important omission. Any unsupported concrete assertion or contradiction fails. Explicit requirements must not become claims of completed implementation or testing. Do not require minor HTTP codes/argument syntax beyond listed facts. No string-match reference answer. For each key fact record answer quote/evidence and judgement; review all remaining assertions against entire file. Rubric never supplied to model. No answer => summary failure.','reading_score':'Exactly one accepted read_file resolving to named target, start 0, real successful complete output equals entire UTF-8 file, unchanged workspace. Partial or repeated reads fail even if later summary good. Declared default normalization only.','handoff_score':'observation result contains complete content; event injected exactly once; committed read -> observation child -> next generation parent identities and digest agree; exact full-context token reconstruction required','task_score':'reading and handoff and summary all pass; final_answer required, zero protocol/out-of-scope errors/repeats','false_completion':'Any final_answer without passing reading/handoff/summary is erroneous completion, even if it does not literally say done; also flag unsupported claims of reading/testing within answer. Resource stop never completed.','gate':'Both registered repeats 4/4 task pass, zero illegal parameters and false completion; unchanged R4 original 7 cases x3 plus independent R2 missing x3 all pass. Only fixed-group stability; no automatic escalation.','regression_reference':'R4 candidate primary21/21 and supplement3/3; rerun unchanged R1 runner/scorer and identical8 cases,3 repeats; separate report, no summary scoring or pooling with historical R1/R2','source_type':'controlled reduction of already authorized R5 actual workspaces; no new dataset version or training data','max_generation_budget':56,'training':False,'github_updates':False}
 assert not (D/'REGISTRATION.json').exists();save(D/'REGISTRATION.json',reg)
 save(D/'PREEXISTING_CHANGES.json',{'files':{p:sha(R/p) for p in subprocess.check_output(['git','diff','--name-only'],cwd=R,text=True).splitlines()}})
 (D/'SOURCE_MANIFEST.json').write_text(json.dumps(pins,indent=2)+'\n')
 rd=D/'read_regression';rd.mkdir();old['source_pins']=pins;save(rd/'REGISTRATION.json',old)
 print('FROZEN',sha(D/'REGISTRATION.json'),flush=True)
def run():
 reg=json.loads((D/'REGISTRATION.json').read_text());assert all(sha(R/p)==h for p,h in reg['source_pins'].items())
 settings=replace(get_runtime_settings(),tool_disclosure_mode='full',return_token_ids=True,state_transport='native_required',state_profile_id='zero',state_profile_sha256='0'*64,read_timeout_seconds=180)
 assert settings.model_sha256==reg['model_sha256'];results=[];start=time.time()
 for repeat in range(1,reg['repeats']+1):
  for c in reg['cases']:
   assert time.time()-start<reg['wall_seconds_batch']
   out=D/'runs'/f"{c['id']}-r{repeat}";out.mkdir(parents=True,exist_ok=False)
   source=R/c['workspace_source'];assert inventory(source)==c['workspace_sha256'];shutil.copytree(source,out/'workspace');before=inventory(out/'workspace')
   def audit(e):
    with (out/'model_trace.jsonl').open('a') as f:f.write(json.dumps(dict(e),ensure_ascii=False)+'\n')
   result={'case':c['id'],'repeat':repeat,'decisions':[],'actions':[],'handoffs':[],'final_output':None,'termination':'decision_budget_exhausted','protocol_error':None,'infrastructure_error':None}
   state=None;t=time.time()
   try:
    model=LongHorizonModel(create_model_session(settings=settings,audit_hook=audit),harness=ActionHarness())
    store=LongHorizonStore(out/'state');controller=LongHorizonController(store,model=model,harness=model.harness)
    state=store.create_run(model.create_literal_goal(c['request'],str(out/'workspace')),run_id=out.name);save(out/'goal.json',state.goal.to_dict())
    for n in range(reg['max_decisions_per_case']):
     previous=state.lane_head('executor')
     decision=model.next_command(state,controller._persist_callback,max_output_tokens=reg['max_output_tokens'])
     result['decisions'].append({'previous_head':previous,'committed_checkpoint':decision.checkpoint.checkpoint_id,'wire_command':{'name':decision.wire_command.name,'arguments':dict(decision.wire_command.arguments)},'command':{'name':decision.command.name,'arguments':dict(decision.command.arguments)}})
     if decision.wire_command.name=='final_answer':
      result['final_output']=str(decision.wire_command.arguments['text']);result['termination']='final_answer'
      state.final_output=result['final_output'];state.final_decision_id=decision.decision.decision_id;state.status=RunStatus.COMPLETED
      controller._persist(state,'run_completed',{'final_output':state.final_output,'output_source':'rwkv_explicit_final_answer_text','controller_rewritten':False})
      break
     if decision.command.name!='read_file':result['termination']='out_of_scope_tool';break
     action=controller._execute_decision(state,decision);result['actions'].append(action.to_dict())
     event=controller._action_observation_event(state,action);parent=state.lane_head('executor');child=model.append_action_observation(state,controller._persist_callback,event)
     save(out/f'observation_{n+1}.json',event.to_dict())
     result['handoffs'].append({'parent':parent,'child':child.checkpoint_id,'child_parent':child.parent_checkpoint_id,'event_id':event.event_id,'child_event_occurrences':child.event_ids.count(event.event_id),'parent_digest':state.model_states[parent].native_state_digest,'child_digest':child.native_state_digest})
   except Exception as e:
    result.update(error_type=type(e).__name__,error=str(e),traceback=traceback.format_exc(),termination=type(e).__name__)
    protocol=type(e).__name__ in ['ModelProtocolError','ModelIOError','InputBudgetError']
    result['protocol_error' if protocol else 'infrastructure_error']=type(e).__name__
   finally:
    if state is not None:save(out/'state_snapshot.json',state.to_dict())
    result['workspace_unchanged']=inventory(out/'workspace')==before;result['elapsed_seconds']=time.time()-t
    save(out/'RESULT.json',result);results.append(result);save(D/'RESULTS.json',results)
    print(out.name,result['termination'],'reads',len(result['actions']),'summary',result['final_output'],flush=True)
   if result['infrastructure_error']:return
if __name__=='__main__':
 if sys.argv[1]=='freeze':freeze()
 elif sys.argv[1]=='run':run()
 elif sys.argv[1]=='regression':
  import run_single_read_diagnostic_r1_20260912 as old
  old.D=D/'read_regression';old.run()
