"""Real trace regression for diagnostic accounting, not a model capability test."""
from pathlib import Path
import subprocess,json
R=Path('/home/chase/GitHub/RWKV-LH');D=R/'data/experiments/RWKV_READ_SUMMARY_BASELINE_R5_20260912'
def test_actual_observation_packet_and_native_stop_tokens():
 subprocess.run([str(R/'.venv/bin/python'),str(R/'temp/audit_read_summary_r5_20260912.py')],check=True)
 rows=json.loads((D/'MECHANICAL_AUDIT.json').read_text());r=next(r for r in rows if r['run']=='full_text-1-r1')
 assert r['handoffs'][0]['full_output_in_projection']
 assert all(c['input_text_exact'] for c in r['calls'])
 assert r['handoff_pass']
