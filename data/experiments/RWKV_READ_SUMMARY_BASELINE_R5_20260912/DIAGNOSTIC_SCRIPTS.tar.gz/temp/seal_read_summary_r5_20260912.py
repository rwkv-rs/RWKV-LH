from pathlib import Path
import json,hashlib,tarfile,subprocess
R=Path('/home/chase/GitHub/RWKV-LH');D=R/'data/experiments/RWKV_READ_SUMMARY_BASELINE_R5_20260912'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
s=json.loads((D/'SUMMARY.json').read_text());assert s['gate']['complete'];assert s['source_pins_unchanged'] and s['preexisting_unchanged'];assert s['components']['exact_input_calls']==16;assert s['regression_tokens']['input_exact']==24
assert '1514 passed' in (D/'PYTEST_FULL.log').read_text() and 'skipped' not in (D/'PYTEST_FULL.log').read_text()
script_names=['run_read_summary_baseline_r5_20260912.py','verify_read_summary_server_r5_20260912.py','audit_read_summary_r5_20260912.py','test_read_summary_audit_r5_20260912.py','record_read_summary_inspection_r5_20260912.py','review_read_summary_r5_20260912.py','summarize_read_summary_r5_20260912.py','write_read_summary_report_r5_20260912.py','seal_read_summary_r5_20260912.py']
manifest={f'temp/{n}':sha(R/'temp'/n) for n in script_names};save(D/'DIAGNOSTIC_SOURCE_MANIFEST.json',manifest)
with tarfile.open(D/'DIAGNOSTIC_SCRIPTS.tar.gz','w:gz') as t:
 for p in manifest:t.add(R/p,arcname=p)
transport=[]
for p in list((D/'runs').glob('*/model_trace.jsonl'))+list((D/'read_regression/runs').glob('*/model_trace.jsonl')):
 for l in p.read_text().splitlines():
  e=json.loads(l)
  if 'error' in e['type'] or e['type']=='native_request_resubmitted':transport.append({'trace':str(p.relative_to(D)),'event':e})
save(D/'TRANSPORT_EVENTS.json',transport)
with tarfile.open(D/'RAW_EVIDENCE.tar.gz','w:gz') as t:
 for name in ['runs','read_regression','RUN.log','READ_REGRESSION.log']:
  t.add(D/name,arcname=name)
report_sha=sha(D/'REPORT.zh-CN.md')
handoff=R/'docs/HANDOFF.zh-CN.md';text=handoff.read_text();assert text.startswith('# 当前交接\n')
entry=f'''\n## 2026-09-12 读取→总结 R5：闭环成立，固定质量门未通过（当前）\n\n本轮是明确路径短文件诊断，不是项目级Strict。4份既有短文件×2遍，任务合格0/8（各0/4）；模型final_answer完成8/8但均未达冻结覆盖门，mutation0，终止全部final_answer。读取完整8/8、真实观察及State交接8/8、总结全部要点0/8；非法参数/重复读取/无总结终止均0，1处文件无直接支持的模块断言。16次生成输入token精确核验16/16，根输入及zero摘要每题两遍一致。主要问题是总结遗漏，未发现State/观察/读取说明缺陷。\n\n原读取回归独立主组{s['read_regression']['primary_r1_valid7']['passed']}/21、R2缺失补充{s['read_regression']['supplement_r2_missing1']['passed']}/3，全部原始输入和失败夹具历史保留。R4简短说明不变，未改生产代码，不训练、部署、新建datasets版本或更新GitHub。完整1514 passed、0 skipped；原5个未提交文件SHA保持。临时离线审计布局修正真实回归1 failed→1 passed，不改变模型结果或口径。\n\n评分含超时、close等细节，0/8不能解读成完全不会总结；逐事实覆盖10/34组，部分覆盖及原回答可复核。若调整主要信息粒度须另轮登记，不能回改本分；下一候选最多是通用摘要覆盖要求，不能填事实、答案或修State来掩盖遗漏。不升级到自主定位。详见[完整报告](../data/experiments/{D.name}/REPORT.zh-CN.md)，SHA `{report_sha}`。\n'''
handoff.write_text('# 当前交接\n'+entry+text[len('# 当前交接\n'):])
files={str(p.relative_to(D)):sha(p) for p in sorted(D.rglob('*')) if p.is_file() and p.name!='SHA256SUMS.json' and '__pycache__' not in p.parts and p.suffix!='.pyc'};save(D/'SHA256SUMS.json',files)
assert all(sha(D/p)==h for p,h in files.items())
print('SEALED',len(files),'report',report_sha,'raw',sha(D/'RAW_EVIDENCE.tar.gz'))
