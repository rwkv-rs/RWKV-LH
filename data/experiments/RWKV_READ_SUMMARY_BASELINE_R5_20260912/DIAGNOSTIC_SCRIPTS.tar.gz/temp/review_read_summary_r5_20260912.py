"""Persist external semantic judgements against pre-run facts; never used by runtime."""
from pathlib import Path
import json,hashlib
R=Path('/home/chase/GitHub/RWKV-LH');D=R/'data/experiments/RWKV_READ_SUMMARY_BASELINE_R5_20260912'
# Explicit reviewer judgements, not substring-based scoring or reference answers.
reviews={
'full_text-1-r1':[
(False,'提供可重启的 SQLite HTTP 预约服务，用于内部会议室与设备的预约','正确概括目标和文档性质，但未覆盖登记的Python标准库约束。'),
(True,'时间单位为 UTC 整数分钟；区间为 `[start,end)`，首尾相接不冲突','也明确同resource confirmed不能重叠。'),
(False,'重复取消幂等；未知 id 返回 404','包含创建/列表/查询/取消及失败无写入，但遗漏取消释放时段。'),
(True,'冲突判定与写入必须为同一原子操作','并明确重启后数据和冲突规则正确。'),
(True,'公开健康检查仅是启动检查；需要补充自己的行为验证','启动db/host/port命令和验证边界均覆盖。')],
'full_text-2-r1':[
(False,'支持库存管理、订单创建和幂等性处理','覆盖SQLite HTTP与重复扣减，但遗漏多行订单部分扣减目标；结尾说明实现要求，不单凭它使用措辞判为已完成。'),
(False,'设置 SKU 的可售库存','接口覆盖，未述库存非负整数、数量正整数。'),
(False,'支持幂等性（通过 Idempotency-Key 头），防止重复扣减库存','遗漏重复SKU规范化/排序、同key不同请求冲突。'),
(False,'错误处理以及事务和幂等性的实现要求','泛指错误处理不能替代缺SKU/库存不足整体无写入、不占key与可更正重试。'),
(False,'事务和幂等性的实现要求','遗漏原子登记、并发不超卖、重启持久和公开健康验证边界。')],
'full_code-1-r1':[
(False,'基于 Python 标准库 http.server 的 HTTP 服务器入口文件','涵盖初始服务器功能，但未说README合同尚待完成。'),
(True,'对其他路径返回 501 状态码和 JSON 响应 {"error": "not_implemented"}','健康200与JSON均准确；在所读GET处理器语境下允许其他路径的简略表达，不据此推断所有HTTP方法。'),
(False,'JSON 响应','遗漏Content-Type、Content-Length与写响应体。'),
(False,'必须指定 --db 和 --port，可选指定 --host（默认 127.0.0.1）','启动与必填/默认覆盖，遗漏port整数和db仅解析未使用。')],
'full_code-2-r1':[
(True,'脚本不验证预订或订单行为，仅提供基础的健康状态检查','正确限定健康检查范围。'),
(False,'通过 HTTP GET 请求 /health 端点','未述命令行HOST/PORT和5秒超时。'),
(False,'检查响应状态码是否为 200 以及响应体是否包含 {"ok": true}','核心断言覆盖；未述关闭连接及打印仍需事务测试提示。')]
}
reviews.update({
'full_text-1-r2':[
(False,'为内部会议室与设备提供可重启的 SQLite HTTP 预约服务','目标正确，未覆盖Python标准库约束。'),
(False,'整数分钟','缺UTC、半开区间/相接允许及同资源confirmed的限定；不把简略冲突预约表达单独判为编造。'),
(False,'取消预约，幂等操作','覆盖接口、失败不改预约；未述取消后时段可再预约。'),
(True,'冲突判定原子操作、终止后重启继续正确','结合数据持久化项，接受对并发冲突与重启规则的紧缩转述。'),
(False,'启动契约','有完整启动参数，遗漏公开健康检查不足以验证功能。')],
'full_text-2-r2':[
(True,'解决网络重试重复扣库存及多行订单部分扣减问题','明确项目目标为实现服务，没有声称已实现。'),
(False,'N 必须为非负整数','库存限制及接口覆盖；未述quantity为正整数。'),
(False,'同 key 相同规范化请求返回 200 同一订单，不再次扣库存','规范化和排序覆盖；未述同key不同customer/明细冲突，后面的不同key不超卖是另一个真实规则，不能替代。'),
(False,'失败应整体无写入，不扣库存、不创建订单、不占用 key','完整回滚已覆盖，但未明确允许更正后重试这一登记子项。'),
(True,'库存判定、扣减和订单/idempotency 登记必须原子完成','并发、持久化、健康检查不能证明交易均有覆盖。')]
})
reviews.update({
'full_code-1-r2':[
(False,'一个简单的 HTTP 服务器入口文件','概括服务器和线程处理，但未述README合同尚待完成；额外threading模块断言单独登记。'),
(True,'返回 HTTP 501 状态码和 JSON 响应 {"error": "not_implemented"}','健康200和其他路径501正确；按GET处理器上下文解释。'),
(False,'JSON 响应','未覆盖Content-Type、Content-Length和写响应体。'),
(False,'可选指定主机地址（--host，默认 127.0.0.1）','启动参数与serve_forever含义基本覆盖；未述port整数、db必填及仅解析未使用。示例命令是由已展示参数规则构成的示例，不作为已执行证明。')],
'full_code-2-r2':[
(True,'脚本明确声明不验证预订/订单行为，仅进行健康检查','边界正确。'),
(False,'脚本接受两个命令行参数：服务器地址（HOST）和端口（PORT）','HOST/PORT及GET覆盖，但遗漏5秒超时。'),
(False,'health smoke passed; transactional behavior still requires tests','断言和打印提示覆盖，但遗漏关闭连接。')]
})
def run():
 reg=json.loads((D/'REGISTRATION.json').read_text());cases={c['id']:c for c in reg['cases']};out=[]
 for name,judgements in reviews.items():
  p=D/'runs'/name/'RESULT.json'
  if not p.exists():continue
  r=json.loads(p.read_text());answer=r['final_output'];facts=cases[r['case']]['key_facts_external_only'];assert len(facts)==len(judgements)
  for ok,quote,note in judgements:assert quote in answer,(name,quote)
  out.append({'run':name,'answer_sha256':hashlib.sha256(answer.encode()).hexdigest(),'rubric_sha256':hashlib.sha256((D/'REGISTRATION.json').read_bytes()).hexdigest(),'facts':[{'fact':f,'covered':ok,'answer_quote':quote,'reason':note} for f,(ok,quote,note) in zip(facts,judgements)],'unsupported_assertions':([{'quote':'它使用 Python 标准库的 http.server 和 threading 模块','reason':'文件只导入argparse、json、BaseHTTPRequestHandler和ThreadingHTTPServer；threading模块的实现细节未在指定文件中提供，超出仅依据文件的边界。线程HTTP服务器本身有直接支持。'}] if name=='full_code-1-r2' else []),'distortions':[],'all_other_assertions_reviewed':True,'summary_pass':all(x[0] for x in judgements) and name!='full_code-1-r2','review_method':'Codex外部语义复核，逐项对照完整原文件与冻结要点，允许转述；没有第二评审人或自动语义评分器。'})
 (D/'SEMANTIC_REVIEW.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print('reviewed',len(out),'pass',sum(x['summary_pass'] for x in out))
if __name__=='__main__':run()
