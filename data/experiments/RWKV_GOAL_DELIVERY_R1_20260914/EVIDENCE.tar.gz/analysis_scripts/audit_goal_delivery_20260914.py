from pathlib import Path
import sys,json,hashlib,subprocess,shutil
R=Path('/home/chase/GitHub/RWKV-LH');sys.path.insert(0,str(R))
from rwkv_lh.schema import RunState
from rwkv_lh.model_io import render_event_append
from rwkv_lh.token_budget import tokenizer
D=R/'data/experiments/RWKV_GOAL_DELIVERY_R1_20260914';reg=json.loads((D/'REGISTRATION.json').read_text());rows=[]
for name,sha in reg['source'].items():assert hashlib.sha256((R/name).read_bytes()).hexdigest()==sha,name
for j in reg['jobs']:
 root=Path(j['output_dir'])
 if not (root/'DELIVERY.json').exists():continue
 delivery=json.loads((root/'DELIVERY.json').read_text());stages=[]
 for step in delivery['workflow']['stages']:
  p=Path(step['directory'])/'execution';result=json.loads((p/'RESULT.json').read_text());s=RunState.from_dict(json.loads((p/'state_snapshot.json').read_text()))
  events=[json.loads(l) for l in (p/'model_trace.jsonl').read_text().splitlines()]
  starts={e['request_id']:e for e in events if e['type']=='model_session_generation_started'};returned=[e for e in events if e['type']=='model_session_generation_returned'];calls=[]
  if step['assistance']=='rwkv_independent':
   gens={e['candidate_checkpoint_id']:e['raw_generation'] for e in returned}
   for e in returned:
    raw=e['raw_generation'];cp=s.model_states[starts[e['request_id']]['input_checkpoint_id']];chain=[]
    while cp:chain.append(cp);cp=s.model_states.get(cp.parent_checkpoint_id)
    ids=[]
    for cp in reversed(chain):
     if cp.checkpoint_id in gens:ids.extend(gens[cp.checkpoint_id]['raw_token_ids'])
     else:
      if cp.parent_checkpoint_id:
       par=s.model_states[cp.parent_checkpoint_id];delta=set(cp.event_ids)-set(par.event_ids);assert len(delta)==1
       assert cp.transcript==render_event_append(s.model_events[next(iter(delta))],previous_transcript=par.transcript)
      ids.extend(tokenizer().encode(cp.transcript))
     if cp.parent_checkpoint_id:assert cp.native_state_metadata['cache_binding']['parent_state_digest']==s.model_states[cp.parent_checkpoint_id].native_state_digest
    assert raw['prompt_token_ids']==[0]+ids
    (p/'actual_inputs').mkdir(exist_ok=True);(p/'actual_inputs'/f'{e["request_id"]}.txt').write_text(tokenizer().decode(ids))
    calls.append(dict(input_tokens=len(raw['prompt_token_ids']),output_tokens=len(raw['raw_token_ids']),finish=raw['finish_reason']))
  else:
   pe=[json.loads(l) for l in (p/'strong_trace.jsonl').read_text().splitlines()];wires=[e for e in pe if e['type']=='strong_execution_wire_request'];envs=[e for e in pe if e['type']=='supervisor_response_envelope_received'];assert len(returned)==len(wires)==len(envs)
   transfer=json.loads((p/'TRANSFER.json').read_text());assert s.model_states[transfer['target_checkpoint']].parent_checkpoint_id is None
   parent=Path(result['continuation']['directory']);assert (p/'PARENT_STATE_SNAPSHOT.json').read_bytes()==(parent/'state_snapshot.json').read_bytes()
   for e,w,env in zip(returned,wires,envs):
    cp=s.model_states[starts[e['request_id']]['input_checkpoint_id']];assert cp.transcript==w['body']['messages'][0]['content'];assert e['raw_output']==env['raw_response']['choices'][0]['message']['content']
    calls.append(dict(provider_usage=env['raw_response'].get('usage'),finish=e['finish_reason']))
  for a in result['actions']:
   ev=s.model_events.get('EV-ACTION-'+a['action_id'])
   if ev is None:
    assert result['termination']!='submitted' and a==result['actions'][-1];continue
   if a['action_type'] in ('check_command','run_command'):
    assert ''.join(x['content'] for stream in ev.payload['result']['command_streams'] for x in stream['exact_spans'])==a['result']['output']
   if a['action_type']=='read_file' and a['result']['success']:
    assert ''.join(x['content'] for x in ev.payload['result']['observation']['exact_spans'])==a['result']['output']
  stages.append(dict(assistance=step['assistance'],calls=calls,termination=result['termination_reason'],raw_final=result['final']))
 external=None
 if j['task_id']=='fix-query':
  out=D/'external'/j['task_id']
  if not (out/'CHECK.json').exists():
   shutil.copytree(delivery['workspace'],out/'workspace');test=(Path(j['workspace'])/'test_query_limit.py').read_bytes();ws=out/'workspace';unchanged=(ws/'test_query_limit.py').read_bytes()==test;(ws/'test_query_limit.py').write_bytes(test)
   c=subprocess.run([sys.executable,'-B','test_query_limit.py'],cwd=ws,capture_output=True,text=True,timeout=60)
   (out/'CHECK.json').write_text(json.dumps(dict(exit_code=c.returncode,stdout=c.stdout,stderr=c.stderr,test_unchanged=unchanged,attribution='external verifier, not model execution'),ensure_ascii=False,indent=2))
  external=json.loads((out/'CHECK.json').read_text())
 selected=Path(delivery['workflow']['stages'][-1]['directory'])/'execution';rr=json.loads((selected/'RESULT.json').read_text());actions=rr['actions'][rr['continuation']['historical_actions'] if rr['continuation'] else 0:]
 rows.append(dict(task=j['task_id'],termination=delivery['termination'],assistance=delivery['assistance'],final=delivery['final'],changed_files=delivery.get('changed_files'),workflow=delivery['workflow'],stages=stages,external=external,selected_actions=[dict(type=a['action_type'],arguments=a['arguments'],output=a['result'].get('output'),exit_code=a['result'].get('exit_code')) for a in actions]))
(D/'MECHANICAL.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2));print([(r['task'],r['termination'],r['assistance'],r['workflow']['model_calls']) for r in rows])
