from pathlib import Path
from dataclasses import asdict,replace
import sys,json,hashlib,datetime,subprocess
R=Path('/home/chase/GitHub/RWKV-LH');sys.path.insert(0,str(R))
from rwkv_lh.runtime.settings import get_runtime_settings
from rwkv_lh.supervisor_openai import SupervisorAPISettings
D=R/'data/experiments/RWKV_GOAL_DELIVERY_R1_20260914';B=R/'data/experiments/RWKV_AGENT_ARCHITECTURE_BATCH_R1_20260914/live';Q=R/'data/experiments/RWKV_QUERY_REPAIR_FEEDBACK_R1_20260914'
jobs=[]
for name,parent,source in [('read-health',B/'read-health',None),('run-recursive',B/'run-recursive/execution',B/'run-recursive/workspace'),('fix-query',Q/'runs/repeat-1/execution',Q/'source')]:
 state=json.loads((parent/'state_snapshot.json').read_text());source=source or Path(state['goal']['workspace_root'])
 jobs.append(dict(task_id=name,request=state['goal']['request'],workspace=str(source),output_dir=str(D/'runs'/name),tool_scope='coding',on_stall='takeover',rwkv_max_calls=24,max_calls=32,max_seconds=1200))
settings=replace(get_runtime_settings(),return_token_ids=True,state_transport='native_required',state_profile_id='zero',state_profile_sha256='0'*64,tool_disclosure_mode='full')
safe={k:v for k,v in asdict(settings).items() if not any(x in k for x in ('key','secret','client_id','proxy'))}
reg=dict(timestamp=datetime.datetime.now(datetime.timezone.utc).isoformat(),jobs=jobs,concurrency=2,settings=safe,strong_model=SupervisorAPISettings.from_env().model,source={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for folder in ('rwkv_lh','scripts','tests') for p in sorted((R/folder).rglob('*.py'))},input_files={j['task_id']:{str(p.relative_to(Path(j['workspace']))):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(Path(j['workspace']).rglob('*')) if p.is_file()} for j in jobs},criteria={'read-health':'Faithful summary of GET /health, 200 and ok=true; excludes booking/order certification; no claim actual execution required; no file changes.','run-recursive':'Actual model command check_recursive.py exit0 and passed=true checks, faithful final, no changes.','fix-query':'Original test_query_limit.py unchanged and passes independent copy, actual model relevant test execution, correct delivered fix and faithful final.'},policy='RWKV first; one takeover only on whitelisted complete-trace no-answer budget stall with remaining total calls/time. Submitted never automatically graded. 24 RWKV/32 combined calls, output1800; inherited repeated-success protection unchanged; no actual guarantee all24 consumed. End-to-end elapsed includes copy/route; cleanup may exceed wall allowance and is flagged.',scope='Three existing approved tasks, one trial each. No general stability, throughput gain or prompt-causality claim.')
for name,val in [('REGISTRATION.json',reg),('JOBS.json',jobs)]:
 with (D/name).open('x') as f:json.dump(val,f,ensure_ascii=False,indent=2)
owner=['rwkv_lh/controller.py','rwkv_lh/model.py','rwkv_lh/supervisor_openai.py','tests/test_hybrid_supervisor.py','tests/test_supervisor_openai.py'];(D/'OWNER_BEFORE.diff').write_bytes(subprocess.check_output(['git','diff','--',*owner],cwd=R))
print('frozen three tasks, RWKV24 / total32 calls each')
