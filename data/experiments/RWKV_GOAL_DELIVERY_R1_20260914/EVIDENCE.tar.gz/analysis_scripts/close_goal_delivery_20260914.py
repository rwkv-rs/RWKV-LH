from pathlib import Path
import hashlib,json,subprocess,tarfile
R=Path('/home/chase/GitHub/RWKV-LH');D=R/'data/experiments/RWKV_GOAL_DELIVERY_R1_20260914';reg=json.loads((D/'REGISTRATION.json').read_text());rows=json.loads((D/'MECHANICAL.json').read_text());assert len(rows)==3
for name,sha in reg['source'].items():assert hashlib.sha256((R/name).read_bytes()).hexdigest()==sha
for j in reg['jobs']:
 ws=Path(j['workspace']);now={str(p.relative_to(ws)):hashlib.sha256(p.read_bytes()).hexdigest() for p in ws.rglob('*') if p.is_file()};assert now==reg['input_files'][j['task_id']]
owner=['rwkv_lh/controller.py','rwkv_lh/model.py','rwkv_lh/supervisor_openai.py','tests/test_hybrid_supervisor.py','tests/test_supervisor_openai.py'];assert subprocess.check_output(['git','diff','--',*owner],cwd=R)==(D/'OWNER_BEFORE.diff').read_bytes()
assert '1650 passed' in (D/'FULL_TESTS.log').read_text() and 'skipped' not in (D/'FULL_TESTS.log').read_text()
stats=[]
for r in rows:
 native=[c for s in r['stages'] if s['assistance']=='rwkv_independent' for c in s['calls']];strong=[c for s in r['stages'] if s['assistance']=='strong_takeover' for c in s['calls']]
 stats.append(dict(task=r['task'],assistance=r['assistance'],termination=r['termination'],rwkv_calls=len(native),rwkv_logical_input=sum(c['input_tokens'] for c in native),rwkv_output=sum(c['output_tokens'] for c in native),strong_calls=len(strong),strong_usage=[c['provider_usage'] for c in strong],end_to_end_seconds=r['workflow']['end_to_end_seconds'],changed_files=r['changed_files']))
(D/'RESOURCE_SUMMARY.json').write_text(json.dumps(stats,ensure_ascii=False,indent=2))
with tarfile.open(D/'EVIDENCE.tar.gz','w:gz') as tar:
 for n in ['runs','external']:
  if (D/n).exists():tar.add(D/n,arcname=n)
 for n in ['freeze_goal_delivery_20260914.py','audit_goal_delivery_20260914.py','close_goal_delivery_20260914.py']:tar.add(R/'temp'/n,arcname='analysis_scripts/'+n)
(D/'SHA256.json').write_text(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in D.iterdir() if p.is_file() and p.name!='SHA256.json'},indent=2))
print(json.dumps(stats,ensure_ascii=False,indent=2))
