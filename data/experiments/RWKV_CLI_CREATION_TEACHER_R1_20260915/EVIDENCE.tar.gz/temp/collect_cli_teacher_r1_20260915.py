from pathlib import Path
from dataclasses import replace
import sys,json,hashlib,time,subprocess
R=Path('/home/chase/GitHub/RWKV-LH');sys.path.insert(0,str(R))
from rwkv_lh.direct_trace_data import replay_run
from rwkv_lh.strong_session import StrongCompletion
from rwkv_lh.supervisor_openai import SupervisorAPISettings
from rwkv_lh.runtime.settings import load_local_env
from rwkv_lh import model_io
from rwkv_lh.usage_accounting import audit_run_usage
D=R/'data/experiments/RWKV_CLI_CREATION_TEACHER_R1_20260915';D.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
load_local_env(R/'.env.local')
settings=replace(SupervisorAPISettings.from_env(),retry_attempts=1,semantic_repair_attempts=0,fallback_models=(),plan_cache_enabled=False,planner_request_options={'thinking':{'type':'disabled'}},read_timeout_seconds=120)
sources=[]
for repeat,selected in (('backup-snapshot','CP-837e835494e14b9b'),('timebook-add','CP-82ee0c6655444b27')):
 root=R/f'data/experiments/RWKV_CLI_ATOMIC_CREATION_R1_20260914/runs/{repeat}/execution'
 replay=replay_run(root,'559371f5b9aef13189ae54b345ac096af4ad2b689996c05d89de687612b3ae65')
 cp,actual=selected,replay[selected]
 assert actual['raw_generation']['finish_reason']=='length'
 original_error=None
 try:model_io.parse_model_command(actual['raw_generation']['raw_output'])
 except Exception as exc:original_error=type(exc).__name__+': '+str(exc)
 assert original_error is not None
 sources.append({'id':repeat,'run_root':str(root),'checkpoint':cp,'actual':actual,'original_tool':None,'original_parameters':None,'original_parse_error':original_error,'source_files':{str(p.relative_to(root)):sha(p) for p in root.rglob('*') if p.is_file() and (p.name in ('RESULT.json','model_trace.jsonl','state_snapshot.json','PARENT_TRACE.jsonl','call.json') or 'before' in p.parts or 'generation_snapshots' in p.parts)}})
save(D/'REGISTRATION.json',{'round':D.name,'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'source_pins':{str(p.relative_to(R)):sha(p) for p in (R/'rwkv_lh').rglob('*.py')},'script_sha256':sha(Path(__file__)),'settings':settings.public_dict(),'budget':{'generation_calls':2,'review_calls':4,'max_output_tokens':1800,'training_steps':0},'selection':'First length-truncated real write candidate in each of two approved CLI source tasks, after the actual README observation. Exact original input only; no later feedback, reference implementation, hidden checker or expected tool parameters supplied. Same1800 output limit; an overlong or incomplete strong candidate is rejected, never auto-repaired. This is candidate collection, not RWKV task success or formal dataset admission.','gate':'Candidate chooses a legal tool with grounded parameters; if edit, execute unchanged and verify the pre-registered scoped external checks red-to-green; if read or test, report actual effect and do not force editing. No automatic parameter/answer repair.','sources':sources})
results=[]
for source in sources:
 folder=D/'runs'/source['id'];folder.mkdir(parents=True)
 save(folder/'INPUT.json',source['actual'])
 completion=StrongCompletion(settings,folder,1);start=time.monotonic()
 record={'id':source['id'],'source_checkpoint':source['checkpoint'],'status':'started'}
 try:
  output=completion.text_completion(source['actual']['input_text'],max_tokens=1800)
  record.update(raw_output=output.content,finish_reason=output.finish_reason,model=output.model,response_id=output.response_id)
  command=model_io.parse_model_command(output.content)
  json.loads(output.content)
  record.update(status='candidate',tool=command.name,arguments=command.arguments)
 except Exception as exc:record.update(status='error',error=type(exc).__name__+': '+str(exc))
 finally:completion.client.close()
 record['elapsed_seconds']=time.monotonic()-start;save(folder/'CANDIDATE.json',record);results.append(record)
 print(source['id'],record['status'],record.get('tool'),flush=True)
save(D/'RESULTS.json',results);save(D/'USAGE.json',audit_run_usage(D))
