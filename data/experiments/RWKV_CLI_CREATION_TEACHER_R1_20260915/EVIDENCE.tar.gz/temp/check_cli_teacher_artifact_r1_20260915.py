from pathlib import Path
import sys,json,hashlib,subprocess
R=Path('/home/chase/GitHub/RWKV-LH');sys.path.insert(0,str(R))
from rwkv_lh.workspace_snapshot import copy_verified_workspace
from rwkv_lh.model import LongHorizonModel
from rwkv_lh.harness import ActionHarness
from rwkv_lh.schema import TaskAction
D=R/'data/experiments/RWKV_CLI_CREATION_TEACHER_R1_20260915';reg=json.loads((D/'REGISTRATION.json').read_text());source=next(s for s in reg['sources'] if s['id']=='timebook-add');folder=D/'runs/timebook-add';candidate=json.loads((folder/'CANDIDATE.json').read_text());out=folder/'artifact_check';out.mkdir()
workspace=out/'workspace';before=Path(source['run_root'])/'generation_snapshots'/source['actual']['request_id']/'before';copy_verified_workspace(before,workspace,audit_path=out/'SOURCE_COPY.json')
original=json.loads((Path(source['run_root'])/'goal.json').read_text());goal=LongHorizonModel.create_literal_goal(original['request'],str(workspace));result=ActionHarness().execute(TaskAction(candidate['tool'],candidate['arguments']),goal)
(out/'TOOL_RESULT.json').write_text(json.dumps(result.to_dict(),ensure_ascii=False,indent=2)+'\n')
assert result.success
subprocess.run([str(R/'.venv/bin/python'),str(R/'temp/verify_cli_atomic_creation_r1_20260914.py'),'timebook-add',str(workspace),str(out/'EXTERNAL_CHECK.json')],check=True)
print((out/'EXTERNAL_CHECK.json').read_text())
