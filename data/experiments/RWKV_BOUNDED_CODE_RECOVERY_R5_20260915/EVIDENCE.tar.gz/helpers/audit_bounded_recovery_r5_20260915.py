from pathlib import Path
import json,sys,hashlib
R=Path('/home/chase/GitHub/RWKV-LH');sys.path.insert(0,str(R))
from rwkv_lh.schema import RunState
from rwkv_lh.model_io import render_event_append
D=R/'data/experiments/RWKV_BOUNDED_CODE_RECOVERY_R5_20260915';p=D/'runs/offset/execution';s=RunState.from_dict(json.loads((p/'state_snapshot.json').read_text()));events=[json.loads(l) for l in (p/'model_trace.jsonl').read_text().splitlines()];strong=[json.loads(l) for l in (p/'strong_trace.jsonl').read_text().splitlines()];wires=[e for e in strong if e['type']=='strong_execution_wire_request'];starts=[e for e in events if e['type']=='model_session_generation_started'];gens={e['request_id']:e for e in events if e['type']=='model_session_generation_returned'};rows=[]
assert len(wires)==len(starts)==4
for start,wire in zip(starts,wires):
 cp=s.model_states[start['input_checkpoint_id']];body=wire['body'];assert body['messages'][0]['content']==cp.transcript
 gen=gens[start['request_id']];child=s.model_states[gen['candidate_checkpoint_id']];assert child.parent_checkpoint_id==cp.checkpoint_id and child.transcript==cp.transcript+gen['raw_output'];assert body['max_tokens']==1800
 rows.append({'request_id':start['request_id'],'input_checkpoint':cp.checkpoint_id,'output_checkpoint':child.checkpoint_id,'input_sha256':hashlib.sha256(cp.transcript.encode()).hexdigest(),'event_ids':list(cp.event_ids),'transport':'prompt_replay','wire_sampling':{k:body[k] for k in ('temperature','top_p','frequency_penalty') if k in body}})
result=json.loads((p/'RESULT.json').read_text());actions=result['actions'][7:];obs=[]
for a in actions:
 eid='EV-ACTION-'+a['action_id'];event=s.model_events[eid];assert eid in rows[-1]['event_ids']
 if a['action_type']=='check_command':
  payload=event.payload['result'];assert payload['exit_code']==a['result']['exit_code'];assert ''.join(span['content'] for stream in payload['command_streams'] for span in stream['exact_spans'])==a['result']['output']
 obs.append({'action_id':a['action_id'],'type':a['action_type'],'seen_in_final_input':True})
(D/'INPUT_AUDIT.json').write_text(json.dumps({'passed':True,'calls':rows,'new_actions':obs,'limits':'Strong takeover uses prompt replay, not native RWKV tensor continuation. Wire sampling is authoritative; absent fields are provider defaults. Parent historical RWKV actions are not new strong actions.'},indent=2)+'\n');print('4 exact wire inputs and parent-child transcripts; all 3 new tool observations visible to final')
