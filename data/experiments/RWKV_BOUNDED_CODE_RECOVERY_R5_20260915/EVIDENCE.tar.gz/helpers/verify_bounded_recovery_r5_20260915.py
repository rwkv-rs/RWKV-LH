from pathlib import Path
import sys,json,hashlib,shutil,subprocess,difflib
R=Path('/home/chase/GitHub/RWKV-LH');sys.path.insert(0,str(R))
from rwkv_lh.usage_accounting import audit_run_usage
D=R/'data/experiments/RWKV_BOUNDED_CODE_RECOVERY_R5_20260915';reg=json.loads((D/'REGISTRATION.json').read_text());delivery=json.loads((D/'runs/offset/DELIVERY.json').read_text());source=Path(reg['workspace']);final=D/'runs/offset/workspace';checks=D/'external';checks.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert all(sha(R/p)==h for p,h in reg['source_pins'].items())
for n in ['README.md','test_timestamp_offset.py']:assert sha(source/n)==sha(final/n)
assert sha(final/'test_timestamp_offset.py')==reg['checks']['offset_test_sha256']
results={}
for arm,w in [('before',source),('after',final)]:
 dest=checks/arm;shutil.copytree(w,dest)
 run=subprocess.run([sys.executable,'-B','test_timestamp_offset.py'],cwd=dest,text=True,capture_output=True,timeout=120);results[arm]={'exit_code':run.returncode,'stdout':run.stdout,'stderr':run.stderr}
subprocess.run([sys.executable,reg['checks']['cli_helper'],'timebook-add',str(checks/'after'),str(checks/'CLI.json')],check=True)
results['cli']=json.loads((checks/'CLI.json').read_text());assert results['before']['exit_code']==1 and results['after']['exit_code']==0 and results['cli']['exit_code']==0
(D/'EXTERNAL_CHECKS.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
(D/'PATCH.diff').write_text(''.join(difflib.unified_diff((source/'timebook.py').read_text().splitlines(True),(final/'timebook.py').read_text().splitlines(True),fromfile='before/timebook.py',tofile='after/timebook.py')))
(D/'USAGE.json').write_text(json.dumps(audit_run_usage(D/'runs/offset/execution'),ensure_ascii=False,indent=2)+'\n')
print('External original test red->green, original scoped CLI green; source/test unchanged except timebook.py patch')
