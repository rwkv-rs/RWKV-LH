"""Fixed zero-State output-budget comparison; no protocol or tool-order override."""
from pathlib import Path
from dataclasses import replace
from concurrent.futures import ProcessPoolExecutor,as_completed
from multiprocessing import get_context
import json,hashlib,time,subprocess,urllib.request
from collect_cli_atomic_creation_r1_20260914 import R,save,sha
from cli_sampling_checked_worker_r1_20260915 import worker
from rwkv_lh.runtime.settings import load_local_env,get_runtime_settings,direct_agent_settings
from rwkv_lh.coding_agent import CodingJob
from rwkv_lh.agent_batch import validate_agent_jobs
D=R/'data/experiments/RWKV_CLI_FREQUENCY_PENALTY_ABLATION_R2_20260915'
if __name__=='__main__':
 D.mkdir(exist_ok=False);load_local_env(R/'.env.local')
 original=R/'data/experiments/RWKV_CLI_ATOMIC_CREATION_R1_20260914'
 cases=json.loads((original/'TASKS_PREPARATION.json').read_text())['jobs'];check=json.loads((original/'EXTERNAL_CHECK_REGISTRATION.json').read_text());assert sha(Path(check['helper_path']))==check['helper_sha256']
 for c in cases:assert all(sha(Path(c['workspace'])/p)==h for p,h in c['files'].items())
 config=direct_agent_settings(replace(get_runtime_settings(),base_url='http://127.0.0.1:29624/v1',model='rwkv-code-agent-gc-r1-ctx24576',model_sha256='559371f5b9aef13189ae54b345ac096af4ad2b689996c05d89de687612b3ae65',max_model_len=24576,state_profile_id='zero',state_profile_sha256='0'*64,read_timeout_seconds=600,default_temperature=.1,default_top_p=1,default_top_k=0,default_presence_penalty=0,default_frequency_penalty=0,default_penalty_decay=.996))
 pins={str(p.relative_to(R)):sha(p) for p in (R/'rwkv_lh').rglob('*.py')}
 order=[(1,0.0),(1,0.2),(2,0.2),(2,0.0)]
 save(D/'REGISTRATION.json',{'tasks':cases,'external_check':check,'source_head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'source_pins':pins,'helper_sha256':sha(Path(__file__)),'worker_helper_sha256':sha(R/'temp/cli_sampling_checked_worker_r1_20260915.py'),'model':config.model,'model_sha256':config.model_sha256,'state':['zero','0'*64],'context_tokens':24576,'sampling':{'temperature':.1,'top_p':1,'top_k':0,'presence_penalty':0,'frequency_penalty':0,'penalty_decay':.996},'output_tokens':8192,'frequency_penalty_arms':[0.0,0.2],'order':order,'budget':{'calls_per_task':8,'seconds_per_task':1800,'total_max_calls':64,'parallel_independent_tasks':2,'overall_seconds':7200},'acceptance':json.loads((original/'TASKS_PREPARATION.json').read_text())['acceptance'],'retention':'Diagnostic single-factor frequency penalty0 versus0.2; decay0.996 unchanged, presence0, temperature0.1, output8192. Both arms rerun same8calls1800seconds and two repeats. Motivated by observed repeated function names/docstring command loops in prior budget diagnostic; not a preregistered broad hyperparameter search. Report artifact pass, truthful final, protocol errors, repeated content, tokens and latency separately. Gate for any proposed default: both tasks both repeats pass with zero illegal calls/false work claims, original read/fidelity regressions additionally required. No automatic retention or training attribution. No input/tool-order change.'})
 for endpoint in ('models','capabilities'):save(D/(endpoint.upper()+'.json'),json.loads(urllib.request.urlopen(config.base_url+'/'+endpoint,timeout=15).read()))
 started=time.monotonic();results=[]
 for repeat,frequency in order:
  assert time.monotonic()-started<7200 and all(sha(R/p)==h for p,h in pins.items())
  settings=replace(config,action_max_output_tokens=8192,default_frequency_penalty=frequency)
  jobs=[CodingJob(c['id'],c['request'],c['workspace'],str(D/'runs'/f'repeat-{repeat}-frequency-{frequency}'/c['id']),8,1800) for c in cases];validate_agent_jobs(jobs,concurrency=2)
  with ProcessPoolExecutor(max_workers=2,mp_context=get_context('spawn')) as pool:
   futures={pool.submit(worker,j,settings,pins):j.task_id for j in jobs}
   for f in as_completed(futures):
    value=f.result();row={'repeat':repeat,'output_tokens_limit':8192,'frequency_penalty':frequency,**value};results.append(row);save(D/'RESULTS.json',results);print(repeat,frequency,value['id'],value['result']['termination'],flush=True)
  assert all(sha(R/p)==h for p,h in pins.items())
 save(D/'SOURCE_AFTER.json',{'all_match':True,'elapsed_seconds':time.monotonic()-started})
