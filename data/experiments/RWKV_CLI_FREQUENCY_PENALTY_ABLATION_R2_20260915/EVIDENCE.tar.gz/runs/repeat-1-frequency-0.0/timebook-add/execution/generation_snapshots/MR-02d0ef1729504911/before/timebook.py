#!/usr/bin/env python3
"""
timebook.py: command-line timebook with SQLite persistence.

Commands:
  add DB --id ID --project PROJECT --start ISO --end ISO
  import DB INPUT_JSON
  stats DB --from YYYY-MM-DD --to YYYY-MM-DD

All timestamps are ISO 8601 with explicit UTC offset or Z, whole-second precision,
timezone-aware, and end strictly after start. IDs and project names are nonempty
strings; whitespace-only values are rejected. Duplicates are identified by exact
ID/project/start/end and normalized to UTC for comparison. Reimporting an
identical ID/project/time interval is a no-op; a conflicting ID is an error.

SQLite is used for persistence. Each CLI invocation is a new process, so
persistence and duplicate detection must survive restarts.

Usage:
  python timebook.py add DB --id ID --project PROJECT --start ISO --end ISO
  python timebook.py import DB INPUT_JSON
  python timebook.py stats DB --from YYYY-MM-DD --to YYYY-MM-DD

Exit codes:
  0: success
  1: error (invalid arguments, duplicate, conflict, etc.)
  2: invalid date range or missing arguments
",
"path":"timebook.py"
}