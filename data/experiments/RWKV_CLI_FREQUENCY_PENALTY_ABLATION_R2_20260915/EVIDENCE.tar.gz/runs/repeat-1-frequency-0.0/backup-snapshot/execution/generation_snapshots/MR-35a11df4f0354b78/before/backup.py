#!/usr/bin/env python3
"""
backup.py: POSIX-portable snapshot and restore for a directory tree.

Usage:
  python backup.py snapshot SOURCE ARCHIVE
  python backup.py restore ARCHIVE DESTINATION

SOURCE is a directory; ARCHIVE must be outside it. DESTINATION is the
directory to restore into.

The archive is a ZIP file containing:
  - manifest.json: version, directories, files
  - files/<relative path>: ZIP member files

Only regular files are preserved. Symbolic links, device nodes, sockets,
pipes, and other non-regular entries are rejected. Empty directories are
preserved. The archive is created atomically; a failed snapshot does not
replace a previous archive.

The restore operation validates the archive before replacing DESTINATION.
It rejects invalid input, duplicate names, absolute paths, parent
traversal, backslashes, and other unsafe names. Restore must validate the
archive before replacing DESTINATION. Successful restore must not retain
old files. Invalid input must never write outside the destination staging
area. Symlink destinations are invalid.

Each invocation is a separate process; no process-memory state is
available. Keep staging files beside their final target so replacement
can be atomic on the same filesystem.

Exit codes:
  0: success
  1: failure (invalid input, I/O error, etc.)
  2: invalid command or arguments
",
  "path": "backup.py"
}