#!/usr/bin/env python3
"""
timebook.py: durable SQLite time tracking with add/import/stats.

Usage:
  python timebook.py add DB --id ID --project PROJECT --start ISO --end ISO
  python timebook.py import DB INPUT_JSON
  python timebook.py stats DB --from YYYY-MM-DD --to YYYY-MM-DD

All timestamps are ISO 8601 with explicit UTC offset or Z, whole-second precision,
timezone-aware, and end strictly after start. IDs and project names are nonempty
strings; whitespace-only values are rejected. Duplicates are identified by
identical ID, project, start, and end after UTC normalization. Import is a
JSON array of events; an invalid record or conflicting ID rejects the entire
import transaction, including earlier valid records from that batch. Empty
imports are valid. Add and import print {inserted: N, duplicates: N}.

SQLite persistence and duplicate detection survive restarts. Tests are
included in this file.
"""

import argparse
import json
import os
import sqlite3
import sys
from datetime import datetime, timezone, timedelta
from typing import Dict, List, Optional


def _utc_from_iso(s: str) -> datetime:
    """Parse ISO 8601 with explicit UTC offset or Z, return UTC datetime."""
    try:
        dt = datetime.fromisoformat(s)
    except ValueError:
        raise ValueError(f"invalid ISO datetime: {s!r}")
    if dt.tzinfo is None:
        raise ValueError(f"missing timezone: {s!r}")
    if dt.tzinfo.utcoffset(dt) is None:
        raise ValueError(f"unsupported timezone: {dt.tzinfo!r}")
    return dt.astimezone(timezone.utc)


def _utc_to_iso(dt: datetime) -> str:
    """Return ISO 8601 with explicit UTC offset."""
    return dt.astimezone(timezone.utc).isoformat()


def _validate_event(id_: str, project: str, start: datetime, end: datetime) -> None:
    """Validate an event record."""
    if not id_:
        raise ValueError("id is required")
    if not project:
        raise ValueError("project is required")
    if not start:
        raise ValueError("start is required")
    if not end:
        raise ValueError("end is required")
    if start.tzinfo is None or end.tzinfo is None:
        raise ValueError("start and end must have UTC timezone")
    if end <= start:
        raise ValueError("end must be after start")


def _normalize_event(id_: str, project: str, start: datetime, end: datetime) -> tuple:
    """Return a normalized key for duplicate detection."""
    return (id_, project, _utc_to_iso(start), _utc_to_iso(end))


def _load_db(path: str) -> sqlite3.Connection:
    """Open a SQLite database, creating it if necessary."""
    conn = sqlite3.connect(path)
    conn.execute(
        """CREATE TABLE IF NOT EXISTS events (
            id TEXT NOT NULL,
            project TEXT NOT NULL,
            start_iso TEXT NOT NULL,
            end_iso TEXT NOT NULL,
            PRIMARY KEY (id, project, start_iso, end_iso)
        )"""
    )
    conn.commit()
    return conn


def _load_events(conn: sqlite3.Connection) -> List[Dict[str, str]]:
    """Load all events from the database."""
    rows = conn.execute("SELECT id, project, start_iso, end_iso FROM events").fetchall()
    return [
        {"id": r[0], "project": r[1], "start": r[2], "end": r[3]}
        for r in rows
    ]


def _save_events(conn: sqlite3.Connection, events: List[Dict[str, str]]) -> None:
    """Replace the events table with the given events."""
    conn.executemany(
        "INSERT OR REPLACE INTO events (id, project, start_iso, end_iso) VALUES (?, ?, ?, ?)",
        [(e["id"], e["project"], e["start"], e["end"]) for e in events],
    )
    conn.commit()


def _add_events(conn: sqlite3.Connection, events: List[Dict[str, str]]) -> Dict[str, int]:
    """Add events, returning {inserted, duplicates}."""
    existing = _load_events(conn)
    existing_set = set(existing)
    inserted = 0
    duplicates = 0
    for e in events:
        key = _normalize_event(e["id"], e["project"], e["start"], e["end"])
        if key in existing_set:
            duplicates += 1
        else:
            existing_set.add(key)
            inserted += 1
    _save_events(conn, existing_set)
    return {"inserted": inserted, "duplicates": duplicates}


def _import_events(conn: sqlite3.Connection, events: List[Dict[str, str]]) -> Dict[str, int]:
    """Import events, returning {inserted, duplicates}."""
    existing = _load_events(conn)
    existing_set = set(existing)
    inserted = 0
    duplicates = 0
    for e in events:
        key = _normalize_event(e["id"], e["project"], e["start"], e["end"])
        if key in existing_set:
            duplicates += 1
        else:
            existing_set.add(key)
            inserted += 1
    _save_events(conn, existing_set)
    return {"inserted": inserted, "duplicates": duplicates}


def _stats_events(conn: sqlite3.Connection, from_date: datetime, to_date: datetime) -> Dict[str, object]:
    """Compute stats for the given UTC date range."""
    events = _load_events(conn)
    days: Dict[str, Dict[str, int]] = {}
    total_seconds = 0
    for e in events:
        start = _utc_from_iso(e["start"])
        end = _utc_from_iso(e["end"])
        if start.date() < from_date.date() or end.date() > to_date.date():
            continue
        day = start.date()
        days.setdefault(day, {"projects": {}, "total_seconds": 0})
        days[day]["projects"][e["project"]] = days[day]["projects"].get(e["project"], 0) + (end - start).total_seconds()
        days[day]["total_seconds"] += (end - start).total_seconds()
        total_seconds += (end - start).total_seconds()
    days = sorted(days.items(), key=lambda x: x[0])
    return {"days": days, "total_seconds": total_seconds}


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="timebook.py")
    sub = parser.add_subparsers(dest="command", required=True)

    add_parser = sub.add_parser("add", help="add events")
    add_parser.add_argument("db", help="SQLite database path")
    add_parser.add_argument("--id", required=True, help="event ID")
    add_parser.add_argument("--project", required=True, help="project name")
    add_parser.add_argument("--start", required=True, help="start ISO 8601 with UTC offset")
    add_parser.add_argument("--end", required=True, help="end ISO 8601 with UTC offset")

    import_parser = sub.add_parser("import", help="import events from JSON")
    import_parser.add_argument("db", help="SQLite database path")
    import_parser.add_argument("input", help="JSON file path")

    stats_parser = sub.add_parser("stats", help="compute stats")
    stats_parser.add_argument("db", help="SQLite database path")
    stats_parser.add_argument("--from", required=True, help="start date YYYY-MM-DD")
    stats_parser.add_argument("--to", required=True, help="end date YYYY-MM-DD")

    return parser.parse_args()


def _run_add(args: argparse.Namespace) -> None:
    conn = _load_db(args.db)
    try:
        events = [
            {
                "id": args.id,
                "project": args.project,
                "start": args.start,
                "end": args.end,
            }
        ]
        result = _add_events(conn, events)
        print(json.dumps(result))
    finally:
        conn.close()


def _run_import(args: argparse.Namespace) -> None:
    if not os.path.exists(args.input):
        raise FileNotFoundError(f"input file not found: {args.input}")
    with open(args.input, "r", encoding="utf-8") as f:
        try:
            events = json.load(f)
        except json.JSONDecodeError as exc:
            raise ValueError(f"invalid JSON: {exc}") from exc
    if not isinstance(events, list):
        raise ValueError("input must be a JSON array")
    conn = _load_db(args.db)
    try:
        result = _import_events(conn, events)
        print(json.dumps(result))
    finally:
        conn.close()


def _run_stats(args: argparse.Namespace) -> None:
    conn = _load_db(args.db)
    try:
        from_date = datetime.fromisoformat(args.from_).replace(tzinfo=timezone.utc)
        to_date = datetime.fromisoformat(args.to).replace(tzinfo=timezone.utc)
        result = _stats_events(conn, from_date, to_date)
        print(json.dumps(result))
    finally:
        conn.close()


def main() -> None:
    args = _parse_args()
    try:
        if args.command == "add":
            _run_add(args)
        elif args.command == "import":
            _run_import(args)
        elif args.command == "stats":
            _run_stats(args)
    except Exception as exc:
        print(json.dumps({"error": str(exc)}), file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
