#!/usr/bin/env python3
"""
backup.py — portable team-folder backup

Commands:
  python backup.py snapshot SOURCE ARCHIVE
  python backup.py restore ARCHIVE DESTINATION
",
"path": "backup.py"
}