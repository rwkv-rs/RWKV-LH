#!/usr/bin/env python3
"""
timebook.py: durable SQLite time-tracking CLI.

Commands:
  add DB --id ID --project PROJECT --start ISO --end ISO
  import DB INPUT_JSON
  stats DB --from YYYY-MM-DD --to YYYY-MM-DD

All timestamps are ISO 8601 with explicit UTC offset or Z, whole-second precision,
timezone-aware, and end strictly after start. IDs and project names are nonempty
strings; whitespace-only values are rejected. Duplicates are detected by exact
id/project/start/end and normalized to UTC for comparison.

SQLite is used for persistence. Each CLI invocation is a new process, so
persistence and duplicate detection must survive restarts.
"""
import argparse
import json
import sqlite3
import sys
from datetime import datetime, timezone, timedelta
from pathlib import Path

DB_SCHEMA = """
CREATE TABLE IF NOT EXISTS events (
    id TEXT NOT NULL,
    project TEXT NOT NULL,
    start_utc TEXT NOT NULL,
    end_utc TEXT NOT NULL,
    PRIMARY KEY (id, project)
);
"""

def _parse_iso(s: str) -> datetime:
    try:
        return datetime.fromisoformat(s)
    except ValueError as exc:
        raise ValueError(f"invalid ISO timestamp: {s!r}") from exc

def _to_utc(dt: datetime) -> datetime:
    if dt.tzinfo is None:
        return dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)

def _overlap(a: datetime, b: datetime, c: datetime, d: datetime) -> bool:
    return max(a, c) < min(b, d)

def _normalize_event(e: dict) -> dict:
    id_ = e["id"].strip()
    if not id_:
        raise ValueError("id is empty")
    project = e["project"].strip()
    if not project:
        raise ValueError("project is empty")
    start = _parse_iso(e["start"])
    end = _parse_iso(e["end"])
    if end <= start:
        raise ValueError("end must be after start")
    return {"id": id_, "project": project, "start": start, "end": end}

def _validate_event(e: dict) -> None:
    if not e["id"]:
        raise ValueError("id is empty")
    if not e["project"]:
        raise ValueError("project is empty")
    if e["end"] <= e["start"]:
        raise ValueError("end must be after start")

def _insert_event(conn: sqlite3.Connection, event: dict) -> None:
    cur = conn.cursor()
    cur.execute("INSERT OR IGNORE INTO events VALUES (?, ?, ?, ?)",
                (event["id"], event["project"], event["start"], event["end"]))
    conn.commit()

def _check_duplicates(conn: sqlite3.Connection, event: dict) -> bool:
    cur = conn.cursor()
    cur.execute("SELECT 1 FROM events WHERE id = ? AND project = ? AND start = ? AND end = ?",
                (event["id"], event["project"], event["start"], event["end"]))
    return cur.fetchone() is not None

def _add(args: argparse.Namespace) -> None:
    conn = sqlite3.connect(args.db)
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute(DB_SCHEMA)
    try:
        events = json.loads(args.input)
        if not isinstance(events, list):
            raise ValueError("input must be a JSON array of events")
        for e in events:
            try:
                ev = _normalize_event(e)
            except ValueError as exc:
                print(json.dumps({"error": str(exc)}), file=sys.stderr)
                sys.exit(1)
            if _check_duplicates(conn, ev):
                print(json.dumps({"inserted": 0, "duplicates": 1}), file=sys.stderr)
                sys.exit(0)
            _validate_event(ev)
            _insert_event(conn, ev)
        print(json.dumps({"inserted": len(events), "duplicates": 0}), file=sys.stderr)
    finally:
        conn.close()

def _import(args: argparse.Namespace) -> None:
    conn = sqlite3.connect(args.db)
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute(DB_SCHEMA)
    try:
        events = json.loads(args.input)
        if not isinstance(events, list):
            raise ValueError("input must be a JSON array of events")
        conflicts = []
        for e in events:
            try:
                ev = _normalize_event(e)
            except ValueError as exc:
                conflicts.append({"id": ev["id"], "project": ev["project"], "start": ev["start"], "end": ev["end"], "error": str(exc)})
                continue
            if _check_duplicates(conn, ev):
                conflicts.append({"id": ev["id"], "project": ev["project"], "start": ev["start"], "end": ev["end"], "error": "duplicate"})
                continue
            _validate_event(ev)
            _insert_event(conn, ev)
        print(json.dumps({"inserted": len(events) - len(conflicts), "duplicates": 0}), file=sys.stderr)
        if conflicts:
            print(json.dumps({"conflicts": conflicts}), file=sys.stderr)
    finally:
        conn.close()

def _stats(args: argparse.Namespace) -> None:
    conn = sqlite3.connect(args.db)
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute(DB_SCHEMA)
    try:
        from_dt = datetime.fromisoformat(args.from_)
        to_dt = datetime.fromisoformat(args.to_)
        if to_dt <= from_dt:
            raise ValueError("to must be after from")
        cur = conn.cursor()
        cur.execute("SELECT id, project, start, end FROM events WHERE start >= ? AND end <= ? ORDER BY id, project",
                    (from_dt.replace(tzinfo=timezone.utc), to_dt.replace(tzinfo=timezone.utc)))
        rows = cur.fetchall()
        days: dict[str, dict[str, int]] = {}
        total = 0
        for id_, project, start, end in rows:
            start_utc = _to_utc(start)
            end_utc = _to_utc(end)
            day = start_utc.date()
            while day <= end_utc.date():
                key = f"{day}"
                days[key] = days.get(key, {})
                days[key][project] = days[key].get(project, 0) + int((end_utc - start_utc).total_seconds())
                total += int((end_utc - start_utc).total_seconds())
                day += timedelta(days=1)
        print(json.dumps({"days": [{"date": str(d), "projects": days[d], "total_seconds": sum(days[d].values())} for d in sorted(days)], "total_seconds": total}, indent=2))
    finally:
        conn.close()

def main() -> None:
    parser = argparse.ArgumentParser()
    subparsers = parser.add_subparsers(dest="command", required=True)

    add_parser = subparsers.add_parser("add")
    add_parser.add_argument("db", type=str)
    add_parser.add_argument("--input", type=str, required=True)
    add_parser.set_defaults(func=_add)

    import_parser = subparsers.add_parser("import")
    import_parser.add_argument("db", type=str)
    import_parser.add_argument("--input", type=str, required=True)
    import_parser.set_defaults(func=_import)

    stats_parser = subparsers.add_parser("stats")
    stats_parser.add_argument("db", type=str)
    stats_parser.add_argument("--from", type=str, required=True)
    stats_parser.add_argument("--to", type=str, required=True)
    stats_parser.set_defaults(func=_stats)

    args = parser.parse_args()
    args.func(args)

if __name__ == "__main__":
    main()
