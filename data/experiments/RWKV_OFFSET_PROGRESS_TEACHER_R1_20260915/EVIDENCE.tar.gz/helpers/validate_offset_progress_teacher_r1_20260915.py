from pathlib import Path
from dataclasses import replace
import sys,json,hashlib,importlib.util
R=Path('/home/chase/GitHub/RWKV-LH');sys.path.insert(0,str(R))
from rwkv_lh.correction_review import build_review_packet,validate_review,REVIEW_INSTRUCTION,REVIEW_SCHEMA
from rwkv_lh.strong_session import AuditedStrongClient
from rwkv_lh.supervisor_openai import SupervisorAPISettings
from rwkv_lh.runtime.settings import load_local_env
from rwkv_lh.coding_corrections import tree_sha256
from rwkv_lh.command_corrections import validate_command_correction
from rwkv_lh.workspace_snapshot import copy_verified_workspace,tree_identity
from rwkv_lh.harness import ActionHarness
from rwkv_lh.schema import GoalState,TaskAction
from rwkv_lh import model_io
D=R/'data/experiments/RWKV_OFFSET_PROGRESS_TEACHER_R1_20260915'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def load(name):
 path=R/'temp'/name;spec=importlib.util.spec_from_file_location(name[:-3],path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
checks={}
reg=json.loads((D/'REGISTRATION.json').read_text());load_local_env(R/'.env.local');settings=replace(SupervisorAPISettings.from_env(),retry_attempts=1,semantic_repair_attempts=0,fallback_models=(),plan_cache_enabled=False,planner_request_options={'thinking':{'type':'disabled'}},read_timeout_seconds=180)
save(D/'REVIEW_AND_VALIDATION_REGISTRATION.json',{'script_sha256':sha(Path(__file__)),'calls':2,'max_output_tokens':4096,'settings':settings.public_dict(),'checks':checks,'gate':'Original supplied command only, source-bound independent reviews. Running the existing public offset test should expose the already-reproduced bug with exit1 and assertion failures. This is valid failed-test progress, not a repaired task or claim of success; the tool may expect0 while actually reporting1. No parameter or answer repair.'})
for source in reg['sources']:
 root=Path(source['run_root']);folder=D/'runs'/source['id'];candidate=json.loads((folder/'CANDIDATE.json').read_text())
 if candidate.get('tool') not in ('check_command','run_command'):continue
 actual=source['actual'];snapshot=f"generation_snapshots/{actual['request_id']}/before";before=root/snapshot
 target=candidate['raw_output']+model_io.JSON_CALL_STOP_SUFFIXES[0];packet=build_review_packet(actual_rwkv_input=actual['input_text'],candidate=candidate['raw_output']);reviews=[]
 for repeat in (1,2):
  dest=folder/f'review-{repeat}';dest.mkdir()
  def audit(event):
   with (dest/'strong_trace.jsonl').open('a') as f:f.write(json.dumps(dict(event),ensure_ascii=False)+'\n')
  client=AuditedStrongClient(settings,audit_hook=audit);save(dest/'REQUEST.json',packet)
  try:
   value=client._request_json(phase='state_tune_target_review',run_id=source['id'],request_digest=hashlib.sha256(json.dumps(packet).encode()).hexdigest(),system_prompt=REVIEW_INSTRUCTION,request_payload=packet,schema=REVIEW_SCHEMA,max_tokens=4096)
   save(dest/'RAW_REVIEW.json',value);review=validate_review(packet,value);save(dest/'VALIDATED_REVIEW.json',review)
   reviews.append({'reviewer':settings.model+f'/independent-context-{repeat}','accepted':review['accepted'],'visible_evidence_only':True,'target_sha256':hashlib.sha256(target.encode()).hexdigest(),'input_sha256':packet['input_sha256'],'review_path':str(dest/'RAW_REVIEW.json'),'review_sha256':sha(dest/'RAW_REVIEW.json')})
  except Exception as exc:save(dest/'ERROR.json',{'error':type(exc).__name__+': '+str(exc)})
  finally:client.close()
 save(folder/'REVIEWS.json',reviews)
 if len(reviews)==2 and all(r['accepted'] for r in reviews):
  arguments={'run_root':str(root),'checkpoint_id':source['checkpoint'],'target_text':target,'model_sha256':'559371f5b9aef13189ae54b345ac096af4ad2b689996c05d89de687612b3ae65','source_files':source['source_files'],'expected_exit_code':1,'expected_output':['FAILED','AssertionError','+00:60'],'reviews':reviews,'output':str(folder/'validation')}
  save(folder/'VALIDATION_REGISTRATION.json',arguments);result=validate_command_correction(**arguments);print(source['id'],result['status'],flush=True)
 else:print(source['id'],'review_not_admitted',[r['accepted'] for r in reviews],flush=True)
