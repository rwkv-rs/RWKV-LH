from pathlib import Path
import json,hashlib,subprocess,tarfile
R=Path('/home/chase/GitHub/RWKV-LH');D=R/'data/experiments/RWKV_ATOMIC_CHANGE_R1_20260914';reg=json.loads((D/'REGISTRATION.json').read_text());rows=json.loads((D/'MECHANICAL.json').read_text());assert len(rows)==2
for name,sha in reg['source'].items():assert hashlib.sha256((R/name).read_bytes()).hexdigest()==sha
owner=['rwkv_lh/controller.py','rwkv_lh/model.py','rwkv_lh/supervisor_openai.py','tests/test_hybrid_supervisor.py','tests/test_supervisor_openai.py'];assert subprocess.check_output(['git','diff','--',*owner],cwd=R)==(D/'OWNER_BEFORE.diff').read_bytes()
S=Path(reg['jobs'][0]['workspace']);assert {str(p.relative_to(S)):hashlib.sha256(p.read_bytes()).hexdigest() for p in S.rglob('*') if p.is_file()}==reg['input_files']
counts=[]
for j,r in zip(reg['jobs'],rows):
 rr=json.loads((Path(j['output_dir'])/'execution/RESULT.json').read_text());cs=r['stages'][0]['calls'];counts.append(dict(task=r['task'],calls=len(cs),input_tokens=sum(c['input_tokens'] for c in cs),output_tokens=sum(c['output_tokens'] for c in cs),seconds=r['execution_elapsed_seconds'],protocol_rejections=rr['protocol_rejections'],termination=rr['termination_reason'],modified=r['changed_files'],final=r['final'],external_exit=r['external']['exit_code']))
(D/'COUNTS.json').write_text(json.dumps(counts,ensure_ascii=False,indent=2))
with tarfile.open(D/'EVIDENCE.tar.gz','w:gz') as tar:
 for name in ['runs','external']:tar.add(D/name,arcname=name)
 for name in ['run_atomic_change_r1_20260914.py','audit_atomic_change_20260914.py','close_atomic_change_20260914.py','clean_verified_duplicates_20260914.py']:tar.add(R/'temp'/name,arcname='analysis_scripts/'+name)
print(json.dumps(counts,ensure_ascii=False,indent=2))
