from pathlib import Path
import sys,json,hashlib,datetime,subprocess
R=Path('/home/chase/GitHub/RWKV-LH');D=R/'data/experiments/RWKV_ATOMIC_CHANGE_R1_20260914';D.mkdir(exist_ok=False)
S=R/'data/experiments/RWKV_QUERY_REPAIR_FEEDBACK_R1_20260914/source'
request='修复 document_index/query.py 中未指定 limit 时查询失败的问题，保持其它查询行为及测试文件不变。当前只完成这一处修改，然后根据实际修改报告结果，并提出下一步建议；如果没有运行测试，明确说明尚未运行，不把建议当成已执行。已有 test_failure.txt 是历史失败日志。'
jobs=[dict(task_id=f'atomic-{i}',request=request,workspace=str(S),output_dir=str(D/'runs'/f'atomic-{i}'),tool_scope='coding',max_calls=12,max_seconds=600) for i in (1,2)]
sys.path.insert(0,str(R))
from dataclasses import asdict,replace
from rwkv_lh.runtime.settings import get_runtime_settings
settings=replace(get_runtime_settings(),return_token_ids=True,state_transport='native_required',state_profile_id='zero',state_profile_sha256='0'*64,tool_disclosure_mode='full')
safe={k:v for k,v in asdict(settings).items() if not any(t in k for t in ('key','secret','client_id','proxy'))}
reg=dict(timestamp=datetime.datetime.now(datetime.timezone.utc).isoformat(),jobs=jobs,settings=safe,source={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for folder in ('rwkv_lh','scripts','tests') for p in sorted((R/folder).rglob('*.py'))},input_files={str(p.relative_to(S)):hashlib.sha256(p.read_bytes()).hexdigest() for p in S.rglob('*') if p.is_file()},criteria='Atomic modification qualifies only if original test unchanged, external original test passes, real code mutation occurred, final faithfully reports work and distinguishes next-step suggestion from executed actions. Model test execution is not required for this atomic phase. Next step should address verification or remaining user work supported by evidence. No fixed patch or tool order.',scope='Two repeated trials of one narrowed existing approved task; not matched causal ablation or whole-project completion. No new dataset version; no strong calls. Existing repeated-success protection unchanged.12 calls/600sec each, output1800, concurrency1.')
for name,v in [('REGISTRATION.json',reg),('JOBS.json',jobs)]: (D/name).write_text(json.dumps(v,ensure_ascii=False,indent=2))
subprocess.run([str(R/'.venv/bin/python'),str(R/'scripts/run_rwkv_agent.py'),'--jobs',str(D/'JOBS.json'),'--concurrency','1'],stdout=(D/'LIVE.log').open('w'),stderr=subprocess.STDOUT)
