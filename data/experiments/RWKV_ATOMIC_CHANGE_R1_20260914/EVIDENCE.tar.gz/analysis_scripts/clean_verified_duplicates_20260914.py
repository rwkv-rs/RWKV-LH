from pathlib import Path
import tarfile,hashlib,json,subprocess
R=Path('/home/chase/GitHub/RWKV-LH');D=R/'data/experiments/RWKV_ATOMIC_CHANGE_R1_20260914';entries=[]
for name in ('RWKV_GOAL_DELIVERY_R1_20260914','RWKV_ASSISTED_RECOVERY_R1_20260914','RWKV_ASSISTED_AGENT_R1_20260914'):
 exp=R/'data/experiments'/name;archive=exp/'EVIDENCE.tar.gz';asha=hashlib.sha256(archive.read_bytes()).hexdigest()
 with tarfile.open(archive) as tar:
  for member in tar.getmembers():
   if not member.isfile():continue
   if member.name.startswith('analysis_scripts/'):
    p=R/'temp'/Path(member.name).name
   elif member.name.startswith('external/'):
    p=exp/member.name
   else:continue
   if not p.is_file() or p.is_symlink():continue
   data=p.read_bytes();arch=tar.extractfile(member).read()
   if data!=arch:continue
   if subprocess.check_output(['git','ls-files','--',str(p)],cwd=R).strip():continue
   entries.append(dict(path=str(p.relative_to(R)),sha256=hashlib.sha256(data).hexdigest(),bytes=len(data),archive=str(archive.relative_to(R)),archive_sha256=asha,member=member.name))
unique={e['path']:e for e in entries};entries=list(unique.values());(D/'CLEANUP_PLAN.json').write_text(json.dumps(entries,indent=2));print('verified duplicate files',len(entries),'bytes',sum(e['bytes'] for e in entries))
