"""Experiment worker: abort on declared/effective sampling mismatch before generation."""
from collect_cli_atomic_creation_r1_20260914 import R, save, sha
from pathlib import Path
import json,time
from rwkv_lh.coding_agent import run_coding_job
from rwkv_lh.model_session import create_model_session, SessionSampling
from rwkv_lh.correction_snapshots import generation_snapshot_audit

def worker(job,settings,pins):
 try:
  assert all(sha(R/p)==h for p,h in pins.items())
  output=Path(job.output_dir);workspace=output/'workspace';execution=output/'execution'
  expected=SessionSampling.from_settings(settings).to_dict()
  def factory(*,settings,audit_hook):
   wrapped=generation_snapshot_audit(workspace=workspace,output=execution,audit_hook=audit_hook)
   def checked(event):
    if event.get('type')=='model_session_generation_started':
     observed=event.get('sampling')
     save(execution/'SAMPLING_PREFLIGHT.json',{'expected':expected,'actual':observed,'match':observed==expected,'request_id':event.get('request_id')})
     if observed != expected:raise RuntimeError('Configured and effective sampling differ; experiment stopped before generation')
    with (execution/'AUDIT_TIMINGS.jsonl').open('a') as f:f.write(json.dumps({'epoch':time.time(),'monotonic':time.monotonic(),'type':event.get('type'),'operation':event.get('operation'),'request_id':event.get('request_id')})+'\n')
    wrapped(event)
   return create_model_session(settings=settings,audit_hook=checked)
  result=run_coding_job(job,settings=settings,session_factory=factory)
 except Exception as exc:
  result={'id':job.task_id,'termination':'error','trace_complete':False,'error':type(exc).__name__+': '+str(exc)}
 save(Path(job.output_dir)/'COLLECTION_RESULT.json',result)
 return {'id':job.task_id,'result':result}
