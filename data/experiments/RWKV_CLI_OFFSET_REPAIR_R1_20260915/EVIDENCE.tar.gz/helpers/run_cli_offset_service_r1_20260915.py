"""Run preregistered CLI budget diagnostic exclusively after training/evaluation."""
from pathlib import Path
import subprocess,time,shlex,urllib.request,json,sys
R=Path('/home/chase/GitHub/RWKV-LH');root='/home/chase/GitHub/RWKV-LH-native-gc-r1-20260914'
for unit in ('rwkv-lh-unified-training-r3.service','rwkv-lh-unified-train3-eval-r1.service'):
 p=subprocess.run(['ssh','rwkv-8222','systemctl','--user','is-active',unit],capture_output=True,text=True)
 if p.stdout.strip() in ('active','activating','deactivating'):raise RuntimeError('GPU stage still active: '+unit)
for _ in range(90):
 p=subprocess.run(['ssh','rwkv-8222',"curl -fsS http://127.0.0.1:18234/metrics | grep -E '^vllm:num_requests_(running|waiting)'"],capture_output=True,text=True)
 if p.returncode==0 and p.stdout and all(float(x.rsplit(' ',1)[1])==0 for x in p.stdout.splitlines()):break
 time.sleep(2)
else:raise RuntimeError('original service idle readiness not established')
subprocess.run(['ssh','rwkv-8222','systemctl','--user','stop','rwkv-lh-native-current.service'],check=True)
socket=str(R/'temp/cli_offset_tunnel_r1.sock')
args=['systemd-run','--user','--unit=rwkv-lh-cli-offset-r1','--property=RuntimeMaxSec=1500','--property=ExecStopPost=/usr/bin/systemctl --user start rwkv-lh-native-current.service',f'--property=StandardOutput=append:{root}/cli_offset_service.log','--property=StandardError=inherit','bash',root+'/launch.sh']
try:
 subprocess.run(['ssh','rwkv-8222',shlex.join(args)],check=True)
 # A dedicated port avoids dependence on the previous experiment's tunnel lifetime.
 subprocess.run(['ssh','-o','BatchMode=yes','-o','ExitOnForwardFailure=yes','-o','ControlMaster=yes','-o',f'ControlPath={socket}','-o','ControlPersist=no','-fNT','-L','127.0.0.1:29624:127.0.0.1:18247','rwkv-8222'],check=True)
 for _ in range(150):
  try:
   value=json.loads(urllib.request.urlopen('http://127.0.0.1:29624/v1/models',timeout=2).read());assert value['data'][0]['id']=='rwkv-code-agent-gc-r1-ctx24576';break
  except (OSError,ValueError):time.sleep(2)
 else:raise RuntimeError('dedicated service readiness budget exceeded')
 subprocess.run([sys.executable,str(R/'temp/run_cli_offset_repair_r1_20260915.py')],cwd=R,check=True)
finally:
 subprocess.run(['ssh','rwkv-8222','systemctl','--user','stop','rwkv-lh-cli-offset-r1.service'])
 subprocess.run(['ssh','rwkv-8222','systemctl','--user','start','rwkv-lh-native-current.service'])
 if Path(socket).exists():subprocess.run(['ssh','-S',socket,'-O','exit','rwkv-8222'])
