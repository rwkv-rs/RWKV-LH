from pathlib import Path
import json,hashlib,shutil,subprocess,sys,collections
R=Path('/home/chase/GitHub/RWKV-LH');sys.path.insert(0,str(R))
from rwkv_lh.direct_trace_data import replay_run
from rwkv_lh.workspace_snapshot import tree_identity
D=R/'data/experiments/RWKV_CLI_OFFSET_REPAIR_R1_20260915';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
reg=json.loads((D/'RUN_REGISTRATION.json').read_text());prep=json.loads((D/'TASK_PREPARATION.json').read_text());assert all(sha(R/p)==h for p,h in reg['source_pins'].items());assert json.loads((D/'SOURCE_AFTER.json').read_text())['all_match']
helper=R/'temp/verify_cli_atomic_creation_r1_20260914.py';assert sha(helper)==reg['external_original_cli_helper_sha256'];rows=[]
for repeat in (1,2):
 root=D/'runs'/f'repeat-{repeat}';result=json.loads((root/'COLLECTION_RESULT.json').read_text());data=replay_run(root/'execution',reg['model_sha256']);raw=[r['raw_generation'] for r in data.values()]
 external=root/'external';external.mkdir(exist_ok=False);work=external/'workspace';shutil.copytree(root/'workspace',work);assert tree_identity(work)==tree_identity(root/'workspace')
 frozen=D/'source/test_timestamp_offset.py';test_unchanged=(work/'test_timestamp_offset.py').is_file() and sha(work/'test_timestamp_offset.py')==sha(frozen)
 public=frozen.read_text().replace("SCRIPT = Path(__file__).resolve().parent / 'timebook.py'", "SCRIPT = Path('timebook.py').resolve()")
 checked=subprocess.run([sys.executable,'-B','-c',public],cwd=work,text=True,capture_output=True,timeout=180)
 (external/'OFFSET_CHECK.json').write_text(json.dumps({'exit_code':checked.returncode,'stdout':checked.stdout,'stderr':checked.stderr,'frozen_test_sha256':sha(frozen),'test_unchanged':test_unchanged},ensure_ascii=False,indent=2)+'\n')
 subprocess.run([sys.executable,str(helper),'timebook-add',str(work),str(external/'CLI_CHECK.json')],check=True)
 cli=json.loads((external/'CLI_CHECK.json').read_text());functions=collections.Counter();calls=[]
 for cp,entry in data.items():
  r=entry['raw_generation']
  try:obj=json.loads(r['raw_output']);functions[obj.get('function','unknown')]+=1
  except (ValueError,AttributeError):obj=None;functions['not_complete_json']+=1
  calls.append({'checkpoint':cp,'request_id':entry['request_id'],'call':obj,'raw_output':r['raw_output'],'finish_reason':r['finish_reason']})
 (root/'CALLS_REVIEW.json').write_text(json.dumps(calls,ensure_ascii=False,indent=2)+'\n')
 rows.append({'repeat':repeat,'artifact_passed':checked.returncode==0 and cli['exit_code']==0 and test_unchanged,'offset_passed':checked.returncode==0,'original_cli_passed':cli['exit_code']==0,'test_unchanged':test_unchanged,'submitted':result.get('termination')=='submitted','termination':result.get('termination'),'termination_reason':result.get('termination_reason'),'changed_files':result.get('changed_files'),'generations':len(raw),'logical_input_tokens':sum(len(r['prompt_token_ids']) for r in raw),'output_tokens':sum(len(r['raw_token_ids']) for r in raw),'finish_reasons':dict(collections.Counter(r['finish_reason'] for r in raw)),'parsed_functions':dict(functions),'protocol_rejections':result.get('protocol_rejections'),'elapsed_seconds':result.get('elapsed_seconds'),'exact_replay':True,'semantic_review':'pending: actual test and faithful final required','sampling_match':all(r['sampling']==dict(temperature=.1,top_p=1.,top_k=0,presence_penalty=0.,frequency_penalty=0.,penalty_decay=.996) for r in raw)})
(D/'TRACE_AND_ARTIFACT_AUDIT.json').write_text(json.dumps({'rows':rows},ensure_ascii=False,indent=2)+'\n');print(json.dumps(rows,ensure_ascii=False,indent=2))
