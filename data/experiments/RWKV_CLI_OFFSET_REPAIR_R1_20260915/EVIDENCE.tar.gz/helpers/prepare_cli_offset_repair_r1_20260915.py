from pathlib import Path
import json,hashlib,shutil,subprocess,sys
R=Path('/home/chase/GitHub/RWKV-LH');D=R/'data/experiments/RWKV_CLI_OFFSET_REPAIR_R1_20260915';D.mkdir(exist_ok=False);W=D/'source';W.mkdir();base=R/'data/experiments/RWKV_CLI_LONG_OUTPUT_TEACHER_R2_20260915/runs/timebook-add';shutil.copy2(base/'artifact_check/workspace/timebook.py',W/'timebook.py');readme=R/'data/experiments/RWKV_CLI_ATOMIC_CREATION_R1_20260914/sources/timebook-add/README.md'
# Resolve the already registered README source without guessing a new task source.
original=json.loads((R/'data/experiments/RWKV_CLI_ATOMIC_CREATION_R1_20260914/TASKS_PREPARATION.json').read_text());source=next(x for x in original['jobs'] if x['id']=='timebook-add');shutil.copy2(Path(source['workspace'])/'README.md',W/'README.md')
check='''from pathlib import Path
import json, subprocess, sys, tempfile, unittest
SCRIPT = Path(__file__).resolve().parent / 'timebook.py'
class OffsetTests(unittest.TestCase):
    def test_offset_validation_and_existing_add(self):
        with tempfile.TemporaryDirectory() as td:
            db = Path(td) / 'time.sqlite'
            def invoke(ident, offset):
                return subprocess.run([sys.executable, str(SCRIPT), 'add', str(db), '--id', ident, '--project', 'team', '--start', '2024-02-29T08:00:00' + offset, '--end', '2024-02-29T09:00:00' + offset], capture_output=True, text=True, timeout=10)
            for n, offset in enumerate(('Z', '+00:00', '+08:00', '-08:00', '+05:30')):
                with self.subTest(valid=offset):
                    first = invoke('valid-' + str(n), offset)
                    self.assertEqual(first.returncode, 0, first.stderr)
                    self.assertEqual(json.loads(first.stdout), {'inserted': 1, 'duplicates': 0})
                    second = invoke('valid-' + str(n), offset)
                    self.assertEqual(second.returncode, 0, second.stderr)
                    self.assertEqual(json.loads(second.stdout), {'inserted': 0, 'duplicates': 1})
            for n, offset in enumerate(('+00:60', '+00:99', '-00:60', '+24:00', '+99:00')):
                with self.subTest(invalid=offset):
                    bad = invoke('bad-' + str(n), offset)
                    self.assertNotEqual(bad.returncode, 0, bad.stdout)
                    self.assertTrue(bad.stderr.strip())
if __name__ == '__main__': unittest.main()
'''
(W/'test_timestamp_offset.py').write_text(check);p=subprocess.run([sys.executable,'-B','test_timestamp_offset.py'],cwd=W,capture_output=True,text=True,timeout=60);assert p.returncode!=0
(D/'BASELINE_FAILURE.json').write_text(json.dumps({'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr},ensure_ascii=False,indent=2)+'\n');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
reg={'task_id':'fix-timebook-offset','request':'修复现有timebook.py的时间戳校验：非法UTC偏移被接受，正常add的持久化与幂等行为应保持。自主检查源码，修改实现，实际运行已有test_timestamp_offset.py并根据真实失败反馈继续修正；保留测试及要求，不修改测试来绕过问题。最后如实说明修改、实际验证和未解决事项。本轮只处理add，不实现import/stats。','workspace':str(W),'files':{p.name:sha(p) for p in W.iterdir() if p.is_file()},'origin':'Given implementation is a strong-generated correction candidate from an actual zero-RWKV creation failure. Its invalid-offset bug was independently reproduced. This trial credits only repairing the given implementation, never creating the whole CLI independently.','family':'CLI','split':'train','source_candidate':str(base/'CANDIDATE.json'),'source_candidate_sha256':sha(base/'CANDIDATE.json'),'defect_evidence':str(base/'CURATION_OFFSET_PROBE.json'),'defect_evidence_sha256':sha(base/'CURATION_OFFSET_PROBE.json'),'helper_sha256':sha(Path(__file__)),'acceptance':'Unchanged visible offset test passes and original frozen scoped CLI checks pass on an isolated copy; actual agent test execution and faithful final required. Different implementation allowed. Raw failures preserved.','planned_settings':{'state':'zero','context':24576,'max_output_tokens':1800,'temperature':0.1,'top_p':1,'top_k':0,'presence_penalty':0,'frequency_penalty':0,'penalty_decay':0.996,'calls_per_task':24,'seconds_per_task':900,'repeats':2,'concurrency':2},'dataset':'No new dataset version. Only later real RWKV traces with independently validated corrections can enter an approved freeze.'}
(D/'TASK_PREPARATION.json').write_text(json.dumps(reg,ensure_ascii=False,indent=2)+'\n');print('frozen source and public check baseline failure')
