from pathlib import Path
from dataclasses import replace
from concurrent.futures import ProcessPoolExecutor,as_completed
from multiprocessing import get_context
import json,time,subprocess,urllib.request
from collect_cli_atomic_creation_r1_20260914 import R,save,sha
from cli_sampling_checked_worker_r1_20260915 import worker
from rwkv_lh.runtime.settings import load_local_env,get_runtime_settings,direct_agent_settings
from rwkv_lh.coding_agent import CodingJob
from rwkv_lh.agent_batch import validate_agent_jobs
D=R/'data/experiments/RWKV_CLI_OFFSET_REPAIR_R1_20260915'
if __name__=='__main__':
 assert not (D/'RUN_REGISTRATION.json').exists();load_local_env(R/'.env.local');reg=json.loads((D/'TASK_PREPARATION.json').read_text());assert all(sha(Path(reg['workspace'])/p)==h for p,h in reg['files'].items())
 settings=direct_agent_settings(replace(get_runtime_settings(),base_url='http://127.0.0.1:29624/v1',model='rwkv-code-agent-gc-r1-ctx24576',model_sha256='559371f5b9aef13189ae54b345ac096af4ad2b689996c05d89de687612b3ae65',max_model_len=24576,state_profile_id='zero',state_profile_sha256='0'*64,read_timeout_seconds=180,default_temperature=.1,default_top_p=1,default_top_k=0,default_presence_penalty=0,default_frequency_penalty=0,default_penalty_decay=.996,action_max_output_tokens=1800))
 pins={str(p.relative_to(R)):sha(p) for p in (R/'rwkv_lh').rglob('*.py')};jobs=[CodingJob(f'fix-timebook-offset-r{r}',reg['request'],reg['workspace'],str(D/'runs'/f'repeat-{r}'),24,900) for r in (1,2)];validate_agent_jobs(jobs,concurrency=2)
 save(D/'RUN_REGISTRATION.json',{'preparation_sha256':sha(D/'TASK_PREPARATION.json'),'source_pins':pins,'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'helper_sha256':sha(Path(__file__)),'worker_sha256':sha(R/'temp/cli_sampling_checked_worker_r1_20260915.py'),'model':settings.model,'model_sha256':settings.model_sha256,'configuration':reg['planned_settings'],'external_original_cli_helper_sha256':sha(R/'temp/verify_cli_atomic_creation_r1_20260914.py'),'attribution':'RWKV independently repairs a given implementation prepared by a strong model; no credit for creating the original project. Production run remains unchanged. Data candidate collection from real calls, no automatic training admission.'})
 for name in ('models','capabilities'):save(D/(name.upper()+'.json'),json.loads(urllib.request.urlopen(settings.base_url+'/'+name,timeout=15).read()))
 results=[];start=time.monotonic()
 with ProcessPoolExecutor(max_workers=2,mp_context=get_context('spawn')) as pool:
  fs={pool.submit(worker,j,settings,pins):j.task_id for j in jobs}
  for f in as_completed(fs):
   row=f.result();results.append(row);save(D/'RESULTS.json',results);print(row['id'],row['result']['termination'],row['result']['termination_reason'],flush=True)
 assert all(sha(R/p)==h for p,h in pins.items());save(D/'SOURCE_AFTER.json',{'all_match':True,'elapsed_seconds':time.monotonic()-start})
