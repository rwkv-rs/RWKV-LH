from pathlib import Path
import json
D=Path('/home/chase/GitHub/RWKV-LH/data/experiments/RWKV_PLAIN_TEXT_SUMMARY_R2_20260913');p=D/'SEMANTIC_REVIEW.json';rows=json.loads(p.read_text())
reviews={
'3b168b45a7':('partial',[],[('purpose','partial','简单健康检查端点/HTTP服务器入口，未说明初始骨架'),('get','covered','health200 JSON，其他路径501 not_implemented'),('db','omitted','仅列必需--db，未说参数未使用'),('cli','covered','db/port必填，host可选默认本地'),('threads','covered','ThreadingHTTPServer'),('json','covered','JSON响应')]),
'59bdd0b752':('partial',[],[('purpose','partial','简单HTTP入口，仅处理GET，未说明待完成合同的骨架性质'),('get','covered','health200，其他501 not_implemented'),('db','omitted','列db必填，没有说明未使用'),('cli','covered','db、port、host参数'),('threads','covered','多线程ThreadingHTTPServer'),('json','covered','JSON响应')]),
'aa47de868a':('partial',[],[('purpose','covered','库存订单README，SQLite和HTTP'),('idempotency','covered','库存管理、订单创建及幂等性控制；术语可概括避免重复效果，不要求逐字重复扣减'),('atomic','partial','仅列事务保证与并发数据一致性，没有解释整单全成或全败/避免部分扣减'),('normalization','omitted','未概括规范化及同key异请求冲突'),('failure_key','omitted','未提失败不占key'),('concurrency','partial','只说并发数据一致性，未说明不超卖'),('persistence','omitted','仅提SQLite，未说明重启持久'),('verification','omitted','未说明健康检查的业务验证边界')])}
for key,(quality,issues,facts) in reviews.items():
 assert key not in {x['anonymous_id'] for x in rows};rows.append(dict(anonymous_id=key,quality=quality,fact_assessments=[dict(id=i,coverage=c,evidence_or_reason=e) for i,c,e in facts],factual_issues=issues,false_completion=False,reviewer='single Codex reviewer; anonymous packets, orchestration context known',rubric_changed=False))
p.write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
