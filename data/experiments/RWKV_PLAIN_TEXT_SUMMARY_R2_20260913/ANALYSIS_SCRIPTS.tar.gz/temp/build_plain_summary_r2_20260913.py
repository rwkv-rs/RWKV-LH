from pathlib import Path
R=Path('/home/chase/GitHub/RWKV-LH');s=(R/'temp/run_read_summary_pathway_r1_20260912.py').read_text().replace('RWKV_READ_SUMMARY_PATHWAY_R1_20260912','RWKV_PLAIN_TEXT_SUMMARY_R2_20260913')
s=s.replace('from rwkv_lh.schema import RunStatus','from rwkv_lh.schema import RunStatus, ModelLaneKind, ModelCheckpointStatus\nfrom rwkv_lh.token_budget import tokenizer')
s=s.replace("def run():",'''def plain_prompt(request,path,content):
 return f"User: {request}\\n\\n以下是指定文件 {path} 的完整内容：\\n<file>\\n{content}\\n</file>\\n\\nAssistant: "

def plain_generate(session,prompt,out,budget):
 cp=session._checkpoint(lane_id=out.name,lane_kind=ModelLaneKind.ACTION,parent_checkpoint_id=None,transcript=prompt,event_ids=(),status=ModelCheckpointStatus.COMMITTED)
 cp.native_state_metadata['native_input_pending']=True
 if len(tokenizer().encode(prompt))+1+budget>session.settings.max_model_len:raise RuntimeError('plain_context_budget')
 session.materialize_input(cp,{cp.checkpoint_id:cp})
 save(out/'plain_root.json',cp.to_dict())
 candidate=session.generate(cp,sampling=LongHorizonModel._SAMPLING,max_output_tokens=budget,json_output=False)
 save(out/'plain_candidate.json',candidate.checkpoint.to_dict())
 save(out/'plain_raw_generation.json',candidate.raw_record())
 # No JSON parser, no fabricated final_answer, no rewrite/repair. Candidate kept as terminal generation evidence.
 return candidate.raw_output,candidate.finish_reason

def run():''')
s=s.replace("    model=LongHorizonModel(create_model_session(settings=settings,audit_hook=audit),harness=ActionHarness())", """    if arm=='plain':
     prompt=plain_prompt(c['common_request'],c['path'],(source/c['path']).read_text())
     (out/'PLAIN_INPUT.txt').write_text(prompt)
     session=create_model_session(settings=settings,audit_hook=audit)
     output,finish=plain_generate(session,prompt,out,reg['max_output_tokens'])
     result['raw_plain_output']=output;result['finish_reason']=finish
     result['final_output']=output if finish=='stop' and output.strip() else None
     result['termination']='plain_stop' if result['final_output'] is not None else 'plain_'+finish
     continue
    model=LongHorizonModel(create_model_session(settings=settings,audit_hook=audit),harness=ActionHarness())""")
# A continue inside try would run finally but skip batch infrastructure check only on successful plain path; exceptions still stop normally.
s=s.replace("    if arm=='direct':request+=reg['attachment_prefix'].format(path=c['path'])+(source/c['path']).read_text()+reg['attachment_suffix']",'')
(R/'temp/run_plain_summary_r2_20260913.py').write_text(s)
