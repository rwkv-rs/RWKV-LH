from pathlib import Path
import sys,json,hashlib
R=Path('/home/chase/GitHub/RWKV-LH');sys.path.insert(0,str(R));D=R/'data/experiments/RWKV_PLAIN_TEXT_SUMMARY_R2_20260913'
from rwkv_lh.token_budget import tokenizer
from run_plain_summary_r2_20260913 import plain_prompt
from rwkv_lh.model_io import render_event_append
from rwkv_lh.schema import ModelEvent
from verify_pathway_input_envelope_r1_20260912 import request_in_bootstrap

def inspect_run(p,c,arm):
 result=json.loads((p/'RESULT.json').read_text());source=(R/c['workspace_source']/c['path']).read_text();tr=[json.loads(l) for l in (p/'model_trace.jsonl').read_text().splitlines()];gens=[e for e in tr if e['type']=='model_session_generation_returned'];starts={e['request_id']:e for e in tr if e['type']=='model_session_generation_started'}
 if arm=='plain':
  root=json.loads((p/'plain_root.json').read_text());candidate=json.loads((p/'plain_candidate.json').read_text());states={x['checkpoint_id']:x for x in [root,candidate]};request_ok=root['transcript']==(p/'PLAIN_INPUT.txt').read_text()==plain_prompt(c['common_request'],c['path'],source);supplied=source in root['transcript'];tool_count=0
 else:
  states=json.loads((p/'state_snapshot.json').read_text())['model_states'];root=next(x for x in states.values() if not x['parent_checkpoint_id']);request=json.loads((p/'REQUEST.json').read_text())['request'];request_ok=request_in_bootstrap(root['transcript'],request) and (arm=='direct' or request==c['common_request']);supplied=arm=='direct' and source in request;tool_count=len(json.loads(root['transcript'].splitlines()[0].removeprefix('System: Tools: ')))
 gen_by_cp={e['candidate_checkpoint_id']:e['raw_generation'] for e in gens};calls=[]
 for e in gens:
  g=e['raw_generation'];st=starts[e['request_id']];cp=states[st['input_checkpoint_id']];chain=[];cur=cp
  while cur:chain.append(cur);cur=states.get(cur['parent_checkpoint_id'])
  ids=[]
  for x in reversed(chain):ids.extend(gen_by_cp[x['checkpoint_id']]['raw_token_ids'] if x['checkpoint_id'] in gen_by_cp else tokenizer().encode(x['transcript']))
  calls.append(dict(input_exact=g['prompt_token_ids'][g['input_bos_token_count']:]==ids,input_digest_matches=st['input_digest']==cp['native_state_digest'],input_checkpoint=cp['checkpoint_id'],input_tokens=len(g['prompt_token_ids']),output_tokens=len(g['raw_token_ids']),finish=g['finish_reason'],sampling=g['sampling'],profile=g['state_profile_id'],profile_sha256=g['state_profile_sha256'],max_output_tokens=g['max_output_tokens'],actual_input=tokenizer().decode(ids)))
 handoffs=[];reads=0;read_calls=0
 for n,(a,h) in enumerate(zip(result['actions'],result['handoffs']),1):
  ev=json.loads((p/f'observation_{n}.json').read_text());child=states[h['child']];rendered=render_event_append(ModelEvent.from_dict(ev));valid=child['transcript']==rendered and child['parent_checkpoint_id']==h['parent'] and child['event_ids'].count(h['event_id'])==1 and sum(x['transcript']==rendered for x in states.values())==1
  if n<len(calls):valid=valid and calls[n]['input_checkpoint']==h['child']
  handoffs.append(valid)
  if a['action_type']=='read_file':
   read_calls+=1;obs=ev['payload']['result'].get('observation',{});full=a['result'].get('success',False) and a['result'].get('output')==source and ''.join(x['content'] for x in obs.get('exact_spans',[]))==source and obs.get('projection_complete',False) and (p/'workspace'/a['arguments']['path']).resolve()==(p/'workspace'/c['path']).resolve();reads+=int(full);supplied=supplied or full
 return dict(run=p.name,arm=arm,case=c['id'],repeat=result['repeat'],request_valid=request_ok,source_acquired=supplied,engineering_valid=request_ok and supplied and all(x['input_exact'] and x['input_digest_matches'] for x in calls) and all(handoffs) and result['workspace_unchanged'] and tool_count==(0 if arm=='plain' else 19),complete_reads=reads,read_calls=read_calls,tool_calls=len(result['actions']),calls=calls,handoffs=handoffs,termination=result['termination'],elapsed_seconds=result['elapsed_seconds'],root_checkpoint=root['checkpoint_id'],root_native_identity=root['native_state_metadata'],submitted=result['final_output'] is not None,protocol_error=result['protocol_error'],infrastructure_error=result['infrastructure_error'])

def main():
 reg=json.loads((D/'REGISTRATION.json').read_text());rows=[];packets=[];mapping={}
 for item in reg['schedule']:
  p=D/'runs'/item['id'];c=next(x for x in reg['cases'] if x['id']==item['case'])
  if not (p/'RESULT.json').exists():continue
  row=inspect_run(p,c,item['arm'])
  for n,call in enumerate(row['calls'],1):(p/f'input_{n:02d}.txt').write_text(call.pop('actual_input'))
  rows.append(row);r=json.loads((p/'RESULT.json').read_text());key=hashlib.sha256(('plain-r2:'+p.name).encode()).hexdigest()[:10];mapping[key]=p.name;packets.append(dict(id=key,task=c['common_request'],file=(R/c['workspace_source']/c['path']).read_text(),facts=c['facts_external_only'],final=r['final_output']))
 for name,value in [('MECHANICAL_AUDIT.json',rows),('ANONYMOUS_MAPPING.json',mapping),('ANONYMOUS_REVIEW_INPUT.json',sorted(packets,key=lambda x:x['id']))]:(D/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
 print('audited',len(rows),'engineering',sum(x['engineering_valid'] for x in rows),'calls',sum(len(x['calls']) for x in rows))
if __name__=='__main__':main()
