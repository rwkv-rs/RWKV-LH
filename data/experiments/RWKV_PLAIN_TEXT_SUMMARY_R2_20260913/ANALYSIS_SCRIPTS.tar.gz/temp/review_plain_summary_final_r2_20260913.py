from pathlib import Path
import json
D=Path('/home/chase/GitHub/RWKV-LH/data/experiments/RWKV_PLAIN_TEXT_SUMMARY_R2_20260913');p=D/'SEMANTIC_REVIEW.json';rows=json.loads(p.read_text())
for key,cli in [('8749ff85d9','partial'),('bda93fdf40','omitted')]:
 assert key not in {x['anonymous_id'] for x in rows};rows.append(dict(anonymous_id=key,quality='satisfies',fact_assessments=[dict(id='purpose',coverage='covered',evidence_or_reason='仅健康检查，不验证预订/订单或其他业务逻辑'),dict(id='assertions',coverage='covered',evidence_or_reason='GET /health检查200及JSON ok=true'),dict(id='cli',coverage=cli,evidence_or_reason='没有明说HOST/PORT来自命令行；重要项允许遗漏')],factual_issues=[],false_completion=False,reviewer='single Codex reviewer; anonymous packets, orchestration context known',rubric_changed=False))
p.write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
