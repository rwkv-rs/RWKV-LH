from pathlib import Path
import sys,json,hashlib,subprocess,time,tarfile
R=Path('/home/chase/GitHub/RWKV-LH');sys.path.insert(0,str(R));D=R/'data/experiments/RWKV_PLAIN_TEXT_SUMMARY_R2_20260913'
from rwkv_lh.model import LongHorizonModel
from rwkv_lh.runtime.settings import get_runtime_settings,load_local_env
from run_plain_summary_r2_20260913 import plain_prompt,inventory
load_local_env(R/'.env.local')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
x=json.loads((D/'CASES_AND_RUBRIC.json').read_text());s=get_runtime_settings();pins={str(p.relative_to(R)):sha(p) for p in sorted((R/'rwkv_lh').rglob('*')) if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc'}
for pattern in ['temp/*plain_summary*r2_20260913.py','tests/*.py']:
 for p in R.glob(pattern):pins[str(p.relative_to(R))]=sha(p)
for p in ['temp/verify_pathway_input_envelope_r1_20260912.py','pyproject.toml','uv.lock','AGENTS.md','docs/RWKV_CODING_AGENT_HARNESS_V1.zh-CN.md']:pins[p]=sha(R/p)
schedule=[]
for repeat in [1,2]:
 for c in x['cases']:
  assert inventory(R/c['workspace_source'])==c['workspace_sha256']
  for arm in (['plain','tool'] if repeat==1 else ['tool','plain']):schedule.append(dict(id=f"attempt-{len(schedule)+1:02d}",case=c['id'],arm=arm,repeat=repeat))
reg=dict(round=D.name,frozen_at_epoch=time.time(),authorization='Owner 2026-09-13 approved true plain-text vs production read diagnostic and offline assistance preparation; no training/datasets/strong calls/GitHub',cases=x['cases'],rubric=x['rubric'],rubric_source_sha256=sha(D/'CASES_AND_RUBRIC.json'),schedule=schedule,source_pins=pins,model_sha256=s.model_sha256,server_identity_sha256=sha(D/'SERVER_IDENTITY.json'),sampling=LongHorizonModel._SAMPLING.to_dict(),seed='not set',state='fresh native_required zero each attempt; same model/tokenizer identity. Plain native root contains only frozen diagnostic text; production carries observation child. Never interchange tasks or models.',max_output_tokens=1800,max_decisions_per_case=4,max_generations=40,max_output_tokens_batch=72000,wall_seconds_batch=3600,wall_policy='No new generation past 3600s; in-flight production transport recovery/read timeout180s retained; no semantic retry.',constraints=['只读任务：不得修改文件、启动服务或调用有副作用的工具。'],plain_policy='One native generate(json_output=False) with no JSON/tool stop fences; natural stop and nonempty raw text counts submitted. length/empty/error not complete; raw candidate saved without forged command or JSON commit. No parsing/extraction/rewrite. Diagnostic text uses existing native session checkpoint/materialize/generate mechanics but intentionally not Agent input protocol.',production_policy='Same R4 description and19tool production builders/loop; any legal read-only route allowed. max4 generations incl raw final. No forced tool sequence or forced Final.',confounds='Whole plain task vs full Agent packaging/tool execution, including decoding termination and history. Same per-answer1800 cap, not equal total compute; no single-factor State/metadata inference or production cost superiority claim.',plain_inputs_sha256={c['id']:hashlib.sha256(plain_prompt(c['common_request'],c['path'],(R/c['workspace_source']/c['path']).read_text()).encode()).hexdigest() for c in x['cases']},stop='Natural plain stop/raw production final_answer, protocol/context/resource limit or infrastructure. Infrastructure stops batch; same-request transport recovery only. No replacement cases.',budget={'strong_calls':0,'new_paid_api':0,'rented_resources':0,'existing_service_window_seconds':3600,'monetary_cost':'NA: self-hosted rate and GPU telemetry unavailable; not zero','plain_generations':8,'production_generations_max':32},review='Same previously frozen rubric, no old rescore; anonymous task/source/raw-final packets, single Codex reviewer with orchestration context limitation. All core covered plus fidelity for satisfies; optional details may be omitted. More legal calls cost only.',gate='Each arm two repeats4/4, no unsupported assertions or engineering errors; fixed group only. No automatic escalation.',local_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip())
assert reg['model_sha256']=='559371f5b9aef13189ae54b345ac096af4ad2b689996c05d89de687612b3ae65'
assert not (D/'REGISTRATION.json').exists();save(D/'REGISTRATION.json',reg);save(D/'SOURCE_MANIFEST.json',pins);save(D/'PREEXISTING_CHANGES.json',{'files':{p:sha(R/p) for p in subprocess.check_output(['git','diff','--name-only'],cwd=R,text=True).splitlines()}})
with tarfile.open(D/'FROZEN_SOURCE.tar.gz','w:gz') as t:
 for p in pins:t.add(R/p,arcname=p)
print('FROZEN',sha(D/'REGISTRATION.json'))
