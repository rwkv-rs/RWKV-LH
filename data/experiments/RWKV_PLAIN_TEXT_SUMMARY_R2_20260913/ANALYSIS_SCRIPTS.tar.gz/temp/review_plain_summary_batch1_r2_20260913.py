from pathlib import Path
import json
D=Path('/home/chase/GitHub/RWKV-LH/data/experiments/RWKV_PLAIN_TEXT_SUMMARY_R2_20260913')
reviews={
'20ea859b53':('satisfies',[],[('purpose','covered','会议资源预约服务的说明文档；内部会议室与设备预约'),('conflict','covered','创建预约需提供资源、开始与结束时间；冲突预约不能重叠。资源预约上下文下概括时段冲突，没有宣称不同资源也互斥；非逐字规则复述'),('cancel','covered','取消后时段可被重新预约'),('failure','omitted','列400等错误码但未说失败不改变预约'),('atomic','covered','冲突判定与写入必须为同一原子操作'),('persistence','covered','后续启动保留数据'),('verification','covered','不能以健康检查替代完整功能')]),
'3c45f5bfb0':('partial',[{'quote':'服务要求所有响应都是 JSON 格式，并且不允许未经文件支持的事实','kind':'localized_unsupported','evidence':'所有响应JSON是文件要求；不补充未经文件支持事实是用户摘要指令，不是服务需求。','impact':'混淆任务指令与被总结资料，加入一条无依据的服务约束。'}],[('purpose','covered','库存与订单服务说明文档；SQLite HTTP订单服务'),('idempotency','covered','解决网络重试重复扣库存；概括目标但未展开key机制，允许不同措辞'),('atomic','partial','提到解决多行订单部分扣减问题，但未说明全成或全败/整体无写入'),('normalization','omitted','未概括规范化/同key异请求冲突'),('failure_key','omitted','未提失败不占key'),('concurrency','omitted','未提不超卖'),('persistence','omitted','仅说SQLite/命令行，未说明重启持久'),('verification','omitted','仅列健康检查接口，未说明验证边界')]),
'b309c164a2':('partial',[{'quote':'GET /bookings：返回所有预约…200 返回 JSON 数组','kind':'localized_contradiction','evidence':'原文返回对象{"bookings":[...]}，不是顶层JSON数组。','impact':'接口返回结构局部错误；预约主旨和时段冲突仍正确。'}],[('purpose','covered','会议资源预约服务；README概括'),('conflict','covered','同resource的confirmed预约不能重叠'),('cancel','partial','取消预约、重复幂等，未提时段释放'),('failure','omitted','未提失败不改变预约'),('atomic','covered','冲突判定与写入必须原子'),('persistence','covered','重启后数据和冲突规则继续正确'),('verification','covered','不得用健康检查替代完整功能验证')])}
rows=[]
for key,(quality,issues,facts) in reviews.items():rows.append(dict(anonymous_id=key,quality=quality,fact_assessments=[dict(id=i,coverage=c,evidence_or_reason=e) for i,c,e in facts],factual_issues=issues,false_completion=False,reviewer='single Codex reviewer; anonymous packets, orchestration context known',rubric_changed=False))
(D/'SEMANTIC_REVIEW.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
