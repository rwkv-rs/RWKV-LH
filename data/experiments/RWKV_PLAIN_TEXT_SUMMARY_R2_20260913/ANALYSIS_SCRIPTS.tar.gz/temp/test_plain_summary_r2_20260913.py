import json,sys
from pathlib import Path
from types import SimpleNamespace
import pytest
R=Path('/home/chase/GitHub/RWKV-LH');sys.path.insert(0,str(R));sys.path.insert(0,str(R/'temp'))
from run_plain_summary_r2_20260913 import plain_prompt,plain_generate
from audit_plain_summary_r2_20260913 import inspect_run
from rwkv_lh.model_session import ModelSession
from rwkv_lh.runtime.settings import RuntimeSettings

@pytest.mark.parametrize('item',list(json.loads((R/'data/experiments/RWKV_READ_SUMMARY_PATHWAY_R1_20260912/REGISTRATION.json').read_text())['schedule']),ids=lambda x:x['id'])
def test_old_true_inputs_including_json_escaping(item):
 reg=json.loads((R/'data/experiments/RWKV_READ_SUMMARY_PATHWAY_R1_20260912/REGISTRATION.json').read_text());c=next(x for x in reg['cases'] if x['id']==item['case']);result=inspect_run(R/'data/experiments/RWKV_READ_SUMMARY_PATHWAY_R1_20260912/runs'/item['id'],c,item['arm']);assert result['engineering_valid']

def test_plain_native_input_contains_only_task_and_source_and_preserves_output(tmp_path):
 reg=json.loads((R/'data/experiments/RWKV_READ_SUMMARY_PATHWAY_R1_20260912/REGISTRATION.json').read_text());c=reg['cases'][0];content=(R/c['workspace_source']/c['path']).read_text();prompt=plain_prompt(c['common_request'],c['path'],content);assert content in prompt;assert 'System: Tools:' not in prompt;assert 'immutable_request' not in prompt
 class Session:
  settings=RuntimeSettings(base_url='http://127.0.0.1:1/v1',api_key='',model='offline',model_sha256='x')
  def __init__(self):self.base=ModelSession(SimpleNamespace(model_name='offline'),settings=self.settings);self.calls=[]
  def _checkpoint(self,**kw):return self.base._checkpoint(**kw)
  def materialize_input(self,cp,checkpoints):assert cp.transcript==prompt;assert len(checkpoints)==1;self.calls.append('materialize')
  def generate(self,cp,**kw):
   assert kw['json_output'] is False;assert kw['max_output_tokens']==1800;self.calls.append('generate');return SimpleNamespace(raw_output='  ORIGINAL\n',finish_reason='stop',checkpoint=cp,raw_record=lambda:{'raw_output':'  ORIGINAL\n'})
 s=Session();output,finish=plain_generate(s,prompt,tmp_path,1800);assert output=='  ORIGINAL\n';assert finish=='stop';assert s.calls==['materialize','generate']
