from pathlib import Path
import json
D=Path('/home/chase/GitHub/RWKV-LH/data/experiments/RWKV_PLAIN_TEXT_SUMMARY_R2_20260913');p=D/'SEMANTIC_REVIEW.json';rows=json.loads(p.read_text())
reviews={
'376ddf0420':('partial',[],[('purpose','partial','简单的健康检查端点/服务器入口；未明确初始骨架'),('get','covered','health200和JSON；其他路径501 not_implemented'),('db','omitted','仅列--db必填，未说明数据库参数未使用'),('cli','covered','db/port必填，host默认127.0.0.1'),('threads','covered','启动ThreadingHTTPServer'),('json','covered','JSON响应')]),
'6aeb200298':('partial',[],[('purpose','partial','提供健康检查的HTTP服务器；未明确初始骨架'),('get','covered','仅GET health实现，其他路径501 not_implemented'),('db','omitted','列--db必需，未说明它未被实际使用'),('cli','covered','db、host、port命令行参数'),('threads','covered','ThreadingHTTPServer处理并发请求'),('json','covered','JSON响应')]),
'5199310694':('satisfies',[],[('purpose','covered','仅健康烟雾测试；不验证预订或订单；交易行为仍需单独测试'),('assertions','covered','GET /health检查200及ok为True'),('cli','partial','指定主机和端口；未明说来自命令行')]),
'ffab6d2087':('satisfies',[],[('purpose','covered','小型仓库SQLite HTTP订单服务需求概括'),('idempotency','covered','同key相同规范化请求同一订单，不再次扣库存'),('atomic','covered','失败整体无写入；库存判定、扣减及登记原子完成'),('normalization','covered','同SKU求和排序；同key不同请求409'),('failure_key','covered','不占用key，可更正请求重试'),('concurrency','covered','并发不同key不得超卖'),('persistence','covered','重启后库存订单key继续有效'),('verification','covered','公开验证只做健康检查，补充交易与恢复验证')])}
for key,(quality,issues,facts) in reviews.items():
 assert key not in {x['anonymous_id'] for x in rows};rows.append(dict(anonymous_id=key,quality=quality,fact_assessments=[dict(id=i,coverage=c,evidence_or_reason=e) for i,c,e in facts],factual_issues=issues,false_completion=False,reviewer='single Codex reviewer; anonymous packets, orchestration context known',rubric_changed=False))
p.write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
