from pathlib import Path
import json,hashlib,tarfile,collections
R=Path('/home/chase/GitHub/RWKV-LH');D=R/'data/experiments/RWKV_PLAIN_TEXT_SUMMARY_R2_20260913'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
reg=json.loads((D/'REGISTRATION.json').read_text());a=json.loads((D/'MECHANICAL_AUDIT.json').read_text());mapping=json.loads((D/'ANONYMOUS_MAPPING.json').read_text());reviews={mapping[x['anonymous_id']]:x for x in json.loads((D/'SEMANTIC_REVIEW.json').read_text())};ident=json.loads((D/'SERVER_IDENTITY.json').read_text())
assert len(a)==len(reviews)==16 and all(x['engineering_valid'] for x in a)
assert all(sha(R/p)==h for p,h in reg['source_pins'].items());pre=json.loads((D/'PREEXISTING_CHANGES.json').read_text())['files'];assert len(pre)==5 and all(sha(R/p)==h for p,h in pre.items())
identity=[]
for row in a:
 p=D/'runs'/row['run'];states=({x['checkpoint_id']:x for x in [json.loads((p/'plain_root.json').read_text()),json.loads((p/'plain_candidate.json').read_text())]} if row['arm']=='plain' else json.loads((p/'state_snapshot.json').read_text())['model_states'])
 for cp in states.values():
  meta=cp['native_state_metadata'];parent=states.get(cp['parent_checkpoint_id']);valid=meta['model_sha256']==reg['model_sha256'] and meta['server_build']==ident['capabilities']['server_build'] and meta['tokenizer_build']==ident['capabilities']['tokenizer_build'] and cp['state_profile_id']=='zero' and cp['state_profile_sha256']=='0'*64 and meta['cache_binding']['parent_state_digest']==(parent['native_state_digest'] if parent else '')
  assert valid;identity.append(dict(run=row['run'],checkpoint=cp['checkpoint_id'],parent=cp['parent_checkpoint_id'],status=cp['status'],identity_and_parent_valid=valid))
 for c in row['calls']:assert c['sampling']==reg['sampling'] and c['max_output_tokens']==1800 and c['profile']=='zero' and c['profile_sha256']=='0'*64 and c['finish']=='stop'
assert len({x['root_checkpoint'] for x in a})==16
save(D/'STATE_IDENTITY_CHECK.json',identity)
joined=[]
for x in a:
 r=reviews[x['run']];joined.append(dict(run=x['run'],arm=x['arm'],case=x['case'],repeat=x['repeat'],submitted=x['submitted'],quality=r['quality'],task_pass=r['quality']=='satisfies' and x['engineering_valid'],engineering_valid=x['engineering_valid'],factual_issues=r['factual_issues'],false_completion=r['false_completion'],termination=x['termination']))
stats={}
for arm in ['plain','tool']:
 rr=[x for x in a if x['arm']==arm];q=[x for x in joined if x['arm']==arm];n=sum(x['task_pass'] for x in q);elapsed=sum(x['elapsed_seconds'] for x in rr)
 stats[arm]=dict(attempts=8,submitted=sum(x['submitted'] for x in rr),quality=dict(collections.Counter(x['quality'] for x in q)),task_pass=n,mutations=0,termination=dict(collections.Counter(x['termination'] for x in rr)),generation_calls=sum(len(x['calls']) for x in rr),tool_calls=sum(x['tool_calls'] for x in rr),complete_reads=sum(x['complete_reads'] for x in rr),input_tokens_full_context=sum(c['input_tokens'] for x in rr for c in x['calls']),output_tokens_raw=sum(c['output_tokens'] for x in rr for c in x['calls']),client_task_seconds=elapsed,client_seconds_per_qualified_including_failed=elapsed/n if n else None,monetary_cost_per_qualified=None,monetary_cost_reason='self-hosted rate and actual device telemetry unavailable, not zero',repeats={str(i):sum(x['task_pass'] for x in q if x['repeat']==i) for i in [1,2]},protocol_errors=sum(bool(x['protocol_error']) for x in rr),infrastructure_errors=sum(bool(x['infrastructure_error']) for x in rr),false_completion=sum(x['false_completion'] for x in q),stable_gate=False)
save(D/'TASK_RESULTS.json',dict(tasks=joined,arms=stats,project_strict=None,assistance='All independent RWKV; strong calls0',old_results_rescored=False))
validation=dict(source_pins_unchanged=True,preexisting_five_unchanged=True,environment='uv sync --frozen --extra selector-runtime --extra benchmark-web --group dev; playwright install chromium succeeded',full_tests={'passed':1514,'skipped':0,'seconds':243.94,'log_sha256':sha(D/'PYTEST_FULL.log')},diagnostic_tests={'passed':17,'log_sha256':sha(D/'DIAGNOSTIC_TESTS.log'),'fixture_error_retained':'Initial1failed/16passed was missing api_key argument in offline RuntimeSettings fixture; corrected before freeze, not production defect.'},assistance_prerequisites={'passed':7,'new_assistance_api_ready':False,'log_sha256':sha(D/'ASSISTANCE_PREREQUISITES.log')},prior_checker_regression='R1 archived red1/green2 plus all16 R1 actual traces verified with structural matcher in this round before freeze; original R1 scores unchanged',generations=24,independent_roots=16,checkpoint_identities=len(identity),tool_handoffs=8,read_regression='No production change; full offline read-contract tests passed; historical R4/R5 21/21+independent3/3 not newly rerun or pooled; new production read8/8 separately reported',datasets_created=False,training=False,github_updates=False)
save(D/'VALIDATION.json',validation)
table='\n'.join('| '+case+' | '+' | '.join('/'.join('满足' if next(x for x in joined if x['case']==case and x['arm']==arm and x['repeat']==i)['task_pass'] else '部分满足' for i in [1,2]) for arm in ['plain','tool'])+' |' for case in ['full_text-1','full_text-2','full_code-1','full_code-2'])
report=f'''# 真正纯文本摘要与生产读取闭环：R2诊断结果

轮次：{D.name}。Owner于2026-09-13批准执行纯文本对照和准备辅助交接离线回归。本轮不更新GitHub、不训练、不建datasets版本、不调用强模型、不扩大文件任务。生产代码和原五个未提交文件SHA全部保留。

## 任务结果

16/16提交原始回答；纯文本8次natural stop，生产8次final_answer自然终止，mutation0。纯文本组3/8满足、5/8部分满足；生产组4/8满足、4/8部分满足；无“不满足”或“无结果”。非法调用、重复调用循环、无总结终止、预算中断、基础设施失败、错误宣称实际操作/测试已完成均0。所有成果均RWKV独立，强模型调用0。不是项目Strict，不与旧R5 0/8或R1成绩相减作为收益。

| 文件用例 | 纯文本第一/第二遍 | 生产第一/第二遍 |
|---|---|---|
{table}

full_text-1为预约README，full_text-2为库存README，full_code-1为server.py，full_code-2为verify_public.py。本轮生产组每题自主一次read_file，再提交原Final；纯文本没有工具调用或虚构read事件。两个组均未达连续两遍4/4的固定组稳定门。

## 对照究竟改变了什么

沿用前轮原四文件、任务句子、原子事实与评分尺度，CASES_AND_RUBRIC.json与前轮逐字相同；文件SHA和原获准workspace清单冻结。每尝试fresh zero，模型/采样/1800单次输出上限一致，按第一遍plain→tool、第二遍tool→plain交错串行，目录用中性attempt编号。

纯文本输入仅“User:共同任务＋指定文件完整原文＋Assistant:”，没有19工具、Agent目标JSON、workspace manifest或观察元数据。复用原生session checkpoint/materialize/generate及完整token审计，json_output=False，不设JSON工具停止边界；只生成一次，无JSON解析/工具执行/答案提取/补写。终止candidate原样保存，不伪造final_answer提交去调用JSON commit。该参照经过owner授权，是诊断文本，不是第二套生产角色协议、生产替代架构或StateTune来源。

生产组仍调用唯一create_literal_goal/_assignment/render_bootstrap、next_command、真实Harness及观察追加，保留R4简短read说明和19工具，只读权限、最高4次生成。合法只读路径不限顺序，不自动补参数，不强制Final。两组每次回答1800上限相同，但总可用计算和停止格式并不相同；这是完整信息获取/Agent封装对照，不是单因素State消融。

## 可以确认的质量问题

- 四份server.py摘要都描述了health与其他GET未实现，但均未说明db参数只解析、未被数据库功能使用。去掉整个Agent工具封装并没有在本固定组消除该遗漏；不能把它解释为读不到文件、观察child接错或输出预算截断。
- 纯文本库存摘要偏概括甚至只列“事务保证”，没有清楚表达整单全成或全败；生产库存两遍主旨和关键保证覆盖充分。纯文本并非普遍更好。
- 两组均有任务/资料来源混淆：把“不补充文件未支持事实”或“不得修改文件/启动服务”等用户约束写成README服务要求。还有GET /bookings顶层JSON数组、列表接口404等局部不实补充。
- 健康脚本四份摘要都能覆盖健康检查、200与ok判断、非业务验证。可省略HOST/PORT来源等重要补充，不要求timeout/close/打印文字逐字复述。

每项核心/重要事实单独记覆盖、部分或遗漏。允许同义概括，不按词命中率：资源预约语境下的时段冲突可概括规则，幂等控制可表达避免重复效果；但只列“事务保证”而不解释整单行为记部分覆盖。问题项均有原输出引文及文件依据，见SEMANTIC_REVIEW.json。单一Codex评审，匿名包隐藏臂/路径，但评审者有先前调度上下文，不能称严格双盲或多人共识。

3/8与4/8的小样本差距不证明任一架构优越，也不证明RWKV普遍能力上限。当前证据仅支持：简化完整Agent封装未明显提升这四文件的合格率，共同关键遗漏仍在。没有依据为了这些遗漏立即重构State或添加角色流水线。

## 输入、State与资源

新结构化检查器先复核R1全部16真实轨迹，再用于本轮冻结；不修改旧R1判定。新轮16/16实际输入和来源检查通过，24次generation精确输入token与父链重建一致，8次生产工具结果全文/观察一次注入/后继child关系正确；16个独立root，48个checkpoint身份与父摘要一致。模型、tokenizer、服务、zero profile、sampling和实际输出预算均匹配冻结登记。纯文本无观察交接，不能把它算作8次生产State交接通过。

没有读取结果截断或生成length停止。raw输出、精确token数组、实际输入txt、工具观察、原生State身份与父子关系、终止原因均保存。正常路径检查不代表故障恢复和数值张量全面验证。

| 诊断指标 | 纯文本8题 | 生产8题 |
|---|---:|---:|
| generation / 工具读取 | 8 / 0 | 16 / 8 |
| 完整上下文输入token累计 | {stats['plain']['input_tokens_full_context']} | {stats['tool']['input_tokens_full_context']} |
| 原始输出token累计 | {stats['plain']['output_tokens_raw']} | {stats['tool']['output_tokens_raw']} |
| 客户端任务用时合计秒 | {stats['plain']['client_task_seconds']:.2f} | {stats['tool']['client_task_seconds']:.2f} |
| 含未达标摊销的每合格任务客户端秒 | {stats['plain']['client_seconds_per_qualified_including_failed']:.2f} | {stats['tool']['client_seconds_per_qualified_including_failed']:.2f} |
| 每合格任务货币成本/实测GPU峰值 | NA/NA | NA/NA |

纯文本没有实际读取、工具提交与对应State运输，较低输入和耗时不能推导生产成本/吞吐收益。完整输入token不是实际prefill，客户端时间不是GPU计算时间；自托管费率与设备遥测缺失，成本不填0。预算40次生成/72000输出token、3600秒调度窗口；实际24次、4797输出token、71718累计完整输入token，预算内。没有额外付费API或租用资源。

## 辅助交接准备与工程验证

已交付ASSISTANCE_REGRESSION_PREPARATION.zh-CN.md：H01–H09分别覆盖零帮助默认路径、显式求助、等待写权限、过期建议、重复投递、接管唯一执行者、交还State、共享预算与贡献归属。

7项离线前置检查通过：现有事件一次追加/父关系/原答案保真、同ID异内容拒绝、部分恢复和预算终止行为。源码确认旧_supervisor_review_event是强制拒绝/修复语义，不能改名为按需建议。等待期执行权、过期建议消费、接管/交还新接口与真实强模型有效性**尚未实现/验证**；没有用xfail占位或临时假状态机冒称完成。此轮准备工程回归，不恢复旧Supervisor必经审核。

全量1514 passed、0 skipped，243.94秒，包含Torch/State和必需浏览器检查；独立诊断17项通过、辅助前置7项通过，临时测试使用不同basetemp。诊断测试最初1项失败为离线fixture缺RuntimeSettings.api_key参数，修正后通过，原日志保留；不是生产根因或模型改进。新结构化检查沿用前轮已红绿验证的修正，并在本轮重新冻结，无事后重评旧结果。

生产源码零变化，R4读取合同全量离线回归通过；历史主组21/21及独立3/3只作同源码历史证据，没有本轮重采或合并。新生产读取8/8另计。

## 下一最小动作

优先实现H02–H05“求助→等待→建议→RWKV自主继续”的最小生产交接入口，并配真实接口先失败后通过回归，暂不接管、不并发。待接口/来源/预算冻结后，以同类可复现困难比较独立完成与一次强模型建议后完成。强模型只看用户目标、原文件、真实回答/尝试及剩余预算，不看隐藏评分事实表，不直接替RWKV写最终答案；也不要求RWKV先独立解决困难才允许帮助。

这只是下一轮建议，不是本轮已调用强模型或已授权新计费配置。若仍研究输入，应另隔离任务与资料边界这一个因素，不能凭本轮整体对照猜定根因；本轮不改提示词再重跑挑结果。

登记SHA-256：{sha(D/'REGISTRATION.json')}。报告及原始包SHA见SHA256SUMS.json。源文件清单运行前后一致；服务132项目文件与6393 engine文件逐一核验，无远端Git。完整源码、临时脚本、原始轨迹与失败夹具记录封存，旧实验保持不变。
'''
assert not (D/'REPORT.zh-CN.md').exists();(D/'REPORT.zh-CN.md').write_text(report)
with tarfile.open(D/'RAW_EVIDENCE.tar.gz','w:gz') as t:t.add(D/'runs',arcname='runs')
with tarfile.open(D/'ANALYSIS_SCRIPTS.tar.gz','w:gz') as t:
 for p in sorted((R/'temp').glob('*r2_20260913.py')):t.add(p,arcname=str(p.relative_to(R)))
save(D/'SHA256SUMS.json',{str(p.relative_to(D)):sha(p) for p in sorted(D.rglob('*')) if p.is_file() and p.name!='SHA256SUMS.json'})
h=R/'docs/HANDOFF.zh-CN.md';old=h.read_text();h.write_text(f'''# 当前进展：纯文本摘要参照与生产闭环 R2（2026-09-13）

- Owner批准真正纯文本对照及辅助交接离线准备，已执行`{D.name}`。四文件×两遍×两组，未新增datasets/训练/强模型/并发/GitHub更新；生产与原五个修改文件SHA保持。
- 任务：16/16自然提交，mutation0。纯文本满足3/8、部分5/8；生产满足4/8、部分4/8。两组未达稳定门，非项目Strict；无非法调用、重复循环、无总结、预算中断或虚假操作/测试完成声明。旧实验未重算收益。
- 真纯文本没有工具菜单或Agent协议，仅任务和原文，8次生成；生产自主读取8次、生成16次。输入/State工程核验16/16，精确输入24份、生产观察8条、独立根16个及48checkpoint身份正确。纯文本candidate终止原样保留，不伪造JSON final调用。
- 简化封装未消除四份server.py共同遗漏db未使用；两组还有任务指令混入文件事实，不能直接推定State缺陷或模型普遍上限。纯文本更少输入/耗时不作为生产成本收益。
- 全量1514 passed/0 skipped，诊断17 passed、辅助前置7 passed；旧结构化检查修正在本轮重新冻结。辅助H01–H09用例已准备，等待写权限/过期建议/接管交还接口仍待实现，不将旧强制Supervisor消息改名为建议。
- 下一步建议先实现H02–H05的按需求助/等待/建议/继续及红绿回归，再另冻结一次强模型建议效用验证；不立即接管、并发或重构State，不向模型提供隐藏评分要点。
- 报告：`data/experiments/{D.name}/REPORT.zh-CN.md`，SHA-256 `{sha(D/'REPORT.zh-CN.md')}`。登记SHA `{sha(D/'REGISTRATION.json')}`。原始证据、评分、资源记录、源代码和脚本已封存。

---

'''+old)
print(json.dumps({'report_sha256':sha(D/'REPORT.zh-CN.md'),'stats':stats,'checkpoints':len(identity)},ensure_ascii=False,indent=2))
