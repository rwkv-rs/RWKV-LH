"""Offline transport prerequisites only. Legacy review messages are NOT the new advice interface."""
from pathlib import Path
import sys,json,copy
import pytest
R=Path('/home/chase/GitHub/RWKV-LH');sys.path.insert(0,str(R));sys.path.insert(0,str(R/'tests'))
from test_unified_controller import build,call
from rwkv_lh.supervisor import SupervisorReview,ReviewDisposition
from rwkv_lh.model import ModelProtocolError

def setup(tmp_path):
 controller,store,w,client,model=build(tmp_path,[call('read_file',path='README.md'),call('final_answer',text='ORIGINAL')]);source=R/'data/experiments/COORDINATOR_ATOMIC_ACTOR_STATE_ABLATION_R5_20260912/arm_b_atomic/cases/RP-API-01/workspace/README.md';(w/'README.md').write_bytes(source.read_bytes());state=store.load('RUN');decision=model.next_command(state,controller._persist_callback);a=controller._execute_decision(state,decision);obs=controller._action_observation_event(state,a);child=model.append_action_observation(state,controller._persist_callback,obs)
 review=SupervisorReview.create(ReviewDisposition.REVISE,summary='核对可见文件证据。',issues=('检查回答是否只依据已经读取的文件。',));event=controller._supervisor_review_event(review,decision.decision.decision_id,repair_number=1);return controller,store,state,model,client,child,event

def test_existing_event_append_is_once_preserves_parent_and_raw_final(tmp_path):
 controller,store,state,model,client,parent,event=setup(tmp_path);child=model._append_event(state,parent,event,controller._persist_callback);assert child.parent_checkpoint_id==parent.checkpoint_id;assert model._append_event(state,child,event,controller._persist_callback).checkpoint_id==child.checkpoint_id
 final=model.next_command(state,controller._persist_callback);assert final.checkpoint.parent_checkpoint_id==child.checkpoint_id;assert final.wire_command.arguments['text']=='ORIGINAL';assert len(client.prompts)==2;assert client.prompts[-1].count('核对可见文件证据。')==1
 assert event.payload['source']=='external_strong_model_supervisor'

def test_existing_handoff_rejects_same_id_changed_content(tmp_path):
 controller,store,state,model,client,parent,event=setup(tmp_path);child=model._append_event(state,parent,event,controller._persist_callback);changed=copy.deepcopy(event);changed.payload['source']='different source'
 with pytest.raises(ModelProtocolError,match='collision'):model._append_event(state,child,changed,controller._persist_callback)
 assert len(client.prompts)==1;assert state.lane_head('executor')==child.checkpoint_id

def test_legacy_review_is_not_a_general_advice_contract(tmp_path):
 *_,event=setup(tmp_path)
 assert 'completion candidate was not accepted' in event.payload['instruction']
 # This is a guard against relabeling a compulsory rejection as optional advice, not evidence of a new API.
