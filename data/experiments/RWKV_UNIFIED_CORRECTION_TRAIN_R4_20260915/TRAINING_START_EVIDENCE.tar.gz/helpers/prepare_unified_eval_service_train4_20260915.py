from pathlib import Path
import json,hashlib,subprocess,shlex
R=Path('/home/chase/GitHub/RWKV-LH');P=R/'data/experiments/RWKV_UNIFIED_CORRECTION_TRAIN_R4_20260915';D=P/'evaluation_service';D.mkdir(exist_ok=False)
remote='/home/chase/GitHub/RWKV-LH-unified-train-r4-20260915';asset='/home/chase/GitHub/RWKV-LH-unified-corrections-r1-20260914';oldremote='/home/chase/GitHub/RWKV-LH-native-gc-r1-20260914';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name in ('RESULT.json','STATE_PROFILES.json'):subprocess.run(['scp','-q',f'rwkv-8222:{remote}/training_runs/direct-unified-r4-20260915/{name}',str(D/name)],check=True)
result=json.loads((D/'RESULT.json').read_text());assert result['status']=='candidate' and result['optimizer_steps']==180 and result['serving_loader_verified'] and result['last_event']=='run_finished'
profile=json.loads((D/'STATE_PROFILES.json').read_text());assert profile['model_artifact']==asset+'/model_ctx24576';profile['model_artifact']=asset+'/model_serving_ctx24576';(D/'STATE_PROFILES_SERVING.json').write_text(json.dumps(profile,indent=2)+'\n')
s=(R/'data/experiments/RWKV_NATIVE_GC_EMPTY_QUEUE_R1_20260914/deployment/launch.sh').read_text()
s=s.replace('unset VLLM_RWKV7_STATE_PROFILE_MANIFEST VLLM_RWKV7_STATE_PROFILE_MANIFEST_SHA256',f'export VLLM_RWKV7_STATE_PROFILE_MANIFEST={remote}/evaluation_service/STATE_PROFILES_SERVING.json\nexport VLLM_RWKV7_STATE_PROFILE_MANIFEST_SHA256={sha(D/"STATE_PROFILES_SERVING.json")}')
s=s.replace(oldremote+'/source',remote+'/source').replace(oldremote+'/validation/PROJECT_SOURCE.json',remote+'/validation/PROJECT_SOURCE.json').replace('2470f1fe98af1f9d01a709fdf1658e0cfa15b8cd0998de0735ce2b1396ee71ee',sha(P/'runtime/PROJECT_SOURCE.json')).replace(oldremote+'/state/',remote+'/evaluation_state/').replace('--port 18247','--port 18250').replace('rwkv-code-agent-gc-r1-ctx24576','rwkv-direct-unified-r4-ctx24576')
(D/'launch.sh').write_text(s)
reg={'candidate_state_sha256':result['output_state']['sha256'],'profile_manifest_sha256':sha(D/'STATE_PROFILES_SERVING.json'),'training_result_sha256':sha(D/'RESULT.json'),'launcher_sha256':sha(D/'launch.sh'),'source_manifest_sha256':sha(P/'runtime/PROJECT_SOURCE.json'),'remote_port':18250,'local_port':29625,'gpu_uuid':'GPU-1faf7f09-25f4-2515-b707-6e0766aa841d','default_profile':'zero','model':'rwkv-direct-unified-r4-ctx24576','artifact':'unchanged indexed24576 artifact','source':'Both server and client use frozen R4 sourceb904ff21. Later resumed-budget engineering fix not imported; original fixed gates/sampling/output1800 explicitly unchanged. Candidate evaluation only, not retained.'}
(D/'REGISTRATION.json').write_text(json.dumps(reg,indent=2)+'\n');subprocess.run(['ssh','rwkv-8222','mkdir','-p',remote+'/evaluation_service'],check=True)
subprocess.run(['rsync','-a',str(D/'launch.sh'),str(D/'STATE_PROFILES_SERVING.json'),str(D/'REGISTRATION.json'),f'rwkv-8222:{remote}/evaluation_service/'],check=True)
args=['systemd-run','--user','--unit=rwkv-lh-unified-train4-eval-r1','--property=RuntimeMaxSec=20000','--property=ExecStopPost=/usr/bin/systemctl --user start rwkv-lh-native-current.service',f'--property=StandardOutput=append:{remote}/evaluation_service/service.log','--property=StandardError=inherit','bash',remote+'/evaluation_service/launch.sh']
import time
for _ in range(120):
 status=subprocess.run(['ssh','rwkv-8222','systemctl','--user','is-active','rwkv-lh-unified-training-r4.service'],capture_output=True,text=True).stdout.strip()
 if status not in ('active','activating','deactivating'):break
 time.sleep(2)
else:raise RuntimeError('training service still owns GPU')
for _ in range(150):
 ready=subprocess.run(['ssh','rwkv-8222',"curl -fsS http://127.0.0.1:18234/metrics | grep -E '^vllm:num_requests_(running|waiting)'"],capture_output=True,text=True)
 if ready.returncode==0 and ready.stdout and all(float(line.rsplit(' ',1)[1])==0 for line in ready.stdout.splitlines()):break
 time.sleep(2)
else:raise RuntimeError('default service idle not established')
subprocess.run(['ssh','rwkv-8222','systemctl','--user','stop','rwkv-lh-native-current.service'],check=True)
try:subprocess.run(['ssh','rwkv-8222',shlex.join(args)],check=True)
except BaseException:
 subprocess.run(['ssh','rwkv-8222','systemctl','--user','start','rwkv-lh-native-current.service']);raise
print('frozen-source R4 evaluation service launched')
