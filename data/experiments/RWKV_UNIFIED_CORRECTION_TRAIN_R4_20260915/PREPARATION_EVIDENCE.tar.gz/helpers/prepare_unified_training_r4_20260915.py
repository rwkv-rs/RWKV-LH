from pathlib import Path
import sys,json,hashlib,shutil,subprocess,datetime
R=Path('/home/chase/GitHub/RWKV-LH');sys.path.insert(0,str(R))
from rwkv_lh.inference.uploaded_sources import source_inventory,PROJECT_SCHEMA
D=R/'data/experiments/RWKV_UNIFIED_CORRECTION_TRAIN_R4_20260915';assert (D/'FREEZE_RESULT.json').exists();P=D/'runtime';P.mkdir();S=P/'source';S.mkdir();remote='/home/chase/GitHub/RWKV-LH-unified-train-r4-20260915';old=R/'data/experiments/RWKV_UNIFIED_CORRECTION_TRAIN_R1_20260914';r2=R/'data/experiments/RWKV_UNIFIED_CORRECTION_TRAIN_R2_20260914';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
assert '1781 passed' in (R/'data/experiments/RWKV_SAMPLING_SETTINGS_FLOW_R1_20260915/FULL_GREEN.log').read_text()
for n in ('rwkv_lh','scripts'):shutil.copytree(R/n,S/n,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
for n in ('pyproject.toml','uv.lock'):shutil.copyfile(R/n,S/n)
save(P/'PROJECT_SOURCE.json',{'schema_version':PROJECT_SCHEMA,'project_root':remote+'/source','source_root':'.','files':[{'path':p,'sha256':h,'bytes':n} for p,(h,n) in sorted(source_inventory(S).items())]})
identity=sha(P/'PROJECT_SOURCE.json');runtime=json.loads((old/'runtime/NATIVE_RUNTIME_R3.json').read_text());runtime['source_manifest']={'path':remote+'/validation/PROJECT_SOURCE.json','sha256':identity};save(P/'NATIVE_RUNTIME.json',runtime)
compat=json.loads((old/'runtime/COMPAT_REGISTRATION_R3.json').read_text());compat.update(round_id=D.name,source_manifest_sha256=identity);compat.pop('previous_failure_sha256',None);compat['attempt']='Revalidate current fully tested source including sampling/replay engineering fixes. Numerical trainer/precision unchanged; zero/nonzero forward/backward and serving State-loader gates unchanged. No model weight training.';save(P/'COMPAT_REGISTRATION.json',compat)
assert (D/'AUTHORIZATION.zh-CN.md').exists()
evalreg=json.loads((r2/'EVALUATION_REGISTRATION.json').read_text());evalreg.update(round_id=D.name,registered_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_manifest_sha256=identity,dataset_manifest_sha256=sha(R/'data/datasets/rwkv_direct_unified_corrections_v3/manifest.json'));save(D/'EVALUATION_REGISTRATION.json',evalreg)
E=D/'evaluation';E.mkdir()
for n in ('REGRESSION_REGISTRATION.json','GATE_INTERPRETATION_PRE_RUN.zh-CN.md'):shutil.copyfile(r2/'evaluation'/n,E/n)
shutil.copyfile(D/'EVALUATION_REGISTRATION.json',E/'EVALUATION_REGISTRATION.json')
T=D/'training';T.mkdir();reg=json.loads((r2/'training/REGISTRATION.json').read_text());reg.update(run_id='direct-unified-r4-20260915',source_manifest_sha256=identity,ledger_root=remote+'/training_runs')
reg['optimizer'].update(epochs=3,max_optimizer_steps=240,max_seconds=5400)
reg['dataset']={'path':remote+'/data/datasets/rwkv_direct_unified_corrections_v3/manifest.json','sha256':sha(R/'data/datasets/rwkv_direct_unified_corrections_v3/manifest.json')}
for k,p,rel in [('runtime',P/'NATIVE_RUNTIME.json','validation/NATIVE_RUNTIME.json'),('compatibility_registration',P/'COMPAT_REGISTRATION.json','validation/COMPAT_REGISTRATION.json'),('authorization',D/'AUTHORIZATION.zh-CN.md','training_registration/AUTHORIZATION.zh-CN.md'),('evaluation_registration',D/'EVALUATION_REGISTRATION.json','training_registration/EVALUATION_REGISTRATION.json')]:reg[k]={'path':remote+'/'+rel,'sha256':sha(p)}
reg['compatibility_result']={'path':remote+'/validation/compat/RESULT.json','sha256':'PENDING_NOT_A_TRAINING_REGISTRATION'}
reg['limits_note']='60 immutable reviewed boundaries: original57 plus complete CLI write, successful scan command and actual failed offset test. Zero/seed20260914/lr1e-4, threeepochs180 planned updates; caps240steps/90minutes/80GiB. No sample skipping, automatic retries, parameter repair or weight training. Unified data and epoch count differ fromR3; no single-factor attribution. Existing dev/diagnostic/coding/read gates unchanged; no confirmation unless all pass. All earlier failures and actual updates retained.'
save(T/'PREPARATION.json',reg)
header=(old/'runtime/validate_r3.sh').read_text().split('exec timeout')[0].replace('/home/chase/GitHub/RWKV-LH-unified-corrections-r1-20260914/source',remote+'/source')
(P/'validate.sh').write_text(header+f'exec timeout 3700 /home/chase/GitHub/RWKV-LH/data/runtime/engines/vllm-rwkv-67f0c5996c50/.venv/bin/python -B {remote}/source/scripts/validate_statetune_native.py --runtime {remote}/validation/NATIVE_RUNTIME.json --runtime-sha256 {sha(P/"NATIVE_RUNTIME.json")} --registration {remote}/validation/COMPAT_REGISTRATION.json --registration-sha256 {sha(P/"COMPAT_REGISTRATION.json")} --output {remote}/validation/compat\n')
save(D/'PREPARATION_IDENTITY.json',{'local_head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'source_manifest_sha256':identity,'helper_sha256':sha(Path(__file__)),'full_tests':'1781 passed, 0 skipped','owner_changes_in_frozen_runtime':True,'dataset_changed':True,'numeric_optimizer_changed':False,'run_status':'prepared_not_launched'})
subprocess.run(['ssh','rwkv-8222','mkdir','-p',remote+'/source',remote+'/validation',remote+'/training_registration',remote+'/data/datasets'],check=True)
subprocess.run(['rsync','-a',str(S)+'/',f'rwkv-8222:{remote}/source/'],check=True)
subprocess.run(['rsync','-a',str(P/'PROJECT_SOURCE.json'),str(P/'NATIVE_RUNTIME.json'),str(P/'COMPAT_REGISTRATION.json'),str(P/'validate.sh'),f'rwkv-8222:{remote}/validation/'],check=True)
subprocess.run(['rsync','-a',str(D/'AUTHORIZATION.zh-CN.md'),str(D/'EVALUATION_REGISTRATION.json'),f'rwkv-8222:{remote}/training_registration/'],check=True)
print(identity)

subprocess.run(['rsync','-a',str(R/'data/datasets/rwkv_direct_unified_corrections_v3'),f'rwkv-8222:{remote}/data/datasets/'],check=True)
