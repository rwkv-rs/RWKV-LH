#!/bin/bash
set -euo pipefail
export PYTHONPATH=/home/chase/GitHub/RWKV-LH-unified-train-r4-20260915/source:/home/chase/GitHub/RWKV-LH-full-trace-runtime-r2-20260911/engine
export PYTHONDONTWRITEBYTECODE=1
export OMP_NUM_THREADS=4
export VLLM_RWKV7_WKV_MODE=fp32io16
export CUDA_DEVICE_ORDER=PCI_BUS_ID
export CUDA_VISIBLE_DEVICES=0
exec timeout 3700 /home/chase/GitHub/RWKV-LH/data/runtime/engines/vllm-rwkv-67f0c5996c50/.venv/bin/python -B /home/chase/GitHub/RWKV-LH-unified-train-r4-20260915/source/scripts/validate_statetune_native.py --runtime /home/chase/GitHub/RWKV-LH-unified-train-r4-20260915/validation/NATIVE_RUNTIME.json --runtime-sha256 e021dc232c9ed1c446ee2166c18e579e3ad95b4015d9383346ab5c362fec20aa --registration /home/chase/GitHub/RWKV-LH-unified-train-r4-20260915/validation/COMPAT_REGISTRATION.json --registration-sha256 ed28ac4910b457134baa40843099377506e1dc38a9fb32a092aec99f59e4ba58 --output /home/chase/GitHub/RWKV-LH-unified-train-r4-20260915/validation/compat
