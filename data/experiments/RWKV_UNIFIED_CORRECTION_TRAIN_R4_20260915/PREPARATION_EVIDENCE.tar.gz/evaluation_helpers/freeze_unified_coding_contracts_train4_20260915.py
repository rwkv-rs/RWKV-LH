from pathlib import Path
import json,sys
R=Path('/home/chase/GitHub/RWKV-LH');S=R/'data/experiments/RWKV_UNIFIED_CORRECTION_TRAIN_R4_20260915/runtime/source';sys.path.insert(0,str(S));D=R/'data/experiments/RWKV_UNIFIED_CORRECTION_TRAIN_R4_20260915/evaluation'
from rwkv_lh import task_review as v
from rwkv_lh.direct_trace_data import protocol_identity
reg=json.loads((D/'RUN_REGISTRATION.json').read_text());policy=json.loads((D/'EVALUATION_REGISTRATION.json').read_text())
identity={'model':reg['model_sha256'],'protocol':protocol_identity()[1],'source':v.digest(reg['source_pins']),'sampling':v.digest(policy['sampling']),'state':v.digest(reg['profiles']),'budget':v.digest(policy['budget'])}
criteria={
 'read-health':[('meaning','总结其主要内容','概括HTTP健康检查及检查200/ok；不能认证预约/订单事务行为'),('fidelity','只依据文件中的信息回答','断言由文件和实际工具观察支持，一般超时/关闭连接等细节可省略')],
 'run-recursive':[('execution','运行工作区中已有的 check_recursive.py','本轮真实执行该脚本，等价命令方式均可；源文件保留'),('report','根据本次真实执行的输出说明测试是否通过','忠实报告脚本内部检查和最终结果；建议或外层退出0不能冒充测试成功')],
 'fix-query':[('behavior','使 test_query_limit.py 中已有测试全部通过','原测试不改且在交付副本上外部执行通过；不限定实现'),('execution','实际运行 test_query_limit.py','本轮真实执行原测试并处理其实际反馈；历史test_failure.txt不算本次运行'),('report','最后如实说明修改内容、实际测试结果和尚未解决的问题','回答准确说明实际修改和验证，不虚构未执行工作')]
}
contracts={}
for c in policy['coding_checks']['jobs']:
 requirements=[dict(id=i,user_quote=q,outcome=o,level='essential',missing_effect='用户要求的交付或真实性缺失',acceptance=o,omission_policy='允许等价实现、工具路径和措辞；一般实现细节可以省略') for i,q,o in criteria[c['task_id']]]
 contract=dict(schema=v.CONTRACT_SCHEMA,task_id=c['task_id'],user_request=c['request'],kind='task_trial',protocol_error_policy='feedback',execution_identity=identity,requirements=requirements)
 path=D/'contracts/coding'/(c['task_id']+'.json');v.freeze_contract(contract,path);contracts[c['task_id']]=v.file_digest(path)
v.write_once(D/'CODING_CONTRACT_REGISTRATION.json',{'script_sha256':v.file_digest(Path(__file__)),'policy_sha256':v.file_digest(D/'EVALUATION_REGISTRATION.json'),'identity':identity,'contracts':contracts,'note':'Concrete encoding of training-before-frozen coding criteria; no extra requirement or reference answer enters model inputs.'})
