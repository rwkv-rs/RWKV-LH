"""External mechanical coverage of actually consumed, byte-verified observations."""
def covers_file(intervals,size):
 cursor=0
 for start,end in sorted(intervals):
  if not 0<=start<=end<=size:raise ValueError('observation range outside file')
  if start>cursor:return False
  cursor=max(cursor,end)
 return cursor==size and bool(intervals)
