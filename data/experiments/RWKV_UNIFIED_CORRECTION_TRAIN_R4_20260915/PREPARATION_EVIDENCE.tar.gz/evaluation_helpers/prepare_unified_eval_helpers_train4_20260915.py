from pathlib import Path
R=Path('/home/chase/GitHub/RWKV-LH');S="S=R/'data/experiments/RWKV_UNIFIED_CORRECTION_TRAIN_R4_20260915/runtime/source';sys.path.insert(0,str(S))"
names=['unified_eval_budget','run_unified_candidate_tasks','freeze_unified_task_contracts','audit_unified_task_traces','review_unified_tasks','unified_observed_coverage','run_unified_read_regression','freeze_unified_coding_contracts','audit_unified_coding_traces','verify_unified_coding_artifacts','run_unified_coding_tasks','audit_unified_original_read']
for name in names:
 s=(R/'temp'/f'{name}_train2_20260914.py').read_text().replace('RWKV_UNIFIED_CORRECTION_TRAIN_R2_20260914','RWKV_UNIFIED_CORRECTION_TRAIN_R4_20260915').replace('_train2_20260914','_train4_20260915').replace('29622','29625').replace('rwkv-direct-unified-r2-ctx24576','rwkv-direct-unified-r4-ctx24576')
 s=s.replace('sys.path.insert(0,str(R))',S).replace("(R/'rwkv_lh').rglob", "(S/'rwkv_lh').rglob").replace('run_direct_original_read_r1_20260913.py','run_direct_original_read_train4_20260915.py')
 (R/'temp'/f'{name}_train4_20260915.py').write_text(s)
s=(R/'temp/run_direct_original_read_r1_20260913.py').read_text().replace('sys.path.insert(0,str(R))',S)
(R/'temp/run_direct_original_read_train4_20260915.py').write_text(s)
print('Prepared frozen-source evaluators; not executed; no confirmation access')
