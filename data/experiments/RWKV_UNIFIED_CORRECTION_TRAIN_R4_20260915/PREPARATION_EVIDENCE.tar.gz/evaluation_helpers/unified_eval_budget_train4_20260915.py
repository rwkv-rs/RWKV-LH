"""Shared outer evaluation budget, counting actual requests across all phases and arms."""
from pathlib import Path
import json,time
D=Path('/home/chase/GitHub/RWKV-LH/data/experiments/RWKV_UNIFIED_CORRECTION_TRAIN_R4_20260915/evaluation')
def reserve(calls,seconds):
 p=D/'BUDGET_START.json'
 if not p.exists():
  with p.open('x') as f:json.dump({'started_at_epoch':time.time(),'max_calls':400,'max_seconds':18000},f)
 start=json.loads(p.read_text());requests=set()
 for trace in D.glob('**/model_trace.jsonl'):
  for line in trace.read_text().splitlines():
   e=json.loads(line)
   if e.get('type')=='model_session_generation_started':requests.add(e['request_id'])
 used=len(requests);elapsed=time.time()-start['started_at_epoch'];allowed=used+calls<=400 and elapsed+seconds<=18000
 with (D/'BUDGET_LEDGER.jsonl').open('a') as f:f.write(json.dumps({'at':time.time(),'actual_started':used,'elapsed_seconds':elapsed,'reserve_calls':calls,'reserve_seconds':seconds,'allowed':allowed})+'\n')
 if not allowed:raise RuntimeError('evaluation resource budget cannot accommodate next fixed task/block; terminate incomplete')
