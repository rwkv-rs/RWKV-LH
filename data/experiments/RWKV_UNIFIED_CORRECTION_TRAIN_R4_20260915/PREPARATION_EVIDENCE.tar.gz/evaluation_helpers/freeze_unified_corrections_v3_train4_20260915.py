from pathlib import Path
import sys,json,hashlib,copy
R=Path('/home/chase/GitHub/RWKV-LH');sys.path.insert(0,str(R))
from rwkv_lh.direct_trace_data import ROW_SCHEMA,ROLE,protocol_identity,normalize_direct_row,audit_source_similarity,freeze_direct_dataset
from rwkv_lh.statetune_data import FREEZE_SCHEMA
from rwkv_lh.token_budget import tokenizer,VOCAB_PATH
D=R/'data/experiments/RWKV_UNIFIED_CORRECTION_TRAIN_R4_20260915';D.mkdir(exist_ok=True);assert not (D/'FREEZE_RESULT.json').exists()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,x):
 p=D/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n');return {'path':str(p),'sha256':sha(p)}
oldroot=R/'data/datasets/rwkv_direct_unified_corrections_v2';old=json.loads((oldroot/'manifest.json').read_text());oldreg=json.loads(Path(old['freeze_registration']['path']).read_text())
rows=list(map(json.loads,(oldroot/'train.jsonl').read_text().splitlines()));assert len(rows)==57
sources=copy.deepcopy(old['sources']);protocol,protocolsha=protocol_identity()
extras=[
 ('cli-add-complete-v3','verified_coding','RWKV_CLI_LONG_OUTPUT_TEACHER_R3_20260915','timebook-add','RWKV_CLI_OUTPUT_BUDGET_ABLATION_R1_20260915','README.md','RP-CLI-02','CLI'),
 ('scan-verify-rows-v3','verified_command','RWKV_VERIFICATION_PROGRESS_TEACHER_R1_20260915','index-recursive','RWKV_CORRECTED_ARTIFACT_VERIFICATION_R1_20260914','document_index/documents.py','RP-MAINT-02','MAINT'),
 ('offset-failing-test-v3','verified_command','RWKV_OFFSET_PROGRESS_TEACHER_R1_20260915','repeat-1','RWKV_CLI_OFFSET_REPAIR_R1_20260915','timebook.py','RP-CLI-02','CLI')]
for ident,authority,origin,case,collection,content_path,task,family in extras:
 p=(R/'data/experiments'/origin/'validation/VALIDATION.json' if ident=='cli-add-complete-v3' else R/'data/experiments'/origin/'runs'/case/'validation/VALIDATION.json');proof=json.loads(p.read_text());assert proof['status']=='validated_candidate'
 root=Path(proof['run_root']);registration_path=R/'data/experiments'/collection/('RUN_REGISTRATION.json' if collection=='RWKV_CLI_OFFSET_REPAIR_R1_20260915' else 'REGISTRATION.json');registration=json.loads(registration_path.read_text())
 collector=save(Path('sources')/ident/'COLLECTOR_SOURCE.json',{'original_registration':{'path':str(registration_path),'sha256':sha(registration_path)},'files':registration['source_pins'],'generation_snapshot_opt_in':True})
 state=json.loads((root/'state_snapshot.json').read_text());metadata=[cp['native_state_metadata'] for cp in state['model_states'].values()];keys=('model_sha256','server_build','tokenizer_build','protocol_version','state_format_version');identity={k:metadata[0][k] for k in keys};assert all({k:m[k] for k in keys}==identity for m in metadata)
 server=save(Path('sources')/ident/'RECORDED_SERVER_IDENTITY.json',{'scope':'identity advertised in sealed original native State records, not a fresh deployment check','identity':identity,'state_snapshot_sha256':sha(root/'state_snapshot.json')})
 manifest=save(Path('sources')/ident/'SOURCE_MANIFEST.json',{'source_type':'native_production_trace','model_sha256':proof['model_sha256'],'collector_source_manifest_sha256':collector['sha256'],'collector_source_reference':collector,'server_identity_sha256':server['sha256'],'server_identity_reference':server,'files':proof['source_files']})
 content=root/proof['snapshot']/content_path;digest=sha(content)
 sources.append({'id':ident,'source_id':ident,'original_task_id':task,'family':family,'split':'train','run_root':str(root),'path':content_path,'source_content_sha256':digest,'content_reference':{'path':str(content),'sha256':digest},'manifest':manifest})
 rows.append({'schema_version':ROW_SCHEMA,'role':ROLE,'split':'train','recomputed':True,'sample_id':ident,'source_id':ident,'family':family,'input_protocol':protocol,'protocol_sha256':protocolsha,'model_sha256':proof['model_sha256'],'tokenizer_sha256':sha(VOCAB_PATH),'source_manifest_sha256':manifest['sha256'],'source_content_sha256':digest,'candidate_checkpoint_id':proof['checkpoint_id'],'input_checkpoint_id':proof['input_checkpoint_id'],'request_id':proof['request_id'],'input_text':proof['input_text'],'input_token_ids':proof['input_token_ids'],'input_token_source':'server_returned_full','target_text':proof['target_text'],'target_token_ids':tokenizer().encode(proof['target_text']),'label_authority':authority,'reviews':proof['reviews'],('correction_validation' if authority=='verified_coding' else 'command_validation'):{'path':str(p),'sha256':sha(p)}})
assert len(rows)==60
for row in rows:normalize_direct_row(row,model_sha256=old['model_sha256'],context_tokens=24576,vocab_size=oldreg['vocab_size'],bos_token_id=oldreg['bos_token_id'])
auth=D/'AUTHORIZATION.zh-CN.md';auth.write_text('Owner已明确授权离线期间持续采集、生成、训练、验收，目标RWKV自己的Code Agent。本轮统一60条：保留v2全部57条，新增1完整CLI写入、1真实成功检查命令、1真实失败测试命令；均来自已获准CLI/MAINT生产zero trace，不是新独立项目。旧同项目timebook候选不再重复加入。两来源绑定审核、人工源语义检查、fresh实际执行通过才准入。不因质量不足凑数量，不把强模型成果归属RWKV。只GPU0，一个zero初始化候选3epochs计划180步，上限240步/90分钟/80GiB。相较R3同时改变数据及epoch，不做单因素归因；R3和所有失败保留。新数据/源码/训练器/初始化/采样/验收在启动前冻结，固定回归与评分不变；不读confirmation/holdout，不push。\n')

regref=oldreg['regression_registration'];regression=json.loads(Path(regref['path']).read_text());similarity=audit_source_similarity([*sources,*regression['cases']],threshold=oldreg['similarity_threshold']);assert similarity['passed']
registration={'schema_version':FREEZE_SCHEMA,'role':ROLE,'authorization':{'path':str(auth),'sha256':sha(auth)},'reviewed_rows':save('REVIEWED_ROWS.json',{'rows':rows}),'regression_registration':regref,'regression_fingerprint':regref['sha256'],'sources':sources,'similarity_threshold':oldreg['similarity_threshold'],'similarity_audit':save('SIMILARITY_AUDIT.json',similarity),'model_sha256':old['model_sha256'],'context_tokens':24576,'vocab_size':oldreg['vocab_size'],'bos_token_id':oldreg['bos_token_id'],'minimum_counts':{'train':60,'dev':4,'confirmation':4},'minimum_coverage':{'source_files':36,'families':4,'read_boundaries':28,'summary_boundaries':24,'coding_boundaries':4,'command_boundaries':4}}
ref=save('FREEZE_REGISTRATION.json',registration);manifest=freeze_direct_dataset(registration,registration_reference=ref,output=R/'data/datasets/rwkv_direct_unified_corrections_v3')
save('FREEZE_RESULT.json',{'manifest_sha256':sha(R/'data/datasets/rwkv_direct_unified_corrections_v3/manifest.json'),'counts':manifest['counts'],'max_sequence_tokens':max(len(r['input_token_ids'])+len(r['target_token_ids'])-1 for r in rows),'context_tokens':24576,'training_steps':0,'new_edit_boundaries':1,'new_command_boundaries':2,'purpose':'Unified mixed candidate with verified complete write and successful/failing test progress, three epochs instead of six. No causal attribution to data alone or epochs alone. All previous57rows retained. No repetition of the pending near-duplicate CLI candidate.'})
print((D/'FREEZE_RESULT.json').read_text())
