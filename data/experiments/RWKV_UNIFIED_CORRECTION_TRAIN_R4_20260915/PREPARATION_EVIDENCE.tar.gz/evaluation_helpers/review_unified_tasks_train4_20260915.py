"""Serialize manual outcome judgments against frozen contracts and real evidence."""
from pathlib import Path
import sys,json,hashlib
R=Path('/home/chase/GitHub/RWKV-LH');S=R/'data/experiments/RWKV_UNIFIED_CORRECTION_TRAIN_R4_20260915/runtime/source';sys.path.insert(0,str(S));D=R/'data/experiments/RWKV_UNIFIED_CORRECTION_TRAIN_R4_20260915/evaluation'
from rwkv_lh import task_review as v
from unified_observed_coverage_train4_20260915 import covers_file
phase=sys.argv[1];mode=sys.argv[2];reg=json.loads((D/(phase.upper()+'_CONTRACT_REGISTRATION.json')).read_text());packets=[];runs={}
for p in sorted((D/phase).iterdir()):
 if not p.is_dir() or not (p/'execution/RESULT.json').exists():continue
 cid,arm,rep=p.name.rsplit('-',2);e=p/'execution';contract=v.load_contract(D/'contracts'/phase/(cid+'.json'))
 run=v.capture_diagnostic_run(e,task_id=cid,arm=arm,repeat=int(rep[1:]),protocol_error_policy='feedback',execution_identity=reg['identity'],historical=False,assistance='rwkv_independent')
 for item in run['evidence']:item['path']=str((e/item['path']).relative_to(D))
 for source in sorted((p/'workspace').rglob('*')):
  if source.is_file():run['evidence'].append(dict(id=f'E{len(run["evidence"])+1}',path=str(source.relative_to(D)),sha256=v.file_digest(source),kind='source'))
 packets.append({'id':p.name,'answer':run['answer'],'answer_sha256':hashlib.sha256((run['answer'] or '').encode()).hexdigest(),'termination':run['termination'],'diagnostics':run['diagnostics']});runs[p.name]=(contract,run)
if mode=='packets':
 v.write_once(D/phase/'REVIEW_PACKETS.json',packets);print(json.dumps(packets,ensure_ascii=False,indent=2));sys.exit()
notes=json.loads((D/phase/'MANUAL_REVIEW_NOTES.json').read_text());assessments=[];rows=[];mechanical={r['id']:r for r in json.loads((D/phase/'MECHANICAL_AUDIT.json').read_text())}
for packet in packets:
 rid=packet['id'];contract,run=runs[rid];n=notes[rid];assert n['answer_sha256']==packet['answer_sha256'];ids=[e['id'] for e in run['evidence']]
 judgment=dict(schema=v.REVIEW_SCHEMA,contract_sha256=v.digest(contract),run_sha256=v.digest(run),reviewer='Codex independent source and actual execution review',validity='valid',validity_reason='Frozen task, sources, original output and mechanical State/input audit available',validity_evidence_ids=ids,requirements=[dict(id=a,status=b,reason=c,evidence_ids=ids) for a,b,c in n['requirements']],findings=[dict(f,evidence_ids=ids) for f in n['findings']],causes=[])
 a=v.assess(contract,run,judgment,evidence_root=D);prefix=D/'reviews'/phase/rid
 v.write_once(prefix.with_suffix('.run.json'),run);v.write_once(prefix.with_suffix('.judgment.json'),judgment);v.write_once(prefix.with_suffix('.assessment.json'),a);assessments.append(a)
 m=mechanical[rid];frozen=json.loads((D/'EVALUATION_REGISTRATION.json' if phase=='diagnostic' else D/'REGRESSION_REGISTRATION.json').read_text());cases=frozen['diagnostic_cases'] if phase=='diagnostic' else frozen['cases'];case=next(c for c in cases if c['id']==run['task_id']);required=case['files'] if phase=='diagnostic' else [case['path']]
 actual=json.loads((D/phase/rid/'execution/RESULT.json').read_text());actions={x['action_id']:x for x in actual['actions']};readpass=all(covers_file([(o['byte_start'],o['byte_end']) for o in m['observations'] if o.get('path')==path and o['consumed_by_answer']],len((D/phase/rid/'workspace'/path).read_bytes())) for path in required)
 score=n.get('scores');pass_score=score=={'subject':1,'central_meaning':2,'fidelity':2} if phase!='diagnostic' else a['outcome']=='met'
 rows.append({'id':rid,'case_id':run['task_id'],'arm':run['arm'],'repeat':run['repeat'],'outcome':a['outcome'],'termination':run['termination'],'task_pass':readpass and m['passed_mechanical_audit'] and run['termination']=='submitted' and pass_score and a['false_work_claims']==0,'read_pass':readpass,'scores':score,'false_work_claims':a['false_work_claims'],'protocol_rejections':m['protocol_rejections'],'diagnostics':run['diagnostics']})
v.write_once(D/phase/'TASK_SUMMARY.json',v.aggregate(assessments));v.write_once(D/phase/'TASK_RESULTS.json',rows);print(json.dumps(rows,ensure_ascii=False,indent=2))
