from pathlib import Path
import json,hashlib,tarfile,subprocess,time
R=Path('/home/chase/GitHub/RWKV-LH');D=R/'data/experiments/RWKV_AGENT_HARNESS_DESIGN_V1_R1_20260912';DOC=R/'docs/RWKV_CODING_AGENT_HARNESS_V1.zh-CN.md'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
pre=json.loads((D/'PREEXISTING_CHANGES.json').read_text())['files'];assert len(pre)==5 and all(sha(R/p)==v for p,v in pre.items())
old=R/'data/experiments/RWKV_READ_SUMMARY_BASELINE_R5_20260912';pins=json.loads((old/'REGISTRATION.json').read_text())['source_pins'];assert all(sha(R/p)==v for p,v in pins.items());oldpre=json.loads((old/'PREEXISTING_CHANGES.json').read_text())['files'];assert oldpre==pre
identity={str(p.relative_to(R)):sha(p) for root in [R/'rwkv_lh',R/'tests'] for p in sorted(root.rglob('*.py'))}
for n in ['pyproject.toml','uv.lock','AGENTS.md','docs/G1J_UNIFIED_PROTOCOL_ITERATION_PLAN.zh-CN.md']:identity[n]=sha(R/n)
save(D/'SOURCE_IDENTITY.json',{'local_commit_before_design':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'files':identity,'uncommitted_runtime_files_preserved':pre})
scripts=[R/'temp/audit_agent_design_evidence_20260912.py',Path(__file__)]
save(D/'VALIDATION.json',{'type':'design_and_readonly_evidence_reconstruction','created_at_epoch':time.time(),'new_model_calls':0,'new_training':False,'new_dataset_version':False,'github_updated':False,'large_refactor':False,'production_changes':False,'state_calls_reconstructed':16,'observation_handoffs_verified':8,'r4_failure_pairs_inspected':3,'old_scores_changed':False,'full_test_evidence':{'reused':True,'rerun':False,'passed':1514,'skipped':0,'log':str((old/'PYTEST_FULL.log').relative_to(R)),'log_sha256':sha(old/'PYTEST_FULL.log'),'runtime_pins_and_preexisting_test_files_unchanged':True},'design_sha256':sha(DOC),'plan_sha256':sha(D/'MINIMAL_VALIDATION_PLAN.zh-CN.md'),'script_sha256':{str(p.relative_to(R)):sha(p) for p in scripts}})
with tarfile.open(D/'DESIGN_AND_REVIEW_SCRIPTS.tar.gz','w:gz') as t:
 t.add(DOC,arcname=str(DOC.relative_to(R)))
 for p in scripts:t.add(p,arcname=str(p.relative_to(R)))
report=f'''# RWKV Agent / Harness 第一版设计交付

本轮交付设计与证据复核，无新增任务/项目验收结果；没有新模型调用、工具执行任务、强模型费用或训练步骤。本轮没有新的Agent mutation统计；生产代码改动为0，变更限于文档与复核记录。

[第一版主设计](../../../docs/RWKV_CODING_AGENT_HARNESS_V1.zh-CN.md)覆盖产品目标、确认的四方职责、唯一执行循环、输入/审计分层、State及恢复、强模型建议/目标调整/接管、隔离调度/并发/集成、资源与成果归属、逐项代码建议、StateTune离线通道。设计SHA `{sha(DOC)}`。

[最小验证计划](MINIMAL_VALIDATION_PLAN.zh-CN.md)优先冻结合理摘要口径，然后同文件直供/生产工具读取对照；其后依次搜索、修改、测试反馈、多文件、强模型与并发。计划SHA `{sha(D/'MINIMAL_VALIDATION_PLAN.zh-CN.md')}`。这不是已经冻结或执行的实验；实际模型/文件/源码/评分/预算仍须在运行前完整登记。

直接全文组不替代生产、不伪造工具结果、不提供参考总结；使用同一生产输入builder，保留实际request/State历史差异。这是信息获取路径对照，不能把差距直接归因于State或元数据。

证据复核：R4/R5/角色约定共613/312/3个封存文件哈希一致；R4原三个失败及候选配对原文检查；R5全部8题、16次generation精确输入token重建，8次真实全文和观察child/唯一注入核验。原0/8保留且不作实际完成率；没有给旧答案重新评分。原始摘录、文件全文、输出及来源SHA见RAW_EVIDENCE_REVIEW.json。

新设计特别区分两项代码边界：cache失效后基于事实重新bootstrap不同于原State精确续接；并行root复制依赖作用域合同，不是通用冲突合并。这是已确认的实现边界/待验证推广风险，不是本轮已发现的摘要损失根因，也没有宣称修复。

保持原5个未提交文件SHA及整个运行源码不变；复用同源码完整1514 passed、0 skipped工程基线，没有把历史测试冒充新跑。新执行验证是证据重建与封存完整性检查。后续任何生产删除/修改均要求真实失败回归先红后绿及仓库要求的全量检查。

源码/test/环境锁文件身份见SOURCE_IDENTITY.json，详细验证见VALIDATION.json；当前设计与复核脚本归档于DESIGN_AND_REVIEW_SCRIPTS.tar.gz。所有文件SHA见SHA256SUMS.json。未读Holdout或隐藏验收，未新建datasets版本、训练、部署、更新GitHub。按规范仅本地提交。
'''
(D/'REPORT.zh-CN.md').write_text(report)
h=R/'docs/HANDOFF.zh-CN.md';prior=h.read_text();assert prior.startswith('# 当前交接\n')
entry=f'''\n## 2026-09-12 RWKV编程Agent与专属Harness第一版设计（当前）\n\nOwner已确认四方角色，且本轮再次明确：RWKV默认执行，强模型按需理解/建议/调整/接管，Harness负责真实工程链，外部验收按用户结果。历史“角色待确认”不再作为门。最终目标是同项目、同质量下比较总成本/资源、交付时间与合格吞吐，并发优势须测量。\n\n[主设计](RWKV_CODING_AGENT_HARNESS_V1.zh-CN.md)已交付，SHA `{sha(DOC)}`；[实验配套报告](../data/experiments/{D.name}/REPORT.zh-CN.md)。当前最新验证顺序优先于旧“立即强模型建议”方案：合理摘要口径→同文件全文直供/生产读取定位对照→按证据最小修复→搜索→单处修改→测试反馈→多文件→强模型协助→并发。仍在单文件范围，未开始新推理或训练，计划尚非运行REGISTRATION。\n\n重新核验R4三失败配对原文及R5全部八题的16次输入token、全文、child State和唯一观察；旧613/312/3文件封存均一致。0/8为旧严格门，不当实际完成率，不重评分为收益。输入重与能力损失因果未证实。另记录cache语义重建不等同原State续接、并行root复制不等同通用合并的边界，未宣称其导致本轮失败。\n\n本轮仅设计/证据记录；生产源码与原5文件SHA保持。同源码1514 passed工程证据复用，未冒充新跑。后续改动逐项red→green及全量回归，不大规模重构，不恢复六角色必经流水线，不更新GitHub、不新建datasets版本。\n'''
h.write_text('# 当前交接\n'+entry+prior[len('# 当前交接\n'):])
save(D/'SHA256SUMS.json',{p.name:sha(p) for p in sorted(D.iterdir()) if p.is_file() and p.name!='SHA256SUMS.json'})
print('design',sha(DOC));print('report',sha(D/'REPORT.zh-CN.md'));print('plan',sha(D/'MINIMAL_VALIDATION_PLAN.zh-CN.md'))
