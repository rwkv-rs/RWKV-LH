"""Read-only inspection of sealed R4/R5 evidence; writes only this design round."""
from pathlib import Path
import sys,json,hashlib,subprocess
R=Path('/home/chase/GitHub/RWKV-LH');sys.path.insert(0,str(R));D=R/'data/experiments/RWKV_AGENT_HARNESS_DESIGN_V1_R1_20260912'
from rwkv_lh.token_budget import tokenizer
from rwkv_lh.model_io import render_event_append
from rwkv_lh.schema import ModelEvent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
seals={}
for name in ['RWKV_READ_PARAMETER_DESCRIPTION_R4_20260912','RWKV_READ_SUMMARY_BASELINE_R5_20260912','RWKV_STRONG_MODEL_ROLE_ALIGNMENT_R1_20260912']:
 d=R/'data/experiments'/name;m=json.loads((d/'SHA256SUMS.json').read_text());bad=[p for p,v in m.items() if sha(d/p)!=v];assert not bad,(name,bad);seals[name]={'files':len(m),'seal_sha256':sha(d/'SHA256SUMS.json')}
base=R/'data/experiments/RWKV_READ_SUMMARY_BASELINE_R5_20260912';rows=[]
for p in sorted((base/'runs').glob('*/RESULT.json')):
 result=json.loads(p.read_text());state=json.loads((p.parent/'state_snapshot.json').read_text());trace=[json.loads(l) for l in (p.parent/'model_trace.jsonl').read_text().splitlines()];states=state['model_states'];gens=[x for x in trace if x['type']=='model_session_generation_returned'];gen_by_cp={x['candidate_checkpoint_id']:x['raw_generation'] for x in gens};starts={x['request_id']:x for x in trace if x['type']=='model_session_generation_started'};calls=[]
 for e in gens:
  g=e['raw_generation'];st=starts[e['request_id']];cp=states[st['input_checkpoint_id']];chain=[];cur=cp
  while cur:chain.append(cur);cur=states.get(cur['parent_checkpoint_id'])
  chain.reverse();expected=[]
  for x in chain:expected.extend(gen_by_cp[x['checkpoint_id']]['raw_token_ids'] if x['checkpoint_id'] in gen_by_cp else tokenizer().encode(x['transcript']))
  assert g['prompt_token_ids'][g['input_bos_token_count']:]==expected
  assert st['input_digest']==cp['native_state_digest']
  calls.append({'request_id':e['request_id'],'input_checkpoint':cp['checkpoint_id'],'parent_state_digest':st['input_digest'],'input_tokens':len(g['prompt_token_ids']),'output_tokens':len(g['raw_token_ids']),'finish_reason':g['finish_reason'],'input_exact':True,'raw_output':g['raw_output'],'input_token_sha256':hashlib.sha256(json.dumps(g['prompt_token_ids']).encode()).hexdigest()})
 event=json.loads((p.parent/'observation_1.json').read_text());obs=event['payload']['result']['observation'];action=result['actions'][0];content=action['result']['output'];path=p.parent/'workspace'/action['arguments']['path'];assert content==path.read_text();assert ''.join(x['content'] for x in obs['exact_spans'])==content and obs['projection_complete'];h=result['handoffs'][0];child=states[h['child']];rendered=render_event_append(ModelEvent.from_dict(event));assert child['transcript']==rendered and child['parent_checkpoint_id']==h['parent'];assert child['event_ids'].count(h['event_id'])==1 and calls[1]['input_checkpoint']==h['child'];assert sum(x['transcript']==rendered for x in states.values())==1
 root=next(x for x in states.values() if not x['parent_checkpoint_id']);defs=json.loads(root['transcript'].splitlines()[0].removeprefix('System: Tools: '))
 rows.append({'run':p.parent.name,'result_path':str(p.relative_to(R)),'result_sha256':sha(p),'trace_sha256':sha(p.parent/'model_trace.jsonl'),'state_snapshot_sha256':sha(p.parent/'state_snapshot.json'),'tool_count':len(defs),'file_tokens':action['result']['metadata']['observed_tokens'],'file_sha256':sha(path),'file_content':content,'final_output':result['final_output'],'handoff':h,'full_observation_and_exactly_once':True,'calls':calls})
r4=R/'data/experiments/RWKV_READ_PARAMETER_DESCRIPTION_R4_20260912';samples=[]
for p in sorted((r4/'before/runs').glob('*/RESULT.json')):
 result=json.loads(p.read_text())
 if result['pass']:continue
 c=p.parent.name
 for arm in ['before','after']:
  q=r4/arm/'runs'/c;res=json.loads((q/'RESULT.json').read_text());tr=[json.loads(l) for l in (q/'model_trace.jsonl').read_text().splitlines()];gg=[e['raw_generation'] for e in tr if e['type']=='model_session_generation_returned'];samples.append({'arm':arm,'run':c,'pass':res['pass'],'error':res.get('error'),'command':res.get('command'),'raw_output':gg[0]['raw_output'],'input_tokens':len(gg[0]['prompt_token_ids']),'output_tokens':len(gg[0]['raw_token_ids']),'result_sha256':sha(q/'RESULT.json'),'trace_sha256':sha(q/'model_trace.jsonl'),'handoff':res.get('observation_handoff'),'actual_tool_result':(res.get('action') or {}).get('result')})
save(D/'RAW_EVIDENCE_REVIEW.json',{'sealed_history_verified':seals,'r4_original_failed_pairs':samples,'r5_all_eight_reconstructed':rows,'new_inference_calls':0,'old_scores_changed':False,'limit':'State/input transport identity proof, not independent numerical tensor validation or new outcome scoring.'})
pre={p:sha(R/p) for p in subprocess.check_output(['git','diff','--name-only'],cwd=R,text=True).splitlines()};assert len(pre)==5;save(D/'PREEXISTING_CHANGES.json',{'files':pre,'git_status':subprocess.check_output(['git','status','--short','--untracked-files=no'],cwd=R,text=True)})
print('seals',seals)
for r in rows:print(r['run'],'file',r['file_tokens'],'tools',r['tool_count'],'calls',[(c['input_tokens'],c['output_tokens'],c['finish_reason']) for c in r['calls']])
for r in samples:print('R4',r['arm'],r['run'],r['pass'],r['raw_output'][:180])
