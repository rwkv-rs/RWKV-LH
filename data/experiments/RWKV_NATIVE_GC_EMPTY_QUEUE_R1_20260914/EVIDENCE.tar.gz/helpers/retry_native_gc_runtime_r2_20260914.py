from pathlib import Path
import json,hashlib,shutil,subprocess
R=Path('/home/chase/GitHub/RWKV-LH');D=R/'data/experiments/RWKV_NATIVE_GC_EMPTY_QUEUE_R1_20260914';P=D/'deployment';remote='/home/chase/GitHub/RWKV-LH-native-gc-r1-20260914'
for name in ('launch.sh','REGISTRATION.json'):shutil.copyfile(P/name,P/(Path(name).stem+'_R1'+Path(name).suffix))
lines=(P/'launch.sh').read_text().splitlines();lines=[line for line in lines if not line.startswith('export VLLM_RWKV7_STATE_PROFILE_MANIFEST')];lines.insert(2,'unset VLLM_RWKV7_STATE_PROFILE_MANIFEST VLLM_RWKV7_STATE_PROFILE_MANIFEST_SHA256');(P/'launch.sh').write_text('\n'.join(lines)+'\n')
reg=json.loads((P/'REGISTRATION.json').read_text());reg.update(profile_manifest_sha256=None,initial_profile='built_in_zero_only',launcher_sha256=hashlib.sha256((P/'launch.sh').read_bytes()).hexdigest(),startup_failure='R1 incorrectly provided an empty profile manifest; existing loader requires nonempty profiles. R2 uses documented existing zero_only mode, without changing source/weights or enabling a rejected State.')
(P/'REGISTRATION.json').write_text(json.dumps(reg,indent=2)+'\n')
subprocess.run(['rsync','-a',str(P/'launch.sh'),str(P/'REGISTRATION.json'),f'rwkv-8222:{remote}/'],check=True)
subprocess.run(['ssh','rwkv-8222','systemctl','--user','restart','rwkv-lh-native-gc-r1.service'],check=True)
