import importlib.util,sys,json,sqlite3,time,hashlib
from pathlib import Path
from contextlib import contextmanager
old=Path('/home/chase/GitHub/RWKV-LH-full-trace-runtime-r2-20260911/source/rwkv_lh/runtime/native_request_recovery.py')
new=Path('/home/chase/GitHub/RWKV-LH-unified-corrections-r1-20260914/temp/native_request_recovery_gc_after_r1.py')
journal=Path('/home/chase/GitHub/RWKV-LH-full-trace-runtime-r2-20260911/state/journal.sqlite3')
sys.path.insert(0,str(old.parents[2]))
def load(path,name):
 spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);sys.modules[name]=module;spec.loader.exec_module(module);return module
classes={'before':load(old,'gc_before').NativeRequestJournal,'after':load(new,'gc_after').NativeRequestJournal}
with sqlite3.connect(journal.resolve().as_uri()+'?mode=ro',uri=True) as connection:
 connection.row_factory=sqlite3.Row
 connection.execute('PRAGMA query_only=ON');connection.execute('BEGIN')
 count=connection.execute('SELECT COUNT(*) FROM native_state_gc').fetchone()[0]
 assert count==0, 'Benchmark only empty queue, no deletion or mutation'
 state_count=connection.execute('SELECT COUNT(*) FROM native_request_states').fetchone()[0]
 @contextmanager
 def readonly():yield connection
 rows=[]
 for arm in ('before','after','after','before'):
  instance=classes[arm].__new__(classes[arm]);instance.path=journal;instance._connect=readonly
  started=time.perf_counter();result=instance.reclaimable_store_keys();elapsed=time.perf_counter()-started
  assert result==[];rows.append({'arm':arm,'elapsed_seconds':elapsed,'result_count':len(result)})
 print(json.dumps({'journal':str(journal),'read_only':True,'consistent_read_transaction':True,'state_count':state_count,'gc_queue_count':count,'source_sha256':{'before':hashlib.sha256(old.read_bytes()).hexdigest(),'after':hashlib.sha256(new.read_bytes()).hexdigest()},'samples':rows},indent=2))
