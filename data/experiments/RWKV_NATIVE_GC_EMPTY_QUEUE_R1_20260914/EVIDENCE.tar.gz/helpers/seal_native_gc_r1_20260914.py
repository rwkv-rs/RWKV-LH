from pathlib import Path
import sys,json,hashlib,tarfile,subprocess
R=Path('/home/chase/GitHub/RWKV-LH');sys.path.insert(0,str(R))
from rwkv_lh.direct_trace_data import replay_run
D=R/'data/experiments/RWKV_NATIVE_GC_EMPTY_QUEUE_R1_20260914'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
replay=replay_run(D/'product_smoke/run/execution','559371f5b9aef13189ae54b345ac096af4ad2b689996c05d89de687612b3ae65')
delivery=json.loads((D/'product_smoke/run/DELIVERY.json').read_text())
audit={'task_pass':True,'basis':'Actual check_command stdout passed=true and exact expected/actual paths match; final matches output; changed_files empty. No project Strict or trained-State claim.','submitted':1,'mutations':len(delivery['changed_files']),'termination':delivery['termination_reason'],'exact_replay':True,'generations':len(replay),'logical_input_tokens':sum(len(r['input_token_ids']) for r in replay.values()),'output_tokens':sum(len(r['raw_generation']['raw_token_ids']) for r in replay.values()),'protocol_rejections':delivery['protocol_rejections'],'end_to_end_seconds':delivery['end_to_end_seconds']}
(D/'PRODUCT_AUDIT.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n')
owner=['rwkv_lh/controller.py','rwkv_lh/model.py','rwkv_lh/supervisor_openai.py','tests/test_hybrid_supervisor.py','tests/test_supervisor_openai.py']
h=hashlib.sha256(subprocess.check_output(['git','diff','--',*owner],cwd=R)).hexdigest();assert h=='314ca524bbb1e4fc28460409f1068222f29f1819cb410d025edefe64c8f796e0',h
(D/'REPORT.zh-CN.md').write_text(f'''# RWKV_NATIVE_GC_EMPTY_QUEUE_R1_20260914

任务级：真实产品 CLI smoke 1/1，通过已有递归检查并忠实回答；submitted 1，mutation 0，answer_submitted。不是项目 Strict、训练收益或并发收益。默认 zero State，未部署 NO_KEEP 候选。

生成级：{len(replay)} 次完整精确重放，逻辑输入 {audit['logical_input_tokens']} / 输出 {audit['output_tokens']} token，协议拒绝 0。真实工具执行及全文输出、State 关系保存在 EVIDENCE.tar.gz；端到端 {audit['end_to_end_seconds']:.3f} 秒（CLI 进程总耗时 9.554 秒）。

根因：reclaimable_store_keys 在 GC 队列为空时仍解码并核验全部历史 State。原服务实际 journal 有 8409 个 State；只读一致事务探针，旧函数 9.277 / 8.422 秒，新函数 0.00004171 / 0.00000662 秒。数字仅代表空 GC 查询函数，不能换算项目加速比。新服务使用独立空 journal，也不能与旧服务直接比较端到端收益。

修复：先查询待回收键，空队列直接返回；非空队列原完整性、存活 owner 和 pending pin 保护原样保留。没有修改模型输入、参数或答案。5000 历史 State 的 SQLite 指令预算回归先红后绿；非空队列损坏元数据仍拒绝。针对性 104 passed；全套 GPU0 1758 passed、0 skipped，327.07 秒。

新服务仅 GPU0，源码完整清单冻结上传，服务器未调用 Git。首次部署误配空 profiles 清单被已有校验拒绝；改用既有 zero_only 默认，失败日志保留。旧服务未改动；两个模型同时驻留的资源不算并发优势。初次只读探针漏配 Row factory 的失败也保留，属于探针错误。

边界：非空 GC、release/alias 路径仍可能扫描历史；历史 State 保留策略未改变。不能称 State 服务全部性能问题已解决。Owner 五处修改 diff SHA {h}，未混入提交。完整源码快照 deployment/source 留本地，不打包 owner 修改；源码 manifest 入证据。
''')
helpers=['benchmark_native_empty_gc_r1_20260914.py','inspect_native_journal_metadata_r1_20260914.py','deploy_native_gc_runtime_r1_20260914.py','retry_native_gc_runtime_r2_20260914.py','run_native_gc_product_smoke_r1_20260914.py','seal_native_gc_r1_20260914.py']
with tarfile.open(D/'EVIDENCE.tar.gz','w:gz') as t:
 for p in sorted(D.rglob('*')):
  rel=p.relative_to(D)
  if p.is_file() and rel.parts[:2]!=('deployment','source') and p.name not in ('EVIDENCE.tar.gz','SHA256.json','REPORT.zh-CN.md'):t.add(p,arcname=str(rel))
 for name in helpers:t.add(R/'temp'/name,arcname='helpers/'+name)
(D/'SHA256.json').write_text(json.dumps({p.name:sha(p) for p in [D/'EVIDENCE.tar.gz',D/'REPORT.zh-CN.md',D/'PRODUCT_AUDIT.json']},indent=2)+'\n')
with (R/'docs/HANDOFF.zh-CN.md').open('a') as f:f.write('\n\nGC 空队列性能根因已修复：旧服务8409历史State时每次空GC仍全表解码核验，实测8–9秒；新逻辑无待回收键直接返回，非空安全检查保留。红→绿及GPU0全套1758 passed。独立新服务真实CLI脚本任务1/1、2生成、零非法调用、无修改、8.54秒；不是项目Strict/训练收益。原服务不动，新服务29621只用GPU0/zero。详见 data/experiments/RWKV_NATIVE_GC_EMPTY_QUEUE_R1_20260914/REPORT.zh-CN.md。四个已有局部修复目标正以24 calls/600s和24K窗口重新采集，条件不同不直接称对照收益。\n')
print(audit)
