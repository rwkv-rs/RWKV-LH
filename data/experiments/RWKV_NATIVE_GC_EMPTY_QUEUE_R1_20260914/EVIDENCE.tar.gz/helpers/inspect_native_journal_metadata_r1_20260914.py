import os,json,sqlite3,hashlib,time
from pathlib import Path
pid=4016428
entries=Path(f'/proc/{pid}/environ').read_bytes().split(b'\0')
env=dict(e.decode().split('=',1) for e in entries if b'=' in e)
p=Path(env['RWKV_NATIVE_REQUEST_JOURNAL']);result={'pid':pid,'journal':str(p),'file_bytes':p.stat().st_size,'epoch':time.time()}
with sqlite3.connect(p.resolve().as_uri()+'?mode=ro',uri=True) as c:
 c.execute('PRAGMA query_only=ON')
 result['counts']={name:c.execute('SELECT COUNT(*) FROM '+name).fetchone()[0] for name in ('native_requests','native_request_states','native_state_gc','native_state_retirements')}
 result['state_metadata_characters']=c.execute('SELECT SUM(LENGTH(metadata_json)) FROM native_request_states').fetchone()[0]
 result['queued_gc_count']=c.execute('SELECT COUNT(*) FROM native_state_gc').fetchone()[0]
result['source_candidates']=[]
for prefix in env.get('PYTHONPATH','').split(':'):
 if not prefix:continue
 f=Path(prefix)/'rwkv_lh/runtime/native_request_recovery.py'
 if f.is_file():result['source_candidates'].append({'path':str(f),'sha256':hashlib.sha256(f.read_bytes()).hexdigest()})
print(json.dumps(result,indent=2))
