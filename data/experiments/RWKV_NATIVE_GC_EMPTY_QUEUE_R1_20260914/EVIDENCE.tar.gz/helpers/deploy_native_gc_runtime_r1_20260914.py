from pathlib import Path
import shutil,json,hashlib,subprocess,sys
R=Path('/home/chase/GitHub/RWKV-LH');sys.path.insert(0,str(R))
from rwkv_lh.inference.uploaded_sources import source_inventory,PROJECT_SCHEMA
D=R/'data/experiments/RWKV_NATIVE_GC_EMPTY_QUEUE_R1_20260914';P=D/'deployment';remote='/home/chase/GitHub/RWKV-LH-native-gc-r1-20260914';old='/home/chase/GitHub/RWKV-LH-unified-corrections-r1-20260914'
assert '1758 passed' in (D/'FULL_TESTS.log').read_text();P.mkdir(exist_ok=False);source=P/'source';source.mkdir()
for name in ('rwkv_lh','scripts'):shutil.copytree(R/name,source/name,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
for name in ('pyproject.toml','uv.lock'):shutil.copyfile(R/name,source/name)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
(P/'validation').mkdir();manifest={'schema_version':PROJECT_SCHEMA,'project_root':remote+'/source','source_root':'.','files':[{'path':p,'sha256':h,'bytes':n} for p,(h,n) in sorted(source_inventory(source).items())]}
(P/'validation/PROJECT_SOURCE.json').write_text(json.dumps(manifest,indent=2)+'\n');project_sha=sha(P/'validation/PROJECT_SOURCE.json')
oldservice=R/'data/experiments/RWKV_UNIFIED_CORRECTION_TRAIN_R1_20260914/evaluation_service'
profiles=json.loads((oldservice/'STATE_PROFILES_SERVING.json').read_text());profiles['profiles']=[];(P/'STATE_PROFILES.json').write_text(json.dumps(profiles,indent=2)+'\n')
launch=(oldservice/'launch.sh').read_text().replace(old+'/source',remote+'/source').replace(old+'/validation/PROJECT_SOURCE.json',remote+'/validation/PROJECT_SOURCE.json').replace('0620845ecdfa75239d5d984d5bf0634b1c3dd0b661f218433af033670185bedf',project_sha).replace(old+'/evaluation_state',remote+'/state').replace(old+'/evaluation_service/STATE_PROFILES_SERVING.json',remote+'/STATE_PROFILES.json').replace(sha(oldservice/'STATE_PROFILES_SERVING.json'),sha(P/'STATE_PROFILES.json')).replace('--port 18246','--port 18247').replace('rwkv-direct-unified-r1-ctx24576','rwkv-code-agent-gc-r1-ctx24576').replace('--gpu-memory-utilization 0.70','--gpu-memory-utilization 0.60')
(P/'launch.sh').write_text(launch)
reg={'local_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'project_manifest_sha256':project_sha,'launcher_sha256':sha(P/'launch.sh'),'profile_manifest_sha256':sha(P/'STATE_PROFILES.json'),'gc_module_sha256':sha(source/'rwkv_lh/runtime/native_request_recovery.py'),'artifact_manifest_sha256':'5d7fc93f1f282d49ea0bd059618297dc9629783cdb080c6d2e3e5448ee0109e0','model_artifact':profiles['model_artifact'],'remote_root':remote,'remote_port':18247,'local_port':29621,'model':'rwkv-code-agent-gc-r1-ctx24576','gpu_uuid':'GPU-1faf7f09-25f4-2515-b707-6e0766aa841d','initial_profile':'zero','original_service':'rwkv-lh-native-current.service','new_service':'rwkv-lh-native-gc-r1.service','scope':'Side service for verified runtime and next collection; original service remains unchanged. Fresh separate journal/blobs, no automatic reuse of old live State or rejected trained profile. Two loaded services on GPU0 are diagnostic overhead, not claimed production resource advantage.'}
(P/'REGISTRATION.json').write_text(json.dumps(reg,indent=2)+'\n')
subprocess.run(['ssh','rwkv-8222','mkdir','-p',remote],check=True)
subprocess.run(['rsync','-a',str(P)+'/',f'rwkv-8222:{remote}/'],check=True)
subprocess.run(['ssh','rwkv-8222','systemd-run','--user','--unit=rwkv-lh-native-gc-r1','--property=RuntimeMaxSec=30000',f'--property=StandardOutput=append:{remote}/service.log','--property=StandardError=inherit','bash',remote+'/launch.sh'],check=True)
print(json.dumps(reg,indent=2))
