#!/bin/bash
set -euo pipefail
export PYTHONPATH=/home/chase/GitHub/RWKV-LH-unified-corrections-r1-20260914/source:/home/chase/GitHub/RWKV-LH-full-trace-runtime-r2-20260911/engine
export PYTHONDONTWRITEBYTECODE=1
export OMP_NUM_THREADS=4
export VLLM_RWKV7_WKV_MODE=fp32io16
export CUDA_DEVICE_ORDER=PCI_BUS_ID
export CUDA_VISIBLE_DEVICES=0
exec timeout 3700 /home/chase/GitHub/RWKV-LH/data/runtime/engines/vllm-rwkv-67f0c5996c50/.venv/bin/python -B /home/chase/GitHub/RWKV-LH-unified-corrections-r1-20260914/gradient_diagnostic_r2/reproduce_native_gradient_failure_r2_20260914.py /home/chase/GitHub/RWKV-LH-unified-corrections-r1-20260914/gradient_diagnostic_r2/REGISTRATION.json 4b2766fd29a133aaacc14410fc7d9b8fd7a0c04352058d0300aeacf2fddfb714 /home/chase/GitHub/RWKV-LH-unified-corrections-r1-20260914/gradient_diagnostic_r2/DIAGNOSTIC_REGISTRATION.json 5fd8645929e09e12e24249130a614a0159f68a6ca472fcbb2acf600cfa21a293
