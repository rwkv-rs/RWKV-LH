"""Replay registered optimizer path and inspect the failing backward, never retain."""
from pathlib import Path
import sys,json,hashlib,time,random
from rwkv_lh import statetune_core as core
from rwkv_lh import statetune_training as training
reg_path=Path(sys.argv[1]);reg_sha=sys.argv[2];spec_path=Path(sys.argv[3]);spec_sha=sys.argv[4]
spec=core.read_sealed_json(spec_path,spec_sha);assert core.sha256_file(__file__)==spec['helper_sha256'];reg=core.read_sealed_json(reg_path,reg_sha);output=Path(spec['output']);output.mkdir(parents=True,exist_ok=True);original=training.optimize_state;phase='replay';handles=[]
def write(name,row):
 output.mkdir(parents=True,exist_ok=True)
 with (output/name).open('a') as f:f.write(json.dumps(row,allow_nan=False)+'\n')
def wrapped(model,samples,config,*,context_tokens,record,started_at,**kwargs):
 import torch
 parameters=core.state_parameters(model,layers=model.layout.layers);last_steps=0
 def inspect_gradient(name,grad):
  finite=torch.isfinite(grad);write('GRADIENT_HOOKS.jsonl',{'phase':phase,'name':name,'dtype':str(grad.dtype),'finite':bool(finite.all()),'nonfinite_count':int((~finite).sum()),'shape':list(grad.shape)})
  return grad
 def observed(row):
  nonlocal last_steps
  record(row)
  if row['event']=='optimizer_step_completed':
   last_steps=row['optimizer_steps']
   if last_steps==spec['capture_after_steps']:
    values={k:p.detach().float().cpu() for k,p in parameters.items()};path=output/'STATE_BEFORE_FAILURE_FP32.pth';torch.save(values,path)
    write('CAPTURE.jsonl',{'step':last_steps,'state_path':str(path),'sha256':core.sha256_file(path),'format':'diagnostic exact FP32 parameters, not a portable production profile','samples_seen':row['samples_seen']})
    for name,p in parameters.items():handles.append(p.register_hook(lambda g,n=name:inspect_gradient(n,g)))
 try:return original(model,samples,config,context_tokens=context_tokens,record=observed,started_at=started_at,**kwargs)
 except ValueError as exc:
  write('FAILURE.jsonl',{'actual_optimizer_steps':last_steps,'error':str(exc)})
  if str(exc)!='State gradient is missing or nonfinite' or last_steps!=spec['capture_after_steps']:raise
  rng=random.Random(config['seed']);order=[]
  for epoch in range(config['epochs']):
   indices=list(range(len(samples)));rng.shuffle(indices);order.extend(indices)
  sample=samples[order[last_steps]];assert sample['sample_id']==spec['failed_sample_id']
  batch=core.collate_samples([sample],context_tokens=context_tokens);reference=None
  for scale in spec['loss_scales']:
   global phase
   phase='diagnostic_scale_'+str(scale);model.zero_grad(set_to_none=True);tick=time.monotonic()
   logits=model(batch['input_ids'].cuda());loss=core.target_cross_entropy(logits,batch['labels'].cuda());assert bool(torch.isfinite(loss));(loss*scale).backward();del logits
   values={n:p.grad.detach().float().cpu()/scale for n,p in parameters.items() if p.grad is not None};missing=sorted(set(parameters)-set(values));finite=not missing and all(bool(torch.isfinite(g).all()) for g in values.values())
   item={'phase':phase,'optimizer_steps':0,'scale':scale,'loss':float(loss.detach()),'missing':missing,'all_finite':finite,'seconds':time.monotonic()-tick,'peak_allocated_bytes':torch.cuda.max_memory_allocated()}
   if finite:
    vec=torch.cat([values[n].flatten() for n in sorted(values)]);item.update(unscaled_gradient_norm=float(torch.linalg.vector_norm(vec.double())),zero_fraction=float((vec==0).float().mean()),all_layers_nonzero=all(bool(g.ne(0).any()) for g in values.values()))
    if reference is None:reference=vec.clone();item['reference_scale']=scale
    else:item['relative_l2_to_first_finite']=float(torch.linalg.vector_norm((vec-reference).double())/torch.linalg.vector_norm(reference.double()).clamp_min(1e-30))
   write('LOSS_SCALE_PROBES.jsonl',item);print(json.dumps(item),flush=True);del loss
   assert torch.cuda.max_memory_allocated()<=spec['max_allocated_bytes']
  raise
 finally:
  for handle in handles:handle.remove()
training.optimize_state=wrapped
try:training.run_training({'path':str(reg_path),'sha256':reg_sha},reg['ledger_root']+'/'+reg['run_id'],source_root=Path(spec['source_root']))
finally:write('DIAGNOSTIC_END.jsonl',{'scope':'No candidate retained; actual replay optimizer steps are in immutable run ledger. Scale probes perform backward only with no optimizer update. Production source unchanged.'})
