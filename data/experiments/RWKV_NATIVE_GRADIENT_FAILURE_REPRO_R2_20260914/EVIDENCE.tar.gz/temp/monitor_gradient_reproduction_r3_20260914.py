from pathlib import Path
import subprocess,json,time
R=Path('/home/chase/GitHub/RWKV-LH');D=R/'data/experiments/RWKV_NATIVE_GRADIENT_FAILURE_REPRO_R2_20260914';remote='/home/chase/GitHub/RWKV-LH-unified-corrections-r1-20260914';start=time.monotonic();last=None
while time.monotonic()-start<3900:
 p=subprocess.run(['scp','-q',f'rwkv-8222:{remote}/training_runs/direct-gradient-replay-r2-20260914/RESULT.json',str(D/'PROGRESS.json')],capture_output=True,text=True)
 if p.returncode==0:
  r=json.loads((D/'PROGRESS.json').read_text());key=(r.get('optimizer_steps',0)//10,r['status'],r['last_event'])
  if key!=last:print(json.dumps({k:r.get(k) for k in ['optimizer_steps','last_event','status','error','elapsed_seconds']}),flush=True);last=key
  if r['last_event'] in ('run_failed','run_finished'):
   subprocess.run(['rsync','-a',f'rwkv-8222:{remote}/gradient_diagnostic_r2/evidence/','--exclude=*.pth',str(D/'evidence')+'/'],check=True)
   subprocess.run(['scp','-q',f'rwkv-8222:{remote}/gradient_diagnostic_r2/run.log',str(D/'run.log')],check=True)
   subprocess.run(['scp','-q',f'rwkv-8222:{remote}/training_runs/direct-gradient-replay-r2-20260914/events.jsonl',str(D/'events.jsonl')],check=True)
   break
 gpu=subprocess.run(['ssh','rwkv-8222','nvidia-smi','-i','0','--query-gpu=uuid,memory.used,utilization.gpu,power.draw','--format=csv,noheader,nounits'],capture_output=True,text=True)
 with (D/'GPU0_TELEMETRY.jsonl').open('a') as f:f.write(json.dumps({'epoch':time.time(),'returncode':gpu.returncode,'raw':gpu.stdout.strip(),'error':gpu.stderr.strip()})+'\n')
 time.sleep(20)
else:raise RuntimeError('diagnostic monitor budget exhausted; inspect service, no automatic data repair')
print('diagnostic ended; retained=false',flush=True)
