from pathlib import Path
import json,hashlib,subprocess,shlex
R=Path('/home/chase/GitHub/RWKV-LH');D=R/'data/experiments/RWKV_NATIVE_GRADIENT_FAILURE_REPRO_R2_20260914';remote='/home/chase/GitHub/RWKV-LH-unified-corrections-r1-20260914';rd=remote+'/gradient_diagnostic_r2';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
probe=subprocess.run(['ssh','rwkv-8222',"curl -fsS http://127.0.0.1:18234/metrics | grep -E '^vllm:num_requests_(running|waiting)'"],capture_output=True,text=True,check=True);(D/'IDLE_BEFORE.txt').write_text(probe.stdout);assert all(float(s.rsplit(' ',1)[1])==0 for s in probe.stdout.splitlines()) and probe.stdout
subprocess.run(['ssh','rwkv-8222','systemctl','--user','stop','rwkv-lh-native-current.service'],check=True)
args=['systemd-run','--user','--unit=rwkv-lh-gradient-replay-r2','--property=RuntimeMaxSec=3800','--property=ExecStopPost=/usr/bin/systemctl --user start rwkv-lh-native-current.service',f'--property=StandardOutput=append:{rd}/run.log','--property=StandardError=inherit','bash',rd+'/launch.sh']
try:subprocess.run(['ssh','rwkv-8222',shlex.join(args)],check=True)
except BaseException:subprocess.run(['ssh','rwkv-8222','systemctl','--user','start','rwkv-lh-native-current.service']);raise
print('diagnostic replay launched, max84 charged optimizer steps, scale probes zero updates')
