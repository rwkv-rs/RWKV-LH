from pathlib import Path
import shutil,re,hashlib,difflib,json
R=Path('/home/chase/GitHub/RWKV-LH');D=R/'data/experiments/RWKV_RESUMED_BUDGET_SCOPE_R1_20260915';C=D/'candidate_source';C.mkdir(exist_ok=False);shutil.copytree(R/'rwkv_lh',C/'rwkv_lh',ignore=shutil.ignore_patterns('__pycache__','*.pyc'));(C/'pytest.ini').write_text('[pytest]\n')
p=C/'rwkv_lh/controller.py';s=p.read_text();original=s
anchor='    @property\n    def max_actions('
assert anchor in s
s=s.replace(anchor,'''    def _identical_result_count(self, state: RunState, fingerprint: str) -> int:
        """Scope repeat limits to the Goal epoch without erasing observations."""
        if not self._goal_self_termination_only(state):
            return state.observation_counts.get(fingerprint, 0)
        start = self._goal_epoch_start_sequence(state)
        return sum(
            event.event_type == "action_finished"
            and event.sequence > start
            and event.payload.get("action", {}).get("observation_fingerprint") == fingerprint
            for event in state.causal_records.values()
        )

'''+anchor,1)
old='''                identical_result_count = state.observation_counts.get(
                    action.observation_fingerprint,
                    0,
                )''';assert s.count(old)==1;s=s.replace(old,'''                identical_result_count = self._identical_result_count(
                    state, action.observation_fingerprint
                )''')
def convert(m):
 i=m.group(1);return i+'if self._lifecycle_budget_count(\n'+i+'    state,\n'+i+'    event_type="protocol_rejection_recorded",\n'+i+'    bounded_total=state.protocol_rejections,\n'+i+') >= self._MAX_PROTOCOL_REJECTIONS:'
s,n=re.subn(r'(?m)^([ \t]*)if state.protocol_rejections >= self._MAX_PROTOCOL_REJECTIONS:',convert,s);assert n==3;p.write_text(s)
(D/'PRECHANGE_CONTROLLER.py.txt').write_text(original);(D/'OWN_CONTROLLER.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True),s.splitlines(True),fromfile='a/rwkv_lh/controller.py',tofile='b/rwkv_lh/controller.py')))
(D/'REGISTRATION.json').write_text(json.dumps({'trigger':'Real takeover starts with fresh declared call budget but inherited successful-read total immediately interrupts it. Four red resume tests reproduce success/protocol scope, existing failure scope already passes.','scope':'Use existing Goal run_yielded epoch boundary for success and protocol limits, as failure budget already does. Non-Goal cumulative behavior unchanged. Keep raw cumulative history, total calls/seconds and original output. No new State field, protocol or forced action.','prechange_sha256':hashlib.sha256(original.encode()).hexdigest(),'candidate_sha256':hashlib.sha256(s.encode()).hexdigest(),'planned_validation':'6 resume cases plus relevant/full tests; actual strong recovery rerun separately after fixed-source freeze. Original source remains untouched until frequency R2 both arms finish.'},indent=2)+'\n')
