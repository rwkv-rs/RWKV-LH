from pathlib import Path
R=Path('/home/chase/GitHub/RWKV-LH')
p=R/'rwkv_lh/model_session.py';s=p.read_text();anchor='    def to_dict(self) -> dict[str, Any]:\n';pos=s.index(anchor,s.index('class SessionSampling:'))
s=s[:pos]+'''    @classmethod
    def from_settings(cls, settings: RuntimeSettings) -> SessionSampling:
        """Resolve defaults from the session that owns this generation."""
        return cls(
            temperature=settings.default_temperature,
            top_p=settings.default_top_p,
            top_k=settings.default_top_k,
            presence_penalty=settings.default_presence_penalty,
            frequency_penalty=settings.default_frequency_penalty,
            penalty_decay=settings.default_penalty_decay,
        )

'''+s[pos:];assert s.count('selected = sampling or SessionSampling()')==2;s=s.replace('selected = sampling or SessionSampling()','selected = sampling if sampling is not None else SessionSampling.from_settings(self.settings)');p.write_text(s)
p=R/'rwkv_lh/model.py';s=p.read_text();s=s.replace('    SessionSampling,\n','');start=s.index('    _SAMPLING = SessionSampling(');end=s.index('    _RESULT_PROJECTION_VERSION',start);s=s[:start]+s[end:];assert s.count('sampling=self._SAMPLING,')==4
s=s.replace('            sampling=self._SAMPLING,\n','').replace('self._SAMPLING.', 'candidate.sampling.');p.write_text(s)
