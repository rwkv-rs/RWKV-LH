from __future__ import annotations

import json
import hashlib
import os
import re
import time
from contextlib import contextmanager
from dataclasses import replace

import requests
import pytest
import rwkv_lh.supervisor_openai as supervisor_openai_module

from rwkv_lh.contract_graph import (
    ObligationPhase,
    ContractPlanRequest,
    ContractReviewRequest,
    ResultCapsule,
)
from rwkv_lh.goal_loop_protocol import (
    GoalObligation, GoalPlanPatch, GoalPlanRequest, GoalPlanStep,
    GoalStageReviewRequest, RollingGoalPlan,
)
from rwkv_lh.supervisor import (
    SupervisorDirectiveRequest,
    SupervisorPlan,
    SupervisorPlanRequest,
    SupervisorReviewRequest,
    SupervisorStageRequest,
)
from rwkv_lh.supervisor_openai import (
    CONTRACT_PLAN_RESPONSE_SCHEMA,
    OpenAICompatibleSupervisorClient,
    OpenAIGoalSupervisorClient,
    SupervisorAPISettings,
    SupervisorGenerationInterrupted,
    SupervisorProtocolError,
    SupervisorTransportError,
    _decode_supervisor_json_content,
    supervisor_policy_from_env,
)


class FakeResponse:
    def __init__(self, payload: dict, status_code: int = 200):
        self.payload = payload
        self.status_code = status_code

    def json(self):
        return self.payload

    def raise_for_status(self):
        if self.status_code >= 400:
            raise RuntimeError(f"HTTP {self.status_code}")


class FakeSession:
    trust_env = False

    def __init__(self, responses: list[FakeResponse | BaseException]):
        self.responses = list(responses)
        self.posts: list[dict] = []
        self.closed = False

    def post(self, url, **kwargs):
        self.posts.append({"url": url, **kwargs})
        response = self.responses.pop(0)
        if isinstance(response, BaseException):
            raise response
        return response

    def get(self, url, **kwargs):
        del url, kwargs
        return FakeResponse({"data": [{"id": "gpt-test"}]})

    def close(self):
        self.closed = True


def response(content: dict, *, model: str = "gpt-test") -> FakeResponse:
    return FakeResponse(
        {
            "model": model,
            "choices": [
                {
                    "message": {"role": "assistant", "content": json.dumps(content)},
                    "finish_reason": "stop",
                }
            ],
            "usage": {"prompt_tokens": 10, "completion_tokens": 8, "total_tokens": 18},
        }
    )


def responses_response(content: dict, *, model: str = "gpt-test") -> FakeResponse:
    return FakeResponse(
        {
            "id": "resp_test",
            "model": model,
            "status": "completed",
            "output": [
                {
                    "id": "msg_test",
                    "type": "message",
                    "role": "assistant",
                    "status": "completed",
                    "content": [
                        {
                            "type": "output_text",
                            "text": json.dumps(content),
                            "annotations": [],
                        }
                    ],
                }
            ],
            "usage": {"input_tokens": 10, "output_tokens": 8, "total_tokens": 18},
        }
    )


def contract_operation_catalog() -> tuple[dict, ...]:
    return (
        {
            "name": "write_file",
            "description": "Write a file.",
            "scope_mode": "path_mutation",
            "capability_class": "local.workspace_mutation",
            "network_access": "none",
            "data_boundary": "workspace",
            "side_effect_class": "workspace_mutation",
        },
        {
            "name": "read_file",
            "description": "Read a file.",
            "scope_mode": "read_only",
            "capability_class": "local.workspace_read",
            "network_access": "none",
            "data_boundary": "workspace",
            "side_effect_class": "read_only",
        },
    )


def contract_work_atom_branches(schema: dict) -> list[dict]:
    atom_schema = schema["properties"]["new_nodes"]["items"]["properties"][
        "atom"
    ]
    return atom_schema["anyOf"]


def nested_schema_keys(value) -> set[str]:
    keys: set[str] = set()
    if isinstance(value, dict):
        keys.update(str(key) for key in value)
        for item in value.values():
            keys.update(nested_schema_keys(item))
    elif isinstance(value, list):
        for item in value:
            keys.update(nested_schema_keys(item))
    return keys


def v2_atom(
    *,
    atom_id: str,
    role: str,
    objective: str,
    depends_on: list[str],
    read_roots: list[str],
    write_roots: list[str],
    kind: str,
    effect_ceiling: str,
    action_budget: int = 1,
) -> dict:
    return {
        "atom_id": atom_id,
        "role": role,
        "kind": kind,
        "effect_ceiling": effect_ceiling,
        "objective": objective,
        "depends_on": depends_on,
        "read_roots": read_roots,
        "write_roots": write_roots,
        "evidence_requirements": {
            "kinds": ["exact_operation_result"],
            "freshness": "current_workspace",
            "source_preferences": ["workspace"],
        },
        "action_budget": action_budget,
    }


def contract_plan_value() -> dict:
    return {
        "summary": "Compile a typed result contract.",
        "new_obligations": [
            {
                "obligation_id": "OBL-result",
                "predicate": "result.txt contains exact text ok.",
                "evidence_kinds": ["read_file"],
                "assertions": [
                    {
                        "assertion_id": "ASSERT-result-text",
                        "kind": "text_exact",
                        "target_path": "result.txt",
                        "target_pointer": "",
                        "sources": [],
                        "expected": "ok",
                        "keys": [],
                        "order": "",
                        "algorithm": "",
                    }
                ],
            }
        ],
        "new_nodes": [
            {
                "obligation_ids": ["OBL-result"],
                "atom": v2_atom(
                    atom_id="NODE-write",
                    role="work",
                    objective="Create result.txt containing exact text ok.",
                    depends_on=[],
                    read_roots=[],
                    write_roots=["result.txt"],
                    kind="mutate",
                    effect_ceiling="workspace_mutation",
                ),
            },
            {
                "obligation_ids": ["OBL-result"],
                "atom": v2_atom(
                    atom_id="NODE-verify",
                    role="work",
                    objective="Read result.txt and verify its exact content.",
                    depends_on=["NODE-write"],
                    read_roots=["result.txt"],
                    write_roots=[],
                    kind="verify",
                    effect_ceiling="local_read_only",
                ),
            },
            {
                "obligation_ids": ["OBL-result"],
                "atom": v2_atom(
                    atom_id="NODE-final",
                    role="finalizer",
                    objective="Read result.txt and report completion.",
                    depends_on=["NODE-verify"],
                    read_roots=["result.txt"],
                    write_roots=[],
                    kind="synthesize",
                    effect_ceiling="local_read_only",
                ),
            },
        ],
    }


def lean_contract_plan_value() -> dict:
    """Return the production Planner payload without Controller-owned fields."""

    value = contract_plan_value()
    for obligation in value["new_obligations"]:
        obligation.pop("phase", None)
        obligation.pop("assertions", None)
    for node in value["new_nodes"]:
        atom = node["atom"]
        atom.pop("evidence_requirements", None)
        atom.pop("action_budget", None)
    return value


def test_contract_compiler_uses_assertion_structure_to_bound_presentation_phase():
    immutable_request = (
        "Create result.txt containing exact text ok, then respond concisely."
    )
    value = contract_plan_value()
    value["new_obligations"][0]["phase"] = "final_presentation"
    value["new_obligations"].append(
        {
            "obligation_id": "OBL-presentation",
            "predicate": "The final answer is concise.",
            "phase": "final_presentation",
            "evidence_kinds": [],
            "assertions": [
                {
                    "assertion_id": "ASSERT-presentation",
                    "kind": "semantic_review",
                    "target_path": "",
                    "target_pointer": "",
                    "sources": [],
                    "expected": "",
                    "keys": [],
                    "order": "",
                    "algorithm": "",
                }
            ],
        }
    )
    value["new_nodes"][-1]["obligation_ids"] = [
        "OBL-result",
        "OBL-presentation",
    ]
    request = ContractPlanRequest(
        run_id="RUN-PHASE-COMPILER",
        request=immutable_request,
        request_digest="digest-phase-compiler",
        graph_revision=0,
        obligations=(),
        nodes=(),
        latest_review=None,
        result_capsules=(),
        available_operations=contract_operation_catalog(),
        workspace_manifest={"entries": []},
    )

    patch = OpenAICompatibleSupervisorClient._contract_patch_from_value(
        request, value
    )

    by_id = {item.obligation_id: item for item in patch.new_obligations}
    assert by_id["OBL-result"].phase == ObligationPhase.EXECUTION_EVIDENCE
    assert by_id["OBL-result"].assertions
    assert by_id["OBL-presentation"].phase == ObligationPhase.FINAL_PRESENTATION
    assert by_id["OBL-presentation"].assertions == ()


def test_contract_compiler_synthesizes_missing_structural_finalizer():
    immutable_request = "Create result.txt containing exact text ok."
    value = contract_plan_value()
    value["new_nodes"] = value["new_nodes"][:-1]
    request = ContractPlanRequest(
        run_id="RUN-AUTO-FINALIZER",
        request=immutable_request,
        request_digest="digest-auto-finalizer",
        graph_revision=0,
        obligations=(),
        nodes=(),
        latest_review=None,
        result_capsules=(),
        available_operations=contract_operation_catalog(),
        workspace_manifest={"entries": []},
    )

    patch = OpenAICompatibleSupervisorClient._contract_patch_from_value(
        request, value
    )

    work = [node for node in patch.new_nodes if node.atom.role.value == "work"]
    finalizers = [
        node for node in patch.new_nodes if node.atom.role.value == "finalizer"
    ]
    assert [node.node_id for node in work] == ["NODE-write", "NODE-verify"]
    assert len(finalizers) == 1
    finalizer = finalizers[0]
    assert finalizer.node_id == "NODE-frozen-finalizer"
    assert finalizer.obligation_ids == ("OBL-result",)
    assert finalizer.atom.depends_on == ("NODE-write", "NODE-verify")
    assert finalizer.atom.write_roots == ()
    assert finalizer.atom.read_roots == (".",)
    assert finalizer.atom.allowed_operations
    assert finalizer.atom.operation_allowset_source
    assert finalizer.atom.minimum_actions == 1


def test_contract_plan_schema_assigns_finalizer_structure_to_controller():
    request = ContractPlanRequest(
        run_id="RUN-CONTROLLER-FINALIZER",
        request="Create result.txt containing exact text ok.",
        request_digest="digest-controller-finalizer",
        graph_revision=0,
        obligations=(),
        nodes=(),
        latest_review=None,
        result_capsules=(),
        available_operations=contract_operation_catalog(),
        workspace_manifest={"entries": []},
    )

    schema = OpenAICompatibleSupervisorClient._contract_plan_schema(request)
    nodes = schema["properties"]["new_nodes"]
    branches = contract_work_atom_branches(schema)
    atom_properties = [branch["properties"] for branch in branches]

    assert nodes["minItems"] == 1
    assert [item["kind"]["enum"] for item in atom_properties] == [
        ["investigate"],
        ["mutate"],
        ["verify"],
    ]
    assert all(item["role"]["enum"] == ["work"] for item in atom_properties)
    assert [item["effect_ceiling"]["enum"] for item in atom_properties] == [
        ["local_read_only", "public_read_only", "local_process_read_only"],
        ["workspace_mutation", "local_process_mutation"],
        ["local_read_only", "public_read_only", "local_process_read_only"],
    ]
    assert all(
        "latest successful read_file/read_json observation"
        in item["depends_on"]["description"]
        for item in atom_properties
    )
    assert not ({"allOf", "if", "then", "else"} & nested_schema_keys(schema))

    correction = OpenAICompatibleSupervisorClient._contract_plan_schema(
        replace(
            request,
            graph_revision=1,
            obligations=({"obligation_id": "OBL-result"},),
        )
    )
    correction_atoms = [
        branch["properties"] for branch in contract_work_atom_branches(correction)
    ]
    assert all(item["role"]["enum"] == ["work"] for item in correction_atoms)
    assert [item["kind"]["enum"] for item in correction_atoms] == [
        ["investigate"],
        ["mutate"],
        ["verify"],
    ]
    correction_pattern = correction_atoms[0]["atom_id"]["pattern"]
    assert all(
        item["atom_id"]["pattern"] == correction_pattern
        for item in correction_atoms
    )
    assert re.fullmatch(correction_pattern, "NODE-write") is None
    correction_namespace = (
        OpenAICompatibleSupervisorClient._contract_plan_atom_id_namespace(
            replace(
                request,
                graph_revision=1,
                obligations=({"obligation_id": "OBL-result"},),
            )
        )
    )
    assert re.fullmatch(correction_pattern, correction_namespace + "repair")

    next_revision = replace(
        request,
        graph_revision=2,
        obligations=({"obligation_id": "OBL-result"},),
    )
    assert (
        OpenAICompatibleSupervisorClient._contract_plan_atom_id_namespace(
            next_revision
        )
        != correction_namespace
    )

    finalizer = OpenAICompatibleSupervisorClient._contract_plan_schema(
        replace(
            request,
            graph_revision=1,
            obligations=({"obligation_id": "OBL-result"},),
            finalizer_required=True,
        )
    )
    finalizer_nodes = finalizer["properties"]["new_nodes"]
    finalizer_atom = finalizer_nodes["items"]["properties"]["atom"][
        "properties"
    ]
    assert finalizer_nodes["minItems"] == 1
    assert finalizer_nodes["maxItems"] == 1
    assert finalizer_atom["role"]["enum"] == ["finalizer"]
    assert finalizer_atom["kind"]["enum"] == ["synthesize"]
    assert finalizer_atom["effect_ceiling"]["enum"] == ["local_read_only"]


def test_contract_plan_namespace_avoids_existing_prefix_and_auto_verifier_id():
    request = ContractPlanRequest(
        run_id="RUN-FRESH-NAMESPACE",
        request="Repair result.txt and verify it.",
        request_digest="digest-fresh-namespace",
        graph_revision=1,
        obligations=({"obligation_id": "OBL-result"},),
        nodes=(),
        latest_review=None,
        result_capsules=(),
        available_operations=contract_operation_catalog(),
        workspace_manifest={"entries": [{"path": "result.txt"}]},
    )
    first_namespace = (
        OpenAICompatibleSupervisorClient._contract_plan_atom_id_namespace(request)
    )
    occupied_request = replace(
        request,
        nodes=({"node_id": first_namespace + "existing"},),
    )
    selected_namespace = (
        OpenAICompatibleSupervisorClient._contract_plan_atom_id_namespace(
            occupied_request
        )
    )
    assert selected_namespace != first_namespace
    assert not (first_namespace + "existing").startswith(selected_namespace)

    mutation_id = selected_namespace + "mutate"
    suffix = hashlib.sha256(
        f"{request.request_digest}\0{mutation_id}".encode("utf-8")
    ).hexdigest()[:12]
    auto_id = f"NODE-auto-verify-{suffix}"
    value = {
        "new_nodes": [
            {
                "obligation_ids": ["OBL-result"],
                "atom": {
                    "atom_id": mutation_id,
                    "role": "work",
                    "kind": "mutate",
                    "effect_ceiling": "workspace_mutation",
                    "objective": "Repair result.txt.",
                    "depends_on": [],
                    "read_roots": ["result.txt"],
                    "write_roots": ["result.txt"],
                },
            }
        ]
    }
    normalized = (
        OpenAICompatibleSupervisorClient._contract_nodes_with_mechanical_verification(
            replace(request, nodes=({"node_id": auto_id},)), value
        )
    )
    identifiers = [str(item["atom"]["atom_id"]) for item in normalized]
    assert auto_id not in identifiers
    assert f"{auto_id}-2" in identifiers


def test_contract_adapter_compiles_feasible_budget_for_every_write_root():
    immutable_request = "Create result.txt and README.md."
    value = lean_contract_plan_value()
    value["new_nodes"][0]["atom"]["write_roots"] = [
        "result.txt",
        "README.md",
    ]
    value["new_nodes"][1]["atom"]["read_roots"] = [
        "result.txt",
        "README.md",
    ]
    value["new_nodes"][2]["atom"]["read_roots"] = [
        "result.txt",
        "README.md",
    ]
    audit: list[dict] = []
    client = OpenAICompatibleSupervisorClient(
        settings(),
        session=FakeSession([response(value)]),
        audit_hook=audit.append,
    )

    patch = client.plan_contract_graph(
        ContractPlanRequest(
            run_id="RUN-PROJECT-BUDGET",
            request=immutable_request,
            request_digest="digest-project-budget",
            graph_revision=0,
            obligations=(),
            nodes=(),
            latest_review=None,
            result_capsules=(),
            available_operations=contract_operation_catalog(),
            workspace_manifest={"entries": []},
        )
    )

    writer = next(node for node in patch.new_nodes if node.node_id == "NODE-write")
    assert writer.atom.minimum_actions == 2
    assert writer.atom.action_budget == 4
    normalized = [
        item
        for item in audit
        if item.get("normalization")
        == "compiled_mechanical_atom_fields"
    ]
    by_id = {item["atom_id"]: item for item in normalized[0]["nodes"]}
    assert by_id["NODE-write"]["projected_action_budget"] == 4
    assert by_id["NODE-write"]["projected_minimum_actions"] == 2


def test_contract_adapter_supports_eight_distinct_project_write_roots():
    roots = tuple(f"src/module_{index}.py" for index in range(8))
    immutable_request = "Create these files: " + ", ".join(roots) + "."
    value = lean_contract_plan_value()
    value["new_obligations"][0]["predicate"] = (
        "Every requested project file exists in the workspace."
    )
    value["new_nodes"][0]["atom"].update(
        {
            "objective": "Create every requested project file.",
            "write_roots": list(roots),
        }
    )
    value["new_nodes"][1]["atom"].update(
        {
            "objective": "Verify every requested project file.",
            "read_roots": [],
        }
    )
    value["new_nodes"][2]["atom"]["read_roots"] = list(roots)

    patch = OpenAICompatibleSupervisorClient._contract_patch_from_value(
        ContractPlanRequest(
            run_id="RUN-EIGHT-ROOTS",
            request=immutable_request,
            request_digest="digest-eight-roots",
            graph_revision=0,
            obligations=(),
            nodes=(),
            latest_review=None,
            result_capsules=(),
            available_operations=contract_operation_catalog(),
            workspace_manifest={"entries": []},
        ),
        value,
    )

    writer = next(node for node in patch.new_nodes if node.node_id == "NODE-write")
    verifier = next(node for node in patch.new_nodes if node.node_id == "NODE-verify")
    assert writer.atom.write_roots == roots
    assert writer.atom.minimum_actions == 8
    assert writer.atom.action_budget == 10
    assert verifier.atom.read_roots == roots


def test_controller_synthesizes_missing_mutation_verifier_without_reprompt():
    immutable_request = "Create result.txt containing exact text ok."
    incomplete = lean_contract_plan_value()
    incomplete["new_nodes"] = [
        node
        for node in incomplete["new_nodes"]
        if node["atom"]["atom_id"] != "NODE-verify"
    ]
    incomplete["new_nodes"][-1]["atom"]["depends_on"] = ["NODE-write"]
    fake = FakeSession([response(incomplete)])
    audit: list[dict] = []
    client = OpenAICompatibleSupervisorClient(
        settings(),
        session=fake,
        audit_hook=audit.append,
    )

    patch = client.plan_contract_graph(
        ContractPlanRequest(
            run_id="RUN-VERIFY-REPAIR",
            request=immutable_request,
            request_digest="digest-verify-repair",
            graph_revision=0,
            obligations=(),
            nodes=(),
            latest_review=None,
            result_capsules=(),
            available_operations=contract_operation_catalog(),
            workspace_manifest={"entries": []},
        )
    )

    synthesized = [
        node
        for node in patch.new_nodes
        if node.node_id.startswith("NODE-auto-verify-")
    ]
    assert len(synthesized) == 1
    assert synthesized[0].atom.depends_on == ("NODE-write",)
    assert synthesized[0].atom.read_roots == ("result.txt",)
    assert len(fake.posts) == 1
    normalized = [
        item
        for item in audit
        if item.get("normalization") == "synthesized_missing_safety_verifier"
    ]
    assert normalized[0]["node_ids"] == [synthesized[0].node_id]
    assert not any(
        item.get("type") == "supervisor_semantic_response_rejected"
        for item in audit
    )


def test_contract_correction_rewires_unreachable_existing_dependency():
    immutable_request = "Create result.txt containing exact text ok."
    request_digest = "digest-unreachable-correction"
    initial_request = ContractPlanRequest(
        run_id="RUN-UNREACHABLE-CORRECTION",
        request=immutable_request,
        request_digest=request_digest,
        graph_revision=0,
        obligations=(),
        nodes=(),
        latest_review=None,
        result_capsules=(),
        available_operations=contract_operation_catalog(),
        workspace_manifest={"entries": []},
    )
    initial_patch = OpenAICompatibleSupervisorClient._contract_patch_from_value(
        initial_request,
        contract_plan_value(),
    )
    correction_request = ContractPlanRequest(
        run_id="RUN-UNREACHABLE-CORRECTION",
        request=immutable_request,
        request_digest=request_digest,
        graph_revision=1,
        obligations=tuple(
            item.to_dict() for item in initial_patch.new_obligations
        ),
        nodes=tuple(item.to_dict() for item in initial_patch.new_nodes),
        latest_review={
            "verdicts": [
                {"obligation_id": "OBL-result", "status": "insufficient"}
            ]
        },
        result_capsules=(),
        available_operations=contract_operation_catalog(),
        workspace_manifest={"entries": [{"path": "result.txt"}]},
        node_statuses={
            node.node_id: (
                "interrupted" if node.node_id == "NODE-write" else "pending"
            )
            for node in initial_patch.new_nodes
        },
    )
    namespace = OpenAICompatibleSupervisorClient._contract_plan_atom_id_namespace(
        correction_request
    )

    def correction(depends_on: list[str]) -> dict:
        return {
            "summary": "Inspect the current artifact before replanning work.",
            "new_obligations": [],
            "new_nodes": [
                {
                    "obligation_ids": ["OBL-result"],
                    "atom": {
                        "atom_id": namespace + "inspect",
                        "role": "work",
                        "kind": "investigate",
                        "effect_ceiling": "local_read_only",
                        "objective": "Inspect the current result.txt content.",
                        "depends_on": depends_on,
                        "read_roots": ["result.txt"],
                        "write_roots": [],
                    },
                }
            ],
        }

    fake = FakeSession(
        [
            response(correction(["NODE-write"])),
            response(correction([])),
        ]
    )
    audit: list[dict] = []
    client = OpenAICompatibleSupervisorClient(
        settings(),
        session=fake,
        audit_hook=audit.append,
    )

    patch = client.plan_contract_graph(correction_request)

    assert patch.new_nodes[0].atom.depends_on == ()
    assert len(fake.posts) == 1
    assert any(
        item.get("type") == "supervisor_contract_plan_normalized"
        and item.get("normalization")
        == "rewired_unreachable_correction_dependencies"
        and item.get("controller_semantic_fields_generated") is False
        for item in audit
    )


def test_controller_propagates_every_mutation_write_root_to_verifier():
    immutable_request = "Create result.txt and README.md."
    value = lean_contract_plan_value()
    value["new_nodes"][0]["atom"]["write_roots"] = [
        "result.txt",
        "README.md",
    ]
    intermediate = {
        "obligation_ids": ["OBL-result"],
        "atom": {
            "atom_id": "NODE-inspect",
            "role": "work",
            "kind": "investigate",
            "effect_ceiling": "local_read_only",
            "objective": "Inspect the generated project structure.",
            "depends_on": ["NODE-write"],
            "read_roots": ["result.txt"],
            "write_roots": [],
        },
    }
    value["new_nodes"].insert(1, intermediate)
    value["new_nodes"][2]["atom"]["depends_on"] = ["NODE-inspect"]

    patch = OpenAICompatibleSupervisorClient._contract_patch_from_value(
        ContractPlanRequest(
            run_id="RUN-VERIFY-ALL-ROOTS",
            request=immutable_request,
            request_digest="digest-verify-all-roots",
            graph_revision=0,
            obligations=(),
            nodes=(),
            latest_review=None,
            result_capsules=(),
            available_operations=contract_operation_catalog(),
            workspace_manifest={"entries": []},
        ),
        value,
    )

    verifier = next(node for node in patch.new_nodes if node.node_id == "NODE-verify")
    assert verifier.atom.depends_on == ("NODE-inspect",)
    assert verifier.atom.read_roots == ("result.txt", "README.md")


def test_controller_replaces_narrow_verifier_scope_with_full_mutation_scope():
    value = lean_contract_plan_value()
    value["new_nodes"][0]["atom"]["write_roots"] = ["src"]
    value["new_nodes"][1]["atom"]["read_roots"] = ["src/main.py"]
    request = ContractPlanRequest(
        run_id="RUN-NARROW-VERIFY",
        request="Update src and verify the complete result.",
        request_digest="digest-narrow-verify",
        graph_revision=0,
        obligations=(),
        nodes=(),
        latest_review=None,
        result_capsules=(),
        available_operations=contract_operation_catalog(),
        workspace_manifest={"entries": []},
    )

    normalized = OpenAICompatibleSupervisorClient._contract_nodes_with_mechanical_verification(
        request,
        value,
    )

    verifier = next(
        item for item in normalized if item["atom"]["atom_id"] == "NODE-verify"
    )
    assert verifier["atom"]["read_roots"] == ["src"]


def test_controller_compacts_many_converged_verifier_roots_losslessly():
    value = lean_contract_plan_value()
    mutations = []
    mutation_ids = []
    for group in range(3):
        atom_id = f"NODE-write-{group}"
        mutation_ids.append(atom_id)
        mutations.append(
            {
                "obligation_ids": ["OBL-result"],
                "atom": {
                    "atom_id": atom_id,
                    "role": "work",
                    "kind": "mutate",
                    "effect_ceiling": "workspace_mutation",
                    "objective": f"Create project file group {group}.",
                    "depends_on": [],
                    "read_roots": [],
                    "write_roots": [
                        f"group_{group}/file_{index}.txt" for index in range(6)
                    ],
                },
            }
        )
    verifier = value["new_nodes"][1]
    verifier["atom"]["depends_on"] = mutation_ids
    verifier["atom"]["read_roots"] = []
    value["new_nodes"] = [*mutations, verifier]
    request = ContractPlanRequest(
        run_id="RUN-COMPACT-VERIFY",
        request="Create and verify the complete multi-directory project.",
        request_digest="digest-compact-verify",
        graph_revision=0,
        obligations=(),
        nodes=(),
        latest_review=None,
        result_capsules=(),
        available_operations=contract_operation_catalog(),
        workspace_manifest={"entries": []},
    )

    normalized = OpenAICompatibleSupervisorClient._contract_nodes_with_mechanical_verification(
        request,
        value,
    )

    compiled_verifier = next(
        item for item in normalized if item["atom"]["atom_id"] == "NODE-verify"
    )
    assert compiled_verifier["atom"]["read_roots"] == ["."]


def settings() -> SupervisorAPISettings:
    return SupervisorAPISettings(
        base_url="https://supervisor.invalid/v1",
        api_key="test-secret-never-audited",
        model="gpt-test",
        stage_checker_model="gpt-test",
        retry_attempts=1,
        plan_cache_enabled=False,
    )


def _current_planner_model_value() -> dict:
    patch = GoalPlanPatch(
        patch_id="GPP-parser-fixture", base_revision=0,
        goal_obligations=(GoalObligation("O1", "Workspace is inspected", ("observe",)),),
        add_steps=(GoalPlanStep(
            step_id="S1", objective="Inspect the workspace", phase="observe",
            obligation_ids=("O1",), read_roots=(".",),
            success_evidence=("Workspace entries are observed",),
        ),), replace_steps=(), discard_step_ids=(), reason="Inspect current evidence",
    )
    value = patch.to_dict()
    for key in ("schema_version", "patch_id", "base_revision"):
        value.pop(key)
    for stage in value["add_stages"]:
        for step in stage["steps"]:
            step.pop("allowed_operations")
    return value


class StreamingResponse:
    status_code = 200

    def __init__(self, value, *, defect=None):
        self.closed = False
        self.on_read = lambda: None
        content = json.dumps(value, ensure_ascii=False)
        self.chunks = [
            {"model": "gpt-test", "choices": [{"index": 0, "delta": {"content": text}, "finish_reason": None}]}
            for text in (content[:31], content[31:])
        ]
        self.chunks.append({"model": "gpt-test", "choices": [{"index": 0, "delta": {}, "finish_reason": "stop"}]})
        self.chunks.append({"choices": [], "usage": {"completion_tokens": 120}})
        self.defect = defect
        if defect == "missing_finish":
            self.chunks.pop(2)
        elif defect == "length":
            self.chunks[2]["choices"][0]["finish_reason"] = "length"
        elif defect == "wrong_choice":
            self.chunks[0]["choices"][0]["index"] = 1
        elif defect == "changed_model":
            self.chunks[1]["model"] = "unexpected-model"
        elif defect == "late_content":
            self.chunks.append({"choices": [{"index": 0, "delta": {"content": "extra"}, "finish_reason": None}]})

    def iter_lines(self):
        self.on_read()
        yield b": keepalive"
        yield b""
        for chunk in self.chunks:
            if self.defect == "invalid_chunk":
                yield b"data: {invalid"
            else:
                # SSE permits multiple data lines within one event.
                lines = json.dumps(chunk, ensure_ascii=False, indent=2).splitlines()
                for line in lines:
                    yield b"data: " + line.encode("utf-8")
            yield b""
        if self.defect != "missing_done":
            yield b"data: [DONE]"
            yield b""

    def close(self):
        self.closed = True


def test_streamed_planner_holds_request_slot_and_uses_identical_contract():
    value = _current_planner_model_value()
    value["reason"] += "，保留原始中文。"
    provider_response = StreamingResponse(value)
    fake = FakeSession([provider_response])
    audit = []
    client = OpenAIGoalSupervisorClient(replace(settings(), stream_responses=True), session=fake, audit_hook=audit.append)
    active_slot = False

    @contextmanager
    def request_slot():
        nonlocal active_slot
        active_slot = True
        try:
            yield
        finally:
            active_slot = False

    def assert_slot_held():
        assert active_slot

    client._client._request_slot = request_slot
    provider_response.on_read = assert_slot_held
    request = GoalPlanRequest(
        run_id="RUN-stream-plan", immutable_request="Inspect the workspace",
        goal_digest="stream-fixture", plan_revision=0,
        active_plan=RollingGoalPlan(goal_digest="stream-fixture").to_model_dict(),
        latest_audit=None, workspace_manifest={"entries": []},
    )

    patch = client.plan_goal_patch(request)

    assert patch.reason == value["reason"]
    assert fake.posts[0]["stream"] is True
    assert fake.posts[0]["json"]["stream"] is True
    assert fake.posts[0]["json"]["max_tokens"] == 8192
    assert provider_response.closed and not active_slot
    returned = next(event for event in audit if event["type"] == "supervisor_request_returned")
    assert returned["finish_reason"] == "stop"
    assert returned["usage"]["completion_tokens"] == 120
    assert returned["stream"] is True


def test_stream_tolerates_usage_only_trailer_choice_after_finish():
    # Many OpenAI-compatible gateways send a final usage chunk that still
    # carries choices[0] with an empty delta and a repeated finish_reason.
    value = _current_planner_model_value()
    provider_response = StreamingResponse(value)
    provider_response.chunks[3] = {
        "choices": [{"index": 0, "delta": {}, "finish_reason": "stop"}],
        "usage": {"completion_tokens": 120},
    }
    data = supervisor_openai_module._decode_chat_completion_stream(
        provider_response, deadline=time.monotonic() + 30,
    )
    assert json.loads(data["choices"][0]["message"]["content"]) == value
    assert data["choices"][0]["finish_reason"] == "stop"
    assert data["usage"] == {"completion_tokens": 120}


def test_stream_still_rejects_text_or_changed_finish_after_finish():
    value = _current_planner_model_value()
    text_after = StreamingResponse(value, defect="late_content")
    with pytest.raises(SupervisorProtocolError, match="text after its finish"):
        supervisor_openai_module._decode_chat_completion_stream(
            text_after, deadline=time.monotonic() + 30,
        )
    changed = StreamingResponse(value)
    changed.chunks.append({"choices": [{"index": 0, "delta": {}, "finish_reason": "length"}]})
    with pytest.raises(SupervisorProtocolError, match="changed finish_reason"):
        supervisor_openai_module._decode_chat_completion_stream(
            changed, deadline=time.monotonic() + 30,
        )


def test_streamed_length_interruption_gets_one_bounded_same_budget_retry():
    # An output-budget interruption is a resource outcome, not an invalid
    # model result: it retries within retry_attempts, unlike protocol defects.
    first = StreamingResponse(_current_planner_model_value(), defect="length")
    second = StreamingResponse(_current_planner_model_value(), defect="length")
    fake = FakeSession([first, second])
    audit = []
    client = OpenAIGoalSupervisorClient(
        replace(settings(), stream_responses=True, retry_attempts=2, retry_backoff_seconds=0.0),
        session=fake, audit_hook=audit.append)
    request = GoalPlanRequest(
        run_id="RUN-length-retry", immutable_request="Inspect the workspace",
        goal_digest="stream-fixture", plan_revision=0,
        active_plan=RollingGoalPlan(goal_digest="stream-fixture").to_model_dict(),
        latest_audit=None, workspace_manifest={"entries": []},
    )

    with pytest.raises(SupervisorGenerationInterrupted):
        client.plan_goal_patch(request)

    assert len(fake.posts) == 2
    assert first.closed and second.closed
    failed = next(event for event in audit if event["type"] == "supervisor_request_failed")
    assert failed["error_category"] == "generation_limit"


@pytest.mark.parametrize("defect", ["missing_done", "missing_finish", "wrong_choice", "changed_model", "late_content", "invalid_chunk"])
def test_streamed_planner_rejects_incomplete_or_ambiguous_stream_without_retry(defect):
    provider_response = StreamingResponse(_current_planner_model_value(), defect=defect)
    fake = FakeSession([provider_response])
    audit = []
    client = OpenAIGoalSupervisorClient(replace(settings(), stream_responses=True, retry_attempts=2), session=fake, audit_hook=audit.append)
    request = GoalPlanRequest(
        run_id="RUN-stream-rejection", immutable_request="Inspect the workspace",
        goal_digest="stream-fixture", plan_revision=0,
        active_plan=RollingGoalPlan(goal_digest="stream-fixture").to_model_dict(),
        latest_audit=None, workspace_manifest={"entries": []},
    )

    with pytest.raises(SupervisorProtocolError):
        client.plan_goal_patch(request)

    assert len(fake.posts) == 1
    assert provider_response.closed
    assert not any(event["type"] == "supervisor_request_returned" for event in audit)
    failed = next(event for event in audit if event["type"] == "supervisor_request_failed")
    assert failed["http_status"] == 200


def test_supervisor_stream_deadline_is_an_interruption():
    with pytest.raises(requests.ReadTimeout, match="read budget"):
        supervisor_openai_module._decode_chat_completion_stream(
            StreamingResponse(_current_planner_model_value()), deadline=-1,
        )


@pytest.mark.parametrize("lines", [
    [b'event: telemetry', b'data: {"provider_status":"upstream reconnect"}', b''],
    [b'data: {"choices":', b''],
    [b'data: \xff', b''],
    [b'data: {"unfinished":'],
])
def test_rejected_supervisor_stream_preserves_exact_consumed_lines_and_attempt(lines):
    import base64
    provider_response = StreamingResponse(_current_planner_model_value())
    provider_response.iter_lines = lambda: iter(lines)
    audit = []
    client = OpenAIGoalSupervisorClient(replace(settings(), stream_responses=True, retry_attempts=2),
        session=FakeSession([provider_response]), audit_hook=audit.append)
    request = GoalPlanRequest(
        run_id="RUN-stream-evidence", immutable_request="Inspect the workspace",
        goal_digest="stream-fixture", plan_revision=0,
        active_plan=RollingGoalPlan(goal_digest="stream-fixture").to_model_dict(),
        latest_audit=None, workspace_manifest={"entries": []},
    )
    with pytest.raises(SupervisorProtocolError):
        client.plan_goal_patch(request)
    evidence = [event for event in audit if event["type"] == "supervisor_stream_received"]
    assert len(evidence) == 1
    transcript = evidence[0]
    consumed = [base64.b64decode(value) for value in transcript["lines_base64"]]
    assert consumed == lines[:len(consumed)] and consumed
    assert transcript["lines_sha256"] == hashlib.sha256(b''.join(
        len(line).to_bytes(8, "big") + line for line in consumed)).hexdigest()
    failed = next(event for event in audit if event["type"] == "supervisor_request_failed")
    assert transcript["call_id"] == failed["call_id"]
    assert transcript["attempt"] == 1
    assert transcript["http_status"] == 200
    assert transcript["decoded"] is False
    assert transcript["run_id"] == request.run_id
    assert provider_response.closed


def test_supervisor_stream_can_be_configured_without_affecting_native_transport(tmp_path, monkeypatch):
    for key in tuple(os.environ):
        if key.startswith(("RWKV_LH_PLANNER_", "RWKV_LH_STAGE_CHECKER_", "SUPERVISOR_")):
            monkeypatch.delenv(key)
    path = tmp_path / "provider.env"
    path.write_text("\n".join((
        "RWKV_LH_PLANNER_BASE_URL=https://fixture.invalid/v1",
        "RWKV_LH_PLANNER_API_KEY=fixture-key",
        "RWKV_LH_PLANNER_MODEL=provider-configured-model",
        "RWKV_LH_PLANNER_STREAM=true",
    )))
    loaded = SupervisorAPISettings.from_env(path)
    assert loaded.stream_responses is True
    assert loaded.public_dict()["stream_responses"] is True
    client = OpenAICompatibleSupervisorClient(replace(loaded, backend_profile="vllm-rwkv-native"))
    _, body, _ = client._wire_request(
        phase="goal_plan", selected_model=loaded.model, system_prompt="Fixture",
        payload_text=supervisor_openai_module._render_user_payload(GoalPlanRequest(
            run_id="RUN-native-stream-isolation", immutable_request="Inspect",
            goal_digest="native-fixture", plan_revision=0,
            active_plan=RollingGoalPlan(goal_digest="native-fixture").to_model_dict(),
            latest_audit=None, workspace_manifest={"entries": []},
        ).to_dict()), max_tokens=8192, schema_revision="fixture", schema={},
    )
    assert body["stream"] is False


@pytest.mark.parametrize("finish_reason", ["length", "content_filter", None])
def test_goal_planner_never_accepts_json_without_natural_completion(finish_reason):
    provider_response = response(_current_planner_model_value())
    provider_response.payload["choices"][0]["finish_reason"] = finish_reason
    fake = FakeSession([provider_response])
    client = OpenAIGoalSupervisorClient(settings(), session=fake)
    request = GoalPlanRequest(
        run_id="RUN-incomplete-plan", immutable_request="Inspect the workspace",
        goal_digest="incomplete-fixture", plan_revision=0,
        active_plan=RollingGoalPlan(goal_digest="incomplete-fixture").to_model_dict(), latest_audit=None,
        workspace_manifest={"entries": []},
    )

    with pytest.raises(SupervisorProtocolError, match="finish_reason"):
        client.plan_goal_patch(request)

    assert len(fake.posts) == 1


@pytest.mark.parametrize("invalid_part", ["top", "stage", "step", "obligation"])
def test_planner_parse_error_preserves_original_value_and_names_wrong_fields(invalid_part):
    value = _current_planner_model_value()
    selected = {
        "top": value,
        "stage": value["add_stages"][0],
        "step": value["add_stages"][0]["steps"][0],
        "obligation": value["goal_obligations"][0],
    }[invalid_part]
    selected["unexpected_fixture_field"] = "Model supplied this field"
    fake = FakeSession([response(value)])
    client = OpenAIGoalSupervisorClient(settings(), session=fake)
    request = GoalPlanRequest(
        run_id="RUN-parser-rejection", immutable_request="Inspect the workspace",
        goal_digest="parser-fixture", plan_revision=0,
        active_plan=RollingGoalPlan(goal_digest="parser-fixture").to_model_dict(), latest_audit=None,
        workspace_manifest={"entries": []},
    )

    with pytest.raises(ValueError) as captured:
        client.plan_goal_patch(request)

    assert captured.value.rejected_patch == value
    assert "unexpected_fixture_field" in str(captured.value)
    assert "unexpected=" in str(captured.value)
    assert "missing=" in str(captured.value)
    assert len(fake.posts) == 1
    # A later caller cannot mutate the provider-owned record through its input.
    selected["unexpected_fixture_field"] = "Changed after rejection"
    assert captured.value.rejected_patch != value


@pytest.mark.parametrize("invalid_part", ["obligations", "add", "replace", "discard", "continuation"])
def test_planner_initial_and_continuation_errors_are_repairable_values(invalid_part):
    value = _current_planner_model_value()
    revision = 0
    if invalid_part == "obligations":
        value["goal_obligations"] = []
    elif invalid_part == "add":
        value["add_stages"] = []
    elif invalid_part == "replace":
        value["replace_stages"] = value["add_stages"]
        value["add_stages"] = []
    elif invalid_part == "discard":
        value["discard_step_ids"] = ["S-previous"]
    else:
        revision = 1
    fake = FakeSession([response(value)])
    client = OpenAIGoalSupervisorClient(settings(), session=fake)
    request = GoalPlanRequest(
        run_id="RUN-parser-boundary", immutable_request="Inspect the workspace",
        goal_digest="parser-fixture", plan_revision=revision,
        active_plan=RollingGoalPlan(goal_digest="parser-fixture").to_model_dict(), latest_audit=None,
        workspace_manifest={"entries": []},
    )

    with pytest.raises(ValueError) as captured:
        client.plan_goal_patch(request)

    assert captured.value.rejected_patch == value
    assert len(fake.posts) == 1


def test_goal_planner_returns_replaceable_steps_without_stealing_selector_role():
    value = {
        "goal_obligations": [
            {
                "obligation_id": "O1",
                "predicate": "config.json is inspected and corrected",
                "required_phases": ["observe", "mutate"],
            }
        ],
        "add_stages": [
            {
                "stage": 1,
                "steps": [
                    {
                        "step_id": "S1",
                        "objective": "Inspect the current configuration.",
                        "phase": "observe",
                        "depends_on": [],
                        "obligation_ids": ["O1"],
                        "success_evidence": ["configuration content is observed"],
                        "read_roots": ["config.json"],
                        "write_roots": [],
                        "constraints": [],
                    }
                ],
            }
        ],
        "replace_stages": [],
        "discard_step_ids": [],
        "reason": "Start with one bounded observation.",
    }
    fake = FakeSession([response(value)])
    client = OpenAICompatibleSupervisorClient(settings(), session=fake)
    request = GoalPlanRequest(
        run_id="RUN-GOAL-PLAN",
        immutable_request="Inspect and correct config.json.",
        goal_digest="goal-digest",
        plan_revision=0,
        active_plan={"stages": []},
        latest_audit=None,
        workspace_manifest={"entries": [{"path": "config.json"}]},
    )

    patch = client.plan_goal_patch(request)

    assert patch.add_steps[0].allowed_operations == ()
    assert patch.add_steps[0].phase == "observe"
    posted = fake.posts[0]["json"]
    assert posted["model"] == "gpt-test"
    assert "seed" not in posted
    assert "temperature" not in posted
    assert "reasoning" not in posted
    assert posted["response_format"] == {"type": "json_object"}
    # Rolling GoalPlan output uses the bounded Planner budget.  The separate
    # ContractGraph planner retains its larger contract-plan budget.
    assert posted["max_tokens"] == 8192
    assert client.settings.max_contract_plan_tokens == 4000
    assert fake.posts[0]["url"].endswith("/chat/completions")
    assert posted["messages"][1]["role"] == "user"
    payload = json.loads(posted["messages"][1]["content"])
    assert list(payload)[-1] == "current_requirement"
    assert payload["current_requirement"] == request.immutable_request
    response_schema = client._goal_plan_patch_schema()
    step_schema = response_schema["properties"]["add_stages"]["items"][
        "properties"
    ]["steps"]["items"]
    assert "allowed_operations" not in step_schema["properties"]
    assert "stage" not in step_schema["properties"]
    assert set(step_schema["required"]) == set(step_schema["properties"])
    assert set(response_schema["required"]) == {
        "goal_obligations",
        "add_stages",
        "replace_stages",
        "discard_step_ids",
        "reason",
    }
    assert "steps nested inside stage objects" in response_schema["description"]
    system_prompt = posted["messages"][0]["content"]
    assert "Controller has already fixed the one project mother path" in system_prompt
    assert "Every read_roots and write_roots item" in system_prompt
    assert "never invent a '/workspace' prefix" in system_prompt
    assert '"add_stages":[{"stage":1,"steps":[' in system_prompt
    assert "do not flatten steps" in system_prompt
    assert "exactly one phase" in system_prompt
    assert "Plan the steps needed for the task" in system_prompt
    assert "HARD CARDINALITY" not in system_prompt
    assert "one to five" not in system_prompt
    assert "at most five" not in system_prompt
    assert "next five" not in system_prompt
    assert "exactly one literal token from observe, mutate, execute" in system_prompt
    assert "Never write labels such as 'public-source observe'" in system_prompt
    assert "never name a concrete tool" in system_prompt
    assert "mutate => read_roots=[], write_roots non-empty" in system_prompt
    assert "read-only execute => read_roots=[], write_roots=[]" in system_prompt
    assert "only through depends_on" in system_prompt
    assert "Planner text is never completion evidence" in system_prompt
    assert "Only the RWKV Auditor can accept" in system_prompt
    assert "no Markdown fence, prose, analysis" in system_prompt
    assert "Each step has exactly step_id, objective, phase" in system_prompt
    assert "never claims that evidence exists" in step_schema["properties"][
        "success_evidence"
    ]["description"]
    assert "Non-empty only for phase=observe" in step_schema["properties"][
        "read_roots"
    ]["description"]

    goal_root_schema = step_schema["properties"]["read_roots"]["items"]
    pattern = goal_root_schema["pattern"]
    for valid in (".", "config.json", "probe_service/settings.py", "./tests"):
        assert re.fullmatch(pattern, valid)
    for invalid in (
        "/workspace/probe_service",
        "/absolute/path",
        "../outside",
        "src/../../outside",
        r"probe_service\settings.py",
    ):
        assert re.fullmatch(pattern, invalid) is None


def test_current_goal_supervisor_boundary_exposes_no_legacy_planner_methods():
    client = OpenAIGoalSupervisorClient(settings(), session=FakeSession([]))

    assert callable(client.plan_goal_patch)
    assert callable(client.review_goal_stage)
    for legacy_name in (
        "plan_contract_graph",
        "review_contract_graph",
        "create_plan",
        "review_final",
        "next_directive",
        "next_stage",
    ):
        assert not hasattr(client, legacy_name)


def test_supervisor_http_error_preserves_only_safe_provider_diagnostics():
    fake = FakeSession(
        [
            FakeResponse(
                {
                    "error": {
                        "type": "new_api_error",
                        "code": "upstream_saturated",
                        "message": "current upstream group is saturated",
                        "param": "",
                    }
                },
                status_code=429,
            )
        ]
    )
    audit: list[dict] = []
    client = OpenAICompatibleSupervisorClient(
        replace(settings(), retry_attempts=1),
        session=fake,
        audit_hook=audit.append,
    )

    with pytest.raises(SupervisorTransportError) as captured:
        client.plan_goal_patch(
            GoalPlanRequest(
                run_id="RUN-GOAL-HTTP-ERROR",
                immutable_request="Inspect config.json.",
                goal_digest="goal-http-error",
                plan_revision=0,
                active_plan={"stages": []},
                latest_audit=None,
                workspace_manifest={"entries": [{"path": "config.json"}]},
            )
        )

    assert captured.value.status_code == 429
    assert captured.value.provider_error["error"] == {
        "type": "new_api_error",
        "code": "upstream_saturated",
        "message": "current upstream group is saturated",
        "param": "",
    }
    failed = [item for item in audit if item["type"] == "supervisor_request_failed"]
    assert failed[0]["provider_error"] == captured.value.provider_error
    assert "authorization" not in json.dumps(failed[0], ensure_ascii=False).casefold()


def test_goal_planner_places_controller_semantic_repair_at_input_tail():
    value = {"goal_obligations": [],
        "add_stages": [
            {
                "stage": 2,
                "steps": [
                    {"obligation_ids": [],
                        "step_id": "S2",
                        "objective": "Read the current configuration.",
                        "phase": "observe",
                        "depends_on": ["S1"],
                        "success_evidence": ["configuration content is observed"],
                        "read_roots": ["config.json"],
                        "write_roots": [],
                        "constraints": [],
                    }
                ],
            }
        ],
        "replace_stages": [],
        "discard_step_ids": [],
        "reason": "Use a fresh id and retain the completed dependency.",
    }
    fake = FakeSession([response(value)])
    client = OpenAICompatibleSupervisorClient(settings(), session=fake)
    request = GoalPlanRequest(
        run_id="RUN-GOAL-PLAN-REPAIR",
        immutable_request="Inspect and correct config.json.",
        goal_digest="goal-digest",
        plan_revision=1,
        active_plan={
            "stages": [
                {
                    "stage": 1,
                    "steps": [{"step_id": "S1", "status": "completed"}],
                }
            ]
        },
        latest_audit=None,
        workspace_manifest={"entries": [{"path": "config.json"}]},
        local_validation_repair={
            "attempt": 1,
            "previous_response_rejected": True,
            "error": "ValueError: Goal PlanPatch cannot reuse existing id S1",
            "instruction": "Return one fresh complete GoalPlanPatch.",
        },
    )

    client.plan_goal_patch(request)

    posted = fake.posts[0]["json"]
    payload = json.loads(posted["messages"][1]["content"])
    assert list(payload)[-1] == "local_validation_repair"
    assert payload["local_validation_repair"]["attempt"] == 1
    assert "cannot reuse existing id S1" in payload["local_validation_repair"][
        "error"
    ]
    assert (
        "immediately preceding patch was rejected"
        in posted["messages"][0]["content"]
    )


def test_goal_stage_checker_returns_three_fields_with_kernel_bound_provenance():
    fake = FakeSession(
        [response({"verdict": "advance", "gaps": [], "reason": "coherent"})]
    )
    client = OpenAICompatibleSupervisorClient(
        replace(settings(), stage_checker_model="claude-test"),
        session=fake,
    )
    request = GoalStageReviewRequest(
        run_id="RUN-STAGE-REVIEW",
        immutable_request="Inspect and correct config.json.",
        goal_digest="goal-digest",
        stage=1,
        stage_steps=(
            {
                "step_id": "S1",
                "objective": "Inspect config.json",
                "accepted_evidence_refs": ["A00001"],
            },
        ),
        workspace_manifest={"entries": [{"path": "config.json"}]},
    )

    review = client.review_goal_stage(request)

    assert review.stage == 1
    assert review.reviewed_step_ids == ("S1",)
    assert review.evidence_refs == ("A00001",)
    posted = fake.posts[0]["json"]
    assert posted["model"] == "claude-test"
    assert posted["response_format"] == {"type": "json_object"}
    schema = client._goal_stage_review_schema()
    assert set(schema["properties"]) == {"verdict", "gaps", "reason"}
    payload = json.loads(posted["messages"][1]["content"])
    assert list(payload)[-1] == "current_requirement"
    assert "Never require artifacts, verifier success" in posted["messages"][0][
        "content"
    ]
    assert '{"verdict":"advance","gaps":[]' in posted["messages"][0]["content"]
    assert "Do not add stage, reviewed_step_ids, evidence_refs" in posted[
        "messages"
    ][0]["content"]


def test_contract_plan_schema_requires_explicit_obligation_phase():
    obligation = CONTRACT_PLAN_RESPONSE_SCHEMA["properties"]["new_obligations"][
        "items"
    ]

    assert "phase" in obligation["required"]
    assert obligation["properties"]["phase"]["enum"] == [
        "execution_evidence",
        "final_presentation",
    ]


@pytest.mark.parametrize("tag", ("analysis", "think"))
def test_supervisor_content_accepts_known_provider_reasoning_envelope(tag):
    content = f"<{tag}>private provider reasoning</{tag}>\n" + json.dumps(
        {"summary": "valid"}
    )

    value, normalization = _decode_supervisor_json_content(content)

    assert value == {"summary": "valid"}
    assert normalization is not None
    assert normalization["normalization"] == f"provider_{tag}_prefix_removed"
    assert normalization["controller_semantic_fields_generated"] is False
    assert "private provider reasoning" not in json.dumps(normalization)


def test_supervisor_content_accepts_bare_json_without_normalization():
    value, normalization = _decode_supervisor_json_content('{"summary":"valid"}')

    assert value == {"summary": "valid"}
    assert normalization is None


def test_supervisor_content_accepts_exact_json_fence_without_semantic_repair():
    value, normalization = _decode_supervisor_json_content(
        '```json\n{"summary":"valid"}\n```'
    )

    assert value == {"summary": "valid"}
    assert normalization is not None
    assert normalization["normalization"] == "provider_json_fence_removed"
    assert normalization["controller_semantic_fields_generated"] is False


@pytest.mark.parametrize(
    "content",
    (
        'provider prose\n{"summary":"valid"}',
        '<analysis>unclosed\n{"summary":"valid"}',
        '<analysis>reasoning</analysis>\n{"summary":"valid"}\ntrailing prose',
        '<analysis>reasoning</analysis>\n[]',
        '```JSON\n{"summary":"valid"}\n```',
        '```json\n{"summary":"valid"}\n```\ntrailing prose',
        '```json\n[]\n```',
    ),
)
def test_supervisor_content_rejects_unknown_or_malformed_envelopes(content):
    with pytest.raises(SupervisorProtocolError):
        _decode_supervisor_json_content(content)


def test_supervisor_env_loading_does_not_pollute_rwkv_namespace(
    tmp_path,
    monkeypatch,
):
    env_path = tmp_path / ".env"
    env_path.write_text(
        "\n".join(
            (
                "SUPERVISOR_BASE_URL=https://supervisor.invalid/v1",
                "SUPERVISOR_API_KEY=test-key",
                "SUPERVISOR_MODEL=gpt-test",
                "SUPERVISOR_MAX_REVIEW_REPAIRS=2",
                "RWKV_TOOL_DISCLOSURE_MODE=full",
            )
        ),
        encoding="utf-8",
    )
    for key in (
        "RWKV_LH_PLANNER_BASE_URL",
        "RWKV_LH_PLANNER_API_KEY",
        "RWKV_LH_PLANNER_MODEL",
        "SUPERVISOR_BASE_URL",
        "SUPERVISOR_API_KEY",
        "SUPERVISOR_MODEL",
        "SUPERVISOR_MAX_REVIEW_REPAIRS",
        "RWKV_TOOL_DISCLOSURE_MODE",
    ):
        monkeypatch.delenv(key, raising=False)

    loaded_settings = SupervisorAPISettings.from_env(env_path)
    loaded_policy = supervisor_policy_from_env(env_path)

    assert loaded_settings.model == "gpt-test"
    assert loaded_policy.max_review_repairs == 2
    assert "RWKV_TOOL_DISCLOSURE_MODE" not in os.environ


def test_openai_supervisor_builds_valid_plan_and_review_without_auditing_key():
    fake = FakeSession(
        [
            response(
                {
                    "objective": "Create and verify the requested artifact.",
                    "constraints": ["Stay inside the workspace."],
                    "steps": ["Inspect inputs.", "Write the artifact.", "Verify it."],
                    "completion_checks": ["The artifact exists with the requested content."],
                    "risks": ["Do not finish before verification."],
                }
            ),
            response(
                {
                    "disposition": "pass",
                    "summary": "The recorded write and read support completion.",
                    "issues": [],
                }
            ),
        ]
    )
    audit: list[dict] = []
    client = OpenAICompatibleSupervisorClient(
        settings(),
        session=fake,
        audit_hook=audit.append,
    )
    plan_request = SupervisorPlanRequest(
        run_id="RUN-1",
        request="Create result.txt and verify it.",
        request_digest="digest-1",
        constraints=("Stay inside the workspace.",),
        workspace_manifest={"entries": []},
    )

    plan = client.create_plan(plan_request)
    review = client.review_final(
        SupervisorReviewRequest(
            run_id="RUN-1",
            request=plan_request.request,
            request_digest=plan_request.request_digest,
            plan=plan,
            candidate_output="Created and verified result.txt.",
            candidate_decision_id="D-1",
            action_count=2,
            actions=({"operation": "write_file", "status": "succeeded"},),
            artifacts=(),
            workspace_manifest={"entries": [{"path": "result.txt"}]},
        )
    )

    assert plan.steps[-1] == "Verify it."
    assert review.disposition.value == "pass"
    assert all(
        post["json"]["response_format"]["type"] == "json_object"
        for post in fake.posts
    )
    assert "test-secret-never-audited" not in json.dumps(audit)
    assert [item["phase"] for item in audit if item["type"] == "supervisor_request_returned"] == [
        "plan",
        "review",
    ]


def test_create_plan_repairs_a_locally_invalid_coordinator_response():
    fake = FakeSession(
        [
            response(
                {
                    "objective": "Create and verify the requested artifact.",
                    "plan": {
                        "steps": ["Inspect inputs.", "Write and verify the artifact."],
                    },
                }
            ),
            response(
                {
                    "objective": "Create and verify the requested artifact.",
                    "constraints": ["Stay inside the workspace."],
                    "steps": ["Inspect inputs.", "Write and verify the artifact."],
                    "completion_checks": ["The requested artifact is verified."],
                    "risks": [],
                }
            ),
        ]
    )
    audit: list[dict] = []
    client = OpenAICompatibleSupervisorClient(
        settings(),
        session=fake,
        audit_hook=audit.append,
    )

    plan = client.create_plan(
        SupervisorPlanRequest(
            run_id="RUN-PLAN-SEMANTIC-REPAIR",
            request="Create and verify the requested artifact.",
            request_digest="digest-plan-semantic-repair",
            constraints=("Stay inside the workspace.",),
            workspace_manifest={"entries": []},
        )
    )

    assert plan.steps == ("Inspect inputs.", "Write and verify the artifact.")
    assert len(fake.posts) == 2
    repair_payload = json.loads(fake.posts[1]["json"]["messages"][1]["content"])
    assert list(repair_payload)[-1] == "local_validation_repair"
    assert repair_payload["local_validation_repair"]["attempt"] == 2
    assert "response top-level keys mismatch" in repair_payload[
        "local_validation_repair"
    ]["error"]
    assert "steps" in repair_payload["local_validation_repair"]["error"]
    assert "plan" in repair_payload["local_validation_repair"]["error"]
    rejected = [
        item
        for item in audit
        if item["type"] == "supervisor_semantic_response_rejected"
    ]
    assert len(rejected) == 1
    assert rejected[0]["phase"] == "plan"
    assert rejected[0]["semantic_attempt"] == 1


def test_review_final_repairs_a_locally_invalid_verifier_response():
    fake = FakeSession(
        [
            response(
                {
                    "summary": "The result is supported, but disposition is missing.",
                    "issues": [],
                }
            ),
            response(
                {
                    "disposition": "pass",
                    "summary": "The exact candidate is supported by public evidence.",
                    "issues": [],
                }
            ),
        ]
    )
    audit: list[dict] = []
    client = OpenAICompatibleSupervisorClient(
        settings(),
        session=fake,
        audit_hook=audit.append,
    )
    plan = SupervisorPlan.create(
        objective="Create and verify result.txt.",
        steps=("Create result.txt.", "Verify result.txt."),
        completion_checks=("result.txt contains ok.",),
    )

    review = client.review_final(
        SupervisorReviewRequest(
            run_id="RUN-REVIEW-SEMANTIC-REPAIR",
            request="Create result.txt containing ok.",
            request_digest="digest-review-semantic-repair",
            plan=plan,
            candidate_output="Created and verified result.txt.",
            candidate_decision_id="D-1",
            action_count=2,
            actions=({"operation": "read_file", "status": "succeeded"},),
            artifacts=(),
            workspace_manifest={"entries": [{"path": "result.txt"}]},
        )
    )

    assert review.disposition.value == "pass"
    assert len(fake.posts) == 2
    repair_payload = json.loads(fake.posts[1]["json"]["messages"][1]["content"])
    assert "response top-level keys mismatch" in repair_payload[
        "local_validation_repair"
    ]["error"]
    assert "disposition" in repair_payload["local_validation_repair"]["error"]
    rejected = [
        item
        for item in audit
        if item["type"] == "supervisor_semantic_response_rejected"
    ]
    assert [(item["phase"], item["semantic_attempt"]) for item in rejected] == [
        ("review", 1)
    ]


def test_next_directive_repairs_a_locally_invalid_coordinator_response():
    fake = FakeSession(
        [
            response(
                {
                    "type": "continue",
                    "review_status": "initial",
                    "review_summary": "Begin with one task.",
                    "issues": [],
                    "microtask_objective": "Inspect result.txt.",
                    "completion_checks": ["The current content is observed."],
                    "constraints": [],
                }
            ),
            response(
                {
                    "disposition": "continue",
                    "review_status": "initial",
                    "review_summary": "Begin with one observable task.",
                    "issues": [],
                    "microtask_objective": "Inspect result.txt.",
                    "completion_checks": ["The current content is observed."],
                    "constraints": [],
                }
            ),
        ]
    )
    audit: list[dict] = []
    client = OpenAICompatibleSupervisorClient(
        settings(),
        session=fake,
        audit_hook=audit.append,
    )
    request = SupervisorDirectiveRequest(
        run_id="RUN-DIRECTIVE-SEMANTIC-REPAIR",
        request="Inspect result.txt.",
        request_digest="digest-directive-semantic-repair",
        constraints=(),
        directive_index=1,
        outcome_ref="initial",
        previous_directive=None,
        worker_outcome=None,
        action_count=0,
        actions=(),
        artifacts=(),
        workspace_manifest={"entries": [{"path": "result.txt"}]},
    )

    directive = client.next_directive(request)

    assert directive.microtask_objective == "Inspect result.txt."
    assert len(fake.posts) == 2
    repair_payload = json.loads(fake.posts[1]["json"]["messages"][1]["content"])
    assert "response top-level keys mismatch" in repair_payload[
        "local_validation_repair"
    ]["error"]
    assert "disposition" in repair_payload["local_validation_repair"]["error"]
    assert "type" in repair_payload["local_validation_repair"]["error"]
    rejected = [
        item
        for item in audit
        if item["type"] == "supervisor_semantic_response_rejected"
    ]
    assert [(item["phase"], item["semantic_attempt"]) for item in rejected] == [
        ("directive", 1)
    ]


def test_contract_planner_and_reviewer_receive_results_without_rwkv_process():
    immutable_request = "Create result.txt containing exact text ok."
    fake = FakeSession(
        [
            response(
                {
                    "summary": "Compile one required artifact obligation.",
                    "new_obligations": [
                        {
                            "obligation_id": "OBL-result",
                            "predicate": "result.txt contains exact text ok.",
                            "evidence_kinds": ["file", "digest"],
                            "assertions": [
                                {
                                    "assertion_id": "ASSERT-result-text",
                                    "kind": "text_exact",
                                    "target_path": "result.txt",
                                    "target_pointer": "",
                                    "sources": [],
                                    "expected": "ok",
                                    "keys": [],
                                    "order": "",
                                    "algorithm": "",
                                }
                            ],
                        }
                    ],
                    "new_nodes": [
                        {
                            "obligation_ids": ["OBL-result"],
                            "atom": {
                                    "atom_id": "NODE-write-result",
                                    "role": "work",
                                    "kind": "mutate",
                                    "effect_ceiling": "workspace_mutation",
                                    "objective": "Create result.txt containing exact text ok.",
                                "depends_on": [],
                                "read_roots": [],
                                "write_roots": ["result.txt"],
                                    "evidence_requirements": {
                                        "kinds": ["exact_operation_result"],
                                        "freshness": "current_workspace",
                                        "source_preferences": ["workspace"],
                                    },
                                "action_budget": 1,
                            },
                        },
                        {
                            "obligation_ids": ["OBL-result"],
                            "atom": {
                                    "atom_id": "NODE-verify-result",
                                    "role": "work",
                                    "kind": "verify",
                                    "effect_ceiling": "local_read_only",
                                "objective": "Read result.txt and verify exact content.",
                                "depends_on": ["NODE-write-result"],
                                "read_roots": ["result.txt"],
                                "write_roots": [],
                                    "evidence_requirements": {
                                        "kinds": ["file_observation"],
                                        "freshness": "current_workspace",
                                        "source_preferences": ["workspace_file"],
                                    },
                                "action_budget": 1,
                            },
                        },
                        {
                            "obligation_ids": ["OBL-result"],
                            "atom": {
                                    "atom_id": "NODE-final",
                                    "role": "finalizer",
                                    "kind": "synthesize",
                                    "effect_ceiling": "local_read_only",
                                "objective": "Read result.txt and report exact completion.",
                                "depends_on": ["NODE-verify-result"],
                                "read_roots": ["result.txt"],
                                "write_roots": [],
                                    "evidence_requirements": {
                                        "kinds": ["verified_ledger"],
                                        "freshness": "current_workspace",
                                        "source_preferences": ["workspace"],
                                    },
                                "action_budget": 1,
                            },
                        },
                    ],
                }
            ),
            response(
                {
                    "summary": "The exact result and artifact identify completion.",
                    "verdicts": [
                        {
                            "obligation_id": "OBL-result",
                            "status": "satisfied",
                            "evidence_refs": ["PLACEHOLDER"],
                            "reason": "The write succeeded at the requested path.",
                        }
                    ],
                }
            ),
        ]
    )
    client = OpenAICompatibleSupervisorClient(
        settings(),
        session=fake,
    )
    operation_catalog = contract_operation_catalog()
    plan_request = ContractPlanRequest(
        run_id="RUN-CONTRACT",
        request=immutable_request,
        request_digest="digest-contract",
        graph_revision=0,
        obligations=(),
        nodes=(),
        latest_review=None,
        result_capsules=(),
        available_operations=operation_catalog,
        workspace_manifest={"entries": []},
    )

    patch = client.plan_contract_graph(plan_request)
    result = ResultCapsule.create(
        node_id="NODE-write-result",
        node_status="completed",
        operation="write_file",
        result={"success": True, "path": "result.txt"},
        artifacts=({"path": "result.txt", "sha256": "a" * 64},),
        workspace_revision="revision-1",
    )
    fake.responses[0].payload["choices"][0]["message"]["content"] = json.dumps(
        {
            "summary": "The exact result and artifact identify completion.",
            "verdicts": [
                {
                    "obligation_id": "OBL-result",
                    "status": "satisfied",
                    "evidence_refs": [result.evidence_id],
                    "reason": "The write succeeded at the requested path.",
                }
            ],
        }
    )
    review = client.review_contract_graph(
        ContractReviewRequest(
            run_id="RUN-CONTRACT",
            request=immutable_request,
            request_digest="digest-contract",
            graph_revision=1,
            obligations=tuple(item.to_dict() for item in patch.new_obligations),
            nodes=tuple(item.to_dict() for item in patch.new_nodes),
            result_capsules=(result,),
            workspace_manifest={"entries": [{"path": "result.txt"}]},
        )
    )

    assert review.verdicts[0].status.value == "satisfied"
    planner_schema = client._contract_plan_schema(plan_request)
    assert "reasoning_effort" not in fake.posts[0]["json"]
    assert "reasoning_effort" not in fake.posts[1]["json"]
    assert fake.posts[0]["json"]["response_format"] == {"type": "json_object"}
    atom_schema = planner_schema["properties"]["new_nodes"]["items"][
        "properties"
    ]["atom"]
    atom_branches = atom_schema["anyOf"]
    branch_properties = [item["properties"] for item in atom_branches]
    obligation_schema = planner_schema["properties"]["new_obligations"]["items"]
    assert all("operations" not in item for item in branch_properties)
    assert all("allowed_operations" not in item for item in branch_properties)
    assert all("action_budget" not in item for item in branch_properties)
    assert all("evidence_requirements" not in item for item in branch_properties)
    assert all(item["write_roots"]["maxItems"] == 8 for item in branch_properties)
    assert "assertions" not in obligation_schema["properties"]
    assert obligation_schema["properties"]["phase"]["enum"] == [
        "execution_evidence",
        "final_presentation",
    ]
    assert "phase" in obligation_schema["required"]
    assert [item["kind"]["enum"] for item in branch_properties] == [
        ["investigate"],
        ["mutate"],
        ["verify"],
    ]
    planner_payload = fake.posts[0]["json"]["messages"][1]["content"]
    assert "write_file" not in planner_payload
    assert "read_file" not in planner_payload
    assert list(json.loads(planner_payload))[-1] == "request"
    forbidden = (
        "candidate_output",
        "transcript",
        "recent_actions",
        "completed_atoms",
        "protocol_rejections",
    )
    for post in fake.posts:
        user_payload = post["json"]["messages"][1]["content"]
        assert not any(name in user_payload for name in forbidden)


def test_supervisor_health_requires_configured_model_in_catalog():
    fake = FakeSession([])
    client = OpenAICompatibleSupervisorClient(settings(), session=fake)

    health = client.health()

    assert health["available"] is True
    assert health["model_present"] is True


def test_goal_plan_upstream_error_mislabeled_http_400_is_retried_once():
    value = {
        "goal_obligations": [
            {
                "obligation_id": "O1",
                "predicate": "config.json is inspected",
                "required_phases": ["observe"],
            }
        ],
        "add_stages": [
            {
                "stage": 1,
                "steps": [
                    {
                        "step_id": "S1",
                        "objective": "Inspect config.json.",
                        "phase": "observe",
                        "depends_on": [],
                        "obligation_ids": ["O1"],
                        "success_evidence": ["config.json is observed"],
                        "read_roots": ["config.json"],
                        "write_roots": [],
                        "constraints": [],
                    }
                ],
            }
        ],
        "replace_stages": [],
        "discard_step_ids": [],
        "reason": "Start with the observation.",
    }
    fake = FakeSession(
        [
            FakeResponse(
                {
                    "error": {
                        "type": "upstream_error",
                        "message": "Upstream request failed",
                    }
                },
                status_code=400,
            ),
            response(value),
        ]
    )
    client = OpenAICompatibleSupervisorClient(
        replace(
            settings(),
            retry_attempts=2,
            retry_backoff_seconds=0,
        ),
        session=fake,
    )

    patch = client.plan_goal_patch(
        GoalPlanRequest(
            run_id="RUN-GOAL-UPSTREAM-RETRY",
            immutable_request="Inspect config.json.",
            goal_digest="goal-upstream-retry",
            plan_revision=0,
            active_plan={"stages": []},
            latest_audit=None,
            workspace_manifest={"entries": [{"path": "config.json"}]},
        )
    )

    assert patch.add_steps[0].step_id == "S1"
    assert len(fake.posts) == 2
    assert all(post["url"].endswith("/chat/completions") for post in fake.posts)


def test_non_retryable_supervisor_http_error_has_structured_contract():
    fake = FakeSession([FakeResponse({}, status_code=400)])
    client = OpenAICompatibleSupervisorClient(
        replace(settings(), retry_attempts=3),
        session=fake,
    )

    with pytest.raises(SupervisorTransportError) as captured:
        client.create_plan(
            SupervisorPlanRequest(
                run_id="RUN-BAD-REQUEST",
                request="Inspect the workspace.",
                request_digest="digest-bad-request",
                constraints=(),
                workspace_manifest={"entries": []},
            )
        )

    assert captured.value.status_code == 400
    assert captured.value.retryable is False
    assert captured.value.category == "request"
    assert len(fake.posts) == 1


def test_openai_supervisor_builds_one_online_microtask_directive():
    fake = FakeSession(
        [
            response(
                {
                    "disposition": "continue",
                    "review_status": "initial",
                    "review_summary": "Assign one observable first microtask.",
                    "issues": [],
                    "microtask_objective": "Inspect the existing input file.",
                    "completion_checks": ["The relevant input content is observed."],
                    "constraints": ["Do not modify unrelated files."],
                }
            )
        ]
    )
    audit: list[dict] = []
    client = OpenAICompatibleSupervisorClient(
        settings(), session=fake, audit_hook=audit.append
    )

    directive = client.next_directive(
        SupervisorDirectiveRequest(
            run_id="RUN-ONLINE",
            request="Transform input.txt into result.txt.",
            request_digest="digest-online",
            constraints=("Stay inside the workspace.",),
            directive_index=1,
            outcome_ref="initial",
            previous_directive=None,
            worker_outcome=None,
            action_count=0,
            actions=(),
            artifacts=(),
            workspace_manifest={"entries": [{"path": "input.txt"}]},
        )
    )

    assert directive.directive_index == 1
    assert directive.disposition.value == "continue"
    assert directive.microtask_objective == "Inspect the existing input file."
    assert fake.posts[0]["json"]["response_format"] == {"type": "json_object"}
    assert [
        item["phase"]
        for item in audit
        if item["type"] == "supervisor_request_returned"
    ] == ["directive"]


def test_openai_supervisor_builds_parallel_ready_atom_stage():
    immutable_request = "Create left.txt and right.txt, then verify both."
    fake = FakeSession(
        [
            response(
                {
                    "disposition": "dispatch",
                    "review_summary": "Dispatch two disjoint file atoms.",
                    "issues": [],
                    "atoms": [
                        {
                            "atom_id": "left",
                            "role": "work",
                            "objective": "Create and verify left.txt.",
                            "request_clauses": [immutable_request],
                            "depends_on": [],
                            "read_roots": [],
                            "write_roots": ["left.txt"],
                            "exclusive": False,
                            "allowed_operations": ["write_file"],
                            "action_budget": 1,
                            "completion_checks": ["left.txt is verified."],
                            "constraints": [],
                        },
                        {
                            "atom_id": "right",
                            "role": "work",
                            "objective": "Create and verify right.txt.",
                            "request_clauses": [immutable_request],
                            "depends_on": [],
                            "read_roots": [],
                            "write_roots": ["right.txt"],
                            "exclusive": False,
                            "allowed_operations": ["write_file"],
                            "action_budget": 1,
                            "completion_checks": ["right.txt is verified."],
                            "constraints": [],
                        },
                    ],
                    "accepted_candidate_atom_id": "",
                }
            )
        ]
    )
    client = OpenAICompatibleSupervisorClient(settings(), session=fake)

    request = SupervisorStageRequest(
            run_id="RUN-PARALLEL",
            request=immutable_request,
            request_digest="digest-parallel",
            constraints=("Stay inside the workspace.",),
            stage_index=1,
            max_parallel_atoms=4,
                previous_stage_id="",
                completed_atoms=(),
                available_operations=(
                    {
                        "name": "read_file",
                        "description": "Read a file.",
                        "scope_mode": "read_only",
                    },
                    {
                        "name": "write_file",
                        "description": "Write a file.",
                        "scope_mode": "path_mutation",
                    },
                ),
                workspace_manifest={"entries": []},
        )
    stage = client.next_stage(request)

    assert [item.atom_id for item in stage.atoms] == ["left", "right"]
    assert stage.request_digest == "digest-parallel"
    assert fake.posts[0]["json"]["response_format"] == {"type": "json_object"}
    stage_schema = client._stage_schema(request)
    assert "allOf" not in stage_schema
    assert stage_schema["additionalProperties"] is False
    depends_on_schema = stage_schema["properties"]["atoms"]["items"][
        "properties"
    ]["depends_on"]
    assert depends_on_schema["maxItems"] == 0
    assert stage_schema["properties"]["accepted_candidate_atom_id"]["enum"] == [
        ""
    ]
    assert stage_schema["properties"]["atoms"]["items"]["properties"][
        "allowed_operations"
    ]["items"]["enum"] == ["read_file", "write_file"]


def test_parallel_stage_locally_repairs_provider_schema_violation():
    immutable_request = "Create result.txt and verify it."

    def stage_content(clause: str):
        return {
            "disposition": "dispatch",
            "review_summary": "Dispatch one bounded atom.",
            "issues": [],
            "atoms": [
                {
                    "atom_id": "result",
                    "role": "work",
                    "objective": "Create and verify result.txt.",
                    "request_clauses": [clause],
                    "depends_on": [],
                    "read_roots": [],
                    "write_roots": ["result.txt"],
                    "exclusive": False,
                    "allowed_operations": ["write_file"],
                    "action_budget": 1,
                    "completion_checks": ["result.txt is verified."],
                    "constraints": [],
                }
            ],
            "accepted_candidate_atom_id": "",
        }

    fake = FakeSession(
        [
            response(stage_content("Invented replacement request.")),
            response(stage_content(immutable_request)),
        ]
    )
    audit: list[dict] = []
    client = OpenAICompatibleSupervisorClient(
        settings(),
        session=fake,
        audit_hook=audit.append,
    )
    request = SupervisorStageRequest(
        run_id="RUN-REPAIR",
        request=immutable_request,
        request_digest="digest-repair",
        constraints=(),
        stage_index=1,
        max_parallel_atoms=4,
        previous_stage_id="",
        completed_atoms=(),
        available_operations=(
            {
                "name": "read_file",
                "description": "Read a file.",
                "scope_mode": "read_only",
            },
            {
                "name": "write_file",
                "description": "Write a file.",
                "scope_mode": "path_mutation",
            },
        ),
        workspace_manifest={"entries": []},
    )

    stage = client.next_stage(request)

    assert stage.atoms[0].request_clauses == (immutable_request,)
    assert len(fake.posts) == 2
    repair = fake.posts[1]["json"]["messages"][1]["content"]
    assert "local_validation_repair" in repair
    assert list(json.loads(repair))[-1] == "local_validation_repair"
    assert any(
        item["type"] == "supervisor_semantic_response_rejected"
        for item in audit
    )


def test_parallel_acceptance_requires_independent_evidence_review():
    immutable_request = "Create result.txt with exact content ok and verify it."
    accepted = {
        "disposition": "accept_final",
        "review_summary": "Planner proposes acceptance.",
        "issues": [],
        "atoms": [],
        "accepted_candidate_atom_id": "final",
    }
    correction = {
        "disposition": "dispatch",
        "review_summary": "Exact evidence contradicts the request.",
        "issues": ["result.txt contains wrong instead of ok."],
        "atoms": [
            {
                "atom_id": "repair_result",
                "role": "work",
                "objective": "Write result.txt with exact content ok.",
                "request_clauses": [immutable_request],
                "depends_on": ["final"],
                "read_roots": [],
                "write_roots": ["result.txt"],
                "exclusive": False,
                "allowed_operations": ["write_file"],
                "action_budget": 1,
                "completion_checks": ["result.txt contains exact content ok."],
                "constraints": [],
            }
        ],
        "accepted_candidate_atom_id": "",
    }
    fake = FakeSession([response(accepted), response(correction)])
    audit: list[dict] = []
    client = OpenAICompatibleSupervisorClient(
        settings(), session=fake, audit_hook=audit.append
    )
    request = SupervisorStageRequest(
        run_id="RUN-INDEPENDENT-REVIEW",
        request=immutable_request,
        request_digest="digest-independent-review",
        constraints=(),
        stage_index=4,
        max_parallel_atoms=4,
        previous_stage_id="STAGE-3",
        completed_atoms=(
            {
                "stage_id": "STAGE-3",
                "atom_id": "final",
                "role": "finalizer",
                "status": "completed",
                "candidate_output": "result.txt is correct.",
                "recent_actions": [
                    {
                        "operation": "read_file",
                        "result": {"success": True, "output": "wrong"},
                    }
                ],
            },
        ),
        available_operations=(
            {
                "name": "read_file",
                "description": "Read a file.",
                "scope_mode": "read_only",
            },
            {
                "name": "write_file",
                "description": "Write a file.",
                "scope_mode": "path_mutation",
            },
        ),
        workspace_manifest={"entries": [{"path": "result.txt"}]},
    )

    stage = client.next_stage(request)

    assert stage.disposition.value == "dispatch"
    assert stage.atoms[0].atom_id == "repair_result"
    assert len(fake.posts) == 2
    assert [
        item["phase"]
        for item in audit
        if item["type"] == "supervisor_request_returned"
    ] == ["stage", "stage_acceptance_review"]
    reviewer_payload = fake.posts[1]["json"]["messages"][1]["content"]
    assert "proposed_acceptance" in reviewer_payload


def test_supervisor_read_timeout_retries_safe_control_plane_request():
    fake = FakeSession(
        [
            requests.ReadTimeout("first attempt timed out"),
            response(
                {
                    "objective": "Inspect and complete the request.",
                    "constraints": [],
                    "steps": ["Inspect the workspace."],
                    "completion_checks": ["The requested result is verified."],
                    "risks": [],
                }
            ),
        ]
    )
    client = OpenAICompatibleSupervisorClient(
        replace(settings(), retry_attempts=2, retry_backoff_seconds=0),
        session=fake,
    )

    plan = client.create_plan(
        SupervisorPlanRequest(
            run_id="RUN-TIMEOUT",
            request="Inspect the workspace.",
            request_digest="digest-timeout",
            constraints=(),
            workspace_manifest={"entries": []},
        )
    )

    assert plan.steps == ("Inspect the workspace.",)
    assert len(fake.posts) == 2


def test_supervisor_http_200_protocol_failure_is_not_a_transport_retry():
    fake = FakeSession([FakeResponse({"choices": []}) for _ in range(3)])
    audit = []
    client = OpenAICompatibleSupervisorClient(
        replace(settings(), retry_attempts=3, retry_backoff_seconds=0),
        session=fake, audit_hook=audit.append,
    )
    with pytest.raises(SupervisorProtocolError):
        client.create_plan(SupervisorPlanRequest(
            run_id="RUN-PROTOCOL-OWNERSHIP", request="Inspect the workspace.",
            request_digest="digest-protocol-ownership", constraints=(), workspace_manifest={},
        ))
    assert len(fake.posts) == 1
    failed = [event for event in audit if event["type"] == "supervisor_request_failed"]
    assert len(failed) == 1 and failed[0]["http_attempts"] == 1
    assert failed[0]["retryable"] is False


def test_contract_plan_http_500_retry_keeps_minimal_request_envelope():
    immutable_request = "Create result.txt containing exact text ok."
    fake = FakeSession(
        [
            FakeResponse({}, status_code=500),
            response(
                {
                    "summary": "Compile one mandatory result obligation.",
                    "new_obligations": [
                        {
                            "obligation_id": "OBL-result",
                            "predicate": "result.txt contains exact text ok.",
                            "evidence_kinds": ["file_observation"],
                            "assertions": [
                                {
                                    "assertion_id": "ASSERT-result-text",
                                    "kind": "text_exact",
                                    "target_path": "result.txt",
                                    "target_pointer": "",
                                    "sources": [],
                                    "expected": "ok",
                                    "keys": [],
                                    "order": "",
                                    "algorithm": "",
                                }
                            ],
                        }
                    ],
                    "new_nodes": [
                        {
                            "obligation_ids": ["OBL-result"],
                            "atom": {
                                    "atom_id": "NODE-write",
                                    "role": "work",
                                    "kind": "mutate",
                                    "effect_ceiling": "workspace_mutation",
                                "objective": "Create result.txt containing exact text ok.",
                                "depends_on": [],
                                "read_roots": [],
                                "write_roots": ["result.txt"],
                                    "evidence_requirements": {
                                        "kinds": ["exact_operation_result"],
                                        "freshness": "current_workspace",
                                        "source_preferences": ["workspace"],
                                    },
                                "action_budget": 1,
                            },
                        },
                        {
                            "obligation_ids": ["OBL-result"],
                            "atom": {
                                    "atom_id": "NODE-verify",
                                    "role": "work",
                                    "kind": "verify",
                                    "effect_ceiling": "local_read_only",
                                "objective": "Read result.txt and verify exact content.",
                                "depends_on": ["NODE-write"],
                                "read_roots": ["result.txt"],
                                "write_roots": [],
                                    "evidence_requirements": {
                                        "kinds": ["file_observation"],
                                        "freshness": "current_workspace",
                                        "source_preferences": ["workspace_file"],
                                    },
                                "action_budget": 1,
                            },
                        },
                        {
                            "obligation_ids": ["OBL-result"],
                            "atom": {
                                    "atom_id": "NODE-final",
                                    "role": "finalizer",
                                    "kind": "synthesize",
                                    "effect_ceiling": "local_read_only",
                                "objective": "Read result.txt and report completion.",
                                "depends_on": ["NODE-verify"],
                                "read_roots": ["result.txt"],
                                "write_roots": [],
                                    "evidence_requirements": {
                                        "kinds": ["verified_ledger"],
                                        "freshness": "current_workspace",
                                        "source_preferences": ["workspace"],
                                    },
                                "action_budget": 1,
                            },
                        },
                    ],
                }
            ),
        ]
    )
    audit: list[dict] = []
    client = OpenAICompatibleSupervisorClient(
        replace(
            settings(),
            retry_attempts=2,
            retry_backoff_seconds=0,
        ),
        session=fake,
        audit_hook=audit.append,
    )

    patch = client.plan_contract_graph(
        ContractPlanRequest(
            run_id="RUN-FALLBACK",
            request=immutable_request,
            request_digest="digest-fallback",
            graph_revision=0,
            obligations=(),
            nodes=(),
            latest_review=None,
            result_capsules=(),
            available_operations=contract_operation_catalog(),
            workspace_manifest={"entries": []},
        )
    )

    assert patch.new_obligations[0].required is True
    assert all("reasoning_effort" not in post["json"] for post in fake.posts)
    assert not any(
        item["type"] == "supervisor_reasoning_fallback_applied" for item in audit
    )


def test_contract_plan_second_http_500_retry_keeps_minimal_request_envelope():
    fake = FakeSession(
        [
            FakeResponse({}, status_code=500),
            response(contract_plan_value()),
        ]
    )
    audit: list[dict] = []
    client = OpenAICompatibleSupervisorClient(
        replace(
            settings(),
            retry_attempts=2,
            retry_backoff_seconds=0,
        ),
        session=fake,
        audit_hook=audit.append,
    )

    patch = client.plan_contract_graph(
        ContractPlanRequest(
            run_id="RUN-NONE-RETRY",
            request="Create result.txt containing exact text ok.",
            request_digest="digest-none-retry",
            graph_revision=0,
            obligations=(),
            nodes=(),
            latest_review=None,
            result_capsules=(),
            available_operations=contract_operation_catalog(),
            workspace_manifest={"entries": []},
        )
    )

    assert patch.new_obligations[0].required is True
    assert all("reasoning_effort" not in post["json"] for post in fake.posts)
    assert not any(
        item["type"] == "supervisor_reasoning_fallback_applied" for item in audit
    )


def test_model_route_falls_back_and_circuit_skips_repeated_primary_failure():
    valid_plan = {
        "objective": "Inspect the workspace.",
        "constraints": [],
        "steps": ["Inspect the workspace."],
        "completion_checks": ["Inspection is complete."],
        "risks": [],
    }
    fake = FakeSession(
        [
            FakeResponse({}, status_code=503),
            response(valid_plan, model="gpt-fallback"),
            response(valid_plan, model="gpt-fallback"),
        ]
    )
    audit: list[dict] = []
    client = OpenAICompatibleSupervisorClient(
        replace(
            settings(),
            fallback_models=("gpt-fallback",),
            circuit_breaker_failures=1,
            circuit_breaker_cooldown_seconds=3600,
        ),
        session=fake,
        audit_hook=audit.append,
    )
    request = SupervisorPlanRequest(
        run_id="RUN-ROUTE",
        request="Inspect the workspace.",
        request_digest="digest-route",
        constraints=(),
        workspace_manifest={"entries": []},
    )

    client.create_plan(request)
    client.create_plan(request)

    assert [post["json"]["model"] for post in fake.posts] == [
        "gpt-test",
        "gpt-fallback",
        "gpt-fallback",
    ]
    assert any(item["type"] == "supervisor_model_fallback_applied" for item in audit)
    assert any(item["type"] == "supervisor_route_skipped" for item in audit)


def test_pending_retry_delay_tracks_phase_circuit_cooldown(monkeypatch):
    client = OpenAICompatibleSupervisorClient(
        replace(
            settings(),
            circuit_breaker_failures=2,
            circuit_breaker_cooldown_seconds=30,
        ),
        session=FakeSession([]),
    )
    client._model_failures[client.model_name] = 2
    client._model_opened_at[client.model_name] = 100.0
    monkeypatch.setattr(supervisor_openai_module.time, "monotonic", lambda: 112.0)

    assert client.pending_retry_delay_seconds("goal_plan") == pytest.approx(18.05)

    client._model_failures[client.model_name] = 1
    assert client.pending_retry_delay_seconds("goal_plan") == 0


def test_validated_contract_plan_cache_avoids_second_api_call(tmp_path):
    cache_dir = tmp_path / "plan-cache"
    configured = replace(
        settings(),
        plan_cache_enabled=True,
        plan_cache_dir=str(cache_dir.resolve()),
    )
    request = ContractPlanRequest(
        run_id="RUN-CACHE",
        request="Create result.txt containing exact text ok.",
        request_digest="digest-cache",
        graph_revision=0,
        obligations=(),
        nodes=(),
        latest_review=None,
        result_capsules=(),
        available_operations=contract_operation_catalog(),
        workspace_manifest={"entries": []},
    )
    first_session = FakeSession([response(contract_plan_value())])
    first = OpenAICompatibleSupervisorClient(configured, session=first_session)
    first_patch = first.plan_contract_graph(request)
    audit: list[dict] = []
    second_session = FakeSession([])
    second = OpenAICompatibleSupervisorClient(
        configured, session=second_session, audit_hook=audit.append
    )

    second_patch = second.plan_contract_graph(request)

    assert second_patch.patch_id == first_patch.patch_id
    assert second_session.posts == []
    assert any(item["type"] == "supervisor_plan_cache_hit" for item in audit)


def test_validated_goal_plan_cache_ignores_per_run_identity(tmp_path):
    cache_dir = tmp_path / "goal-plan-cache"
    configured = replace(
        settings(),
        plan_cache_enabled=True,
        plan_cache_dir=str(cache_dir.resolve()),
    )
    value = {
        "goal_obligations": [
            {
                "obligation_id": "O1",
                "predicate": "config.json is inspected",
                "required_phases": ["observe"],
            }
        ],
        "add_stages": [
            {
                "stage": 1,
                "steps": [
                    {
                        "step_id": "S1",
                        "objective": "Inspect config.json.",
                        "phase": "observe",
                        "depends_on": [],
                        "obligation_ids": ["O1"],
                        "success_evidence": ["config.json is observed"],
                        "read_roots": ["config.json"],
                        "write_roots": [],
                        "constraints": [],
                    }
                ],
            }
        ],
        "replace_stages": [],
        "discard_step_ids": [],
        "reason": "Start with one observation step.",
    }
    first_request = GoalPlanRequest(
        run_id="RUN-GOAL-CACHE-1",
        immutable_request="Inspect config.json.",
        goal_digest="goal-digest-1",
        plan_revision=0,
        active_plan={"goal_digest": "goal-digest-1", "stages": []},
        latest_audit={
            "audit_id": "AUD-per-run-1",
            "verdict": "repair",
            "step_id": "S0",
            "evidence_refs": ["A00001"],
            "gaps": ["configuration still needs inspection"],
            "reason": "repair is required",
        },
        latest_stage_review={
            "review_id": "GSR-per-run-1",
            "stage": 1,
            "verdict": "repair",
            "reviewed_step_ids": ["S0"],
            "evidence_refs": ["A00001"],
            "gaps": ["configuration still needs inspection"],
            "reason": "repair is required",
        },
        workspace_manifest={"entries": [{"path": "config.json", "sha256": "a"}]},
    )
    second_request = GoalPlanRequest(
        run_id="RUN-GOAL-CACHE-2",
        immutable_request="Inspect config.json.",
        goal_digest="goal-digest-2",
        plan_revision=0,
        active_plan={"goal_digest": "goal-digest-2", "stages": []},
        latest_audit={
            "audit_id": "AUD-per-run-2",
            "verdict": "repair",
            "step_id": "S0",
            "evidence_refs": ["A00001"],
            "gaps": ["configuration still needs inspection"],
            "reason": "repair is required",
        },
        latest_stage_review={
            "review_id": "GSR-per-run-2",
            "stage": 1,
            "verdict": "repair",
            "reviewed_step_ids": ["S0"],
            "evidence_refs": ["A00001"],
            "gaps": ["configuration still needs inspection"],
            "reason": "repair is required",
        },
        workspace_manifest={"entries": [{"path": "config.json", "sha256": "a"}]},
    )
    first_session = FakeSession([response(value)])
    first = OpenAICompatibleSupervisorClient(configured, session=first_session)
    first_patch = first.plan_goal_patch(first_request)
    first.accept_goal_plan_cache_candidate(first_patch.patch_id)
    audit: list[dict] = []
    second_session = FakeSession([])
    second = OpenAICompatibleSupervisorClient(
        configured, session=second_session, audit_hook=audit.append
    )

    second_patch = second.plan_goal_patch(second_request)

    assert second_patch.add_steps == first_patch.add_steps
    assert second_session.posts == []
    assert any(
        item["type"] == "supervisor_plan_cache_hit"
        and item["phase"] == "goal_plan"
        for item in audit
    )


def test_rejected_goal_plan_cache_candidate_is_never_replayed(tmp_path):
    cache_dir = tmp_path / "rejected-goal-plan-cache"
    configured = replace(
        settings(),
        plan_cache_enabled=True,
        plan_cache_dir=str(cache_dir.resolve()),
    )
    value = {
        "goal_obligations": [
            {
                "obligation_id": "O1",
                "predicate": "config.json is inspected",
                "required_phases": ["observe"],
            }
        ],
        "add_stages": [
            {
                "stage": 1,
                "steps": [
                    {
                        "step_id": "S1",
                        "objective": "Inspect config.json.",
                        "phase": "observe",
                        "depends_on": [],
                        "obligation_ids": ["O1"],
                        "success_evidence": ["config.json is observed"],
                        "read_roots": ["config.json"],
                        "write_roots": [],
                        "constraints": [],
                    }
                ],
            }
        ],
        "replace_stages": [],
        "discard_step_ids": [],
        "reason": "Candidate requires Controller validation.",
    }
    request = GoalPlanRequest(
        run_id="RUN-GOAL-REJECTED-CACHE",
        immutable_request="Inspect config.json.",
        goal_digest="goal-digest",
        plan_revision=0,
        active_plan={"goal_digest": "goal-digest", "stages": []},
        latest_audit=None,
        workspace_manifest={"entries": [{"path": "config.json", "sha256": "a"}]},
    )
    fake = FakeSession([response(value), response(value)])
    client = OpenAICompatibleSupervisorClient(configured, session=fake)

    rejected = client.plan_goal_patch(request)
    client.discard_goal_plan_cache_candidate(rejected.patch_id)
    replacement = client.plan_goal_patch(request)

    assert replacement.add_steps == rejected.add_steps
    assert len(fake.posts) == 2
    assert list(cache_dir.glob("*.json")) == []


def test_validated_goal_stage_review_cache_ignores_per_run_identity(tmp_path):
    cache_dir = tmp_path / "goal-stage-cache"
    configured = replace(
        settings(),
        plan_cache_enabled=True,
        plan_cache_dir=str(cache_dir.resolve()),
    )
    first_request = GoalStageReviewRequest(
        run_id="RUN-STAGE-CACHE-1",
        immutable_request="Inspect config.json.",
        goal_digest="goal-digest-1",
        stage=1,
        stage_steps=(
            {
                "step_id": "S1",
                "objective": "Inspect config.json",
                "accepted_evidence_refs": ["A00001"],
            },
        ),
        workspace_manifest={"entries": [{"path": "config.json", "sha256": "a"}]},
    )
    second_request = GoalStageReviewRequest(
        run_id="RUN-STAGE-CACHE-2",
        immutable_request="Inspect config.json.",
        goal_digest="goal-digest-2",
        stage=1,
        stage_steps=first_request.stage_steps,
        workspace_manifest=first_request.workspace_manifest,
    )
    first_session = FakeSession(
        [response({"verdict": "advance", "gaps": [], "reason": "coherent"})]
    )
    first = OpenAICompatibleSupervisorClient(configured, session=first_session)
    first_review = first.review_goal_stage(first_request)
    audit: list[dict] = []
    second_session = FakeSession([])
    second = OpenAICompatibleSupervisorClient(
        configured, session=second_session, audit_hook=audit.append
    )

    second_review = second.review_goal_stage(second_request)

    assert second_review.verdict == first_review.verdict
    assert second_session.posts == []
    assert any(
        item["type"] == "supervisor_plan_cache_hit"
        and item["phase"] == "goal_stage_review"
        for item in audit
    )
