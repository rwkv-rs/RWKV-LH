from pathlib import Path
import sys,json,hashlib,time,subprocess,tarfile
R=Path('/home/chase/GitHub/RWKV-LH');sys.path.insert(0,str(R));D=R/'data/experiments/RWKV_READ_SUMMARY_PATHWAY_R1_20260912'
from rwkv_lh.model import LongHorizonModel
from rwkv_lh.token_budget import tokenizer
from rwkv_lh.runtime.settings import get_runtime_settings,load_local_env
load_local_env(R/'.env.local')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
x=json.loads((D/'CASES_AND_RUBRIC.json').read_text());s=get_runtime_settings();identity=json.loads((D/'SERVER_IDENTITY.json').read_text());assert identity['capabilities']['max_model_len']==16384
pins={str(p.relative_to(R)):sha(p) for p in sorted((R/'rwkv_lh').rglob('*')) if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc'}
for glob in ['temp/*read_summary_pathway*r1_20260912.py','tests/*.py']:
 for p in R.glob(glob):pins[str(p.relative_to(R))]=sha(p)
for p in ['temp/run_read_summary_baseline_r5_20260912.py','pyproject.toml','uv.lock','AGENTS.md','docs/RWKV_CODING_AGENT_HARNESS_V1.zh-CN.md','data/experiments/RWKV_AGENT_HARNESS_DESIGN_V1_R1_20260912/MINIMAL_VALIDATION_PLAN.zh-CN.md']:
 pins[p]=sha(R/p)
schedule=[]
for repeat in [1,2]:
 for c in x['cases']:
  for arm in (['direct','tool'] if repeat==1 else ['tool','direct']):schedule.append(dict(id=f"{len(schedule)+1:02d}-{c['id']}-r{repeat}-{arm}",case=c['id'],repeat=repeat,arm=arm))
for c in x['cases']:
 w=R/c['workspace_source'];assert {str(p.relative_to(w)):sha(p) for p in w.rglob('*') if p.is_file()}==c['workspace_sha256'];assert len(tokenizer().encode((w/c['path']).read_text()))<4096
reg=dict(round=D.name,frozen_at_epoch=time.time(),authorization='Owner latest instruction continue implementing revised plan; no training/dataset/GitHub changes',cases=x['cases'],rubric=x['rubric'],rubric_sha256=sha(D/'CASES_AND_RUBRIC.json'),schedule=schedule,source_pins=pins,local_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),model_sha256=s.model_sha256,server_identity_sha256=sha(D/'SERVER_IDENTITY.json'),sampling=LongHorizonModel._SAMPLING.to_dict(),seed='not set; backend stochastic, no exact token reproducibility claim',state='fresh native_required zero with zero profile SHA per attempt; continuous committed generation -> observation child -> next generation; exact replay/export/rebuild distinguished by trace',max_output_tokens=1800,max_decisions_per_case=4,max_generations=64,max_output_tokens_batch=115200,wall_seconds_batch=3600,wall_limit_semantics='No new generation after 3600s; current transport bounded 180s read timeout and existing same-request recovery. No new deployment or paid strong API call.',cost_budget={'strong_model_calls':0,'new_paid_api_spend':0,'existing_self_hosted_service':'one serial batch <=3600s scheduling window; no new rented resources; GPU currency rate unavailable, cost NA not zero','resource_metrics':'client end-to-end/time, exact full and incremental input/output token counts; no actual GPU prefill/peak telemetry inferred from tokens','regression':'no production change; existing sealed R4/R5 21/21 +3/3 references only, fresh offline full tests; no unbudgeted extra inference'},constraints=['只读任务：不得修改文件、启动服务或调用有副作用的工具。'],attachment_prefix='\n\n以下是用户提供的指定文件全文，来源路径：{path}。\n<user_provided_file>\n',attachment_suffix='\n</user_provided_file>\n',tools='Same full production 19 tools and R4 description; any lawful read-only path allowed by registry; explicit write prohibition enforced mechanically, no forced sequence or parameter repair',stop='raw final_answer; generation/context/wall budget; protocol rejection; readonly violation. No semantic retry or forced Final. Infrastructure stops entire batch. Existing same-request transport recovery retained.',grading='Anonymous final packets only, one reviewer with context-awareness limitation; no arm/tool identifiers. No old-score rescore. Per-arm 2 repeats4/4 gate; repeated reads do not fail.',preexisting_sha256=sha(D/'PREEXISTING_CHANGES.json'))
assert reg['model_sha256']=='559371f5b9aef13189ae54b345ac096af4ad2b689996c05d89de687612b3ae65'
assert not (D/'REGISTRATION.json').exists();save(D/'REGISTRATION.json',reg);save(D/'SOURCE_MANIFEST.json',pins)
with tarfile.open(D/'FROZEN_SOURCE.tar.gz','w:gz') as t:
 for p,h in pins.items():assert sha(R/p)==h;t.add(R/p,arcname=p)
print('FROZEN',sha(D/'REGISTRATION.json'))
