"""Human-authored semantic judgments of anonymous original outputs, no model answer generation."""
from pathlib import Path
import json
D=Path('/home/chase/GitHub/RWKV-LH/data/experiments/RWKV_READ_SUMMARY_PATHWAY_R1_20260912')
# Each tuple: frozen fact id, coverage, exact answer quote or reason for omission.
reviews={
'0e284fedda':('satisfies',[],[
('purpose','covered','给小型仓库实现的 SQLite HTTP 订单服务'),('idempotency','covered','同 key、相同规范化请求返回 200 同一订单，不再次扣库存'),('atomic','covered','失败应整体无写入，不扣其他 SKU、不创建订单'),('normalization','covered','同 SKU 的重复项数量求和，再按 SKU 排序；同 key 不同 customer/明细返回 409'),('failure_key','covered','不占用 key，允许之后更正请求重试'),('concurrency','covered','并发相同 key 只创建一单，不得超卖'),('persistence','covered','进程重启后继续有效'),('verification','covered','公开验证只做健康检查')]),
'31afac4b35':('satisfies',[],[
('purpose','covered','小型仓库的 HTTP 订单服务'),('idempotency','covered','用于解决网络重试导致的重复扣库存；POST /orders 必须带有非空的 Idempotency-Key'),('atomic','covered','任何失败应整体无写入，不扣库存、不创建订单'),('normalization','partial','同一 SKU 的重复项数量求和，按 SKU 排序；遗漏同key异请求冲突'),('failure_key','covered','不占用 key，允许之后更正请求重试'),('concurrency','omitted','未概括并发不超卖'),('persistence','covered','重启后数据保留'),('verification','omitted','未提健康验证边界；未声称业务测试通过')]),
'372b0ad746':('satisfies',[],[
('purpose','covered','README.md 概括；会议资源预约服务；要求：多个请求同时到达时'),('conflict','covered','同一资源的 confirmed 预约不能重叠'),('cancel','covered','取消后时段可被重新预约'),('failure','omitted','列错误码但未说明失败不改状态'),('atomic','covered','冲突判定与写入必须为同一原子操作'),('persistence','covered','数据和冲突规则必须继续正确'),('verification','covered','公开验证仅是启动健康检查，需要补充自己的行为验证')]),
'720dd945ab':('partial',[{'quote':'非法输入、缺字段、坏 JSON、失败写入等返回 400','kind':'localized_unsupported','evidence':'原文仅把非法输入/缺字段/坏JSON映射400；失败不改变预约是独立约束，未规定一般写入失败返回400。','impact':'错误码的局部无依据扩展；主旨和冲突规则仍正确。'}],[
('purpose','covered','会议资源预约服务的说明文档；描述了服务的目标'),('conflict','covered','同 resource 的 confirmed 预约不能重叠'),('cancel','partial','取消预约；重复取消幂等；未说明释放时段'),('failure','omitted','未说明失败不改变已有预约'),('atomic','covered','冲突判定与写入必须为同一原子操作'),('persistence','covered','数据和冲突规则必须继续正确'),('verification','covered','公开健康检查不能替代完整功能')]),
'540067598f':('partial',[{'quote':'导入必要的模块：argparse、json、http.server、threading','kind':'localized_unsupported','evidence':'源码从http.server导入ThreadingHTTPServer，没有导入threading；线程HTTP服务这一行为正确。','impact':'加入文件未支持的模块事实；不抹去已正确的健康接口描述。'}],[
('purpose','partial','轻量级 HTTP 服务器入口；其他路径尚未实现，但未清楚概括初始骨架'),('get','covered','/health返回HTTP200和JSON；其他路径返回501 not_implemented'),('db','omitted','只说接收--db，没有说明其未使用'),('cli','covered','接收 --db、--host 和 --port 参数'),('threads','covered','使用 ThreadingHTTPServer 实现多线程请求处理'),('json','covered','JSON 响应')]),
'ac634a4571':('partial',[{'quote':'在 main 函数中，解析命令行参数','kind':'localized_inaccuracy','evidence':'源码是if __name__ == "__main__"主程序块，没有定义main函数；实际CLI行为描述正确。','impact':'结构名称不准确；核心问题仍是未说明db未使用和初始骨架。'}],[
('purpose','partial','简单的健康检查接口/基本的HTTP服务器；未强调待完成合同的初始入口'),('get','covered','/health返回200；其他路径返回501 not_implemented'),('db','omitted','仅列必需--db，没有数据库未使用说明'),('cli','covered','必需的 --db 和 --port，以及可选的 --host'),('threads','covered','创建 ThreadingHTTPServer 实例'),('json','covered','JSON 响应')]),
'fd1be87a25':('satisfies',[],[
('purpose','covered','只读的健康检查脚本；不会测试预订或订单行为'),('assertions','covered','HTTP GET 请求 /health；状态码为 200 且 JSON 体中的 ok 字段为 true'),('cli','covered','两个命令行参数：主机和端口')])
}
rows=[]
for key,(quality,issues,facts) in reviews.items():
 rows.append({'anonymous_id':key,'quality':quality,'fact_assessments':[dict(id=i,coverage=c,evidence_or_reason=e) for i,c,e in facts],'factual_issues':issues,'false_completion':False,'false_completion_reason':'没有声称实施代码变更或运行测试并通过；提交答案和遗漏不视作错误完成。','reviewer':'single Codex reviewer; arm/path hidden from review packets, prior orchestration context known','rubric_changed':False})
(D/'SEMANTIC_REVIEW.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
