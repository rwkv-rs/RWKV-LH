from pathlib import Path
import json
D=Path('/home/chase/GitHub/RWKV-LH/data/experiments/RWKV_READ_SUMMARY_PATHWAY_R1_20260912');p=D/'SEMANTIC_REVIEW.json';rows=json.loads(p.read_text())
new={
'8c8c1d69b6':('satisfies',[],[('purpose','covered','只读健康检查脚本，不测试预订或订单行为；需要额外测试'),('assertions','covered','GET /health，状态码200且ok为true'),('cli','covered','主机和端口两个命令行参数')]),
'ac9a412c66':('partial',[],[('purpose','partial','简单健康检查接口/服务器入口；未强调初始骨架和README合同尚待完成'),('get','covered','处理GET；health200，其他路径501 not_implemented'),('db','omitted','仅列必需--db，未说明其未使用'),('cli','covered','--db、--port必需；--host可选'),('threads','covered','ThreadingHTTPServer实例'),('json','covered','JSON响应')])}
for key,(quality,issues,facts) in new.items():
 assert key not in {x['anonymous_id'] for x in rows};rows.append(dict(anonymous_id=key,quality=quality,fact_assessments=[dict(id=i,coverage=c,evidence_or_reason=e) for i,c,e in facts],factual_issues=issues,false_completion=False,false_completion_reason='未声称实施变更或测试通过；提交及遗漏不算虚假完成。',reviewer='single Codex reviewer; anonymous output packet, prior orchestration context known',rubric_changed=False))
p.write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
