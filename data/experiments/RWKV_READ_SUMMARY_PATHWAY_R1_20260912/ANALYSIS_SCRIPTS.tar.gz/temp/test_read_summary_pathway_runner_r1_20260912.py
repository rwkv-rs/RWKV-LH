"""Offline runner contract tests; only existing authorized fixture workspaces."""
import sys,json,os,importlib
from pathlib import Path
import pytest
R=Path('/home/chase/GitHub/RWKV-LH');sys.path.insert(0,str(R/'tests'));sys.path.insert(0,str(R/'temp'))
from test_unified_controller import QueueClient,call,settings
from rwkv_lh.model_session import ModelSession
m=importlib.import_module(os.environ.get('PATHWAY_RUNNER','run_read_summary_pathway_r1_20260912'))
def execute(tmp_path,monkeypatch,calls,arm='tool'):
 reg=json.loads((R/'data/experiments/RWKV_READ_PARAMETER_DESCRIPTION_R4_20260912/REGISTRATION.json').read_text());c=reg['cases'][0];c['common_request']='阅读指定文件 README.md，概括主要内容。';c['request']=c['common_request']
 client=QueueClient(calls);s=settings();d=tmp_path/'experiment';d.mkdir()
 registration=dict(cases=[c],schedule=[dict(case=c['id'],repeat=1,arm=arm,id='trial')],repeats=1,source_pins={},model_sha256=s.model_sha256,wall_seconds_batch=60,max_decisions_per_case=len(calls),max_output_tokens=1800,attachment_prefix='\n用户提供文件 {path}：\n',attachment_suffix='\n资料结束',constraints=['只读，不修改文件'])
 (d/'REGISTRATION.json').write_text(json.dumps(registration));monkeypatch.setattr(m,'D',d);monkeypatch.setattr(m,'get_runtime_settings',lambda:s);monkeypatch.setattr(m,'create_model_session',lambda **kwargs:ModelSession(client,settings=s));m.run();return json.loads((d/'RESULTS.json').read_text())[0],client

def test_lawful_directory_then_read_then_original_final(tmp_path,monkeypatch):
 r,c=execute(tmp_path,monkeypatch,[call('list_directory',path='.'),call('read_file',path='README.md'),call('final_answer',text='ORIGINAL')]);assert r['termination']=='final_answer';assert r['final_output']=='ORIGINAL';assert len(r['handoffs'])==2;assert len(c.prompts)==3

def test_budget_does_not_force_answer_after_repeated_read(tmp_path,monkeypatch):
 r,c=execute(tmp_path,monkeypatch,[call('read_file',path='README.md')]*4);assert r['termination']=='decision_budget_exhausted';assert r['final_output'] is None;assert len(r['actions'])==4;assert len(c.prompts)==4

def test_direct_input_is_user_data_and_does_not_force_a_read(tmp_path,monkeypatch):
 r,c=execute(tmp_path,monkeypatch,[call('final_answer',text='ORIGINAL')],arm='direct');assert not r['actions'];assert r['final_output']=='ORIGINAL';assert '为内部会议室与设备提供' in c.prompts[0];assert '用户提供文件 README.md' in c.prompts[0]

def test_budget_persists_interrupted_state(tmp_path,monkeypatch):
 r,c=execute(tmp_path,monkeypatch,[call('read_file',path='README.md')]);p=next((tmp_path/'experiment'/'runs').glob('*/state_snapshot.json'));assert json.loads(p.read_text())['status']=='interrupted'
