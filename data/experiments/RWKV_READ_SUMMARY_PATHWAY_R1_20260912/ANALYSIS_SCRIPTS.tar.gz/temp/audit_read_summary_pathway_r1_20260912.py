from pathlib import Path
import sys,json,hashlib
R=Path('/home/chase/GitHub/RWKV-LH');sys.path.insert(0,str(R));D=R/'data/experiments/RWKV_READ_SUMMARY_PATHWAY_R1_20260912'
from rwkv_lh.token_budget import tokenizer
from rwkv_lh.schema import ModelEvent
from rwkv_lh.model_io import render_event_append

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
reg=json.loads((D/'REGISTRATION.json').read_text());rows=[];packets=[];mapping={}
for item in reg['schedule']:
 p=D/'runs'/item['id'];c=next(c for c in reg['cases'] if c['id']==item['case'])
 if not (p/'RESULT.json').exists():continue
 result=json.loads((p/'RESULT.json').read_text());state=json.loads((p/'state_snapshot.json').read_text());states=state['model_states'];tr=[json.loads(l) for l in (p/'model_trace.jsonl').read_text().splitlines()];gens=[e for e in tr if e['type']=='model_session_generation_returned'];starts={e['request_id']:e for e in tr if e['type']=='model_session_generation_started'};gen_by_cp={e['candidate_checkpoint_id']:e['raw_generation'] for e in gens};calls=[];checks=[]
 for n,e in enumerate(gens,1):
  g=e['raw_generation'];checks.extend([g['sampling']==reg['sampling'],g['max_output_tokens']==reg['max_output_tokens'],g['state_profile_id']=='zero',g['state_profile_sha256']=='0'*64,g['postprocessed'] is False]);st=starts[e['request_id']];cp=states[st['input_checkpoint_id']];chain=[];cur=cp
  while cur:chain.append(cur);cur=states.get(cur['parent_checkpoint_id'])
  chain.reverse();ids=[]
  for x in chain:ids.extend(gen_by_cp[x['checkpoint_id']]['raw_token_ids'] if x['checkpoint_id'] in gen_by_cp else tokenizer().encode(x['transcript']))
  exact=g['prompt_token_ids'][g['input_bos_token_count']:]==ids;digest=st['input_digest']==cp['native_state_digest'];checks.extend([exact,digest]);(p/f'input_{n:02d}.txt').write_text(tokenizer().decode(ids))
  calls.append(dict(request_id=e['request_id'],input_checkpoint=cp['checkpoint_id'],input_digest=st['input_digest'],input_exact=exact,digest_matches=digest,input_tokens=len(g['prompt_token_ids']),output_tokens=len(g['raw_token_ids']),last_checkpoint_text_tokens=len(tokenizer().encode(cp['transcript'])),finish_reason=g['finish_reason'],raw_output=g['raw_output']))
 handoffs=[];source=(R/c['workspace_source']/c['path']).read_text();acquired=item['arm']=='direct';fullreads=0;readattempts=0
 for n,(action,h) in enumerate(zip(result['actions'],result['handoffs']),1):
  ev=json.loads((p/f'observation_{n}.json').read_text());child=states[h['child']];rendered=render_event_append(ModelEvent.from_dict(ev));ok=child['transcript']==rendered and child['parent_checkpoint_id']==h['parent'] and child['event_ids'].count(h['event_id'])==1 and sum(x['transcript']==rendered for x in states.values())==1
  # Match the next generation to this exact observation, not a reconstructed root.
  nextcalls=[i for i,x in enumerate(result['decisions']) if x['committed_checkpoint']==h['parent']]
  if nextcalls and nextcalls[0]+1<len(calls):ok=ok and calls[nextcalls[0]+1]['input_checkpoint']==h['child']
  checks.append(ok);full=False
  if action['action_type']=='read_file':
   readattempts+=1;raw=action['result'];obs=ev['payload']['result'].get('observation',{});full=raw.get('success',False) and raw.get('output')==source and ''.join(x['content'] for x in obs.get('exact_spans',[]))==source and obs.get('projection_complete',False) and (p/'workspace'/action['arguments']['path']).resolve()==(p/'workspace'/c['path']).resolve()
   fullreads+=int(full);acquired=acquired or full
  handoffs.append(dict(**h,verified=ok,complete_target_read=full))
 root=next(x for x in states.values() if not x['parent_checkpoint_id']);defs=json.loads(root['transcript'].splitlines()[0].removeprefix('System: Tools: '));checks.append(len(defs)==19)
 request=json.loads((p/'REQUEST.json').read_text())['request'];checks.append((item['arm']!='direct') or source in request and source in root['transcript'])
 # Alternative lawful acquisition requires manual original-observation review, never guessed from tool name.
 row=dict(run=item['id'],arm=item['arm'],case=item['case'],repeat=item['repeat'],termination=result['termination'],submitted=result['final_output'] is not None,source_acquired=acquired,complete_target_reads=fullreads,read_calls=readattempts,tool_calls=len(result['actions']),generation_calls=len(gens),protocol_error=result['protocol_error'],infrastructure_error=result['infrastructure_error'],workspace_unchanged=result['workspace_unchanged'],engineering_invariants=all(checks),calls=calls,handoffs=handoffs,root_checkpoint=root['checkpoint_id'],elapsed_seconds=result['elapsed_seconds'],input_tokens=sum(x['input_tokens'] for x in calls),output_tokens=sum(x['output_tokens'] for x in calls),recovery_events=[e for e in tr if any(k in e['type'] for k in ['recover','rebuild','import'])],tool_count=len(defs))
 rows.append(row);anon=hashlib.sha256(('pathway-review-v1:'+item['id']).encode()).hexdigest()[:10];mapping[anon]=item['id'];packets.append(dict(id=anon,task=c['common_request'],file=source,facts=c['facts_external_only'],final=result['final_output']))
save(D/'MECHANICAL_AUDIT.json',rows);save(D/'ANONYMOUS_MAPPING.json',mapping);save(D/'ANONYMOUS_REVIEW_INPUT.json',sorted(packets,key=lambda x:x['id']))
print('audited',len(rows),'generations',sum(x['generation_calls'] for x in rows),'invariants',all(x['engineering_invariants'] for x in rows),'root_states',len(set(x['root_checkpoint'] for x in rows)))
