"""Non-scoring verification of actual encoded user inputs and native identities."""
from pathlib import Path
import sys,json,hashlib
R=Path('/home/chase/GitHub/RWKV-LH');sys.path.insert(0,str(R));D=R/'data/experiments/RWKV_READ_SUMMARY_PATHWAY_R1_20260912'
from verify_pathway_input_envelope_r1_20260912 import request_in_bootstrap
reg=json.loads((D/'REGISTRATION.json').read_text());ident=json.loads((D/'SERVER_IDENTITY.json').read_text());rows=[]
for p in sorted((D/'runs').glob('*/RESULT.json')):
 s=json.loads((p.parent/'state_snapshot.json').read_text());r=json.loads(p.read_text());req=json.loads((p.parent/'REQUEST.json').read_text())['request'];root=next(x for x in s['model_states'].values() if not x['parent_checkpoint_id']);c=next(x for x in reg['cases'] if x['id']==r['case']);source=(R/c['workspace_source']/c['path']).read_text();native=[]
 for cp in s['model_states'].values():
  meta=cp['native_state_metadata'];binding=meta['cache_binding'];parent=s['model_states'].get(cp['parent_checkpoint_id']);native.append(dict(checkpoint_id=cp['checkpoint_id'],model_matches=meta['model_sha256']==reg['model_sha256'],server_matches=meta['server_build']==ident['capabilities']['server_build'],tokenizer_matches=meta['tokenizer_build']==ident['capabilities']['tokenizer_build'],profile_matches=cp['state_profile_id']=='zero' and cp['state_profile_sha256']=='0'*64,parent_digest_matches=binding['parent_state_digest']==(parent['native_state_digest'] if parent else '')))
 expected=c['common_request']+(reg['attachment_prefix'].format(path=c['path'])+source+reg['attachment_suffix'] if r['arm']=='direct' else '')
 rows.append(dict(run=p.parent.name,request_matches_frozen=expected==req,encoded_input_matches_production_goal=request_in_bootstrap(root['transcript'],req),frozen_plain_substring_check=source in root['transcript'] if r['arm']=='direct' else None,native_states=native))
out={'purpose':'Supplemental evidence only; frozen MECHANICAL_AUDIT and semantic rubric unchanged. Plain substring matcher is invalid for JSON-escaped multiline payloads. No retrospective repair gain or clean automatic gate claimed.','rows':rows,'all_structural_checks':all(r['request_matches_frozen'] and r['encoded_input_matches_production_goal'] and all(all(v for k,v in cp.items() if k!='checkpoint_id') for cp in r['native_states']) for r in rows)}
(D/'SUPPLEMENTAL_INPUT_IDENTITY_CHECK.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print('supplemental',len(rows),out['all_structural_checks'])
