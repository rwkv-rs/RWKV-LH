import json,sys
from pathlib import Path
R=Path('/home/chase/GitHub/RWKV-LH');sys.path.insert(0,str(R/'temp'))
from verify_pathway_input_envelope_r1_20260912 import request_in_bootstrap

def test_actual_escaped_supplied_request():
 p=next((R/'data/experiments/RWKV_READ_SUMMARY_PATHWAY_R1_20260912/runs').glob('*direct/state_snapshot.json'));s=json.loads(p.read_text());root=next(x for x in s['model_states'].values() if not x['parent_checkpoint_id']);req=json.loads((p.parent/'REQUEST.json').read_text())['request'];assert request_in_bootstrap(root['transcript'],req)

def test_wrong_request_rejected():
 p=next((R/'data/experiments/RWKV_READ_SUMMARY_PATHWAY_R1_20260912/runs').glob('*direct/state_snapshot.json'));s=json.loads(p.read_text());root=next(x for x in s['model_states'].values() if not x['parent_checkpoint_id']);assert not request_in_bootstrap(root['transcript'],'not the real user request')
