from pathlib import Path
import json
D=Path('/home/chase/GitHub/RWKV-LH/data/experiments/RWKV_READ_SUMMARY_PATHWAY_R1_20260912');p=D/'SEMANTIC_REVIEW.json';rows=json.loads(p.read_text())
new={
'057a0d28d5':('satisfies',[],[('purpose','covered','README.md 概括；可重启的会议资源预约服务'),('conflict','covered','预约冲突按同一资源的已确认预约判定，取消后时段可被重新预约；结合时段上下文概括同资源有效预约冲突，不要求逐字不重叠'),('cancel','covered','取消后时段可被重新预约'),('failure','omitted','未说明失败不改状态；400/404为所列部分错误码，没有一律/仅这些状态码的明确全称声明，不强求列全409'),('atomic','omitted','未说明并发原子性'),('persistence','covered','SQLite持久化；后续启动保留数据'),('verification','omitted','没有健康检查非业务验证的限制；也未声称业务测试通过')]),
'44f6f5a847':('satisfies',[],[('purpose','covered','只读健康检查脚本，不测试业务行为'),('assertions','covered','GET /health；状态码200且ok为true'),('cli','omitted','未提HOST/PORT来自命令行，属允许的完整程度差异')])}
for key,(quality,issues,facts) in new.items():
 assert key not in {x['anonymous_id'] for x in rows};rows.append(dict(anonymous_id=key,quality=quality,fact_assessments=[dict(id=i,coverage=c,evidence_or_reason=e) for i,c,e in facts],factual_issues=issues,false_completion=False,false_completion_reason='未声称实施变更或测试通过；提交及遗漏不算虚假完成。',reviewer='single Codex reviewer; anonymous output packet, prior orchestration context known',rubric_changed=False))
p.write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
