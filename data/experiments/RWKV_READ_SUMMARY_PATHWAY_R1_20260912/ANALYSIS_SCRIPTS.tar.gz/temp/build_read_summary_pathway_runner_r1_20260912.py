from pathlib import Path
R=Path('/home/chase/GitHub/RWKV-LH');src=(R/'temp/run_read_summary_baseline_r5_20260912.py').read_text();start=src.index('def freeze():');end=src.index('def run():');src=src[:start]+src[end:];src=src[:src.index("if __name__=='__main__':")];src=src.replace('RWKV_READ_SUMMARY_BASELINE_R5_20260912','RWKV_READ_SUMMARY_PATHWAY_R1_20260912')
a=src.index(" for repeat in range(1,reg['repeats']+1):");b=src.index("   source=R/c['workspace_source']",a)
src=src[:a]+''' for item in reg['schedule']:
   repeat=item['repeat'];arm=item['arm'];c=next(c for c in reg['cases'] if c['id']==item['case'])
   if time.time()-start>=reg['wall_seconds_batch']:
    save(D/'BATCH_STOP.json',{'reason':'wall_budget','next_item':item});return
   out=D/'runs'/item['id'];out.mkdir(parents=True,exist_ok=False)
'''+src[b:]
src=src.replace("'case':c['id'],'repeat':repeat", "'case':c['id'],'repeat':repeat,'arm':arm")
src=src.replace("state=store.create_run(model.create_literal_goal(c['request'],str(out/'workspace')),run_id=out.name);save(out/'goal.json',state.goal.to_dict())", """request=c['common_request']
    if arm=='direct':request+=reg['attachment_prefix'].format(path=c['path'])+(source/c['path']).read_text()+reg['attachment_suffix']
    save(out/'REQUEST.json',{'request':request,'request_sha256':hashlib.sha256(request.encode()).hexdigest(),'common_request_sha256':hashlib.sha256(c['common_request'].encode()).hexdigest()})
    state=store.create_run(model.create_literal_goal(request,str(out/'workspace'),constraints=reg['constraints']),run_id=out.name);save(out/'goal.json',state.goal.to_dict())""")
src=src.replace("     previous=state.lane_head('executor')", "     if time.time()-start>=reg['wall_seconds_batch']:\n      result['termination']='wall_budget';break\n     previous=state.lane_head('executor')")
src=src.replace("     if decision.command.name!='read_file':result['termination']='out_of_scope_tool';break", "     definition=model.harness.definition(decision.command.name)\n     if not definition.read_only or definition.side_effect:\n      result['termination']='readonly_permission_violation';break")
src=src.replace("'summary',result['final_output']", "'submitted',result['final_output'] is not None")
src=src.replace("   if result['infrastructure_error']:return", "   if result['infrastructure_error'] or result['termination']=='wall_budget':return")
src+="\nif __name__=='__main__':run()\n";(R/'temp/run_read_summary_pathway_r1_20260912.py').write_text(src)
