from pathlib import Path
import json
D=Path('/home/chase/GitHub/RWKV-LH/data/experiments/RWKV_READ_SUMMARY_PATHWAY_R1_20260912');p=D/'SEMANTIC_REVIEW.json';rows=json.loads(p.read_text())
new={
'1d2002c823':('satisfies',[],[('purpose','covered','给小型仓库实现的SQLite HTTP订单服务；README需求概括语境'),('idempotency','covered','同key相同规范化请求返回同一订单，不再次扣库存'),('atomic','covered','失败整体无写入；库存判定、扣减和登记必须原子完成'),('normalization','covered','同SKU求和排序；同key不同请求409'),('failure_key','covered','不占用key，允许更正请求重试'),('concurrency','covered','并发不同key不得超卖'),('persistence','covered','库存、订单、key进程重启后继续有效；事务恢复概括有持久化与恢复验证原文支撑'),('verification','covered','公开验证只做健康检查')]),
'69ce49f6ec':('partial',[],[('purpose','partial','简单的健康检查端点/服务器入口；呈现未实现其他路径，但没有明确初始骨架'),('get','covered','health200+JSON ok；其他路径501 not_implemented'),('db','omitted','仅要求必须指定--db，未说明参数并未用于数据库'),('cli','covered','--db、--port必填，--host可选默认127.0.0.1'),('threads','covered','启动ThreadingHTTPServer'),('json','covered','JSON响应')])}
for key,(quality,issues,facts) in new.items():
 assert key not in {x['anonymous_id'] for x in rows};rows.append(dict(anonymous_id=key,quality=quality,fact_assessments=[dict(id=i,coverage=c,evidence_or_reason=e) for i,c,e in facts],factual_issues=issues,false_completion=False,false_completion_reason='未声称实施变更或测试通过；提交及遗漏不算虚假完成。',reviewer='single Codex reviewer; anonymous output packet, prior orchestration context known',rubric_changed=False))
p.write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
