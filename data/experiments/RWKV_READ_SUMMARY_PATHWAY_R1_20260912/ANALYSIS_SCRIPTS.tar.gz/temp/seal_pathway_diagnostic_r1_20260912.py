from pathlib import Path
import json,hashlib,tarfile,time,subprocess,collections
R=Path('/home/chase/GitHub/RWKV-LH');D=R/'data/experiments/RWKV_READ_SUMMARY_PATHWAY_R1_20260912'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
reg=json.loads((D/'REGISTRATION.json').read_text());rows=json.loads((D/'MECHANICAL_AUDIT.json').read_text());mapping=json.loads((D/'ANONYMOUS_MAPPING.json').read_text());reviews={mapping[x['anonymous_id']]:x for x in json.loads((D/'SEMANTIC_REVIEW.json').read_text())};proof=json.loads((D/'SUPPLEMENTAL_INPUT_IDENTITY_CHECK.json').read_text())
assert len(rows)==len(reviews)==len(reg['schedule'])==16;assert proof['all_structural_checks'];assert len(proof['rows'])==16
assert all(sha(R/p)==h for p,h in reg['source_pins'].items());pre=json.loads((D/'PREEXISTING_CHANGES.json').read_text())['files'];assert all(sha(R/p)==h for p,h in pre.items())
joined=[]
for x in rows:
 r=reviews[x['run']];joined.append(dict(run=x['run'],arm=x['arm'],case=x['case'],repeat=x['repeat'],submitted=x['submitted'],quality=r['quality'],source_acquired=x['source_acquired'],source_read_complete=x['complete_target_reads']==1,observations_verified=all(h['verified'] for h in x['handoffs']),exact_input_verified=all(c['input_exact'] and c['digest_matches'] for c in x['calls']),frozen_mechanical_gate=x['engineering_invariants'],supplemental_structural_proof=True,factual_issues=r['factual_issues'],false_completion=r['false_completion'],task_outcome_from_actual_evidence=r['quality']=='satisfies' and x['source_acquired'] and x['workspace_unchanged'],note='Actual-evidence outcome is reported separately from preserved frozen mechanical flag; no clean automatic-gate or retrospective repair benefit claimed.'))
stats={}
for arm in ['direct','tool']:
 a=[x for x in rows if x['arm']==arm];q=[x for x in joined if x['arm']==arm];counts=dict(collections.Counter(x['quality'] for x in q));n=counts.get('satisfies',0);elapsed=sum(x['elapsed_seconds'] for x in a)
 stats[arm]=dict(attempts=len(a),quality=counts,actual_evidence_task_pass=n,submitted=sum(x['submitted'] for x in a),termination=dict(collections.Counter(x['termination'] for x in a)),mutations=sum(not x['workspace_unchanged'] for x in a),generation_calls=sum(x['generation_calls'] for x in a),tool_calls=sum(x['tool_calls'] for x in a),complete_reads=sum(x['complete_target_reads'] for x in a),protocol_errors=sum(bool(x['protocol_error']) for x in a),infrastructure_errors=sum(bool(x['infrastructure_error']) for x in a),false_completion=sum(x['false_completion'] for x in q),input_tokens_full_context=sum(x['input_tokens'] for x in a),output_tokens_raw=sum(x['output_tokens'] for x in a),client_task_seconds_total=elapsed,client_seconds_per_qualified_including_failed=elapsed/n if n else None,monetary_cost_per_qualified=None,monetary_cost_reason='Self-hosted tariff and actual GPU resource attribution unavailable; not zero. No new paid API, training or strong-model call.',repeats={str(i):sum(x['quality']=='satisfies' for x in q if x['repeat']==i) for i in [1,2]},frozen_mechanical_pass=sum(x['engineering_invariants'] for x in a),gate_reached=False)
save(D/'TASK_RESULTS.json',{'tasks':joined,'arms':stats,'project_strict':None,'assistance':'all RWKV independent; strong calls0','old_results_rescored':False,'automatic_gate_status':'NOT_REACHED; direct frozen matcher has known JSON-escaping false negatives. Original audit retained, structural supplement separately recorded.'})
validation={'environment':'uv sync --frozen --extra selector-runtime --extra benchmark-web --group dev; playwright install chromium completed','full_tests':{'passed':1514,'skipped':0,'seconds':233.39,'log':'PYTEST_FULL.log','log_sha256':sha(D/'PYTEST_FULL.log')},'first_full_test_failure':{'passed':1512,'failed':2,'log':'PYTEST_FULL_INTERFERENCE.log','cause':'Concurrent pytest invocations shared configured data/test_runs/pytest basetemp; directory cleanup interfered with SQLite files. Rerun exclusively passed without production change; later temp tests use separate basetemp.'},'runner_regressions':{'old_out_of_scope_baseline':'1 failed (lawful directory-read-final rejected)','budget_candidate':'1 failed (initialized snapshot after budget)','candidate_final':'4 passed','production_changed':False},'supplemental_envelope_regression':{'red':'1 failed,1 passed','green':'2 passed','scope':'Supplemental checker only; original frozen checker and classifications preserved.'},'source_pin_count':len(reg['source_pins']),'source_pins_unchanged':True,'preexisting_five_unchanged':True,'reading_regression':'R4/R5 original primary21/21 and independent3/3 retained as historical same-production evidence; not newly rerun or pooled. Production unchanged, full offline suite including R4 parameter tests passed.','new_generations':sum(x['generation_calls'] for x in rows),'datasets_created':False,'training':False,'github_updates':False}
save(D/'VALIDATION.json',validation)
table='\n'.join(f"| {c} | "+' | '.join('/'.join('满足' if next(x for x in joined if x['case']==c and x['arm']==arm and x['repeat']==i)['quality']=='satisfies' else '部分满足' for i in [1,2]) for arm in ['direct','tool'])+' |' for c in ['full_text-1','full_text-2','full_code-1','full_code-2'])
report=f'''# P0/P1 实现与真实诊断：单文件读取、理解、总结

轮次：{D.name}。按 owner 最新“继续实现修订计划”执行；依据修订提交16ff27a8。仍为单文件任务，没有搜索定位任务、修改任务、强模型调用、Coordinator、训练或并发；未更新GitHub。生产代码没有改动，原五个未提交文件SHA保持一致。

## 任务结果优先

16/16自主读取完整指定文件并提交原始总结，mutation 0，终止原因全部final_answer。没有非法参数、重复调用循环、无总结终止或错误宣称实施/测试完成。所有任务为RWKV独立执行。

按提前冻结的摘要口径与原始证据，直供组4/8满足、4/8部分满足；工具组6/8满足、2/8部分满足。无“不满足”或“无结果”。这是任务级诊断，不是项目Strict；不与历史R5严格覆盖0/8重算或相减为修复收益。重要但可省略的信息逐项记录，缺少它们不把主旨正确的摘要归零。

| 原用例/文件 | 直供：第一/第二遍 | 工具：第一/第二遍 |
|---|---|---|
{table}

full_text-1为预约README，full_text-2为库存README，full_code-1为server.py，full_code-2为verify_public.py。语义评审的每项覆盖、遗漏、原回答引文与不实补充依据见SEMANTIC_REVIEW.json；匿名输入与映射分别保存。单一Codex评审，评审包隐藏臂/路径/调用，但评审者有先前调度上下文，不能冒称严格双盲或多人共识。

**两组都未达到连续两遍4/4的门槛。** 不升级能力范围，不称固定组普遍稳定，也不把局部错误称为模型完全不会总结。

## 实際对照及结论边界

直供8/8仍自主调用read_file一次；工具8/8同样读取一次。没有程序强制先读/强制Final，也没有为直供臂删除工具。按分配臂保留全部样本，不替换重读样本。

因此，实际比较是“原目标附全文、随后仍自主读取”与“原目标仅路径、随后自主读取”。直供组并非纯粹的一次全文总结；它在同一Agent协议内多了一份早期全文。两组共有19工具、R4说明、生产输入builder和后续真实观察；实际request及工作目录身份必然不同，内容/任务要求相同。该比较不能单独归因State、菜单、元数据、输入长度或能力上限。4文件2遍、无固定seed的2题差距不证明工具架构优于直供，也不支持删补偿即可提升质量。

可复核的问题：server.py四份摘要都没说明--db只解析未使用；部分提到了健康接口与其他GET未实现，却没有完整表达初始骨架性质。还有局部无依据内容：threading导入、将查询UTF-8名称泛化为UTF-8路径参数、将一般失败写入映射400；main函数一处是主程序块的结构名称不准确。它们与正确的信息分别保留，不作全有全无描述。预约短摘要允许用同资源有效预约冲突和取消后时段可复用概括时段约束；部分错误码罗列不自动推断为“仅允许这些码”。这些边界判定均有记录，便于复审。

## 读取、输入及State证据

32次generation的完整输入token与父链重建逐个相符，16次工具全文及exact_spans完整，16次观察各追加一次，下一次调用接在该child上。16个独立root，64个checkpoint的模型、tokenizer、服务、zero profile及父State摘要由补充身份核查确认。无正常链路观察遗漏/重复或错误State续接证据；不据此证明未触发的cache失效恢复或数值张量全面正确。

原始wire调用、默认正规化后的调用、真实工具结果、事件、State快照、逐次input_NN.txt、raw输出、精确token数组、协议/运输事件都保存在runs/及RAW_EVIDENCE.tar.gz。model_trace.jsonl为原生产审计输出。

### 冻结自动核验器的误报单独保留

冻结检查器对直供输入错误使用`source in root.transcript`：生产User消息内全文是JSON字符串，换行被转义，不能按未转义多行子串判断缺失。原MECHANICAL_AUDIT.json保留直供0/8、工具8/8的自动机械判定；这不是RWKV读取失败。PRELIMINARY_FROZEN_AUDIT.json保留首次发现记录。

补充核查只解码真实生产User消息，并用create_literal_goal的既有request正规化核对immutable_request。真实输入正例/错误request负例：先1 failed、1 passed，再2 passed。SUPPLEMENTAL_INPUT_IDENTITY_CHECK.json确认16/16实际请求和身份正确。未修改冻结检查器、生产源码、模型输入或语义评分，未用补充检查覆盖旧判，也未将它登记为本轮“完整自动门已通过”。下一轮正式冻结应使用已验证的结构化检查器。任务表描述的是语义与实际证据，原自动门保留独立，不能拿误报压成能力0分或把修订当模型收益。

## 调用与资源诊断

| 项目 | 直供8题 | 工具8题 |
|---|---:|---:|
| generation / 读取 | 16 / 8 | 16 / 8 |
| 完整上下文输入token总和 | {stats['direct']['input_tokens_full_context']} | {stats['tool']['input_tokens_full_context']} |
| 原始输出token总和 | {stats['direct']['output_tokens_raw']} | {stats['tool']['output_tokens_raw']} |
| 客户端各任务用时合计秒 | {stats['direct']['client_task_seconds_total']:.2f} | {stats['tool']['client_task_seconds_total']:.2f} |
| 含失败摊销的每合格任务客户端秒 | {stats['direct']['client_seconds_per_qualified_including_failed']:.2f} | {stats['tool']['client_seconds_per_qualified_including_failed']:.2f} |
| 每合格任务货币成本 / 实测GPU峰值 | NA / NA | NA / NA |

完整输入token不是实际重复prefill，不按它推算GPU消耗或费用；客户端时间也不是GPU计算时间。总32次生成、143229完整输入token、7163输出token，预算内；原任务耗时包含真实读取和State运输。自托管费率/设备遥测缺失，货币成本不填0。不新增付费API/租用资源，强模型调用0。此处不宣称项目成本或吞吐收益。

## 本轮实际实现与回归

1. 临时诊断运行器复用唯一生产create_literal_goal/_assignment/render_bootstrap、next_command、Harness执行和观察追加。它不是新生产Controller，也不手写角色协议。依R4/R5获准工作区拷贝原始短文件，未建datasets版本。
2. 旧R5运行器会拒绝合法list_directory→read→final；原运行器回归先失败。本轮按统一只读权限执行合法工具，原回答逐字保留，不替模型选路径；最终4项离线回归通过。
3. 候选的预算终止快照还停在initialized，失败回归后改为持久化interrupted；不追加生成。失败候选源码及红/绿日志保留。这些修改只在实验运行器，未改变生产代码。
4. 全套1514 passed、0 skipped，233.39秒，含Torch/State/必需浏览器检查。第一次全套2失败/1512通过，是同时启动的pytest共用basetemp导致SQLite临时文件访问干扰；原日志保留，独占重跑不改生产代码即全绿。后续临时回归显式隔离basetemp。
5. 原读取回归主组21/21、独立补充3/3仅引用R4/R5同生产源码历史结果，没有本轮重采、合并或冒充新收益；本轮新读取16/16以及全套参数合同测试单列。生产变更时仍需原组真实重跑。

REGISTRATION SHA-256：{sha(D/'REGISTRATION.json')}。源码冻结{len(reg['source_pins'])}文件；运行前后SHA一致。SERVER_IDENTITY记录132项目文件、6393 engine文件逐一核验，无远端Git。冻结包、原始trace包和SHA256SUMS提供复核身份。

## 下一步，按证据而不是固定阶段门

优先把结构化输入检查用于下一次冻结，并保留这次错误候选。质量口径已可表达好摘要、关键遗漏和局部不实，无需调整隐藏评分去迎合回答。

模型侧不立刻改菜单/State或增加角色。当前实际两组均经过读取且共同遗漏--db未使用，下一最小诊断可按修订计划另轮登记纯文本摘要参照：相同四文件、任务、模型、采样、输出预算及原子评分，明确它与生产Agent封装协议不同，仅用于定位，不替代生产入口。它可帮助判断共同Agent封装与内容理解的边界；不先认定其中任何一个是根因。任何候选提示/封装修改另冻结两臂并保留失败，不重评分本轮。

这四份server.py遗漏已提供可复现困难，后续P7强模型建议验证不必等P6多文件通过，但须先实现并冻结等待写权限、唯一执行者、建议/接管归属与交还State回归。独立只读并发则从已合格子集及State隔离证据另冻结同质量性能对照，不把本组有未达门任务直接宣布整体并发可用。本轮不启动这些新实验。
'''
assert not (D/'REPORT.zh-CN.md').exists();(D/'REPORT.zh-CN.md').write_text(report)
with tarfile.open(D/'RAW_EVIDENCE.tar.gz','w:gz') as t:t.add(D/'runs',arcname='runs')
with tarfile.open(D/'ANALYSIS_SCRIPTS.tar.gz','w:gz') as t:
 for p in sorted((R/'temp').glob('*pathway*r1_20260912.py')):t.add(p,arcname=str(p.relative_to(R)))
manifest={str(p.relative_to(D)):sha(p) for p in sorted(D.rglob('*')) if p.is_file() and p.name!='SHA256SUMS.json'};save(D/'SHA256SUMS.json',manifest)
h=R/'docs/HANDOFF.zh-CN.md';old=h.read_text();entry=f'''# 当前进展：P0/P1单文件摘要路径对照已执行（2026-09-12）

- 轮次：`{D.name}`。先按owner提交16ff27a8复核交接与依赖修订，再执行本轮最小验证。生产源码与原五个未提交修改保持不变；无GitHub更新、训练、新datasets、强模型或并发。
- 任务结果：16/16完整读取并自主提交；mutation0，全部final_answer自然终止。直供语义满足4/8、部分4/8；工具满足6/8、部分2/8；非法参数/重复循环/无总结/虚假实施或测试声明0。非项目Strict，未重算旧R5 0/8为收益。
- 两遍分别直供2/4、2/4，工具3/4、3/4，均未达稳定门。直供8/8仍自主重读，不能把它当纯文本摘要对照；四份server.py摘要均遗漏db只解析未使用。少量差距不选架构赢家。
- 32份实际输入token及16次观察child交接相符；补充结构核查16任务、64State身份正确。冻结自动检查对直供JSON转义全文做原文子串匹配而误报，原判完整保留；补充检查先红后绿，不覆盖旧判、不称完整自动门通过。
- 验证：1514 passed/0 skipped；运行器4项通过；补充输入核验2项通过。第一次全测2个SQLite临时目录干扰失败保留，独占重跑全绿。原读取21/21+独立3/3仅作为历史同源码证据，本轮新读取16/16另报。
- 下一步：结构化核验器用于下一轮冻结；可优先另登记同四文件的纯文本摘要诊断参照以定位共同Agent封装，不先重构。强模型帮助可在已复现困难与交接回归就绪后单独验证，无需等多文件；独立只读并发亦按各自质量/隔离前置证据，非固定阶段门。本轮不自动升级。
- 报告：`data/experiments/{D.name}/REPORT.zh-CN.md`，SHA-256 `{sha(D/'REPORT.zh-CN.md')}`。登记SHA `{sha(D/'REGISTRATION.json')}`；完整原轨迹、评分和源码包在该目录。

---

''';h.write_text(entry+old)
print(json.dumps({'report_sha256':sha(D/'REPORT.zh-CN.md'),'sealed_files':len(manifest),'arms':stats},ensure_ascii=False,indent=2))
