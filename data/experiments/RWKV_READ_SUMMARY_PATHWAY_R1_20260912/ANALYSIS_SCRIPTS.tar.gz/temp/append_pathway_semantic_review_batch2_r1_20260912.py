from pathlib import Path
import json
D=Path('/home/chase/GitHub/RWKV-LH/data/experiments/RWKV_READ_SUMMARY_PATHWAY_R1_20260912');p=D/'SEMANTIC_REVIEW.json';rows=json.loads(p.read_text())
new={
'4f69c4190f':('satisfies',[],[('purpose','covered','小型仓库的 SQLite HTTP 订单服务；服务要求/环境说明语境未声称实现和测试已完成'),('idempotency','covered','相同规范化请求返回同一订单，不再次扣库存'),('atomic','covered','失败应整体无写入；库存判定、扣减和订单/idempotency登记必须原子完成'),('normalization','covered','同SKU重复项求和排序；同key不同customer/明细返回409'),('failure_key','covered','不占用key，允许更正请求重试'),('concurrency','covered','并发不同key不得超卖'),('persistence','covered','进程重启后继续有效'),('verification','covered','公开验证只做健康检查')]),
'c5ffbb2f49':('partial',[{'quote':'支持 UTF-8 路径参数','kind':'localized_unsupported','evidence':'原文要求?resource=...查询过滤时UTF-8名称保持原样；未规定UTF-8路径参数这一能力。','impact':'将查询参数/名称扩大为路径参数，局部接口事实不忠实；其余主旨和约束覆盖充分。'}],[('purpose','covered','用于内部会议室与设备的预约管理'),('conflict','covered','同resource的confirmed预约不能重叠'),('cancel','covered','取消后时段可被重新预约'),('failure','covered','失败不得改变任何预约'),('atomic','covered','冲突判定与写入必须为同一原子操作'),('persistence','covered','重启后数据和冲突规则必须继续正确'),('verification','covered','不能以健康检查替代完整功能')])}
for key,(quality,issues,facts) in new.items():
 assert key not in {x['anonymous_id'] for x in rows};rows.append(dict(anonymous_id=key,quality=quality,fact_assessments=[dict(id=i,coverage=c,evidence_or_reason=e) for i,c,e in facts],factual_issues=issues,false_completion=False,false_completion_reason='未声称实施变更或测试通过；提交及遗漏不算虚假完成。',reviewer='single Codex reviewer; anonymous output packet, prior orchestration context known',rubric_changed=False))
p.write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
