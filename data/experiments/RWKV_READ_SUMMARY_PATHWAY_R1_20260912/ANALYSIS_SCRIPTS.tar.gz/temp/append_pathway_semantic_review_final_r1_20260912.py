from pathlib import Path
import json
D=Path('/home/chase/GitHub/RWKV-LH/data/experiments/RWKV_READ_SUMMARY_PATHWAY_R1_20260912');p=D/'SEMANTIC_REVIEW.json';rows=json.loads(p.read_text());key='570e31e1aa';assert key not in {x['anonymous_id'] for x in rows}
rows.append(dict(anonymous_id=key,quality='satisfies',fact_assessments=[dict(id='purpose',coverage='covered',evidence_or_reason='不验证booking/order行为，仅作为健康检查'),dict(id='assertions',coverage='covered',evidence_or_reason='GET /health，200且ok为true后输出成功提示'),dict(id='cli',coverage='covered',evidence_or_reason='HOST和PORT两个命令行参数')],factual_issues=[],false_completion=False,false_completion_reason='条件式描述脚本行为，不是声称已替用户运行测试。',reviewer='single Codex reviewer; anonymous output packet, prior orchestration context known',rubric_changed=False))
p.write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
