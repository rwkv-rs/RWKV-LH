import sys
a=list(map(int,sys.stdin.buffer.read().split())); n=a[0]; a=a[1:]; best=1<<60
def visit(i,done,current):
    global best
    if i==n:
        best=min(best,done^current); return
    visit(i+1,done,current|a[i])
    visit(i+1,done^current,a[i])
visit(1,0,a[0]); print(best)
