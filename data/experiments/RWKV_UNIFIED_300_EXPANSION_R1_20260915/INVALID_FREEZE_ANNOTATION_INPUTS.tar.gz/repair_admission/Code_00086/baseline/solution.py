import sys

def solve() -> None:
    data = sys.stdin.read().strip().split()
    if not data:
        return
    n = int(data[0])
    a = list(map(int, data[1:1 + n]))

    # dp[i] = minimal XOR achievable for prefix a[0:i] (i elements)
    dp = [0] * (n + 1)
    dp[0] = 0

    for i in range(1, n + 1):
        best = None
        # try every possible last interval [j, i-1]
        for j in range(i):
            or_val = 0
            for k in range(j, i):
                or_val |= a[k]
            cand = dp[j] ^ or_val
            if best is None or cand < best:
                best = cand
        dp[i] = best

    print(dp[n])

if __name__ == "__main__":
    solve()
