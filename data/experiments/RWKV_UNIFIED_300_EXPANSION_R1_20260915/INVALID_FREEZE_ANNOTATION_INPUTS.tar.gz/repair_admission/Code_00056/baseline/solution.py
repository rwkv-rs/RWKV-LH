import sys

def main():
    data = sys.stdin.read().strip().split()
    if not data:
        return
    n = int(data[0])
    a = list(map(int, data[1:1+n]))
    a.sort(reverse=True)
    ans = 0
    for i in range(n):
        ans += a[i] * abs(i - (n - 1 - i))
    print(ans)

if __name__ == "__main__":
    main()
