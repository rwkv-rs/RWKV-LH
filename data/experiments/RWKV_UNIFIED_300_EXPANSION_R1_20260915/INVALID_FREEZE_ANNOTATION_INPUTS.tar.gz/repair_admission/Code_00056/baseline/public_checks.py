import json, subprocess, sys
CASES = [('4\n1 3 4 2\n', '20\n'), ('6\n5 5 6 1 1 1\n', '58\n')]
results = []
for i, (stdin, expected) in enumerate(CASES, 1):
    run = subprocess.run([sys.executable, 'solution.py'], input=stdin, text=True, capture_output=True, timeout=10)
    results.append({'case': i, 'exit_code': run.returncode, 'stdout': run.stdout, 'stderr': run.stderr, 'passed': run.returncode == 0 and run.stdout.rstrip() == expected.rstrip()})
print(json.dumps({'checks': results, 'passed': all(r['passed'] for r in results)}, ensure_ascii=False))
sys.exit(0 if all(r['passed'] for r in results) else 1)
