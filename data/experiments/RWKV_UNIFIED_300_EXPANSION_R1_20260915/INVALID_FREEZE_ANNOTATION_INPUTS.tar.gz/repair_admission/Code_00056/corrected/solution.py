import sys
a = list(map(int, sys.stdin.buffer.read().split())); n = a[0]
items = sorted(((v,i) for i,v in enumerate(a[1:])), reverse=True)
dp = [0]
for used,(v,pos) in enumerate(items):
    nd = [-1]*(used+2)
    for left, old in enumerate(dp):
        right = used-left
        nd[left+1] = max(nd[left+1], old+v*abs(pos-left))
        nd[left] = max(nd[left], old+v*abs(pos-(n-1-right)))
    dp = nd
print(max(dp))
