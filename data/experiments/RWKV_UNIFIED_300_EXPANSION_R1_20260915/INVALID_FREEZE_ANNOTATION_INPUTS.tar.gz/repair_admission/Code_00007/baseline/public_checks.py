import json, subprocess, sys
CASES = [('QWERTYASDFZXCV\n', '5\n'), ('ZABCZ\n', '4\n'), ('HASFJGHOGAKZZFEGA\n', '12\n')]
results = []
for i, (stdin, expected) in enumerate(CASES, 1):
    run = subprocess.run([sys.executable, 'solution.py'], input=stdin, text=True, capture_output=True, timeout=10)
    results.append({'case': i, 'exit_code': run.returncode, 'stdout': run.stdout, 'stderr': run.stderr, 'passed': run.returncode == 0 and run.stdout.rstrip() == expected.rstrip()})
print(json.dumps({'checks': results, 'passed': all(r['passed'] for r in results)}, ensure_ascii=False))
sys.exit(0 if all(r['passed'] for r in results) else 1)
