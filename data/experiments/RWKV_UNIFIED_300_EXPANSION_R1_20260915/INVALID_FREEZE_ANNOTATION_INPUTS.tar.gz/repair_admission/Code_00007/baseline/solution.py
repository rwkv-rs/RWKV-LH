import sys

def main():
    s = sys.stdin.readline().rstrip('\n')
    n = len(s)
    if n == 0:
        print(0)
        return

    first_a = -1
    last_z = -1
    for i, ch in enumerate(s):
        if ch == 'A':
            first_a = i
        if ch == 'Z':
            last_z = i

    if first_a == -1 or last_z == -1 or last_z < first_a:
        print(0)
        return

    print(last_z - first_a + 1)

if __name__ == '__main__':
    main()
