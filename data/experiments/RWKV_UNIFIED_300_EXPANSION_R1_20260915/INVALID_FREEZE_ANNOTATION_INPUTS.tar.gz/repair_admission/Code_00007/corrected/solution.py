import sys

s = sys.stdin.readline().strip()
print(s.rfind('Z') - s.find('A') + 1)
