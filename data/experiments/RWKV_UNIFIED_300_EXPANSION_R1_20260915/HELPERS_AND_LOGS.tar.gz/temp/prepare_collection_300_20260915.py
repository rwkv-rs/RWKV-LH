from pathlib import Path
import json,hashlib,shutil
R=Path('/home/chase/GitHub/RWKV-LH');E=R/'data/experiments/RWKV_UNIFIED_300_EXPANSION_R1_20260915';D=R/'data/experiments/RWKV_COLLECTION_300_R1_20260915';D.mkdir(exist_ok=False)
reg=json.loads((R/'data/experiments/RWKV_FEEDBACK_COLLECTION_150_R1_20260915/REGISTRATION.json').read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
samples={1:('3 2\n2 2\n2 2\n','12\n'),2:('5\n','Takahashi\n'),6:('WBWBWWBWBWBWWBWBWWBW\n','Do\n'),28:('2 3\n','3\n'),30:('3 2\n','2\n'),31:('5\n0 2 5 1 0\n','3\n'),34:('5 4\n1 2 1\n1 3 1\n1 4 1\n1 5 1\n','-1\n'),35:('9 3\n0001000100\n','1 3 2 3\n'),37:('abcabab\nab\n','3\n'),38:('3 1\n3 1 4\n5 3 2\n','1\n'),39:('3\n1 2\n2 3\n1\n1 3\n','3\n'),47:('4 1\n2 3 4 1\n','3\n'),49:('2\n5 3\n','1\n'),50:('3\n2 3 1\n','5\n'),52:('3 2 1\n1 2 1 2\n1 3 2 4\n1 11\n1 2\n2 5\n','2\n14\n'),55:('3 9\n1 5 10\n','3\n'),61:('5 3\n10 14 19 34 33\n','202\n'),62:('1 6 4\n1 1 1 6\n......\n','2\n'),67:('2\n0 0 0\n1 2 3\n','9\n'),73:('3\n1 2 1\n1 2\n2 3\n','5\n4\n0\n'),74:('5\n1 3\n2 2\n3 2\n4 1\n4 3\n','1 2 7\n'),75:('2\nBB\nBW\n','2\n'),79:('101\n2\n','2\n'),80:('3 2\n','5\n'),91:('4 3\n1 4\n2 4\n3 4\n3\n1 2 3\n','5\n')}
assert len(samples)==25
cases=[]
for n,pair in samples.items():
 ident=f'Code_{n:05d}';source=E/'admission'/ident/'corrected'
 assert source.is_dir(),ident
 name=ident+'-check';work=D/'tasks'/name;work.mkdir(parents=True)
 for f in ('solution.py','TASK.md'):shutil.copyfile(source/f,work/f)
 # Public sample transcribed from source TASK, never inferred from private checks.
 code="import json,subprocess,sys\nstdin,expected="+repr(pair)+"\nr=subprocess.run([sys.executable,'solution.py'],input=stdin,text=True,capture_output=True,timeout=10)\npassed=r.returncode==0 and r.stdout.rstrip()==expected.rstrip()\nprint(json.dumps({'checks':[{'case':1,'exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'passed':passed}],'passed':passed},ensure_ascii=False))\nsys.exit(0 if passed else 1)\n"
 (work/'public_checks.py').write_text(code)
 cases.append({'id':name,'kind':'public_check','workspace':str(work),'task_sha256':sha(work/'TASK.md'),'files':{p.name:sha(p) for p in work.iterdir()},'original_task_id':ident,'source_workspace':str(source),'request':reg['request'],'rubric':'Actual tool executed, faithful checker/child exit and observed stdout; no unsupported expected values or invented execution.'})
# Read and understand actual teacher-verified code; separate tasks, fresh State.
orig=R/'data/experiments/RWKV_CODEX_UNIFIED_DATA_FREEZE_R1_20260915/validation'
for source in sorted([*(E/'admission').glob('Code_*/corrected'),*orig.glob('Code_*/corrected')]):
 ident=source.parent.name;name=ident+'-understand';work=D/'tasks'/name;work.mkdir(parents=True)
 for f in ('solution.py','TASK.md'):shutil.copyfile(source/f,work/f)
 cases.append({'id':name,'kind':'code_understanding','workspace':str(work),'task_sha256':sha(work/'TASK.md'),'files':{p.name:sha(p) for p in work.iterdir()},'original_task_id':ident,'source_workspace':str(source),'request':'阅读工作区的 solution.py，简要说明这个程序如何处理输入、核心计算方法和输出。只依据代码说明，不把题目要求当作已经实现的行为，不声称运行过未执行的测试。无需修改文件或运行测试。','rubric':'Core input/computation/output behavior faithful to observed complete code; no invented implementation or tests; minor implementation details may be omitted.'})
assert len(cases)==75
reg.update(cases=cases,rejected=[],repeats=1,registered_before_run=True,change='25 new program checks plus50 code-understanding tasks from verified actual artifacts; not autonomous coding scores; each independent task zero State.',authorization_reference={'path':str(E/'AUTHORIZATION.zh-CN.md'),'sha256':sha(E/'AUTHORIZATION.zh-CN.md')})
reg['budget'].update(total_calls=900,overall_seconds=14400,strong_model_calls=0)
s=(R/'temp/run_feedback_collection_150_r1_20260915.py').read_text().replace('RWKV_FEEDBACK_COLLECTION_150_R1_20260915','RWKV_COLLECTION_300_R1_20260915').replace('29632','29633').replace('>=10800','>=14400').replace("CodingJob(case['id'],reg['request'],", "CodingJob(case['id'],case['request'],")
runner=R/'temp/run_collection_300_20260915.py';runner.write_text(s);reg['runner_sha256']=sha(runner)
(D/'REGISTRATION.json').write_text(json.dumps(reg,ensure_ascii=False,indent=2)+'\n')
s=(R/'temp/continue_feedback_collection_150_r1_20260915.py').read_text().replace('RWKV_FEEDBACK_COLLECTION_150_R1_20260915','RWKV_COLLECTION_300_R1_20260915').replace('rwkv-lh-feedback-150-r1.service','rwkv-lh-collection-300-r1.service').replace('feedback_150_r1','collection_300_r1').replace('18257','18258').replace('29632','29633').replace('run_feedback_collection_150_r1_20260915.py','run_collection_300_20260915.py')
(R/'temp/continue_collection_300_20260915.py').write_text(s)
print('registered',len(cases),'tasks')
