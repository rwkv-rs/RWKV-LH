from pathlib import Path
import json,hashlib,tarfile,collections
R=Path('/home/chase/GitHub/RWKV-LH');D=R/'data/experiments/RWKV_UNIFIED_300_EXPANSION_R1_20260915';V=R/'data/datasets/rwkv_direct_unified_corrections_v6';old=R/'data/datasets/rwkv_direct_unified_corrections_v5'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,x):(D/name).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
rows=[json.loads(l) for l in (V/'train.jsonl').read_text().splitlines()];prior=[json.loads(l) for l in (D/'invalid_v6_annotation_candidate/train.jsonl').read_text().splitlines()];fields=('input_text','target_text','input_token_ids','target_token_ids');assert len(rows)==len(prior)==300 and all(all(a[k]==b[k] for k in fields) for a,b in zip(rows,prior));assert (V/'train.jsonl').read_bytes().startswith((old/'train.jsonl').read_bytes());assert sha(V/'regression.json')==sha(old/'regression.json');digest=sha(V/'manifest.json')
p=D/'ANNOTATION_CORRECTION.json';x=json.loads(p.read_text());x.update(status='refrozen_correct_annotation',new_manifest_sha256=digest,all300_training_input_target_bytes_and_tokens_unchanged=True);save(p.name,x)
p=D/'REPORT.zh-CN.md';s=p.read_text().replace(x['old_manifest_sha256'],digest);s=s.replace('## 下一阶段','最终源码复核还发现Code7教师归因注释把“循环不断覆盖first_a，得到最后一个A”误写为Z的问题。原训练修复代码正确且已通过测试；未提交的首次v6候选及证明均保留并标注INVALID，修正归因、重新验证和冻结后，300条模型输入/目标文本及token逐条完全不变。见 `ANNOTATION_CORRECTION.json`。\n\n## 下一阶段');p.write_text(s)
for name in ('SOURCE_IDENTITY.json','FINAL_CHECKS.json'):
 x=json.loads((D/name).read_text());key='dataset_manifest_sha256' if name=='SOURCE_IDENTITY.json' else 'final_manifest_sha256';x[key]=digest;save(name,x)
x=json.loads((D/'COVERAGE_AND_DEDUP.json').read_text());tok=collections.Counter();inc=collections.Counter()
for r in rows:
 op=json.loads(r['target_text'].rsplit('\n```',1)[0])['function'];tok[op]+=len(r['target_token_ids']);inc[op]+=len(r['input_token_ids'])
x.update(target_tokens_by_operation=dict(tok),input_tokens_by_operation=dict(inc),weight_note='Sample frequency and target-token mass are different; freeze trainer loss normalization and sampling weights together.');save('COVERAGE_AND_DEDUP.json',x)
x=json.loads((D/'PROGRESS.json').read_text());x.update(phase='data_phase_complete',formal_rows=300,remaining=[],training_steps=0);save('PROGRESS.json',x)
# Refresh helper archive after final generator changes, with no active redirected output file.
helpers=sorted(p for p in (R/'temp').glob('*300*20260915*') if p.is_file());helperhash={str(p.relative_to(R)):sha(p) for p in helpers}
with tarfile.open(D/'HELPERS_AND_LOGS.tar.gz','w:gz') as tar:
 for p in helpers:tar.add(p,arcname=str(p.relative_to(R)))
save('HELPER_MANIFEST.json',{'files':helperhash,'archive_sha256':sha(D/'HELPERS_AND_LOGS.tar.gz')})
# Recheck frozen dataset files and every source identity already used in admission.
m=json.loads((V/'manifest.json').read_text());assert m['counts']=={'train':300,'dev':4,'confirmation':4}
for source in m['sources']:
 ref=source['manifest'];assert sha(Path(ref['path']))==ref['sha256'];source_manifest=json.loads(Path(ref['path']).read_text());root=Path(source['run_root'])
 for path,d in source_manifest['files'].items():assert sha(root/path)==d,(source['source_id'],path)
reg=json.loads((D/'REGISTRATION.json').read_text());assert all(sha(R/p)==h for p,h in reg['owner_file_sha256'].items());assert '1833 passed' in (D/'FULL_TESTS.log').read_text()
for rel,d in json.loads((D/'RAW_MANIFEST.json').read_text())['files'].items():assert sha(R/rel)==d,rel
allhash={str(p.relative_to(R)):sha(p) for base in (D,V) for p in base.rglob('*') if p.is_file() and p.name!='SHA256.json'}
allhash.update({str(p.relative_to(R)):sha(p) for p in (R/'docs/HANDOFF.zh-CN.md',R/'docs/STATETUNE_10000_PLAN.zh-CN.md')});save('SHA256.json',{'files':allhash,'report_sha256':sha(D/'REPORT.zh-CN.md'),'dataset_manifest_sha256':digest})
print('FINAL300',digest,'checked_files',len(allhash),'report_sha256',sha(D/'REPORT.zh-CN.md'))
