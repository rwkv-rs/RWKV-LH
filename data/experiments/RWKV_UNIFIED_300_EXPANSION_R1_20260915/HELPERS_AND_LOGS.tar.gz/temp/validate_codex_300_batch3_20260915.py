from pathlib import Path
import sys,json,hashlib,shutil
R=Path('/home/chase/GitHub/RWKV-LH');sys.path.insert(0,str(R))
from rwkv_lh.direct_trace_data import replay_run
from rwkv_lh.correction_snapshots import validate_generation_snapshot
from rwkv_lh.model_io import parse_model_command,JSON_CALL_STOP_SUFFIXES
from rwkv_lh.harness import ActionHarness
from rwkv_lh.schema import GoalState,TaskAction
from rwkv_lh.stdio_verifier import verify_python_submission
D=R/'data/experiments/RWKV_UNIFIED_300_EXPANSION_R1_20260915/batch3';P=R/'data/experiments/RWKV_ULTRADATA_COLLECTION_R3_20260915';reg=json.loads((P/'REGISTRATION.json').read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
save(D/'REGISTRATION.json',{'source_registration_sha256':sha(P/'REGISTRATION.json'),'teacher_manifest_sha256':sha(D/'TEACHER_TARGETS.json'),'validator_sha256':sha(Path(__file__)),'scope':'First original generation after a successful complete TASK.md observation; teacher supplies one independently authored write, existing unique input rebuilt, snapshot validated, baseline and corrected checked through original private stdio suite. No teacher answer from private checks, no old scores changed.','target_policy':'Targets frozen before external checks; failures retained; no automatic fix or second target from test output','training_admitted':False})
records=[]
for target in json.loads((D/'TEACHER_TARGETS.json').read_text()):
 name=target['id'];root=P/'runs'/(name+'-r1')/'execution';out=D/'validation'/name
 try:
  result=json.loads((root/'RESULT.json').read_text());actuals=replay_run(root,reg['model_sha256']);calls=list(actuals.items());indices={x['request_id']:i for i,(cp,x) in enumerate(calls)};case=next(c for c in reg['cases'] if c['id']==name)
  complete=next(a for a in result['actions'] if a['action_type']=='read_file' and a['result']['success'] and a['result']['output'].encode()==(Path(case['workspace'])/'TASK.md').read_bytes())
  cp,actual=calls[indices[complete['request_id']]+1];sealed={str(p.relative_to(root)):sha(p) for p in root.rglob('*') if p.is_file()};before=validate_generation_snapshot(root,actual,sealed);assert complete['result']['output'] in actual['input_text'] or json.dumps(complete['result']['output'],ensure_ascii=False)[1:-1] in actual['input_text']
  code=Path(target['path']).read_text();assert sha(Path(target['path']))==target['sha256'];text=json.dumps({'function':'write_file','params':{'path':'solution.py','content':code}},ensure_ascii=False)+JSON_CALL_STOP_SUFFIXES[0];command=parse_model_command(text[:-len(JSON_CALL_STOP_SUFFIXES[0])]);save(out/'FROZEN_TARGET.json',{'target_text':text,'teacher':target,'input_sha256':hashlib.sha256(actual['input_text'].encode()).hexdigest()});save(out/'SOURCE_FILES.json',sealed);save(out/'ACTUAL_INPUT.json',actual)
  shutil.copytree(before,out/'baseline');shutil.copytree(before,out/'corrected');checks=json.loads(Path(case['private_tests_path']).read_text());assert sha(Path(case['private_tests_path']))==case['private_tests_sha256'];baseline=verify_python_submission(out/'baseline',checks);save(out/'BASELINE.json',baseline);obs=ActionHarness().execute(TaskAction(command.name,command.arguments),GoalState.create(request=reg['request'],workspace_root=str(out/'corrected'),constraints=[])).to_dict();save(out/'TOOL.json',obs);after=verify_python_submission(out/'corrected',checks);save(out/'AFTER.json',after)
  record={'id':name,'source_run':str(root),'checkpoint_id':cp,'request_id':actual['request_id'],'input_checkpoint_id':actual['input_checkpoint_id'],'input_sha256':hashlib.sha256(actual['input_text'].encode()).hexdigest(),'original_output':actual['raw_generation']['raw_output'],'target_text':text,'teacher':'current Codex assistant','baseline_pass':baseline['passed'],'after_pass':after['passed'],'test_count':len(after['cases']),'status':'execution_verified_candidate' if not baseline['passed'] and obs['success'] and after['passed'] else 'verification_failed','training_admitted':False,'source_snapshot':str(before.relative_to(root))}
 except Exception as e:
  record={'id':name,'status':'validation_error','error_type':type(e).__name__,'error':str(e),'training_admitted':False}
 save(out/'CANDIDATE.json',record);records.append(record);save(D/'RESULTS.json',records);print(name,record['status'],flush=True)
