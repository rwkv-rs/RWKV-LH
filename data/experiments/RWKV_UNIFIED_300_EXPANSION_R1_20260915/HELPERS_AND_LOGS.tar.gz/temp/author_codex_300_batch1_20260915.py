from pathlib import Path
import json,hashlib,textwrap
D=Path('/home/chase/GitHub/RWKV-LH/data/experiments/RWKV_UNIFIED_300_EXPANSION_R1_20260915/batch1');codes={}
codes[28]='''
from functools import lru_cache
L,R=map(int,input().split());mod=10**9+7
@lru_cache(None)
def f(bit,above,below,started):
    if bit<0:return int(started)
    lb=(L>>bit)&1;rb=(R>>bit)&1;ans=0
    for x,y in ((0,0),(0,1),(1,1)):
        if not started and x!=y:continue
        if not above and x<lb:continue
        if not below and y>rb:continue
        ans+=f(bit-1,above or x>lb,below or y<rb,started or x==1)
    return ans%mod
print(f(59,False,False,False))
'''
codes[30]='''
n,k=map(int,input().split());mod=10**9+7
if k%2:print(0);raise SystemExit
dp={(0,0):1}
for i in range(n):
    nd={}
    for (j,cost),v in dp.items():
        for h,mul in ((j+1,1),(j,2*j+1),(j-1,j*j)):
            c=cost+2*h
            if h<0 or h>n-i-1 or c>k:continue
            nd[h,c]=(nd.get((h,c),0)+v*mul)%mod
    dp=nd
print(dp.get((0,k),0))
'''
codes[31]='''
import sys
a=list(map(int,sys.stdin.buffer.read().split()));n=a[0]-1;s=a[1:];ans=0
for d in range(1,n):
    total=0
    for k in range(1,(n-1)//d):
        if n%d==0 and 2*k*d>=n:break
        total+=s[k*d]+s[n-k*d]
        ans=max(ans,total)
print(ans)
'''
codes[34]='''
import sys,heapq
a=iter(map(int,sys.stdin.buffer.read().split()));n,m=next(a),next(a);g=[[] for _ in range(n)];near=[]
for _ in range(m):
    u,v,w=next(a)-1,next(a)-1,next(a)
    if u==0:near.append((v,w))
    elif v==0:near.append((u,w))
    else:g[u].append((v,w));g[v].append((u,w))
inf=10**30;ans=inf
for i,(start,first) in enumerate(near):
    dist=[inf]*n;dist[start]=0;q=[(0,start)]
    while q:
        d,u=heapq.heappop(q)
        if d!=dist[u]:continue
        for v,w in g[u]:
            if d+w<dist[v]:dist[v]=d+w;heapq.heappush(q,(d+w,v))
    for v,w in near[i+1:]:ans=min(ans,first+dist[v]+w)
print(-1 if ans==inf else ans)
'''
codes[35]='''
n,m=map(int,input().split());s=input().strip();p=n;steps=[]
while p:
    q=max(0,p-m)
    while q<p and s[q]=='1':q+=1
    if q==p:print(-1);raise SystemExit
    steps.append(p-q);p=q
print(*reversed(steps))
'''
codes[37]='''
import math
s=input().strip();t=input().strip();n=len(s);m=len(t)
a=t+'#'+(s*((n+m+n-1)//n))[:n+m-1];z=[0]*len(a);l=r=0
for i in range(1,len(a)):
    if i<=r:z[i]=min(r-i+1,z[i-l])
    while i+z[i]<len(a) and a[z[i]]==a[i+z[i]]:z[i]+=1
    if i+z[i]-1>r:l,r=i,i+z[i]-1
ok=[z[m+1+i]>=m for i in range(n)];ans=0
for start in range(math.gcd(n,m)):
    cycle=[];p=start
    while True:
        cycle.append(ok[p]);p=(p+m)%n
        if p==start:break
    if all(cycle):print(-1);raise SystemExit
    run=0
    for v in cycle+cycle:
        run=run+1 if v else 0;ans=max(ans,run)
print(ans)
'''
codes[38]='''
import sys
a=iter(map(int,sys.stdin.buffer.read().split()));k,q=next(a),next(a);d=[next(a) for _ in range(k)];out=[]
for _ in range(q):
    n,x,m=next(a),next(a),next(a);whole,part=divmod(n-1,k);rem=[v%m for v in d]
    total=sum(rem)*whole+sum(rem[:part]);zeros=rem.count(0)*whole+rem[:part].count(0)
    out.append(str(n-1-zeros-(x%m+total)//m))
print('\n'.join(out))
'''
codes[67]='''
import sys
a=iter(map(int,sys.stdin.buffer.read().split()));n=next(a);p=[(next(a),next(a),next(a)) for _ in range(n)]
c=[[abs(x-u)+abs(y-v)+max(0,w-z) for u,v,w in p] for x,y,z in p];inf=10**30;size=1<<(n-1)
dp=[[inf]*n for _ in range(size)];dp[0][0]=0
for mask in range(size):
    remaining=(size-1)^mask
    for i,base in enumerate(dp[mask]):
        if base==inf:continue
        bits=remaining
        while bits:
            bit=bits&-bits;j=bit.bit_length();bits-=bit
            nxt=mask|bit;v=base+c[i][j]
            if v<dp[nxt][j]:dp[nxt][j]=v
print(min(dp[-1][i]+c[i][0] for i in range(1,n)))
'''
codes[79]='''
s=input().strip();k=int(input());mod=10**9+7;inv2=(mod+1)//2;ways=pow(2,s.count('?')*k,mod)
def difference(a,b):
    if '?' in (a,b):return ways*inv2%mod
    return ways if a!=b else 0
edges=sum(difference(a,b) for a,b in zip(s,s[1:]))*k
edges+=difference(s[-1],s[0])*(k-1)
ends=0 if len(s)*k==1 else difference(s[0],s[-1])
print((edges+ends)*inv2%mod)
'''
codes[80]='''
n,k=map(int,input().split());mod=10**9+7;hi=[];width=[];l=1
while l<=n:
    r=n//(n//l);hi.append(r);width.append(r-l+1);l=r+1
index={v:i for i,v in enumerate(hi)};dest=[index[n//v] for v in hi];dp=[1]*len(hi)
for _ in range(k-1):
    acc=0;pref=[]
    for v,w in zip(dp,width):acc=(acc+v*w)%mod;pref.append(acc)
    dp=[pref[j] for j in dest]
print(sum(v*w for v,w in zip(dp,width))%mod)
'''
codes[91]='''
import sys
from collections import deque
a=iter(map(int,sys.stdin.buffer.read().split()));n,m=next(a),next(a);g=[[] for _ in range(n)]
for _ in range(m):
    u,v=next(a)-1,next(a)-1;g[u].append(v);g[v].append(u)
k=next(a);c=[next(a)-1 for _ in range(k)];ds=[]
for s in c:
    d=[-1]*n;d[s]=0;q=deque([s])
    while q:
        u=q.popleft()
        for v in g[u]:
            if d[v]<0:d[v]=d[u]+1;q.append(v)
    if any(d[v]<0 for v in c):print(-1);raise SystemExit
    ds.append([d[v] for v in c])
inf=10**9;dp=[[inf]*k for _ in range(1<<k)]
for i in range(k):dp[1<<i][i]=1
for mask in range(1,1<<k):
    left=((1<<k)-1)^mask
    for i,v in enumerate(dp[mask]):
        if v==inf:continue
        bits=left
        while bits:
            b=bits&-bits;j=b.bit_length()-1;bits-=b
            nxt=mask|b;cost=v+ds[i][j]
            if cost<dp[nxt][j]:dp[nxt][j]=cost
print(min(dp[-1]))
'''
notes={28:'Subset bits with equal highest set bit; digit DP enforces L<=x and y<=R.',30:'Open unmatched row/column endpoints; 1,2j+1,j^2 transitions with 2*new_open displacement cost.',31:'Enumerate positive net stride and paired visited positions; prohibit collisions and nonpositive backward jump.',34:'Shortest path between distinct neighbors of home with home excluded.',35:'Reverse maximal legal jump yields lexicographically smallest shortest forward path.',37:'Linear Z matches and cyclic stride components; all-matching cycle means infinity.',38:'Reduce increments modulo m; subtract zero steps and wrap count.',67:'Directed triangle-inequality travel costs; subset DP visiting all cities and returning.',79:'Minimum interval flips equals ceil(adjacent changes/2); sum changes and endpoint parity over assignments.',80:'Group equal floor(N/x), weighted prefix DP per ending value.',91:'BFS special-pair distances then subset shortest visiting path, counting vertices.'}
D.mkdir(exist_ok=False);rows=[]
for num,code in codes.items():
    p=D/f'Code_{num:05d}'/'solution.py';p.parent.mkdir();p.write_text(textwrap.dedent(code).lstrip());rows.append({'id':f'Code_{num:05d}','path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'teacher':'current Codex assistant','visible_source_review':notes[num],'output_contract':'exact_unique','private_tests_seen_before_authoring':False})
(D/'TEACHER_TARGETS.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
print('authored',len(rows))
