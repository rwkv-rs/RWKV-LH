"""Reconstruct real inputs and check profile-bound State ancestry, without re-generation."""
from pathlib import Path
import sys,json,hashlib
R=Path('/home/chase/GitHub/RWKV-LH');S=R/'data/experiments/RWKV_ULTRADATA_CODE_PILOT_R2_20260915/source';sys.path.insert(0,str(S))
from rwkv_lh.model_io import render_event_append,render_bootstrap,parse_model_command
from rwkv_lh.schema import RunState
from rwkv_lh.model import LongHorizonModel
from rwkv_lh.model_session import ModelSession
from rwkv_lh.runtime.settings import RuntimeSettings
from rwkv_lh.harness import ActionHarness
from rwkv_lh.token_budget import tokenizer
P=R/'data/experiments/RWKV_UNIFIED_CORRECTION_TRAIN_R4_20260915';D=R/'data/experiments/RWKV_FAILURE_REPAIR_300_R1_20260915'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main(phase):
 reg=json.loads((D/'REGISTRATION.json').read_text());assert json.loads((D/'SOURCE_AFTER.json').read_text())['all_match'];assert all(sha(R/p)==h for p,h in reg['source_pins'].items());rows=[]
 for root in sorted((D/phase).iterdir()):
  if not root.is_dir():continue
  p=root/'execution';result=json.loads((p/'RESULT.json').read_text());s=RunState.from_dict(json.loads((p/'state_snapshot.json').read_text()));arm=root.name.rsplit('-',2)[1];profile={'id':reg['state_profile_id'],'sha256':reg['state_profile_sha256']}
  events=[json.loads(l) for l in (p/'model_trace.jsonl').read_text().splitlines()];gens={e['candidate_checkpoint_id']:e['raw_generation'] for e in events if e['type']=='model_session_generation_returned'};starts={e['request_id']:e for e in events if e['type']=='model_session_generation_started'}
  model=LongHorizonModel(ModelSession(client=object(),settings=RuntimeSettings(base_url='http://unused.invalid',api_key='',model='audit',tool_disclosure_mode='full')),harness=ActionHarness())
  initial_case=next(c for c in reg['cases'] if root.name.startswith(c['id']+'-'));assert s.goal.request==initial_case['request'];initial_source=Path(initial_case['workspace']);assert all(sha(initial_source/n)==h for n,h in initial_case['files'].items());initial=RunState(run_id=s.run_id,goal=model.create_literal_goal(s.goal.request,str(initial_source),constraints=s.goal.constraints,runtime_policy=s.goal.runtime_policy));bootstrap=render_bootstrap(model.direct_definitions(),model._assignment(initial,recent_limit=None));calls=[];consumed=set();answer_events=set();committed={e['candidate_id'] for e in events if e['type']=='model_session_candidate_committed'}
  for e in events:
   if e['type']!='model_session_generation_returned':continue
   raw=e['raw_generation'];start=starts[e['request_id']];assert raw['sampling']==reg['sampling'] and start['max_tokens']==reg['budget']['max_output_tokens'];cp=s.model_states[start['input_checkpoint_id']];chain=[];visited=set()
   while cp:
    assert cp.checkpoint_id not in visited;visited.add(cp.checkpoint_id);chain.append(cp);cp=s.model_states.get(cp.parent_checkpoint_id)
   assert chain[-1].transcript==bootstrap;ids=[];seen=set()
   for cp in reversed(chain):
    assert cp.state_profile_id==profile['id'] and cp.state_profile_sha256==profile['sha256'];assert cp.native_state_metadata['model_sha256']==reg['model_sha256']
    if cp.parent_checkpoint_id:assert cp.native_state_metadata['cache_binding']['parent_state_digest']==s.model_states[cp.parent_checkpoint_id].native_state_digest
    if cp.checkpoint_id in gens:ids.extend(gens[cp.checkpoint_id]['raw_token_ids'])
    else:
     if cp.parent_checkpoint_id:
      delta=set(cp.event_ids)-set(s.model_states[cp.parent_checkpoint_id].event_ids);assert len(delta)==1;eid=next(iter(delta));assert eid not in seen;seen.add(eid);assert render_event_append(s.model_events[eid],previous_transcript=s.model_states[cp.parent_checkpoint_id].transcript)==cp.transcript
     ids.extend(tokenizer().encode(cp.transcript))
   assert raw['prompt_token_ids']==[0]+ids and raw['input_bos_token_count']==1
   assert start['input_digest']==s.model_states[start['input_checkpoint_id']].native_state_digest
   text=tokenizer().decode(ids);(p/'actual_inputs').mkdir(exist_ok=True);(p/'actual_inputs'/f"{e['request_id']}.txt").write_text(text);consumed.update(seen)
   if raw.get('candidate_id') in committed and result['final'] is not None:
    try:command=parse_model_command(raw['raw_output'])
    except Exception:command=None
    if command is not None and command.name=='final_answer' and command.arguments['text']==result['final']:answer_events=set(seen)
   calls.append({'request_id':e['request_id'],'input_tokens':len(raw['prompt_token_ids']),'output_tokens':len(raw['raw_token_ids']),'input_sha256':hashlib.sha256(text.encode()).hexdigest(),'input_checkpoint':start['input_checkpoint_id'],'candidate_checkpoint':e['candidate_checkpoint_id'],'finish':raw['finish_reason'],'events':sorted(seen),'raw_output':raw['raw_output']})
  case=initial_case;source=Path(case['workspace']);assert all(sha(source/n)==h for n,h in case['files'].items());known={n:(source/n).read_bytes() for n in case['files']}
  observations=[]
  for action_index,action in enumerate(result['actions'],1):
   eid='EV-ACTION-'+action['action_id'];event=s.model_events.get(eid);item={'action_id':action['action_id'],'operation':action['action_type'],'success':action['result']['success'],'consumed':eid in consumed,'consumed_by_answer':eid in answer_events}
   call_index=next(i for i,c in enumerate(calls) if c['request_id']==action['request_id']);later=calls[call_index+1:]
   if later:assert eid in later[0]['events'],'next actual generation omitted tool observation'
   item['pending_at_terminal']=event is None
   if event is None:
    assert not later and result['final'] is None and result['termination'] in ('budget','error') and action['action_id']==result['actions'][-1]['action_id']
    item['projection_failed']=result['termination']=='error'
   if action['action_type']=='read_file' and action['result']['success']:
    file_path=Path(action['arguments']['path']);relative=str(file_path.relative_to(s.goal.workspace_root)) if file_path.is_absolute() else str(file_path);content=known[relative];chunk=action['result']['metadata']['chunk'];item['source_bytes_mismatch']=action['result']['output'].encode()!=content[chunk['byte_start']:chunk['byte_end']];item.update(path=action['arguments']['path'],byte_start=chunk['byte_start'],byte_end=chunk['byte_end'],file_bytes=len(content));item['complete_file']=chunk['byte_start']==0 and chunk['byte_end']==len(content)
    if event is not None:
     obs=event.payload['result']['observation'];assert obs['projection_complete'] and ''.join(span['content'] for span in obs['exact_spans'])==action['result']['output']
   call_dir=p/'tool_snapshots'/f'{action_index:03d}';recorded=json.loads((call_dir/'call.json').read_text());assert recorded['action_type']==action['action_type'] and recorded['arguments']==action['arguments']
   if (call_dir/'after').is_dir():known={str(f.relative_to(call_dir/'after')):f.read_bytes() for f in (call_dir/'after').rglob('*') if f.is_file()}
   observations.append(item)
  rows.append({'id':root.name,'arm':arm,'termination':result['termination'],'final':result['final'],'protocol_rejections':result['protocol_rejections'],'calls':calls,'observations':observations,'passed_mechanical_audit':all(not o.get('source_bytes_mismatch',False) and not o.get('projection_failed',False) for o in observations),'interpretation':'exact declared profile/input/parent lineage, not a new independent tensor equivalence measurement'})
 (D/phase/'MECHANICAL_AUDIT.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n');print(phase,len(rows),sum(len(r['calls']) for r in rows))
if __name__=='__main__':main(sys.argv[1])
