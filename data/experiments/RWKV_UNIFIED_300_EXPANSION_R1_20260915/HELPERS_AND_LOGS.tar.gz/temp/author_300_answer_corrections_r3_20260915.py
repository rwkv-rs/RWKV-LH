from pathlib import Path
import sys,json,hashlib
R=Path('/home/chase/GitHub/RWKV-LH');sys.path.insert(0,str(R))
from rwkv_lh.direct_trace_data import replay_run
from rwkv_lh.model_io import parse_model_command,JSON_CALL_STOP_SUFFIXES
D=R/'data/experiments/RWKV_300_ANSWER_CORRECTIONS_R3_20260915';D.mkdir(exist_ok=False);P=R/'data/experiments/RWKV_COLLECTION_300_R1_20260915';reg=json.loads((P/'REGISTRATION.json').read_text())
corrections={66: ('程序从标准输入读入 n、t 和后续整数，将这些整数按 n//2 分成两半。sums 从 [0] 开始，逐个元素扩展不超过 t 的子集和列表；这里没有去重。程序排序右半的子集和，对每个左半子集和 x，用二分查找选出不超过 t-x 的最大右半和，最终输出两者相加的最大值。这是合计不超过 t 的子集和搜索，不是要求每一半各自不超过 t 后任意相加。本次只阅读代码，没有运行测试。', '原回答虚构去重，开头约束表述不清，需明确合计<=t。'), 69: ('程序读入四个整数 h、w、a、b，使用位掩码表示 h×w 网格的占用情况，并以 lru_cache 缓存递归状态。每次选第一个空格：若还有 b，则放一个只覆盖该格的单格块；若还有 a，则在边界内且相邻格为空时，尝试向右或向下放一个双格块。覆盖全部格子后，只有 a、b 都耗尽才计为一种方案。最后输出从空网格开始的方案总数。输入没有给出逐格的网格内容。本次没有运行测试。', '原回答将单格块说成覆盖相邻两个位置，且把尺寸输入说成读取网格。'), 70: ('程序读入 x、y，使用带缓存的递归函数 solve(v)，最终输出 solve(y)。若 v≤x，返回 x-v；否则先以 v-x 为候选。v 为偶数时还比较 1+solve(v//2)；v 为奇数时同时比较 2+solve(v//2) 和 2+solve(v//2+1)。因此奇数分支包含先减1再减半和先加1再减半两种方向。它计算这些增减与减半路径中的最小操作代价。本次只阅读代码，没有运行测试。', '原回答遗漏奇数先减1再减半分支，却将列举说成完整递归。'), 72: ('程序读取 n、m、q，接着读取 n 对物品大小和价值，以及 m 个箱子容量。每次查询 l、r 时，排除1起始编号 l 到 r 的箱子，并把剩余容量升序排列。物品也按大小排序；依次处理箱子，将能装入当前容量且尚未加入的物品价值取负放入堆，再选取其中价值最大的一个计入 ans。每个查询输出选中物品的总价值，不是未装入的物品数。本次没有运行测试。', '原回答误读二元组、区间排除方向、堆优先级和输出含义。'), 82: ('程序读入整数 k，再读一行字符串并只保留其长度 n。它在模10^9+7下预计算阶乘及逆阶乘，然后对 i=0 到 k 累加 C(n+i-1,i)×25^i×26^(k-i)，最后输出这个和。p25 从1开始逐轮乘25，p26 从26^k开始逐轮乘26的模逆元。代码没有字典序排序或第n小字符串的计算，也不使用字符串的具体字符。本次只阅读代码，没有运行测试。', '原回答编造字典序第n小，且颠倒幂次、初始化和循环范围。')}
rows=[]
for num,(answer,reason) in corrections.items():
 name=f'Code_{num:05d}-understand';root=P/'runs'/(name+'-r1')/'execution';result=json.loads((root/'RESULT.json').read_text());found=[]
 for cp,actual in replay_run(root,reg['model_sha256']).items():
  try:c=parse_model_command(actual['raw_generation']['raw_output'])
  except Exception:continue
  if c.name=='final_answer' and c.arguments['text']==result['final']:found.append((cp,actual))
 assert len(found)==1;cp,actual=found[0];out=D/name;out.mkdir();(out/'ACTUAL_INPUT.json').write_text(json.dumps(actual,ensure_ascii=False,indent=2)+'\n');raw=json.dumps({'function':'final_answer','params':{'text':answer}},ensure_ascii=False)
 rows.append({'id':name,'source_run':str(root),'checkpoint_id':cp,'original_answer':result['final'],'target_text':raw+JSON_CALL_STOP_SUFFIXES[0],'teacher':'current Codex assistant','reason':reason,'input_sha256':hashlib.sha256(actual['input_text'].encode()).hexdigest(),'status':'candidate_not_admitted'})
(D/'CANDIDATES.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
