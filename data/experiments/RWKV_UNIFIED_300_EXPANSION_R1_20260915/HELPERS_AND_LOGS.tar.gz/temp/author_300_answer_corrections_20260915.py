from pathlib import Path
import sys,json,hashlib
R=Path('/home/chase/GitHub/RWKV-LH');sys.path.insert(0,str(R))
from rwkv_lh.direct_trace_data import replay_run
from rwkv_lh.model_io import parse_model_command,JSON_CALL_STOP_SUFFIXES
D=R/'data/experiments/RWKV_300_ANSWER_CORRECTIONS_R1_20260915';D.mkdir(exist_ok=False);P=R/'data/experiments/RWKV_COLLECTION_300_R1_20260915';reg=json.loads((P/'REGISTRATION.json').read_text())
corrections={'Code_00019-understand':('程序读入整数 x，初始化 best=1，然后枚举满足 base²≤x 的整数 base。从 base² 开始反复乘以 base，枚举不超过 x 的 base²、base³等整数幂，并更新最大值。最终输出找到的最大整数幂；如果没有进入枚举循环则输出初始值 1。它找的不仅是平方数，也包括立方及更高次幂。本次只阅读代码，没有运行测试。','RWKV把反复乘以base产生的整数幂误称为平方数，导致核心计算与输出含义错误。'), 'Code_00013-understand':('程序先读入整数 n，再读入并去除两端空白的字符串 s；n 没有参与后续计算。它遍历 s，遇到左括号将 balance 加1，其余字符将 balance 减1，并记录最小 balance。最后在 s 前补 -minimum 个左括号，在后补 balance-minimum 个右括号并输出。对括号字符串，这会补齐前缀缺少的左括号和末尾缺少的右括号。代码没有检查 s 的长度是否等于 n，也没有校验字符种类。本次没有运行测试。','澄清长度n未校验及n未参与计算；保留原回答和外部原审核，不将独立通过等同最终准入。')}
rows=[]
for name,(answer,reason) in corrections.items():
 root=P/'runs'/(name+'-r1')/'execution';result=json.loads((root/'RESULT.json').read_text());found=[]
 for cp,actual in replay_run(root,reg['model_sha256']).items():
  try:c=parse_model_command(actual['raw_generation']['raw_output'])
  except Exception:continue
  if c.name=='final_answer' and c.arguments['text']==result['final']:found.append((cp,actual))
 assert len(found)==1;cp,actual=found[0];out=D/name;out.mkdir();(out/'ACTUAL_INPUT.json').write_text(json.dumps(actual,ensure_ascii=False,indent=2)+'\n');raw=json.dumps({'function':'final_answer','params':{'text':answer}},ensure_ascii=False)
 rows.append({'id':name,'source_run':str(root),'checkpoint_id':cp,'original_answer':result['final'],'target_text':raw+JSON_CALL_STOP_SUFFIXES[0],'teacher':'current Codex assistant','reason':reason,'input_sha256':hashlib.sha256(actual['input_text'].encode()).hexdigest(),'status':'candidate_not_admitted'})
(D/'CANDIDATES.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n');print('saved two separate Codex factual corrections')
