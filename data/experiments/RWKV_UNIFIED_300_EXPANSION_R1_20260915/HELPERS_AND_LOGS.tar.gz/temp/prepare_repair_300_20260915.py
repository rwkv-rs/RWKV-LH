from pathlib import Path
import json,hashlib,shutil
R=Path('/home/chase/GitHub/RWKV-LH');D=R/'data/experiments/RWKV_FAILURE_REPAIR_300_R1_20260915';D.mkdir(exist_ok=False);P=R/'data/experiments/RWKV_FEEDBACK_COLLECTION_150_R1_20260915';reg=json.loads((P/'REGISTRATION.json').read_text());cases=[]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
request='工作区的 solution.py 是已有程序，public_checks.py 是公开样例检查。请检查并修复程序，使其满足 TASK.md 的要求。实际运行公开检查，根据观察定位问题，修改 solution.py 后再次验证；不要修改检查脚本。最后如实说明修改和本次实际验证，不要把计划执行说成已经通过。'
for n in (7,56,86):
 ident=f'Code_{n:05d}';source=P/'tasks'/(ident+'-student');work=D/'tasks'/ident;shutil.copytree(source,work)
 cases.append({'id':ident,'workspace':str(work),'task_sha256':sha(work/'TASK.md'),'files':{p.name:sha(p) for p in work.iterdir()},'original_task_id':ident,'source_workspace':str(source),'request':request,'artifact_origin':'unchanged real failed RWKV program already collected; no artificial bug injection'})
reg.update(cases=cases,rejected=[],repeats=1,request=request,registered_before_run=True,change='Three existing real student failures, complete repair goal; no forced tool order, no automatic parameter/answer correction.',acceptance='Original private exact stdio tests outside workspace plus truthful final; public checks stay unchanged. Submission and code correctness separate; budgets never force final.')
reg['budget'].update(total_calls=36,overall_seconds=1800,strong_model_calls=0)
s=(R/'temp/run_collection_300_20260915.py').read_text().replace('RWKV_COLLECTION_300_R1_20260915','RWKV_FAILURE_REPAIR_300_R1_20260915').replace('29633','29634').replace('>=14400','>=1800');runner=R/'temp/run_repair_300_20260915.py';runner.write_text(s);reg['runner_sha256']=sha(runner)
(D/'REGISTRATION.json').write_text(json.dumps(reg,ensure_ascii=False,indent=2)+'\n')
s=(R/'temp/continue_collection_300_20260915.py').read_text().replace('RWKV_COLLECTION_300_R1_20260915','RWKV_FAILURE_REPAIR_300_R1_20260915').replace('rwkv-lh-collection-300-r1.service','rwkv-lh-repair-300-r1.service').replace('collection_300_r1','repair_300_r1').replace('18258','18259').replace('29633','29634').replace('run_collection_300_20260915.py','run_repair_300_20260915.py');(R/'temp/continue_repair_300_20260915.py').write_text(s)
print('registered three real failure repair tasks, not launched')
