from pathlib import Path
from dataclasses import replace
import sys,json,hashlib
R=Path('/home/chase/GitHub/RWKV-LH');sys.path.insert(0,str(R))
from rwkv_lh.correction_review import build_review_packet,validate_review,REVIEW_INSTRUCTION,REVIEW_SCHEMA
from rwkv_lh.model_io import JSON_CALL_STOP_SUFFIXES
from rwkv_lh.strong_session import AuditedStrongClient
from rwkv_lh.supervisor_openai import SupervisorAPISettings
from rwkv_lh.runtime.settings import load_local_env
D=R/'data/experiments/RWKV_300_ANSWER_CORRECTIONS_R4_20260915';load_local_env(R/'.env.local');settings=replace(SupervisorAPISettings.from_env(),retry_attempts=1,semantic_repair_attempts=0,fallback_models=(),plan_cache_enabled=False,planner_request_options={'thinking':{'type':'disabled'}},read_timeout_seconds=90)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
candidates=json.loads((D/'CANDIDATES.json').read_text());save(D/'REVIEW_REGISTRATION.json',{'helper_sha256':sha(Path(__file__)),'candidates_sha256':sha(D/'CANDIDATES.json'),'settings':settings.public_dict(),'calls_max':len(candidates),'output_tokens_max':3072,'policy':'New Codex factual candidates, no rescore of raw student answers; unchanged shared input builder and review validation.'});rows=[]
for c in candidates:
 name=c['id'];out=D/name;actual=json.loads((out/'ACTUAL_INPUT.json').read_text());raw=c['target_text'][:-len(JSON_CALL_STOP_SUFFIXES[0])];packet=build_review_packet(actual_rwkv_input=actual['input_text'],candidate=raw);save(out/'PACKET.json',packet)
 def audit(e):
  with (out/'strong_trace.jsonl').open('a') as f:f.write(json.dumps(dict(e),ensure_ascii=False)+'\n')
 client=AuditedStrongClient(settings,audit_hook=audit)
 try:
  v=client._request_json(phase='state_tune_target_review',run_id=name,request_digest=hashlib.sha256(json.dumps(packet).encode()).hexdigest(),system_prompt=REVIEW_INSTRUCTION,request_payload=packet,schema=REVIEW_SCHEMA,max_tokens=3072);save(out/'RAW_REVIEW.json',v);checked=validate_review(packet,v);save(out/'VALIDATED_REVIEW.json',checked);rows.append({**c,'status':'accepted' if checked['accepted'] else 'rejected','issues':checked['issues'],'independent_review_path':str(out/'VALIDATED_REVIEW.json'),'independent_review_sha256':sha(out/'VALIDATED_REVIEW.json')})
 except Exception as e:rows.append({**c,'status':'error','error':type(e).__name__+': '+str(e)})
 finally:client.close()
 save(D/'RESULTS.json',rows);print(name,rows[-1]['status'],flush=True)
