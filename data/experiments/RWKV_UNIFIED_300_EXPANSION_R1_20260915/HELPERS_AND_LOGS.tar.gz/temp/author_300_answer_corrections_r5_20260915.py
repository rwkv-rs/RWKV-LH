from pathlib import Path
import sys,json,hashlib
R=Path('/home/chase/GitHub/RWKV-LH');sys.path.insert(0,str(R))
from rwkv_lh.direct_trace_data import replay_run
from rwkv_lh.model_io import parse_model_command,JSON_CALL_STOP_SUFFIXES
D=R/'data/experiments/RWKV_300_ANSWER_CORRECTIONS_R5_20260915';D.mkdir(exist_ok=False);P=R/'data/experiments/RWKV_COLLECTION_300_R1_20260915';reg=json.loads((P/'REGISTRATION.json').read_text())
corrections={1: ('程序读取 r、c、x、y、d、l 六个整数，枚举四条边界是否为空的16种组合。它用集合记录被排除的行、列，按剩余格数计算选出 d+l 个位置再分配 d 个位置的组合数；根据被选边界数量的奇偶加减，最后乘矩形在 r×c 中的放置位置数，并对10^9+7取模输出。容斥符号取决于 mask 中1的个数，不是 mask 整数本身的奇偶。本次只阅读代码，没有运行测试。', '澄清原回答mask奇偶性应为置位数量奇偶，不改变原始评分。'), 2: ('程序读入 n，令 depth 为 n 的二进制位数，初始化 x=1、turn=0。在 x≤n 时，每轮把 x 翻倍；若当前轮是否属于 turn=0 与 depth 是否为奇数相同，则再加1，然后翻转 turn。循环在 x>n 时结束，此时 turn=0 输出 Takahashi，否则输出 Aoki。程序只输出这个名字，没有输出 x 或循环次数。本次没有运行测试。', '原回答仅说循环更新x，补清决定每一步变化的depth与turn关系。'), 6: ('程序读取一行字符串 s，用12字符的键盘颜色序列重复3次形成36字符 pattern。它依次检查偏移0、2、4、5、7、9、11开始的20字符切片，对应 Do、Re、Mi、Fa、So、La、Si；遇到与 s 完全相等的切片就输出对应音名并停止。若没有匹配，代码没有额外输出分支。本次只阅读代码，没有运行测试。', '原回答把36字符pattern说成20字符，并没有准确区分固定偏移和连续偏移。'), 28: ('程序读入 L、R，用带缓存的数位递归同时构造两个正整数 x、y。每个二进制位只允许(0,0)、(0,1)、(1,1)，并要求开始出现1之前两者该位相同；这使 x 的置位包含于 y，且两者最高置位相同。above、below 分别约束 x 不小于 L、y 不大于 R。递归从第59位处理到第0位，累计合法数对数量，最后对10^9+7取模输出。它没有统计单个整数中1的奇偶性。本次没有运行测试。', '原回答将双变量位对计数编造成单个整数的奇数置位计数。'), 30: ('程序读入 n、k；k 为奇数时直接输出0。否则用字典从状态(j,cost)=(0,0)开始迭代 n 轮。每轮的新 j 值 h 分别为 j+1、j、j-1，对应计数乘数为1、2j+1、j²；新代价为 cost+2h。它丢弃 h<0、h 超过剩余轮数或代价超过 k 的分支，并对计数取模10^9+7。最终输出状态(0,k)的计数，不存在则输出0。本次只阅读代码，没有运行测试。', '原回答混淆新状态和计数乘数，把分支说成减1、乘2、平方。'), 31: ('程序读取所有整数，把首项减1记为 n，其余整数作为数组 s，答案初始为0。它枚举正步长 d，再逐步增加 k，累加 s[k*d]+s[n-k*d] 并更新最大累计值；循环上界保证步长关系有效，且当 n 能被 d 整除时，在2*k*d≥n前停止，避免位置相遇或重复。最后输出最大的累计值，若所有候选更差则保留0。配对下标之和是 n，而不是 d。本次没有运行测试。', '原回答忽略首项减1、累加前缀与碰撞条件，并把配对下标和写成d。')}
rows=[]
for num,(answer,reason) in corrections.items():
 name=f'Code_{num:05d}-understand';root=P/'runs'/(name+'-r1')/'execution';result=json.loads((root/'RESULT.json').read_text());found=[]
 for cp,actual in replay_run(root,reg['model_sha256']).items():
  try:c=parse_model_command(actual['raw_generation']['raw_output'])
  except Exception:continue
  if c.name=='final_answer' and c.arguments['text']==result['final']:found.append((cp,actual))
 assert len(found)==1;cp,actual=found[0];out=D/name;out.mkdir();(out/'ACTUAL_INPUT.json').write_text(json.dumps(actual,ensure_ascii=False,indent=2)+'\n');raw=json.dumps({'function':'final_answer','params':{'text':answer}},ensure_ascii=False)
 rows.append({'id':name,'source_run':str(root),'checkpoint_id':cp,'original_answer':result['final'],'target_text':raw+JSON_CALL_STOP_SUFFIXES[0],'teacher':'current Codex assistant','reason':reason,'input_sha256':hashlib.sha256(actual['input_text'].encode()).hexdigest(),'status':'candidate_not_admitted'})
(D/'CANDIDATES.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
