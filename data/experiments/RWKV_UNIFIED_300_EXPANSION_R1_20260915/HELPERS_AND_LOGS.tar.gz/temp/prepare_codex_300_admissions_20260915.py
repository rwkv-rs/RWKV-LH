from pathlib import Path
import sys,json,hashlib
R=Path('/home/chase/GitHub/RWKV-LH');sys.path.insert(0,str(R))
from rwkv_lh.stdio_corrections import validate_stdio_correction
from rwkv_lh.direct_trace_data import ROW_SCHEMA,ROLE,protocol_identity,normalize_direct_row
from rwkv_lh.token_budget import tokenizer,VOCAB_PATH
D=R/'data/experiments/RWKV_UNIFIED_300_EXPANSION_R1_20260915';old=json.loads((R/'data/datasets/rwkv_direct_unified_corrections_v5/manifest.json').read_text());oldrows=[json.loads(s) for s in (R/'data/datasets/rwkv_direct_unified_corrections_v5/train.jsonl').read_text().splitlines()];oldpairs={(r['request_id'],r['input_checkpoint_id']) for r in oldrows};protocol,psha=protocol_identity()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n');return {'path':str(p),'sha256':sha(p)}
entries=[];excluded=[]
for batch in ('batch1','batch2','batch3','batch4'):
 B=D/batch;targets={x['id']:x for x in json.loads((B/'TEACHER_TARGETS.json').read_text())}
 for x in json.loads((B/'RESULTS.json').read_text()):
  if x['status']!='execution_verified_candidate':excluded.append({'batch':batch,'id':x['id'],'reason':x['status']});continue
  actual=json.loads((B/'validation'/x['id']/'ACTUAL_INPUT.json').read_text())
  if (actual['request_id'],actual['input_checkpoint_id']) in oldpairs:excluded.append({'batch':batch,'id':x['id'],'reason':'already admitted original generation boundary; do not inflate with another correction'});continue
  entries.append((B,x,actual,targets[x['id']]))
assert len(entries)==25,len(entries)
rows=[];sources=[]
for B,x,actual,target in entries:
 ident=x['id'];root=Path(x['source_run']);P=root.parents[2];reg=json.loads((P/'REGISTRATION.json').read_text());case=next(c for c in reg['cases'] if c['id']==ident);task=Path(case['workspace'])/'TASK.md';files={str(p.relative_to(root)):sha(p) for p in root.rglob('*') if p.is_file()};text=x['target_text']
 review={'reviewer':'current Codex assistant: explicit source and algorithm review','accepted':True,'visible_evidence_only':True,'source_consistent':True,'output_contract':'exact_unique','task_sha256':sha(task),'input_sha256':hashlib.sha256(actual['input_text'].encode()).hexdigest(),'target_sha256':hashlib.sha256(text.encode()).hexdigest(),'scope':target['visible_source_review'],'teacher_target_reference':{'path':str(B/'TEACHER_TARGETS.json'),'sha256':sha(B/'TEACHER_TARGETS.json')},'private_output_not_used_for_algorithm':True}
 proof=validate_stdio_correction(run_root=root,checkpoint_id=x['checkpoint_id'],target_text=text,model_sha256=old['model_sha256'],source_files=files,cases_reference={'path':case['private_tests_path'],'sha256':case['private_tests_sha256']},review=review,output=D/'admission'/ident)
 assert proof['status']=='validated_candidate',(ident,proof['status'])
 collector=save(D/'sources'/ident/'COLLECTOR.json',{'original_registration':{'path':str(P/'REGISTRATION.json'),'sha256':sha(P/'REGISTRATION.json')},'files':reg['source_pins']});state=json.loads((root/'state_snapshot.json').read_text());meta=[s['native_state_metadata'] for s in state['model_states'].values()];keys=('model_sha256','server_build','tokenizer_build','protocol_version','state_format_version');identity={k:meta[0][k] for k in keys};assert all({k:m[k] for k in keys}==identity for m in meta)
 server=save(D/'sources'/ident/'SERVER.json',{'identity':identity,'state_snapshot_sha256':sha(root/'state_snapshot.json')});manifest=save(D/'sources'/ident/'MANIFEST.json',{'source_type':'native_production_trace','model_sha256':old['model_sha256'],'collector_source_manifest_sha256':collector['sha256'],'collector_source_reference':collector,'server_identity_sha256':server['sha256'],'server_identity_reference':server,'files':files});sid='ultradata-codex300-'+ident
 sources.append({'id':sid,'source_id':sid,'original_task_id':ident,'family':'ULTRADATA_CODE','split':'train','run_root':str(root),'path':'TASK.md','source_content_sha256':sha(task),'content_reference':{'path':str(task),'sha256':sha(task)},'manifest':manifest})
 path=D/'admission'/ident/'VALIDATION.json';rows.append({'schema_version':ROW_SCHEMA,'role':ROLE,'split':'train','recomputed':True,'sample_id':sid,'source_id':sid,'family':'ULTRADATA_CODE','input_protocol':protocol,'protocol_sha256':psha,'model_sha256':old['model_sha256'],'tokenizer_sha256':sha(VOCAB_PATH),'source_manifest_sha256':manifest['sha256'],'source_content_sha256':sha(task),'candidate_checkpoint_id':x['checkpoint_id'],'input_checkpoint_id':actual['input_checkpoint_id'],'request_id':actual['request_id'],'input_text':actual['input_text'],'input_token_ids':actual['input_token_ids'],'input_token_source':'server_returned_full','target_text':text,'target_token_ids':tokenizer().encode(text),'label_authority':'verified_stdio','stdio_review':review,'stdio_validation':{'path':str(path),'sha256':sha(path)},'teacher':'current Codex assistant'})
 save(D/'EDIT_ADMISSIONS.json',{'rows':rows,'sources':sources,'excluded':excluded});print('validated',ident,flush=True)
print('prepared',len(rows),'distinct new edits, not frozen dataset yet',flush=True)
