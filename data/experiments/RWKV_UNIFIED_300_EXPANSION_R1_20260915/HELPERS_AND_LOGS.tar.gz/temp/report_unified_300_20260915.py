from pathlib import Path
import json,hashlib,subprocess
R=Path('/home/chase/GitHub/RWKV-LH');D=R/'data/experiments/RWKV_UNIFIED_300_EXPANSION_R1_20260915';V=R/'data/datasets/rwkv_direct_unified_corrections_v6'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
f=json.loads((D/'FREEZE_RESULT.json').read_text());u=json.loads((D/'REVIEW_USAGE.json').read_text())['summary'];t=json.loads((D/'TASK_REVIEW.json').read_text());m=json.loads((V/'manifest.json').read_text());head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
(D/'SOURCE_IDENTITY.json').write_text(json.dumps({'local_base_commit':head,'dataset_manifest_sha256':sha(V/'manifest.json'),'model_sha256':m['model_sha256'],'protocol':m.get('input_protocol',m.get('protocol_version')),'freeze_generator':{'path':str(R/'temp/freeze_unified_300_v6_20260915.py'),'sha256':sha(R/'temp/freeze_unified_300_v6_20260915.py')},'scope':'Local Git identity only; remote service identity uses previously frozen full source manifests, as referenced by collection registrations/service identity. No remote Git.'},ensure_ascii=False,indent=2)+'\n')
text=f'''# 统一 StateTune 300 条阶段报告

本轮完成 owner 授权的150→300扩量。数据已冻结到 `data/datasets/rwkv_direct_unified_corrections_v6/`，旧150条逐字节保留。未训练，未push；物理GPU仅0，原服务已恢复空闲。

## 任务级真实结果

新采集78个任务、183次RWKV生成：75个自然提交、3个预算中断、实际修改文件0。全程RWKV独立执行，运行时强模型调用0；不能把离线教师修复算作RWKV交付。

- 运行现有公开检查并忠实报告：25/25。每题只证明提供的公开检查及报告；程序是此前教师纠正工件，不是本次RWKV编写。
- 阅读实际 `solution.py` 并解释：50份均拿到完整代码并提交。人工按已登记主旨/计算/输出/事实规则检查：6份准确可用，5份主旨可用但有精度问题，3份解释过于笼统，36份存在实质误读。质量分层用于解释差异，不是运行后修改对照评分，也不把所有不足压成相同质量。逐条原文、来源及理由见 `TASK_REVIEW.json`。
- 三个已有真实错误程序的修复：0/3，全部预算中断，无实际修改。Code7读取后出现协议拒绝；Code56看见公开测试失败后反复对Python使用 `patch_json`；Code86尝试改动明确要求不得修改的公开检查脚本。拒绝的调用没有变成实际修改。

这些是有不同目标的诊断任务，不合并成项目级Strict，也不是StateTune收益或普遍代码理解能力结论。

## 数据交付

|新增边界|条数|证据|
|---|---:|---|
|实现与修复写入|28|25个不同问题的实现纠正＋3个真实错误程序的修复；原快照失败、真实写入、原隔离测试通过；3个修复均未改检查脚本|
|检查命令|24|原边界、独立审核、真实命令执行及冻结时复验；另1份审核格式错误保留未入训|
|实际检查后回答|11|9份忠实RWKV原回答＋2份Codex简洁等价标签；后2份不算学生事实错误修复|
|代码理解回答|19|18份Codex对真实误读的纠正＋1份忠实RWKV原回答；另有正确/候选回答因精度或独立审核格式问题未准入|
|首次完整读取|68|25个原任务文档＋43个实际程序；排除已有Code28读取和所有重复读取|
|合计|150|旧150＋新增150＝300|

完整300条为122读取、65回答、57写入/修改、56命令。300是决策边界数，**不是300个项目或300种独立行为**。同形检查调用和读取仍占比较大，已保存精确去重和语义重复说明；训练前必须冻结采样权重，不能以换工作区路径宣称行为多样性。只有1条新修复位于真实失败测试观察之后，这个覆盖仍薄弱。

manifest SHA-256：`{f['manifest_sha256']}`。

固定dev4/confirmation4元数据逐字节未变，未运行confirmation或最终holdout。最大序列{f['max_sequence_tokens']} token，24576上下文内，不截断。所有300条原始请求及输入/目标对精确唯一；freeze重新检查真实输入、源码/模型/协议/来源身份、相似度隔离与对应工具证明。

## 已得到的错误规律

1. **计数对象与数学语义混淆**：整数幂被说成平方数、区间第二大值求和被说成逆序对、子集方案数被说成质因子数、整除分块被说成GCD算法。
2. **条件与边界遗漏**：输出相等位置被说成取较小值、最后物品允许超时被抹掉、有限/无限分支遗漏、奇数递归分支遗漏。
3. **方向及运算混淆**：上升费用写反、单格与双格分支混淆、组内OR/组间XOR被说成任选子集、状态转移与计数乘数混淆。
4. **执行推进与工具对象错误**：读取后停滞；测试失败后无法进入正确修改；用JSON工具处理Python；尝试修改受保护的检查目标。

前三类可统一归入事实忠实/代码理解，第四类归入工具协议、目标约束和推进。审核格式错误、审核者的错误反驳、教师代码错误分别保留，不能一概归因为RWKV。State父链与完整观察审计通过，不据此声称数值State或输入组织永无问题，也不把目前误读归因于已证实的State丢失。

本轮Codex代码候选曾出现一次换行转义语法错误，另一次输入按行解析未适应来源检查的空白布局；两个原失败候选保留，修订后分别通过原测试。已有Code59边界的重复纠正排除，没有重复计数。

## 用量与工程检查

RWKV：183次生成，精确输入895186、输出25927 token；9次协议拒绝。78/78输入/观察/State链路审计通过。75任务采集778.275秒，3修复任务107.767秒（均为服务就绪后的阶段耗时，不含全部部署、教师与验收时间）。Code82有一次重复完整读取，原轨迹保留且不重复入训。

独立离线审核：149个实际HTTP请求，输入{u['prompt_tokens']}、输出{u['completion_tokens']} token；原始结果为24份命令验证候选、32份回答审核接受、41份拒绝、52份格式/引文错误。外部“接受”还需Codex逐条语义复核，不等于训练准入或学生任务成功。没有重算原评分、修改parser或反复请求凑通过。2份原回答忠实但审核格式不合格的样本，使用独立的新简洁教师标签，来源归属明确保留。

Codex教师自身账单和精确上下文用量未暴露，不能将教师成本记零；GPU峰值/总能耗和货币成本未测得，不宣称效率收益。

完整工程回归：1833 passed、0 skipped、344.99秒。没有改动生产代码；owner原5处修改SHA保持一致。冻结脚本两次先期失败（假定全部25命令审核通过；来源清单误包含后追加的审计文件）被门禁拒绝，原脚本/日志及第二次输入归档保留；最终采用原验证证明的精确文件清单，未改变证明或准入规则。封存脚本对回归文件名的错误假设亦已记录。

## 下一阶段

以本300条为不可变数据起点，预注册统一State训练参数、初始化、采样权重和预算，只用GPU0。继续使用已验证的生产协议与输入函数，不同时引入router或替换架构；实际训练后端身份如实登记，不能把LH Native称作RWKV-PEFT。

随后在原固定回归上进行zero与候选任务级对照，重点看真实修改、失败反馈修复、代码解释忠实性及原读取不退化。先保留合格State再扩大任务，不按每个问题维护一个State。300条是否优于150条必须实测，本轮没有训练收益结论。

## 复核入口

- `FREEZE_RESULT.json`、`COVERAGE_AND_DEDUP.json`：数量、旧150字节保持、覆盖与重复。
- `TASK_REVIEW.json`：78个任务原回答和逐条人工评估。
- `EDIT_ADMISSIONS.json`、`REPAIR_ADMISSIONS.json`、`MANUAL_ANSWER_ADMISSIONS.json`：教师、边界与验证来源。
- `REVIEW_USAGE.json`、`PENDING_CANDIDATES.json`：所有外部用量、拒绝和格式错误。
- `RAW_MANIFEST.json`：本地原始运行/审核文件及SHA；原始大文件并非全部随Git镜像上传。
- `HELPERS_AND_LOGS.tar.gz`、`HELPER_MANIFEST.json`：可重建辅助脚本和日志。
- `FINAL_HEALTH.json`、`FINAL_CHECKS.json`、`SOURCE_IDENTITY.json`：服务恢复、owner修改保护及源码身份。
'''
(D/'REPORT.zh-CN.md').write_text(text)
h=R/'docs/HANDOFF.zh-CN.md';s=h.read_text();lines=s.splitlines();lines[0]='# 当前交接（2026-09-15）';s='\n'.join(lines)+'\n';start=s.index('**最新：');end=s.index('\n',start);s=s[:start]+'**最新：统一StateTune v6正式300条（新增150，旧150逐字节保持）；新28写入/修复、24命令、30回答、68读取。78真实任务/183生成：公开检查25/25，代码解释质量分层，自主修复0/3；28离线教师纠正写入均真实验证，其中1条在失败测试观察之后。1833回归通过、0跳过；训练0、仅GPU0、原服务恢复、owner修改保留、未push。详见[300条阶段报告](../data/experiments/RWKV_UNIFIED_300_EXPANSION_R1_20260915/REPORT.zh-CN.md)。**'+s[end:];s=s.replace('## owner授权Codex纠错与扩量（已完成本数据阶段）','## 当前下一步\n\n300是决策边界数，不是项目数。先冻结统一State训练的采样权重/参数/预算，重点控制重复读取与同形命令权重，再训练并在原固定任务上与zero比较。下一阶段不同时加router或换架构；失败反馈后的修复覆盖仍少。以下为历史记录，旧数量不代表当前库存。\n\n## owner授权Codex纠错与扩量（历史数据阶段）');h.write_text(s)
p=R/'docs/STATETUNE_10000_PLAN.zh-CN.md';s=p.read_text();s+='\n\n## 2026-09-15：统一300条已冻结\n\nOwner要求在150条基础上再增加150条，v6现已完成，旧150及固定回归元数据逐字节不变。本轮新增28写入/修复、24命令、30回答、68首次读取；仅1条修复位于真实失败测试观察之后。同形读取和命令仍较多，训练采样权重需事前登记。没有训练，300不等于300独立项目，也不证明为最优数据规模。详见[300条报告](../data/experiments/RWKV_UNIFIED_300_EXPANSION_R1_20260915/REPORT.zh-CN.md)。\n';p.write_text(s)
progress=json.loads((D/'PROGRESS.json').read_text());progress.update(phase='frozen300_final_audit_and_commit',formal_rows=300,verified_new_edits=28,training_steps=0,remaining=['final SHA audit and local commit']);(D/'PROGRESS.json').write_text(json.dumps(progress,ensure_ascii=False,indent=2)+'\n')
print('report and handoff updated')
