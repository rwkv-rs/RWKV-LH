from pathlib import Path
import sys,json,hashlib
R=Path('/home/chase/GitHub/RWKV-LH');sys.path.insert(0,str(R))
from rwkv_lh.direct_trace_data import replay_run
from rwkv_lh.model_io import parse_model_command,JSON_CALL_STOP_SUFFIXES
D=R/'data/experiments/RWKV_300_ANSWER_CORRECTIONS_R4_20260915';D.mkdir(exist_ok=False);P=R/'data/experiments/RWKV_COLLECTION_300_R1_20260915';reg=json.loads((P/'REGISTRATION.json').read_text())
corrections={84: ('程序读入 n、k，通过容斥公式 cumulative(s) 计算三个数都在1到n之间、总和不超过 s 的有序三元组数量。它先二分找到累计数量达到 k 的最小总和 s，再减去总和小于 s 的数量，得到当前总和内的排名。随后按第一个数 i 升序枚举，计算合法第二个数的区间并扣除整段数量，定位 j 后输出 i、j、s-i-j。它求的是按总和再按各数顺序排列的第 k 个有序三元组，不是要求某个总和的无序分拆数恰好等于 k。本次没有运行测试。', '原回答把累计计数当成固定和计数，混淆有序三元组、无序分拆和排名。'), 85: ('程序读入两组各 n 个二维点。对每组计算坐标和，再用 (n*x-sx,n*y-sy) 得到放大 n 倍的中心化坐标。n=1 时直接输出 Yes；否则从第一组选择一个非零参考向量，在第二组枚举平方长度相等的向量，用点积、叉积构造对应的旋转比较，并通过集合相等判断所有点是否匹配。为避免除法，比较双方都包含相同的 norm 因子。找到匹配输出 Yes，否则 No；这不允许两组点任意缩放。本次没有运行测试。', '原回答把共同的整数缩放因子误当允许缩放，且把首个非零点说成第一个点。'), 86: ('程序读取 n 和后续数组元素，通过递归枚举在相邻元素之间是否切分，形成若干连续非空组。current 保存当前组的按位或，done 保存此前已结束各组结果的按位异或。每步要么把 a[i] 并入当前组，要么将当前组异或进 done 并以 a[i] 开启新组。到达末尾时用 done^current 更新最小值，最后输出该值。它不是任选子集再求异或，也没有丢弃元素。本次没有运行测试。', '原回答将连续分组中的组内OR、组间XOR误写为任选子集。'), 87: ('程序读入无向图并构建邻接表，逐个收集连通分量的顶点。对每个分量，先把根的颜色固定为0，再回溯枚举其余顶点的三种颜色，排除已经被邻居使用的颜色；递归结束计为一种合法着色。该分量的计数乘3，以恢复根的三种对称颜色选择，再与其他分量的计数相乘。最后输出全图相邻顶点颜色不同的三色着色方案数。本次只阅读代码，没有运行测试。', '原回答将固定根颜色后乘3写成直接从根尝试三种颜色，且把收集顶点顺序说成DFS。'), 88: ('程序先读入 n、k 和 n 行网格，只为字符为点号的空格建立上下左右邻接位掩码。states 初始包含每个单独空格构成的集合；随后扩展 k-1 轮，每次在已有集合的边界上加入一个尚未选中的相邻空格，并用 set 去除相同集合的重复路径。最终输出 states 的数量，即由 k 个空格组成的不同连通格子集合数，不是 k 步可到达的空格数。本次没有运行测试。', '原回答混淆集合状态计数和可达格子数量，忽略每次只加入一个格子。'), 92: ('程序读入 a、b，先生成2到72之间的质数。对区间内每个整数，构造它能被这些质数中哪些整除的位掩码。动态规划初始只含空选择；处理一个整数时保留不选它的方案，并仅在它的掩码与已用掩码不相交时累加选它的方案。最后输出所有状态的方案数之和，包含空集。这里统计的是满足这些质因子不重复条件的整数子集选择数，不是质因子的个数，也不是不同掩码的个数。本次没有运行测试。', '原回答混淆计数对象：子集方案数、不同掩码数和质因子数。')}
rows=[]
for num,(answer,reason) in corrections.items():
 name=f'Code_{num:05d}-understand';root=P/'runs'/(name+'-r1')/'execution';result=json.loads((root/'RESULT.json').read_text());found=[]
 for cp,actual in replay_run(root,reg['model_sha256']).items():
  try:c=parse_model_command(actual['raw_generation']['raw_output'])
  except Exception:continue
  if c.name=='final_answer' and c.arguments['text']==result['final']:found.append((cp,actual))
 assert len(found)==1;cp,actual=found[0];out=D/name;out.mkdir();(out/'ACTUAL_INPUT.json').write_text(json.dumps(actual,ensure_ascii=False,indent=2)+'\n');raw=json.dumps({'function':'final_answer','params':{'text':answer}},ensure_ascii=False)
 rows.append({'id':name,'source_run':str(root),'checkpoint_id':cp,'original_answer':result['final'],'target_text':raw+JSON_CALL_STOP_SUFFIXES[0],'teacher':'current Codex assistant','reason':reason,'input_sha256':hashlib.sha256(actual['input_text'].encode()).hexdigest(),'status':'candidate_not_admitted'})
(D/'CANDIDATES.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
