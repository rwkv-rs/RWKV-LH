from pathlib import Path
import sys,json,hashlib
R=Path('/home/chase/GitHub/RWKV-LH');sys.path.insert(0,str(R))
from rwkv_lh.direct_trace_data import replay_run
from rwkv_lh.model_io import parse_model_command,JSON_CALL_STOP_SUFFIXES
D=R/'data/experiments/RWKV_300_ANSWER_CORRECTIONS_R2_20260915';D.mkdir(exist_ok=False);P=R/'data/experiments/RWKV_COLLECTION_300_R1_20260915';reg=json.loads((P/'REGISTRATION.json').read_text())
corrections={33:('程序从标准输入读入 n、m 和 n 对整数，并将这些二元组排序。它依次遍历 day=1 到 m，把第一项不大于当前 day 的二元组的第二项取负后加入堆；若堆非空，每轮取出第二项最大的一个并累加到 ans。最后输出 ans。代码按第一项达到阈值后加入候选，并非按截止日期删除过期任务。本次只阅读代码，没有运行测试。','原回答将加入候选的阈值说成截止日期，方向不符。'),42:('程序读入 n、k、c 和字符串 s，分别从左向右、从右向左贪心寻找至多 k 个字符 o 的位置，每次选中后向当前方向移动 c+1 格。随后将 left 与反转后的 right 按顺序配对，只有两侧位置相等时才输出该位置加1，也就是对应的1起始编号。它不会输出每一对的较小值。本次没有运行测试。','原回答漏掉a==b条件，把相同位置输出说成每对取较小值。'),44:('程序读取整数序列，将前两个数记为 n、s，对后续每个数 x 进行动态规划。dp 长度为 s+1，初始全部为0；每处理一个 x，先把 dp[0] 加1，再按 j 从 s 到 x 递减，将 dp[j-x] 累加到 dp[j] 并取模998244353。每轮将 dp[s] 累加到 ans，最后输出 ans。dp[0] 每轮增加对应新的起点，因此不能把它描述成只初始化一次的普通全数组子集计数。本次只阅读代码，没有运行测试。','原回答遗漏每轮dp[0]+=1并虚构dp[0]初始1，改变计数意义。'),45:('程序读取整数 n，按 floor(n/i) 相同的连续区间分组求和。每组从 l 开始，令 q=n//l、r=n//q，利用等差数列公式计算 l 到 r 的整数和，再乘 q(q+1)/2 加入 ans；随后从 r+1 继续，最后输出 ans。计算的表达式是对 i=1 到 n 累加 i×floor(n/i)×(floor(n/i)+1)/2。代码没有计算 GCD，也没有计算欧拉函数。本次没有运行测试。','原回答编造GCD和欧拉函数算法，实际是整除分块求和。'),56:('程序将标准输入解析为整数列表，第一个数 n 用作最终排列长度；后续各数与其原始0起始索引组成二元组，按值从大到小处理。动态规划状态记录已有多少个数放在左端。对当前值 v、原位置 pos，分别尝试放到左侧下一个位置或右侧下一个位置，并增加 v 乘以移动距离绝对值，保留各状态的最大总分。最终输出所有状态中的最大值。输入首项 n 不被当作待排列的元素。本次没有运行测试。','原回答把n当作元素并说只读n-1个值，且未解释加权位移目标。'),59:('程序读入 n、t 和 n 对 duration、value，并按 duration 排序。dp 长度是 t，记录累计时长严格小于 t 时的最大价值，初始仅 dp[0]=0。处理每件物品时，先用 max(dp)+value 更新独立的 ans，允许当前物品作为最后一件而不限制其结束时刻；再倒序更新仍能装入 dp 的时长状态，避免同一物品重复使用。最后输出 ans，而不是 max(dp)。本次只阅读代码，没有运行测试。','原回答将dp长度写成t+1、输出写成max(dp)，遗漏最后物品允许超时的关键行为。')}
rows=[]
for num,(answer,reason) in corrections.items():
 name=f'Code_{num:05d}-understand';root=P/'runs'/(name+'-r1')/'execution';result=json.loads((root/'RESULT.json').read_text());found=[]
 for cp,actual in replay_run(root,reg['model_sha256']).items():
  try:c=parse_model_command(actual['raw_generation']['raw_output'])
  except Exception:continue
  if c.name=='final_answer' and c.arguments['text']==result['final']:found.append((cp,actual))
 assert len(found)==1;cp,actual=found[0];out=D/name;out.mkdir();(out/'ACTUAL_INPUT.json').write_text(json.dumps(actual,ensure_ascii=False,indent=2)+'\n');raw=json.dumps({'function':'final_answer','params':{'text':answer}},ensure_ascii=False)
 rows.append({'id':name,'source_run':str(root),'checkpoint_id':cp,'original_answer':result['final'],'target_text':raw+JSON_CALL_STOP_SUFFIXES[0],'teacher':'current Codex assistant','reason':reason,'input_sha256':hashlib.sha256(actual['input_text'].encode()).hexdigest(),'status':'candidate_not_admitted'})
(D/'CANDIDATES.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
