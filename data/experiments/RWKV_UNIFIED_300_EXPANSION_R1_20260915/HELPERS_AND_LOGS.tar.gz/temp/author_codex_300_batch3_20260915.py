from pathlib import Path
import json,hashlib,textwrap
E=Path('/home/chase/GitHub/RWKV-LH/data/experiments/RWKV_UNIFIED_300_EXPANSION_R1_20260915');D=E/'batch3';codes={}
codes[38]=(E/'batch1/Code_00038/solution.py').read_text().replace("print('\n'.join(out))","print(*out, sep=chr(10))")
codes[79]=(E/'batch1/Code_00079/solution.py').read_text().replace("s=input().strip();k=int(input());", "import sys\ns,raw_k=sys.stdin.read().split();k=int(raw_k);")
codes[50]='''
import sys
a=list(map(int,sys.stdin.buffer.read().split()));n=a[0];p=a[1:];pos=[0]*(n+1)
for i,v in enumerate(p,1):pos[v]=i
left=list(range(-1,n+1));right=list(range(1,n+3));ans=0
# Remove smaller values; surviving adjacent indices are the nearest greater values.
for value in range(1,n+1):
    i=pos[value];l=left[i];r=right[i]
    ll=left[l] if l else 0;rr=right[r] if r<=n else n+1
    ans+=value*((l-ll)*(r-i)+(rr-r)*(i-l))
    right[l]=r;left[r]=l
print(ans)
'''
codes[55]='''
import sys
from functools import lru_cache
a=list(map(int,sys.stdin.buffer.read().split()));n,x=a[:2];coins=a[2:]
@lru_cache(None)
def f(i,amount):
    if i==n-1:return 1
    next_coin=coins[i+1];remainder=amount%next_coin
    if remainder==0:return f(i+1,amount)
    return f(i+1,amount-remainder)+f(i+1,amount-remainder+next_coin)
print(f(0,x))
'''
codes[62]='''
import sys
from collections import deque
input=sys.stdin.buffer.readline
h,w,k=map(int,input().split());sx,sy,tx,ty=map(int,input().split());sx-=1;sy-=1;tx-=1;ty-=1
g=[input().strip() for _ in range(h)];d=[[-1]*w for _ in range(h)];d[sx][sy]=0;q=deque([(sx,sy)])
while q:
    x,y=q.popleft()
    if (x,y)==(tx,ty):print(d[x][y]);raise SystemExit
    nd=d[x][y]+1
    for dx,dy in ((1,0),(-1,0),(0,1),(0,-1)):
        xx,yy=x,y
        for _ in range(k):
            xx+=dx;yy+=dy
            if not (0<=xx<h and 0<=yy<w) or g[xx][yy]==64:break
            old=d[xx][yy]
            if 0<=old<nd:break
            if old==nd:continue
            d[xx][yy]=nd;q.append((xx,yy))
print(-1)
'''
codes[73]='''
import sys
sys.setrecursionlimit(1000000)
a=iter(map(int,sys.stdin.buffer.read().split()));n=next(a);colors=[next(a)-1 for _ in range(n)];g=[[] for _ in range(n)]
for _ in range(n-1):
    u,v=next(a)-1,next(a)-1;g[u].append(v);g[v].append(u)
covered=[0]*n;ans=[n*(n+1)//2]*n
# Components left when a color is removed contain all paths avoiding that color.
def dfs(u,p):
    c=colors[u];before=covered[c];size=1
    for v in g[u]:
        if v==p:continue
        prev=covered[c];child=dfs(v,u);gap=child-(covered[c]-prev)
        ans[c]-=gap*(gap+1)//2;size+=child
    covered[c]=before+size
    return size
dfs(0,-1)
for c in range(n):
    rest=n-covered[c];print(ans[c]-rest*(rest+1)//2)
'''
codes[74]='''
import sys,math,bisect
a=iter(map(int,sys.stdin.buffer.read().split()));n=next(a);points=[(next(a),next(a)) for _ in range(n)];right=obtuse=0;pi=math.pi;eps=1e-10
for x,y in points:
    angles=sorted(math.atan2(v-y,u-x) for u,v in points if (u,v)!=(x,y));m=len(angles);angles+=[v+2*pi for v in angles]
    for i in range(m):
        angle=angles[i];r1=bisect.bisect_left(angles,angle+pi/2-eps,i+1,i+m);r2=bisect.bisect_right(angles,angle+pi/2+eps,r1,i+m);end=bisect.bisect_left(angles,angle+pi-eps,r2,i+m)
        right+=r2-r1;obtuse+=end-r2
print(n*(n-1)*(n-2)//6-right-obtuse,right,obtuse)
'''
codes[75]='''
import sys
from collections import deque
sys.setrecursionlimit(1000000)
n=int(input());grid=[input().strip() for _ in range(n)];s=n*n;t=s+1;g=[[] for _ in range(t+1)]
def add(u,v,c):
    g[u].append([v,c,len(g[v])]);g[v].append([u,0,len(g[u])-1])
inf=10**9
for i in range(n):
    for j in range(n):
        u=i*n+j;ch=grid[i][j]
        if ch!='?':
            color=(ch=='B')^((i+j)%2)
            if color:add(s,u,inf)
            else:add(u,t,inf)
        for di,dj in ((1,0),(0,1)):
            ii,jj=i+di,j+dj
            if ii<n and jj<n:v=ii*n+jj;add(u,v,1);add(v,u,1)
flow=0
while True:
    level=[-1]*len(g);level[s]=0;q=deque([s])
    while q:
        u=q.popleft()
        for v,c,r in g[u]:
            if c and level[v]<0:level[v]=level[u]+1;q.append(v)
    if level[t]<0:break
    it=[0]*len(g)
    def dfs(u,f):
        if u==t:return f
        while it[u]<len(g[u]):
            e=g[u][it[u]];v,c,r=e
            if c and level[v]==level[u]+1:
                sent=dfs(v,min(f,c))
                if sent:e[1]-=sent;g[v][r][1]+=sent;return sent
            it[u]+=1
        return 0
    while True:
        sent=dfs(s,inf)
        if not sent:break
        flow+=sent
print(2*n*(n-1)-flow)
'''
notes={38:'Same modulo-count algorithm; repair malformed newline string in teacher serialization. Original failed candidate retained.',79:'Same expectation formula; whitespace-token input accepts documented two values independent of line layout. Original failed candidate retained.',50:'Remove permutation values in ascending order; two nearest greater indices on each side count exactly one greater value.',55:'For nonzero lower denomination remainder, pay or receive it; recurse rounded-down/up remaining amounts. Memoization bounds states per level.',62:'BFS straight rays; stop on obstacles or a strictly earlier distance, continue through equal next distance.',73:'Subtract monochrome-deletion component path counts with per-color covered subtree totals.',74:'Count right and obtuse angles by sorted atan2 and binary search. Integer determinant/dot separation with coords<=10000 supports epsilon1e-10.',75:'Flip colors on checkerboard parity, then mincut counts lost differing-neighbor edges; fixed colors have large capacities.'}
D.mkdir(exist_ok=False);rows=[]
for num,code in codes.items():
 p=D/f'Code_{num:05d}'/'solution.py';p.parent.mkdir();p.write_text(textwrap.dedent(code).lstrip());rows.append({'id':f'Code_{num:05d}','path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'teacher':'current Codex assistant','visible_source_review':notes[num],'output_contract':'exact_unique','private_tests_seen_before_authoring':False,'prior_candidate_failed':num in (38,79)})
(D/'TEACHER_TARGETS.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
print('authored',len(rows))
