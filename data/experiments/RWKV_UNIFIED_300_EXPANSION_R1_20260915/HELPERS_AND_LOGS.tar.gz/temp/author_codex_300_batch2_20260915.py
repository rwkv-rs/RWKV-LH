from pathlib import Path
import json,hashlib,textwrap
D=Path('/home/chase/GitHub/RWKV-LH/data/experiments/RWKV_UNIFIED_300_EXPANSION_R1_20260915/batch2');codes={}
codes[39]='''
import sys
a=iter(map(int,sys.stdin.buffer.read().split()));n=next(a);g=[[] for _ in range(n)]
for e in range(n-1):
    u,v=next(a)-1,next(a)-1;g[u].append((v,1<<e));g[v].append((u,1<<e))
x=[0]*n;stack=[(0,-1)]
while stack:
    u,p=stack.pop()
    for v,b in g[u]:
        if v!=p:x[v]=x[u]^b;stack.append((v,u))
m=next(a);paths=[x[next(a)-1]^x[next(a)-1] for _ in range(m)];union=[0]*(1<<m);ans=1<<(n-1)
for mask in range(1,1<<m):
    bit=mask&-mask;u=union[mask^bit]|paths[bit.bit_length()-1];union[mask]=u
    value=1<<(n-1-u.bit_count());ans+=-value if mask.bit_count()%2 else value
print(ans)
'''
codes[47]='''
import sys
a=list(map(int,sys.stdin.buffer.read().split()));n,k=a[:2];h=[0]+a[2:];inf=10**30
# Keeping n-k original columns is sufficient; changed gaps can be made monotone.
keep=n-k
if keep==0:print(0);raise SystemExit
dp=[0]+[inf]*n
for count in range(1,keep+1):
    nd=[inf]*(n+1)
    for i in range(count,n+1):
        best=inf
        for j in range(count-1,i):
            value=dp[j]+max(0,h[i]-h[j])
            if value<best:best=value
        nd[i]=best
    dp=nd
print(min(dp))
'''
codes[49]='''
import sys
from functools import lru_cache
a=list(map(int,sys.stdin.buffer.read().split()))[1:];xor=0
for v in a[2:]:xor^=v
s=a[0]+a[1]
if s<xor or (s-xor)%2:print(-1);raise SystemExit
common=(s-xor)//2
if common&xor:print(-1);raise SystemExit
bound=a[0];bits=max(s.bit_length(),1)
@lru_cache(None)
def choose(i,tight):
    if i<0:return 0
    limit=(bound>>i)&1 if tight else 1
    options=(1,) if common>>i&1 else ((1,0) if xor>>i&1 else (0,))
    for b in options:
        if b>limit:continue
        rest=choose(i-1,tight and b==limit)
        if rest is not None:return (b<<i)|rest
    return None
x=choose(bits-1,True)
print(-1 if x is None or x<1 else a[0]-x)
'''
codes[52]='''
import sys,heapq
a=iter(map(int,sys.stdin.buffer.read().split()));n,m,s=next(a),next(a),next(a);g=[[] for _ in range(n)];mx=0
for _ in range(m):
    u,v,c,t=next(a)-1,next(a)-1,next(a),next(a);mx=max(mx,c);g[u].append((v,c,t));g[v].append((u,c,t))
exchange=[(next(a),next(a)) for _ in range(n)];cap=mx*(n-1);s=min(s,cap);inf=10**30;d=[[inf]*(cap+1) for _ in range(n)];d[0][s]=0;q=[(0,0,s)]
while q:
    t,u,coins=heapq.heappop(q)
    if t!=d[u][coins]:continue
    amount,elapsed=exchange[u];more=min(cap,coins+amount)
    if t+elapsed<d[u][more]:d[u][more]=t+elapsed;heapq.heappush(q,(t+elapsed,u,more))
    for v,c,w in g[u]:
        if coins>=c and t+w<d[v][coins-c]:d[v][coins-c]=t+w;heapq.heappush(q,(t+w,v,coins-c))
for row in d[1:]:print(min(row))
'''
codes[59]='''
import sys
a=iter(map(int,sys.stdin.buffer.read().split()));n,t=next(a),next(a);food=sorted((next(a),next(a)) for _ in range(n));dp=[-10**20]*t;dp[0]=0;ans=0
for duration,value in food:
    ans=max(ans,max(dp)+value)
    for used in range(t-1,duration-1,-1):dp[used]=max(dp[used],dp[used-duration]+value)
print(ans)
'''
codes[61]='''
import sys,bisect
a=list(map(int,sys.stdin.buffer.read().split()));n,m=a[:2];a=sorted(a[2:]);pref=[0]
for v in a:pref.append(pref[-1]+v)
lo,hi=0,2*a[-1]+1
while hi-lo>1:
    mid=(lo+hi)//2;count=sum(n-bisect.bisect_left(a,mid-v) for v in a)
    if count>=m:lo=mid
    else:hi=mid
count=total=0
for v in a:
    i=bisect.bisect_left(a,lo-v);count+=n-i;total+=(n-i)*v+pref[-1]-pref[i]
print(total-(count-m)*lo)
'''
notes={39:'Root-path XOR gives each restriction edge mask; inclusion-exclusion on all-white path events.',47:'Keep n-k heights and bridge changed positions monotonically; DP sums positive rises. O(N^3) worst case, reviewed separately for budget.',49:'Nim zero xor requires two piles sum s and xor t; common=(s-t)/2 disjoint t. Digit DP maximizes first pile <= original and >0.',52:'Dijkstra(city,coins); cap max_edge_fare*(N-1) suffices to travel any simple path from the last exchange.',59:'Sort duration; any feasible chosen set can finish with its longest dish. Knapsack before T, last dish may overrun.',61:'Binary search ordered-pair sum threshold then sum all >= threshold and remove equal-threshold surplus.'}
D.mkdir(exist_ok=False);rows=[]
for num,code in codes.items():
 p=D/f'Code_{num:05d}'/'solution.py';p.parent.mkdir();p.write_text(textwrap.dedent(code).lstrip());rows.append({'id':f'Code_{num:05d}','path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'teacher':'current Codex assistant','visible_source_review':notes[num],'output_contract':'exact_unique','private_tests_seen_before_authoring':False})
(D/'TEACHER_TARGETS.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
print('authored',len(rows))
