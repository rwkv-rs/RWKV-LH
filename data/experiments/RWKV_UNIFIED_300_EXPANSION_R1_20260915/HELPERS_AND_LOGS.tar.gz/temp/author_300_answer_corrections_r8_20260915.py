from pathlib import Path
import sys,json,hashlib
R=Path('/home/chase/GitHub/RWKV-LH');sys.path.insert(0,str(R))
from rwkv_lh.direct_trace_data import replay_run
from rwkv_lh.model_io import parse_model_command,JSON_CALL_STOP_SUFFIXES
D=R/'data/experiments/RWKV_300_ANSWER_CORRECTIONS_R8_20260915';D.mkdir(exist_ok=False);P=R/'data/experiments/RWKV_COLLECTION_300_R1_20260915';reg=json.loads((P/'REGISTRATION.json').read_text())
corrections={1: ('已执行 python public_checks.py，检查进程退出码为0。公开样例通过；被检查程序的实际标准输出是12并带换行，标准错误为空。本次没有修改程序。', '原RWKV回答忠实；保留原引文审核失败，教师提供简洁等价标签，不算纠正了RWKV事实错误。'), 6: ('已执行 python public_checks.py，检查进程退出码为0。公开样例通过；程序实际输出 Do 并带换行，标准错误为空。本次只执行检查，没有编写或修改现有程序。', '原RWKV回答忠实；原审核多出type字段无效。独立的新简洁教师候选，不重算旧审核。'), 28: ('已执行 python public_checks.py，退出码为0。公开样例检查通过，程序实际输出3并带换行，标准错误为空。本次未修改 solution.py。', '原RWKV回答忠实；教师等价简化标签，原引文定位错误仍保留，不算学生错误修复。')}
rows=[]
for num,(answer,reason) in corrections.items():
 name=f'Code_{num:05d}-check';root=P/'runs'/(name+'-r1')/'execution';result=json.loads((root/'RESULT.json').read_text());found=[]
 for cp,actual in replay_run(root,reg['model_sha256']).items():
  try:c=parse_model_command(actual['raw_generation']['raw_output'])
  except Exception:continue
  if c.name=='final_answer' and c.arguments['text']==result['final']:found.append((cp,actual))
 assert len(found)==1;cp,actual=found[0];out=D/name;out.mkdir();(out/'ACTUAL_INPUT.json').write_text(json.dumps(actual,ensure_ascii=False,indent=2)+'\n');raw=json.dumps({'function':'final_answer','params':{'text':answer}},ensure_ascii=False)
 rows.append({'id':name,'source_run':str(root),'checkpoint_id':cp,'original_answer':result['final'],'target_text':raw+JSON_CALL_STOP_SUFFIXES[0],'teacher':'current Codex assistant','reason':reason,'input_sha256':hashlib.sha256(actual['input_text'].encode()).hexdigest(),'status':'candidate_not_admitted'})
(D/'CANDIDATES.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
