from pathlib import Path
import json,hashlib,textwrap
D=Path('/home/chase/GitHub/RWKV-LH/data/experiments/RWKV_UNIFIED_300_EXPANSION_R1_20260915/batch4')
codes={1:'''import sys,math
r,c,x,y,d,l=map(int,sys.stdin.buffer.read().split());mod=10**9+7;ans=0
for mask in range(16):
    rows=set();cols=set()
    if mask&1:rows.add(0)
    if mask&2:rows.add(x-1)
    if mask&4:cols.add(0)
    if mask&8:cols.add(y-1)
    cells=(x-len(rows))*(y-len(cols))
    if cells<d+l:continue
    ways=math.comb(cells,d+l)*math.comb(d+l,d)
    ans+=-ways if mask.bit_count()%2 else ways
print(ans*(r-x+1)*(c-y+1)%mod)
''',2:'''n=int(input());depth=n.bit_length();x=1;turn=0
while x<=n:
    x=2*x+int((turn==0)==(depth%2==1));turn^=1
print('Takahashi' if turn==0 else 'Aoki')
''',6:'''s=input().strip();pattern='WBWBWWBWBWBW'*3
for offset,name in zip((0,2,4,5,7,9,11),('Do','Re','Mi','Fa','So','La','Si')):
    if pattern[offset:offset+20]==s:print(name);break
'''}
notes={1:'Inclusion-exclusion of four empty boundaries with distinct deleted row/column sets handles X=1 or Y=1; multiply placements and type combinations.',2:'Depth parity determines whether the first player maximizes or minimizes x on its turns; opposite choice by second player.',6:'Match the full 20-key input against seven white-key offsets in repeated 12-key octave.'}
D.mkdir(exist_ok=False);rows=[]
for n,code in codes.items():
 p=D/f'Code_{n:05d}'/'solution.py';p.parent.mkdir();p.write_text(code);rows.append({'id':f'Code_{n:05d}','path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'teacher':'current Codex assistant','visible_source_review':notes[n],'output_contract':'exact_unique','private_tests_seen_before_authoring':False})
(D/'TEACHER_TARGETS.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
