from pathlib import Path
import sys,time,json,subprocess,hashlib,collections
R=Path('/home/chase/GitHub/RWKV-LH');D=R/'data/experiments/RWKV_ULTRADATA_COLLECTION_R3_20260915';start=time.monotonic()
while time.monotonic()-start<16800:
 if (D/'SOURCE_AFTER.json').exists() and (D/'ARTIFACT_RESULTS.json').exists():
  try:
   rows=json.loads((D/'RESULTS.json').read_text());checks=json.loads((D/'ARTIFACT_RESULTS.json').read_text())
   if len(rows)==len(checks):break
  except json.JSONDecodeError:pass
 if (D/'BUDGET_STOP.json').exists():raise RuntimeError('collection budget stopped; preserve partial rows for explicit review')
 time.sleep(15)
else:raise TimeoutError('collection not complete; no success inferred')
subprocess.run([sys.executable,str(R/'temp/audit_ultradata_collection_r3_20260915.py'),'runs'],check=True)
audit=json.loads((D/'runs/MECHANICAL_AUDIT.json').read_text());index=[]
for row in audit:
 for c in row['calls']:index.append({'run':row['id'],'request_id':c['request_id'],'input_checkpoint':c['input_checkpoint'],'candidate_checkpoint':c['candidate_checkpoint'],'input_sha256':c['input_sha256'],'input_tokens':c['input_tokens'],'output_tokens':c['output_tokens'],'status':'awaiting Codex correction; no automatic target label'})
(D/'BOUNDARY_INDEX.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n')
summary={'runs':len(rows),'artifact_pass':sum(c['artifact_pass'] for c in checks),'submitted':sum(x['result']['final'] is not None for x in rows),'qualified_delivery':'pending final factuality and source review; not inferred from artifact pass','terminations':dict(collections.Counter(x['result']['termination_reason'] for x in rows)),'generation_boundaries':len(index),'mechanical_audit_pass':sum(x['passed_mechanical_audit'] for x in audit),'input_tokens':sum(x['input_tokens'] for x in index),'output_tokens':sum(x['output_tokens'] for x in index),'protocol_rejections':sum(x['protocol_rejections'] for x in audit),'new_training_rows':0,'external_teacher_calls':0}
(D/'COLLECTION_SUMMARY.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');print(json.dumps(summary,ensure_ascii=False),flush=True)
