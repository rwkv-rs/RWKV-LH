from pathlib import Path
import sys,json,hashlib,shutil
R=Path('/home/chase/GitHub/RWKV-LH');sys.path.insert(0,str(R))
from rwkv_lh.direct_trace_data import replay_run
from rwkv_lh.model_io import parse_model_command,JSON_CALL_STOP_SUFFIXES
from rwkv_lh.harness import ActionHarness
from rwkv_lh.schema import GoalState,TaskAction
D=R/'data/experiments/RWKV_CODEX_CORRECTION_COLLECTION_R1_20260915';D.mkdir(exist_ok=False);P=R/'data/experiments/RWKV_ULTRADATA_CODE_PILOT_R2_20260915';reg=json.loads((P/'REGISTRATION.json').read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
save(D/'REGISTRATION.json',{'authorization':'Owner requests large-scale real failure collection and corrections by current Codex assistant. No extra account credentials used.','teacher':'current Codex assistant','scope':'Inventory all 247 real generation boundaries; first three manually authored stdin corrections verified on actual before snapshots. Known ambiguous source Code_00009 quarantined. No hidden test information in targets.','source_registration_sha256':sha(P/'REGISTRATION.json'),'helper_sha256':sha(Path(__file__)),'formal_training_admitted':False,'reason':'Candidate verification and provenance retained; no fabricated second review.'})
# These sample inputs/outputs were manually read by the assistant from public TASK.md, not private acceptance.
selected={'Code_00007-r1':('QWERTYASDFZXCV\n','5\n'),'Code_00013-r1':('3\n())\n','(())\n'),'Code_00019-r2':('10\n','9\n')}
index=[];corrected=[]
for folder in sorted((P/'runs').iterdir()):
 if not folder.is_dir():continue
 root=folder/'execution';result=json.loads((root/'RESULT.json').read_text());actuals=replay_run(root,reg['model_sha256'])
 for cp,actual in actuals.items():
  dst=D/'boundaries'/folder.name/cp;save(dst/'ACTUAL.json',actual)
  raw=actual['raw_generation']['raw_output']
  try:cmd=parse_model_command(raw);operation=cmd.name;protocol=True
  except Exception:operation=None;protocol=False
  index.append({'run':folder.name,'checkpoint_id':cp,'request_id':actual['request_id'],'actual_path':str((dst/'ACTUAL.json').relative_to(R)),'actual_sha256':sha(dst/'ACTUAL.json'),'operation':operation,'protocol_valid':protocol,'source_quarantined':folder.name.startswith('Code_00009-'),'label_status':'unreviewed_boundary_not_training_label','input_tokens':len(actual['input_token_ids'])})
 if folder.name not in selected:continue
 action_index,action=next((i,x) for i,x in enumerate(result['actions'],1) if x['action_type']=='run_command');cp,actual=next((cp,x) for cp,x in actuals.items() if x['request_id']==action['request_id']);sample,expected=selected[folder.name]
 assert sample.splitlines()[0] in actual['input_text'] and expected.strip() in actual['input_text']
 code="import subprocess, sys; r = subprocess.run([sys.executable, 'solution.py'], input="+repr(sample)+", text=True, capture_output=True, timeout=10); print(r.stdout, end=''); print(r.stderr, file=sys.stderr, end=''); assert r.returncode == 0, r.returncode; assert r.stdout == "+repr(expected)+", repr(r.stdout)"
 target=json.dumps({'function':'run_command','params':{'argv':['python','-c',code],'timeout':30}},ensure_ascii=False)+JSON_CALL_STOP_SUFFIXES[0];command=parse_model_command(target[:-len(JSON_CALL_STOP_SUFFIXES[0])]);out=D/'corrections'/folder.name;shutil.copytree(root/'tool_snapshots'/f'{action_index:03d}'/'before',out/'workspace');goal=GoalState.create(request=reg['request'],workspace_root=str(out/'workspace'),constraints=[]);obs=ActionHarness().execute(TaskAction(command.name,command.arguments),goal).to_dict();assert obs['success'] and obs['output']==expected
 record={'source_run':str(root.relative_to(R)),'checkpoint_id':cp,'request_id':actual['request_id'],'source_sha256':{n:sha(root/n) for n in ['RESULT.json','model_trace.jsonl','state_snapshot.json']},'input_sha256':hashlib.sha256(actual['input_text'].encode()).hexdigest(),'original_output':actual['raw_generation']['raw_output'],'original_tool_result':action['result'],'target_text':target,'teacher':'current Codex assistant','correction':'Use subprocess input to send visible public sample through stdin; assert actual exit and stdout, do not substitute expected text for program execution.','evidence_scope':'Public TASK.md sample and current source only. No private acceptance used.','tool_result':obs,'status':'execution_verified_candidate','training_admitted':False,'future_observation_not_in_original_input':True};save(out/'CANDIDATE.json',record);save(out/'ACTUAL_INPUT.json',actual);corrected.append(record);print(folder.name,'corrected actual stdin ->',repr(obs['output']),flush=True)
save(D/'BOUNDARY_INDEX.json',index);save(D/'CORRECTIONS.json',corrected);save(D/'SUMMARY.json',{'source_runs':40,'generation_boundaries':len(index),'protocol_invalid':sum(not x['protocol_valid'] for x in index),'manual_codex_corrections':len(corrected),'execution_verified':len(corrected),'new_formal_training_rows':0});print('boundaries',len(index),flush=True)
