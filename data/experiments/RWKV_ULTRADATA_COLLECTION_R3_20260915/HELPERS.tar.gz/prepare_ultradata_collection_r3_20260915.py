from pathlib import Path
import json,hashlib
R=Path('/home/chase/GitHub/RWKV-LH');D=R/'data/experiments/RWKV_ULTRADATA_COLLECTION_R3_20260915';P=R/'data/experiments/RWKV_ULTRADATA_CODE_PILOT_R2_20260915';reg=json.loads((P/'REGISTRATION.json').read_text());old={x['id'] for x in reg['cases']};cases=[];rejected=[];seen=[]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for row in json.loads((D/'SOURCE_ROWS.json').read_text()):
 g=row['ground_truth'];g=json.loads(g) if isinstance(g,str) else g;q=row['query'];grams={q[i:i+5] for i in range(max(0,len(q)-4))};reason=None
 if row['uuid'] in old:reason='already collected frozen pilot; no new independent source count'
 elif g.get('call_type')!='std' or g.get('fn_name') is not None or not g.get('inputs') or len(g['inputs'])!=len(g['outputs']):reason='invalid stdio schema'
 elif len(g['inputs'])>64 or max(len(s.encode()) for s in g['inputs']+g['outputs'])>1048576:reason='fixture resource cap'
 elif len(q)>12000:reason='input character cap'
 elif any(len(grams&other)/max(1,len(grams|other))>=.85 for other in seen):reason='near duplicate'
 if reason:rejected.append({'id':row['uuid'],'reason':reason});seen.append(grams);continue
 seen.append(grams);work=D/'tasks'/row['uuid'];work.mkdir(parents=True);(work/'TASK.md').write_text(q+'\n');private=D/'private'/f"{row['uuid']}.json";private.parent.mkdir(exist_ok=True);private.write_text(json.dumps(g,ensure_ascii=False)+'\n');cases.append({'id':row['uuid'],'workspace':str(work),'task_sha256':sha(work/'TASK.md'),'private_tests_path':str(private),'private_tests_sha256':sha(private),'tests':len(g['inputs'])})
assert cases
# Preserve the exact R2 frozen source and unique production builder.
s=(R/'temp/run_ultradata_code_pilot_r2_20260915.py').read_text();s=s.replace("D=R/'data/experiments/RWKV_ULTRADATA_CODE_PILOT_R2_20260915'","D=R/'data/experiments/RWKV_ULTRADATA_COLLECTION_R3_20260915'").replace('29630','29631').replace('for repeat in [1,2]:','for repeat in [1]:').replace('>=10800','>=14400');runner=R/'temp/run_ultradata_collection_r3_20260915.py';runner.write_text(s)
reg.update(cases=cases,rejected=rejected,repeats=1,runner_sha256=sha(runner),change='Expansion to new source tasks only; same frozen R2 client, model, zero State, sampling and per-task budgets. Collection, not comparative treatment arm.',registered_before_run=True,source_fetch_sha256=sha(D/'FETCH.json'));reg['budget'].update(total_calls=12*len(cases),overall_seconds=14400);reg['teacher_policy']='Current Codex assistant corrects offline real visible boundaries after collection; no external provider runtime calls. Corrections remain separate from raw RWKV outcomes.';(D/'REGISTRATION.json').write_text(json.dumps(reg,ensure_ascii=False,indent=2)+'\n')
s=(R/'temp/continue_ultradata_code_pilot_r2_20260915.py').read_text().replace("D=R/'data/experiments/RWKV_ULTRADATA_CODE_PILOT_R2_20260915'","D=R/'data/experiments/RWKV_ULTRADATA_COLLECTION_R3_20260915'").replace("unit='rwkv-lh-ultradata-code-pilot-r2.service'","unit='rwkv-lh-ultradata-collection-r3.service'").replace('ultradata_code_pilot_r2_tunnel','ultradata_collection_r3_tunnel').replace('ultradata_code_pilot_r2_service','ultradata_collection_r3_service').replace('ultradata_code_pilot_r2_state','ultradata_collection_r3_state').replace('18255','18256').replace('29630','29631').replace('run_ultradata_code_pilot_r2_20260915.py','run_ultradata_collection_r3_20260915.py').replace('RuntimeMaxSec=14400','RuntimeMaxSec=16200');(R/'temp/continue_ultradata_collection_r3_20260915.py').write_text(s)
s=(R/'temp/check_ultradata_code_pilot_r2_20260915.py').read_text().replace('RWKV_ULTRADATA_CODE_PILOT_R2_20260915','RWKV_ULTRADATA_COLLECTION_R3_20260915').replace('len(done)==40',f'len(done)=={len(cases)}').replace('<14400','<16200');(R/'temp/check_ultradata_collection_r3_20260915.py').write_text(s)
print('frozen',len(cases),'new tasks; max calls',12*len(cases))
