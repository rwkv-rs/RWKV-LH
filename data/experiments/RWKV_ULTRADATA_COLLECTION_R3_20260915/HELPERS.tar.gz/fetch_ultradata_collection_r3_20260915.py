from pathlib import Path
import requests,json,hashlib
R=Path('/home/chase/GitHub/RWKV-LH');D=R/'data/experiments/RWKV_ULTRADATA_COLLECTION_R3_20260915';tree=json.loads((R/'data/experiments/ARTICLE_DATA_REVIEW_R1_20260909/rl_audit/dataset_tree.json').read_text());f=next(x for x in tree if x['path'].startswith('data/Code/') and x['path'].endswith('.jsonl'));url='https://huggingface.co/datasets/openbmb/UltraData-RL-2609/resolve/e6ecfa733708a4c54b5a98c3ca0fd16fc6923790/'+f['path'];limit=512*1024*1024
with requests.get(url,headers={'Range':f'bytes=0-{limit-1}'},timeout=(10,60),stream=True) as response:
 response.raise_for_status();buf=b'';size=0;rows=[]
 for chunk in response.iter_content(65536):
  size+=len(chunk)
  if size>limit:break
  buf+=chunk
  while b'\n' in buf:
   line,buf=buf.split(b'\n',1)
   if line:rows.append(json.loads(line))
  if len(rows)>=180:break
(D/'SOURCE_ROWS.json').write_text(json.dumps(rows,ensure_ascii=False)+'\n');(D/'FETCH.json').write_text(json.dumps({'url':url,'revision':'e6ecfa733708a4c54b5a98c3ca0fd16fc6923790','bytes_received':size,'max_bytes':limit,'complete_rows':len(rows),'selection':'first180complete or512MiB cap; deterministic prefix, not random representative','sha256':hashlib.sha256((D/'SOURCE_ROWS.json').read_bytes()).hexdigest()},indent=2)+'\n');print('fetched',len(rows),size,flush=True)
