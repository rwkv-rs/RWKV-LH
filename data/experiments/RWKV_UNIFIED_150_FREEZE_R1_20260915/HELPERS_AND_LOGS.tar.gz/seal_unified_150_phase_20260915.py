from pathlib import Path
import json,hashlib,collections,tarfile,subprocess
R=Path('/home/chase/GitHub/RWKV-LH');D=R/'data/experiments/RWKV_UNIFIED_150_FREEZE_R1_20260915';P=R/'data/experiments/RWKV_FEEDBACK_COLLECTION_150_R1_20260915';data=R/'data/datasets/rwkv_direct_unified_corrections_v5';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
test=R/'temp/unified_150_full_tests_20260915.log';assert '1833 passed' in test.read_text() and 'skipped' not in test.read_text()
old=(R/'data/datasets/rwkv_direct_unified_corrections_v4/train.jsonl').read_bytes().splitlines(keepends=True);lines=(data/'train.jsonl').read_bytes().splitlines(keepends=True);assert len(lines)==150 and old==lines[:85];rows=[json.loads(l) for l in lines]
ids=[(r['source_id'],r['request_id']) for r in rows];exact=[(hashlib.sha256(r['input_text'].encode()).hexdigest(),r['target_text']) for r in rows];assert len(set(ids))==len(set(exact))==150
save(D/'COVERAGE_AND_DEDUP.json',{'rows':150,'old85_byte_identical':True,'old_prefix_sha256':hashlib.sha256(b''.join(lines[:85])).hexdigest(),'unique_source_request_pairs':len(set(ids)),'unique_exact_input_target_pairs':len(set(exact)),'new_boundary_types':{'first_complete_read':26,'public_check_command':28,'after_command_answer':11},'all_operation_counts':{'read':54,'answer':35,'edit':29,'command':32},'semantic_repetition':{'largest_new_identical_target_group':max(collections.Counter(r['target_text'] for r in rows[85:]).values()),'explanation':'28 command instances share python public_checks.py; different original program snapshots/outcomes, not28 distinct tool behaviors. No claim65new independent problems.','training_caution':'Measure mixing weights and post-command regression; do not treat row count as behavioral diversity.'},'new_actual_model_failures_corrected_and_admitted':['Code_00056-student wrong expected value'],'new_unchanged_truthful_answers':10,'new_admitted_post_command_answers':11,'remaining_missing':'Observed failing tests followed by autonomous repair and multi-file integration remain underrepresented. Code7 student factual correction pending valid independent citation review.'})
proc=subprocess.run(['ssh','rwkv-8222','systemctl --user is-active rwkv-lh-native-current.service; curl -fsS http://127.0.0.1:18234/metrics | grep -E "^vllm:num_requests_(running|waiting)"'],capture_output=True,text=True);assert proc.returncode==0;(D/'RUNTIME_RESTORED.txt').write_text(proc.stdout)
(D/'FULL_TESTS.log').write_bytes(test.read_bytes())
(D/'REPORT.zh-CN.md').write_text('''# 统一StateTune正式数据达到150条

## 任务结果与范围

28个新验证任务全部结束：实际执行公开检查并忠实报告26/28，提交28、文件修改0；全部自然提交，没有预算中断。已提供程序的公开检查通过25、失败3，失败是有效观察而非验证任务必败。两个不合格报告分别把样例期望值编造为20，以及混淆checker退出码、被测程序退出码和实际输出。不是项目Strict，不是28个自主编程成功项目，也不是训练收益。

全部56次真实RWKV生成，213365精确输入token、4496输出token，协议拒绝0，28/28输入/观察/State父链核验；集合运行201.135秒。只用GPU0，现已恢复原zero服务空闲，临时服务关闭。不预设并发或低成本收益。

## 正式训练数据

v5已冻结150条，v4原85条逐字节保留。新增26个不同原题的首次完整读取、28个真实工件上的公开检查命令、11个真实检查观察后的回答。合计读取54、回答35、修改29、命令32。不是新增65个独立问题：28检查命令来自25个既有问题的工件及3个原学生失败版本，命令形状相同，明确计入语义重复审计，不宣称28种工具能力。

11个新回答中，10个是保留的RWKV真实正确回答，1个是当前Codex亲自纠正的错误期望值回答，且未泄露当时不可见的真正期望58。目标只说实际观察20/通过、59/失败以及checker1/child0。Code7错误也已由Codex纠正，但独立审核引文无效，保留候选未放行；不自动修理审核输出、不重算旧结果。

命令由Codex给出当前目标对应的真实工具调用，另经独立模型审核及Harness实际运行；默认期待成功的调用在真实失败时保留exit1，不用未来信息改成预期成功。回答由Codex逐条对照真实观察，再独立审核。独立审核只判断候选，不为生产模型逐步把关，也不代写教师答案。

固定回归未换，源身份/原生token/完整上下文/家族切分/相似度全部核验；所有代码和命令证明在冻结时重新执行。150个source/request及精确input/target组合唯一，不复制同一生成凑数。保留同命令多工件实例的分布与权重风险。最大序列24455 token，未截断。

## 审核成本与失败

独立审核共61请求，322753输入/21015输出token，其中251776缓存输入token；累加响应延迟113698ms，不当作并发端到端延迟。请求结果28命令验证候选、11回答接受、1语义拒绝、21格式/引文错误，原始输入与响应全部保留。21审核接口失败不能解释为21个RWKV回答错误。Codex当前会话token/费用未得到可核验账单，不能称教师费用0。

## 本阶段完成与后续

本阶段已完成采集、亲自纠正、独立审核、真实验证、去重、正式150条冻结以及完整1833回归（0跳过），本地提交，不push。训练0步。新增11条真实执行后回答填补了此前对应输入缺口，但还不能说明模型已学会。

下一阶段应冻结统一训练/验证预算，用同一回归比较zero与候选，重点查实际输出、退出码、期望值、通过/失败归属，以及执行后推进；不要按每种错误分别训练State。相同命令实例的权重及有效行为覆盖需如实测量，不能仅凭150条称能自主完成复杂Code Agent项目。现有rwkv-peft/Native身份与三个参考项目的边界不变，不把数据完成冒称已训练。
''')
with tarfile.open(D/'HELPERS_AND_LOGS.tar.gz','w:gz') as tar:
 for n in ['prepare_feedback_collection_150_r1_20260915.py','run_feedback_collection_150_r1_20260915.py','continue_feedback_collection_150_r1_20260915.py','audit_feedback_collection_150_r1_20260915.py','review_feedback_commands_150_r1_20260915.py','review_feedback_answers_150_r1_20260915.py','review_feedback_corrections_150_r2_20260915.py','review_feedback_finish_150_r3_20260915.py','prepare_unified_150_base_r1_20260915.py','freeze_unified_150_v5_r1_20260915.py','audit_unified_150_phase_20260915.py','seal_unified_150_phase_20260915.py']:
  tar.add(R/'temp'/n,arcname=n)
 for n in ['continue_feedback_collection_150_r1_20260915.log','review_feedback_commands_150_r1_20260915.log','review_feedback_answers_150_r1_20260915.log','review_feedback_corrections_150_r2_20260915.log','review_feedback_finish_150_r3_20260915.log','freeze_unified_150_v5_r1_20260915.log']:
  tar.add(R/'temp'/n,arcname=n)
folders=[P,R/'data/experiments/RWKV_FEEDBACK_COMMAND_REVIEW_150_R1_20260915',R/'data/experiments/RWKV_FEEDBACK_ANSWER_REVIEW_150_R1_20260915',R/'data/experiments/RWKV_FEEDBACK_ANSWER_CORRECTIONS_150_R2_20260915',R/'data/experiments/RWKV_FEEDBACK_REVIEW_FINISH_150_R3_20260915']
for base in folders:
 save(base/'RAW_MANIFEST.json',{str(p.relative_to(R)):sha(p) for p in base.rglob('*') if p.is_file() and p.name not in ('RAW_MANIFEST.json','SHA256.json')});save(base/'SHA256.json',{p.name:sha(p) for p in base.iterdir() if p.is_file() and p.name!='SHA256.json'})
save(D/'RAW_MANIFEST.json',{str(p.relative_to(R)):sha(p) for p in (D/'sources').rglob('*') if p.is_file()});save(D/'SHA256.json',{p.name:sha(p) for p in D.iterdir() if p.is_file() and p.name!='SHA256.json'})
p=R/'docs/HANDOFF.zh-CN.md';s=p.read_text();i=s.index('**最新：');j=s.index('\n\n',i);s=s[:i]+'**最新：统一StateTune v5正式150条，旧85逐字节保留；新增26读取、28检查命令、11真实命令观察后回答。28验证任务26/28忠实完成，不是自主编程成功率。56真实生成/0协议错/28链路核验通过，1833回归通过、0跳过。训练0、GPU仅0、原服务恢复、owner修改保留、未push。详见[150条阶段报告](../data/experiments/RWKV_UNIFIED_150_FREEZE_R1_20260915/REPORT.zh-CN.md)。**'+s[j:];p.write_text(s)
p=R/'docs/STATETUNE_10000_PLAN.zh-CN.md';s=p.read_text();pos=s.index('\n## 最新优先级');s=s[:pos]+'\n## 2026-09-15统一数据150条目标已完成\n\nv5现为150条（54读取/35回答/29修改/32命令），保留v4全部85条，新11回答来自真实测试观察。65新增边界不等于65新问题，28检查调用具有同一命令形状，语义重复和权重风险已记录。当前训练0步，固定回归未改；下一步登记统一训练预算并检查事实忠实与执行后推进，不按问题分别训练State。详见RWKV_UNIFIED_150_FREEZE_R1_20260915。\n'+s[pos:];p.write_text(s)
print('sealed150')
