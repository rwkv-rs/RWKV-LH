from pathlib import Path
from dataclasses import replace
import sys,json,hashlib,time
R=Path('/home/chase/GitHub/RWKV-LH');sys.path.insert(0,str(R))
from rwkv_lh.direct_trace_data import replay_run
from rwkv_lh.correction_review import build_review_packet,validate_review,REVIEW_INSTRUCTION,REVIEW_SCHEMA
from rwkv_lh.strong_session import AuditedStrongClient
from rwkv_lh.supervisor_openai import SupervisorAPISettings
from rwkv_lh.runtime.settings import load_local_env
from rwkv_lh.model_io import parse_model_command,JSON_CALL_STOP_SUFFIXES
D=R/'data/experiments/RWKV_FEEDBACK_ANSWER_REVIEW_150_R1_20260915';D.mkdir(exist_ok=False);P=R/'data/experiments/RWKV_FEEDBACK_COLLECTION_150_R1_20260915';reg=json.loads((P/'REGISTRATION.json').read_text());load_local_env(R/'.env.local');settings=replace(SupervisorAPISettings.from_env(),retry_attempts=1,semantic_repair_attempts=0,fallback_models=(),plan_cache_enabled=False,planner_request_options={'thinking':{'type':'disabled'}},read_timeout_seconds=90)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
save(D/'REGISTRATION.json',{'source_registration_sha256':sha(P/'REGISTRATION.json'),'helper_sha256':sha(Path(__file__)),'settings':settings.public_dict(),'max_external_calls':28,'max_output_tokens':3072,'scope':'Independent review of unchanged RWKV original final answers only. Current Codex manually checks original command observations separately before admission. No answer synthesis or automatic repair. Non-submissions remain failures.','training_steps':0})
rows=[];done=set();start=time.monotonic()
while len(done)<len(reg['cases']) and time.monotonic()-start<14400:
 for case in reg['cases']:
  name=case['id'];root=P/'runs'/(name+'-r1')/'execution'
  if name in done or not (root/'RESULT.json').exists():continue
  done.add(name);out=D/name
  try:
   result=json.loads((root/'RESULT.json').read_text())
   if result['final'] is None:rows.append({'id':name,'status':'no_final'});save(D/'RESULTS.json',rows);continue
   found=[]
   for cp,actual in replay_run(root,reg['model_sha256']).items():
    try:c=parse_model_command(actual['raw_generation']['raw_output'])
    except Exception:continue
    if c.name=='final_answer' and c.arguments['text']==result['final']:found.append((cp,actual))
   assert len(found)==1;cp,actual=found[0];raw=actual['raw_generation']['raw_output'];packet=build_review_packet(actual_rwkv_input=actual['input_text'],candidate=raw);save(out/'ACTUAL_INPUT.json',actual);save(out/'PACKET.json',packet)
   def audit(e):
    with (out/'strong_trace.jsonl').open('a') as f:f.write(json.dumps(dict(e),ensure_ascii=False)+'\n')
   client=AuditedStrongClient(settings,audit_hook=audit)
   try:v=client._request_json(phase='state_tune_target_review',run_id=name,request_digest=hashlib.sha256(json.dumps(packet).encode()).hexdigest(),system_prompt=REVIEW_INSTRUCTION,request_payload=packet,schema=REVIEW_SCHEMA,max_tokens=3072)
   finally:client.close()
   save(out/'RAW_REVIEW.json',v);checked=validate_review(packet,v);save(out/'VALIDATED_REVIEW.json',checked);rows.append({'id':name,'status':'accepted' if checked['accepted'] else 'rejected','issues':checked['issues'],'checkpoint_id':cp,'target_text':raw+JSON_CALL_STOP_SUFFIXES[0],'independent_review_path':str(out/'VALIDATED_REVIEW.json'),'independent_review_sha256':sha(out/'VALIDATED_REVIEW.json'),'codex_semantic_review':'pending explicit per-answer audit'})
  except Exception as e:rows.append({'id':name,'status':'error','error':type(e).__name__+': '+str(e)})
  save(D/'RESULTS.json',rows);print(rows[-1]['id'],rows[-1]['status'],flush=True)
 if len(done)<len(reg['cases']):time.sleep(10)
