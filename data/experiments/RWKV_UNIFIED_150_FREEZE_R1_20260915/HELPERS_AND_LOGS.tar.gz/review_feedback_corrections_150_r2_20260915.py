from pathlib import Path
from dataclasses import replace
import sys,json,hashlib
R=Path('/home/chase/GitHub/RWKV-LH');sys.path.insert(0,str(R))
from rwkv_lh.correction_review import build_review_packet,validate_review,REVIEW_INSTRUCTION,REVIEW_SCHEMA
from rwkv_lh.strong_session import AuditedStrongClient
from rwkv_lh.supervisor_openai import SupervisorAPISettings
from rwkv_lh.runtime.settings import load_local_env
from rwkv_lh.model_io import JSON_CALL_STOP_SUFFIXES
D=R/'data/experiments/RWKV_FEEDBACK_ANSWER_CORRECTIONS_150_R2_20260915';D.mkdir(exist_ok=False);P=R/'data/experiments/RWKV_FEEDBACK_ANSWER_REVIEW_150_R1_20260915';load_local_env(R/'.env.local');settings=replace(SupervisorAPISettings.from_env(),retry_attempts=1,semantic_repair_attempts=0,fallback_models=(),plan_cache_enabled=False,planner_request_options={'thinking':{'type':'disabled'}},read_timeout_seconds=90)
answers={
'Code_00056-student':'已实际运行 public_checks.py，检查器退出码为 1，公开检查未全部通过。第 1 个样例的实际输出为 20，通过；第 2 个样例的实际输出为 59，未通过。两个样例中的被测程序退出码都是 0。观察没有提供期望输出，不能把第 1 个样例的 20 当成第 2 个样例的期望值。本次没有修改或编写程序。',
'Code_00007-student':'已实际运行 public_checks.py，检查器退出码为 1。第 1、2 个样例通过，实际输出分别为 5、4；第 3 个样例失败，实际输出为 0。三个样例中的被测程序退出码均为 0，标准错误均为空。检查器退出码、被测程序退出码和输出数值是不同字段。本次未修改程序。',
'Code_00086-student':'已实际运行 public_checks.py，检查器退出码为 1，公开检查失败。唯一的样例实际输出为 3，被测程序退出码为 0，标准错误为空，检查结果为未通过。本次没有修改或编写程序。'
}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
save(D/'REGISTRATION.json',{'helper_sha256':sha(Path(__file__)),'settings':settings.public_dict(),'max_calls':3,'max_tokens':3072,'answers_frozen_before_review':answers,'teacher':'current Codex assistant','origin':'Code56 and Code7 correct real factual errors. Code86 is a truthful rephrasing of already correct raw answer after invalid external citation review, not a model failure.','no_new_model_input':True,'prior_results_unchanged':True})
rows=[]
for name,text in answers.items():
 actual=json.loads((P/name/'ACTUAL_INPUT.json').read_text());raw=json.dumps({'function':'final_answer','params':{'text':text}},ensure_ascii=False);packet=build_review_packet(actual_rwkv_input=actual['input_text'],candidate=raw);out=D/name;save(out/'PACKET.json',packet);save(out/'ACTUAL_INPUT.json',actual)
 def audit(e):
  with (out/'strong_trace.jsonl').open('a') as f:f.write(json.dumps(dict(e),ensure_ascii=False)+'\n')
 client=AuditedStrongClient(settings,audit_hook=audit)
 try:
  v=client._request_json(phase='state_tune_target_review',run_id=name,request_digest=hashlib.sha256(json.dumps(packet).encode()).hexdigest(),system_prompt=REVIEW_INSTRUCTION,request_payload=packet,schema=REVIEW_SCHEMA,max_tokens=3072);save(out/'RAW_REVIEW.json',v);valid=validate_review(packet,v);save(out/'VALIDATED_REVIEW.json',valid);row={'id':name,'status':'accepted' if valid['accepted'] else 'rejected','issues':valid['issues'],'target_text':raw+JSON_CALL_STOP_SUFFIXES[0],'independent_review_path':str(out/'VALIDATED_REVIEW.json'),'independent_review_sha256':sha(out/'VALIDATED_REVIEW.json'),'codex_authored':True}
 except Exception as e:row={'id':name,'status':'error','error':type(e).__name__+': '+str(e)}
 finally:client.close()
 rows.append(row);save(D/'RESULTS.json',rows);print(name,row['status'],flush=True)
