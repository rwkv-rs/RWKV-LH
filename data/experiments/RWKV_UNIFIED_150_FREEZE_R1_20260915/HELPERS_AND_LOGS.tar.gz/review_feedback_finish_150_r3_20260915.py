from pathlib import Path
from dataclasses import replace
import sys,json,hashlib
R=Path('/home/chase/GitHub/RWKV-LH');sys.path.insert(0,str(R))
from rwkv_lh.correction_review import build_review_packet,validate_review,REVIEW_INSTRUCTION,REVIEW_SCHEMA
from rwkv_lh.strong_session import AuditedStrongClient
from rwkv_lh.supervisor_openai import SupervisorAPISettings
from rwkv_lh.runtime.settings import load_local_env
from rwkv_lh.model_io import JSON_CALL_STOP_SUFFIXES
from rwkv_lh.command_corrections import validate_command_correction
from rwkv_lh.correction_snapshots import validate_generation_snapshot
from rwkv_lh.workspace_snapshot import copy_verified_workspace
from rwkv_lh.harness import ActionHarness
from rwkv_lh.schema import GoalState,TaskAction
from rwkv_lh.direct_trace_data import replay_run
D=R/'data/experiments/RWKV_FEEDBACK_REVIEW_FINISH_150_R3_20260915';D.mkdir(exist_ok=False);P=R/'data/experiments/RWKV_FEEDBACK_COLLECTION_150_R1_20260915';reg=json.loads((P/'REGISTRATION.json').read_text());load_local_env(R/'.env.local');settings=replace(SupervisorAPISettings.from_env(),retry_attempts=1,semantic_repair_attempts=0,fallback_models=(),plan_cache_enabled=False,planner_request_options={'thinking':{'type':'disabled'}},read_timeout_seconds=90)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
answer='已运行 public_checks.py，检查器退出码为 1，整体检查失败。第 1 个样例实际输出 5，检查通过。第 2 个样例实际输出 4，检查通过。第 3 个样例实际输出 0，检查失败；该样例的被测程序退出码为 0，标准错误为空。本次没有修改程序。'
save(D/'REGISTRATION.json',{'max_calls':2,'max_tokens':3072,'helper_sha256':sha(Path(__file__)),'settings':settings.public_dict(),'scope':'New prospective command review after malformed prior review; new Codex answer with separate clauses, identical facts to prior correction. No prior results rescored or parser changes.','frozen_answer':answer})
rows=[]
for name,kind in [('Code_00072-verified','command'),('Code_00007-student','answer')]:
 origin=R/'data/experiments'/('RWKV_FEEDBACK_COMMAND_REVIEW_150_R1_20260915' if kind=='command' else 'RWKV_FEEDBACK_ANSWER_REVIEW_150_R1_20260915')/name;actual=json.loads((origin/'ACTUAL_INPUT.json').read_text());root=P/'runs'/(name+'-r1')/'execution';cp=next(cp for cp,a in replay_run(root,reg['model_sha256']).items() if a['request_id']==actual['request_id']);raw=json.dumps({'function':'run_command','params':{'argv':['python','public_checks.py'],'timeout':30}}) if kind=='command' else json.dumps({'function':'final_answer','params':{'text':answer}},ensure_ascii=False);target=raw+JSON_CALL_STOP_SUFFIXES[0];packet=build_review_packet(actual_rwkv_input=actual['input_text'],candidate=raw);out=D/name;save(out/'PACKET.json',packet);save(out/'ACTUAL_INPUT.json',actual)
 def audit(e):
  with (out/'strong_trace.jsonl').open('a') as f:f.write(json.dumps(dict(e),ensure_ascii=False)+'\n')
 client=AuditedStrongClient(settings,audit_hook=audit)
 try:
  value=client._request_json(phase='state_tune_target_review',run_id=name,request_digest=hashlib.sha256(json.dumps(packet).encode()).hexdigest(),system_prompt=REVIEW_INSTRUCTION,request_payload=packet,schema=REVIEW_SCHEMA,max_tokens=3072);save(out/'RAW_REVIEW.json',value);valid=validate_review(packet,value);save(out/'VALIDATED_REVIEW.json',valid);assert valid['accepted'],valid['issues'];row={'id':name,'kind':kind,'status':'accepted','checkpoint_id':cp,'target_text':target,'independent_review_path':str(out/'VALIDATED_REVIEW.json'),'independent_review_sha256':sha(out/'VALIDATED_REVIEW.json')}
  if kind=='command':
   reviews=[{'reviewer':who,'accepted':True,'visible_evidence_only':True,'input_sha256':hashlib.sha256(actual['input_text'].encode()).hexdigest(),'target_sha256':hashlib.sha256(target.encode()).hexdigest()} for who in ['current Codex assistant: goal-bound command review','independent '+settings.model+' reviewer']];files={str(p.relative_to(root)):sha(p) for p in root.rglob('*') if p.is_file()};before=validate_generation_snapshot(root,actual,files);copy_verified_workspace(before,out/'probe');obs=ActionHarness().execute(TaskAction('run_command',{'argv':['python','public_checks.py'],'timeout':30}),GoalState.create(request=reg['request'],workspace_root=str(out/'probe'),constraints=[])).to_dict();proof=validate_command_correction(run_root=root,checkpoint_id=cp,target_text=target,model_sha256=reg['model_sha256'],source_files=files,reviews=reviews,expected_exit_code=obs['exit_code'],expected_output=[obs['output']],output=out/'validation');assert proof['status']=='validated_candidate';row.update(status=proof['status'],proof_path=str(out/'validation/VALIDATION.json'),proof_sha256=sha(out/'validation/VALIDATION.json'))
 except Exception as e:row={'id':name,'kind':kind,'status':'error','error':type(e).__name__+': '+str(e)}
 finally:client.close()
 rows.append(row);save(D/'RESULTS.json',rows);print(row['id'],row['status'],flush=True)
