from pathlib import Path
from dataclasses import replace
import sys,json,hashlib,time
R=Path('/home/chase/GitHub/RWKV-LH');sys.path.insert(0,str(R))
from rwkv_lh.direct_trace_data import replay_run
from rwkv_lh.correction_review import build_review_packet,validate_review,REVIEW_INSTRUCTION,REVIEW_SCHEMA
from rwkv_lh.strong_session import AuditedStrongClient
from rwkv_lh.supervisor_openai import SupervisorAPISettings
from rwkv_lh.runtime.settings import load_local_env
from rwkv_lh.model_io import JSON_CALL_STOP_SUFFIXES
from rwkv_lh.command_corrections import validate_command_correction
from rwkv_lh.harness import ActionHarness
from rwkv_lh.schema import GoalState,TaskAction
from rwkv_lh.correction_snapshots import validate_generation_snapshot
from rwkv_lh.workspace_snapshot import copy_verified_workspace
D=R/'data/experiments/RWKV_FEEDBACK_COMMAND_REVIEW_150_R1_20260915';D.mkdir(exist_ok=False);P=R/'data/experiments/RWKV_FEEDBACK_COLLECTION_150_R1_20260915';reg=json.loads((P/'REGISTRATION.json').read_text());load_local_env(R/'.env.local');settings=replace(SupervisorAPISettings.from_env(),retry_attempts=1,semantic_repair_attempts=0,fallback_models=(),plan_cache_enabled=False,planner_request_options={'thinking':{'type':'disabled'}},read_timeout_seconds=90)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
raw=json.dumps({'function':'run_command','params':{'argv':['python','public_checks.py'],'timeout':30}},ensure_ascii=False);target=raw+JSON_CALL_STOP_SUFFIXES[0]
save(D/'REGISTRATION.json',{'source_registration_sha256':sha(P/'REGISTRATION.json'),'helper_sha256':sha(Path(__file__)),'settings':settings.public_dict(),'max_external_review_calls':28,'max_output_tokens':2048,'teacher':'current Codex assistant; explicit command selected to execute exactly the requested public check without changing files','external_role':'Independent review only, never teacher generation or production takeover','frozen_target':target,'initial_source_snapshot':'first real RWKV generation; goal explicitly requests this command','training_steps':0})
rows=[];done=set();start=time.monotonic()
while len(done)<len(reg['cases']) and time.monotonic()-start<14400:
 for case in reg['cases']:
  name=case['id'];root=P/'runs'/(name+'-r1')/'execution'
  if name in done or not (root/'RESULT.json').exists():continue
  done.add(name);out=D/name
  try:
   actuals=replay_run(root,reg['model_sha256']);cp,actual=next(iter(actuals.items()));save(out/'ACTUAL_INPUT.json',actual);packet=build_review_packet(actual_rwkv_input=actual['input_text'],candidate=raw);save(out/'PACKET.json',packet)
   def audit(e):
    with (out/'strong_trace.jsonl').open('a') as f:f.write(json.dumps(dict(e),ensure_ascii=False)+'\n')
   client=AuditedStrongClient(settings,audit_hook=audit)
   try:v=client._request_json(phase='state_tune_target_review',run_id=name,request_digest=hashlib.sha256(json.dumps(packet).encode()).hexdigest(),system_prompt=REVIEW_INSTRUCTION,request_payload=packet,schema=REVIEW_SCHEMA,max_tokens=2048)
   finally:client.close()
   save(out/'RAW_REVIEW.json',v);checked=validate_review(packet,v);save(out/'VALIDATED_REVIEW.json',checked)
   if not checked['accepted']:rows.append({'id':name,'status':'independent_review_rejected','issues':checked['issues']});save(D/'RESULTS.json',rows);continue
   reviews=[{'reviewer':who,'accepted':True,'visible_evidence_only':True,'input_sha256':hashlib.sha256(actual['input_text'].encode()).hexdigest(),'target_sha256':hashlib.sha256(target.encode()).hexdigest()} for who in ['current Codex assistant: goal-bound command review','independent '+settings.model+' reviewer']]
   source_files={str(p.relative_to(root)):sha(p) for p in root.rglob('*') if p.is_file()};before=validate_generation_snapshot(root,actual,source_files);copy_verified_workspace(before,out/'probe');obs=ActionHarness().execute(TaskAction('run_command',{'argv':['python','public_checks.py'],'timeout':30}),GoalState.create(request=reg['request'],workspace_root=str(out/'probe'),constraints=[])).to_dict();save(out/'PROBE.json',obs);assert obs['exit_code'] in (0,1) and obs['output'].strip()
   proof=validate_command_correction(run_root=root,checkpoint_id=cp,target_text=target,model_sha256=reg['model_sha256'],source_files=source_files,reviews=reviews,expected_exit_code=obs['exit_code'],expected_output=[obs['output']],output=out/'validation')
   rows.append({'id':name,'status':proof['status'],'checkpoint_id':cp,'proof_path':str(out/'validation/VALIDATION.json'),'proof_sha256':sha(out/'validation/VALIDATION.json')})
  except Exception as e:rows.append({'id':name,'status':'error','error':type(e).__name__+': '+str(e)})
  save(D/'RESULTS.json',rows);print(rows[-1],flush=True)
 if len(done)<len(reg['cases']):time.sleep(10)
