from pathlib import Path
from dataclasses import replace
import sys,json,hashlib,datetime
R=Path('/home/chase/GitHub/RWKV-LH');sys.path.insert(0,str(R))
from rwkv_lh.correction_review import build_review_packet,validate_review,REVIEW_INSTRUCTION,REVIEW_SCHEMA
from rwkv_lh.strong_session import AuditedStrongClient
from rwkv_lh.supervisor_openai import SupervisorAPISettings
from rwkv_lh.runtime.settings import load_local_env
D=R/'data/experiments/RWKV_POST_COMMAND_ANSWER_REVIEW_R1_20260915';D.mkdir(exist_ok=False)
load_local_env(R/'.env.local');settings=replace(SupervisorAPISettings.from_env(),retry_attempts=1,semantic_repair_attempts=0,fallback_models=(),plan_cache_enabled=False,planner_request_options={'thinking':{'type':'disabled'}},read_timeout_seconds=120)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
p=R/'data/experiments/RWKV_FAILED_TEST_REPORT_COLLECTION_R1_20260915/PENDING_REVIEW_PACKETS.json';sources=json.loads(p.read_text())
save(D/'REGISTRATION.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_sha256':sha(p),'helper_sha256':sha(Path(__file__)),'review_module_sha256':sha(R/'rwkv_lh/correction_review.py'),'max_calls':4,'max_tokens_per_call':4096,'settings':settings.public_dict(),'scope':'Two independent contexts per source, same provider/model; not independent providers. No earlier judgment or future evidence enters another review. No new dataset or training. Original source unchanged.'})
summary=[]
for source in sources:
 inp=(R/source['source_input_path']).read_text();assert hashlib.sha256(inp.encode()).hexdigest()==source['source_input_sha256']
 envelope=json.loads(source['original_raw_output']);envelope['params']['text']=source['candidate_text']
 packet=build_review_packet(actual_rwkv_input=inp,candidate=json.dumps(envelope,ensure_ascii=False));root=D/source['source_run'];save(root/'PACKET.json',packet)
 for repeat in (1,2):
  dest=root/f'review-{repeat}';dest.mkdir()
  def audit(e):
   with (dest/'strong_trace.jsonl').open('a') as f:f.write(json.dumps(dict(e),ensure_ascii=False)+'\n')
  client=AuditedStrongClient(settings,audit_hook=audit)
  try:
   v=client._request_json(phase='state_tune_target_review',run_id=source['source_run'],request_digest=hashlib.sha256(json.dumps(packet).encode()).hexdigest(),system_prompt=REVIEW_INSTRUCTION,request_payload=packet,schema=REVIEW_SCHEMA,max_tokens=4096)
   save(dest/'RAW_REVIEW.json',v);validated=validate_review(packet,v);save(dest/'VALIDATED_REVIEW.json',validated);row={'source':source['source_run'],'repeat':repeat,'accepted':validated['accepted'],'issues':validated['issues'],'training_admitted':False}
  except Exception as e:row={'source':source['source_run'],'repeat':repeat,'accepted':False,'error':type(e).__name__+': '+str(e),'training_admitted':False};save(dest/'ERROR.json',row)
  finally:client.close()
  summary.append(row);save(D/'RESULTS.json',summary);print(json.dumps(row,ensure_ascii=False),flush=True)
