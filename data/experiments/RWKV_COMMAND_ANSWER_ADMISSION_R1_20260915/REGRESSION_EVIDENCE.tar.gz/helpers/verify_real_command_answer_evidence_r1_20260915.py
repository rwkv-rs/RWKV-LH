from pathlib import Path
import json,hashlib,sys
R=Path('/home/chase/GitHub/RWKV-LH');sys.path.insert(0,str(R));from rwkv_lh.direct_trace_data import replay_run,_complete_observed_text_hashes
from rwkv_lh.schema import RunState
D=R/'data/experiments/RWKV_COMMAND_ANSWER_ADMISSION_R1_20260915';rows=[]
for name in ['run-recursive-zero-r1','run-recursive-zero-r2']:
 p=R/'data/experiments/RWKV_UNIFIED_CORRECTION_TRAIN_R4_20260915/evaluation/coding'/name/'execution';actual=replay_run(p,'559371f5b9aef13189ae54b345ac096af4ad2b689996c05d89de687612b3ae65');state=RunState.from_dict(json.loads((p/'state_snapshot.json').read_text()));boundary=next(r for r in actual.values() if 'final_answer' in r['raw_generation']['raw_output']);cp=state.model_states[boundary['input_checkpoint_id']];visible=set()
 while cp:
  visible.update(cp.event_ids);cp=state.model_states.get(cp.parent_checkpoint_id)
 for eid in visible:
  e=state.model_events[eid];result=e.payload.get('result',{});streams=result.get('command_streams',[])
  if not streams:continue
  old=[];obs=result.get('observation',{})
  if obs.get('projection_complete'):old=[hashlib.sha256(''.join(x['content'] for x in obs.get('exact_spans',[])).encode()).hexdigest()]
  new=_complete_observed_text_hashes(result);stdout=next(s for s in streams if s['stream']=='stdout');assert stdout['stream_sha256'] not in old and stdout['stream_sha256'] in new
  rows.append({'source':str(p),'request_id':boundary['request_id'],'input_checkpoint_id':boundary['input_checkpoint_id'],'input_sha256':hashlib.sha256(boundary['input_text'].encode()).hexdigest(),'source_model_trace_sha256':hashlib.sha256((p/'model_trace.jsonl').read_bytes()).hexdigest(),'event_id':eid,'actual_exit_code':result['exit_code'],'stdout_sha256':stdout['stream_sha256'],'old_bound':False,'new_bound':True,'observed_text':''.join(s['content'] for s in stdout['exact_spans']),'scope':'Read-only actual dev trace used only to reproduce engineering gate. No label generation/admission or evaluation score change.'})
training=R/'data/datasets/rwkv_direct_unified_corrections_v3/train.jsonl';answer_checks=[]
for row in map(json.loads,training.read_text().splitlines()):
 if row['label_authority']!='independent_review':continue
 evs=[json.loads(line[len('User: Function output: '):]) for line in row['input_text'].splitlines() if line.startswith('User: Function output: ')];hashes=[]
 for e in evs:hashes.extend(_complete_observed_text_hashes(e['payload'].get('result',{})))
 assert row['source_content_sha256'] in hashes;answer_checks.append(row['sample_id'])
(D/'REAL_TRACE_PROBE.json').write_text(json.dumps({'real_command_boundaries':rows,'existing_v3_answer_rows_unchanged':answer_checks,'training_file_sha256':hashlib.sha256(training.read_bytes()).hexdigest(),'new_datasets':0,'new_training_steps':0},ensure_ascii=False,indent=2)+'\n');print('real command boundaries',len(rows),'existing answer rows',len(answer_checks))
