"""Supplemental structural evidence. Does not overwrite frozen audit or semantic scores."""
import json
from rwkv_lh.model import LongHorizonModel

def request_in_bootstrap(transcript,request):
 packets=[json.loads(line.removeprefix('User: ')) for line in transcript.splitlines() if line.startswith('User: ')]
 expected=LongHorizonModel.create_literal_goal(request,'.').request
 return len(packets)==1 and packets[0].get('immutable_request')==expected
