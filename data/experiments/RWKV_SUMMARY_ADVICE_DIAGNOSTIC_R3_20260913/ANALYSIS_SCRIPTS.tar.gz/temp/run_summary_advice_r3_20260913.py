from pathlib import Path
import sys,json,hashlib,shutil,time,traceback
from dataclasses import replace
R=Path('/home/chase/GitHub/RWKV-LH');sys.path.insert(0,str(R));D=R/'data/experiments/RWKV_SUMMARY_ADVICE_DIAGNOSTIC_R3_20260913'
from run_plain_summary_r2_20260913 import plain_prompt,plain_generate,inventory
from rwkv_lh.model import LongHorizonModel
from rwkv_lh.model_session import create_model_session
from rwkv_lh.runtime.settings import get_runtime_settings
from rwkv_lh.harness import ActionHarness
from rwkv_lh.controller import LongHorizonController
from rwkv_lh.store import LongHorizonStore
from rwkv_lh.schema import RunStatus
from rwkv_lh.summary_advice import request_advice,make_advice_event,build_advice_request
from rwkv_lh.supervisor_openai import SupervisorAPISettings,OpenAICompatibleSupervisorClient

def save(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def settings():return replace(get_runtime_settings(),tool_disclosure_mode='full',return_token_ids=True,state_transport='native_required',state_profile_id='zero',state_profile_sha256='0'*64,read_timeout_seconds=180)
def strong_settings():return replace(SupervisorAPISettings.from_env(),retry_attempts=1,semantic_repair_attempts=0,fallback_models=(),plan_cache_enabled=False,read_timeout_seconds=180)
def hook(p):
 def emit(e):
  with p.open('a') as f:f.write(json.dumps(dict(e),ensure_ascii=False)+'\n')
 return emit

def run(stage):
 reg=json.loads((D/'REGISTRATION.json').read_text());assert all(sha(R/p)==h for p,h in reg['source_pins'].items());c=reg['case'];results=[];started=time.time()
 for item in reg['schedule']:
  if item['stage']!=stage:continue
  assert time.time()-started<reg['wall_seconds_per_stage'];p=D/'runs'/item['id'];p.mkdir(parents=True,exist_ok=False);source=R/c['workspace_source'];assert inventory(source)==c['workspace_sha256'];shutil.copytree(source,p/'workspace');before=inventory(p/'workspace');text=(source/c['path']).read_text();result=dict(id=item['id'],arm=item['arm'],repeat=item['repeat'],stage=stage,baseline=None,final=None,actions=[],decisions=[],handoffs=[],termination='budget',advice=None);state=None;t=time.time()
  try:
   session=create_model_session(settings=settings(),audit_hook=hook(p/'model_trace.jsonl'))
   if stage=='probe':
    prompt=plain_prompt(reg['probe_request'],c['path'],text);(p/'PLAIN_INPUT.txt').write_text(prompt);out,finish=plain_generate(session,prompt,p,1800);result.update(final=out,termination=finish)
   else:
    model=LongHorizonModel(session,harness=ActionHarness());store=LongHorizonStore(p/'state');controller=LongHorizonController(store,model=model,harness=model.harness);state=store.create_run(model.create_literal_goal(c['common_request'],str(p/'workspace'),constraints=reg['constraints']),run_id=item['id']);save(p/'goal.json',state.goal.to_dict())
    for phase in ['baseline','continuation']:
     event=None
     if phase=='continuation':
      if result['baseline'] is None:break
      parent=state.lane_head('executor');save(p/'pre_advice_state.json',state.to_dict());baseline_inventory=inventory(p/'workspace')
      # Synchronous owner-triggered read-only experiment. No concurrent writer, takeover or hidden scorer trigger.
      if item['arm']=='advice':
       save(p/'STRONG_INPUT.json',build_advice_request(state.goal,{c['path']:text},result['baseline']))
       client=OpenAICompatibleSupervisorClient(settings=strong_settings(),audit_hook=hook(p/'strong_trace.jsonl'))
       try:advice=request_advice(client,state.goal,{c['path']:text},result['baseline'],item['id'],reg['strong_max_tokens'])
       finally:client.close()
       origin='external_strong_model';model_id=strong_settings().model
      else:advice=reg['self_check'];origin='owner_requested_self_check';model_id='none'
      assert inventory(p/'workspace')==baseline_inventory and state.lane_head('executor')==parent
      result['advice']=advice;event=make_advice_event('ADVICE-'+item['id'],advice,origin,model_id);save(p/'ADVICE_EVENT.json',event.to_dict())
     for n in range(reg['max_calls_per_phase']):
      if time.time()-started>=reg['wall_seconds_per_stage']:raise TimeoutError('stage wall budget')
      decision=model.next_command(state,controller._persist_callback,max_output_tokens=1800,event=event);event=None
      result['decisions'].append(dict(phase=phase,checkpoint=decision.checkpoint.checkpoint_id,wire_command={'name':decision.wire_command.name,'arguments':dict(decision.wire_command.arguments)}))
      if decision.wire_command.name=='final_answer':
       result[phase if phase=='baseline' else 'final']=decision.wire_command.arguments['text'];result['termination']=phase+'_submitted';break
      definition=model.harness.definition(decision.command.name)
      if not definition.read_only or definition.side_effect:raise ValueError('readonly_permission_violation')
      a=controller._execute_decision(state,decision);ev=controller._action_observation_event(state,a);parent=state.lane_head('executor');child=model.append_action_observation(state,controller._persist_callback,ev);result['actions'].append(a.to_dict());result['handoffs'].append(dict(parent=parent,child=child.checkpoint_id,event_id=ev.event_id));save(p/f"observation_{len(result['actions'])}.json",ev.to_dict())
    state.final_output=result['final'] or '';state.status=RunStatus.COMPLETED if result['final'] is not None else RunStatus.INTERRUPTED;controller._persist(state,'run_completed' if result['final'] is not None else 'run_interrupted',{'final_output':state.final_output,'controller_rewritten':False})
  except Exception as e:
   result.update(termination=type(e).__name__,error=str(e),traceback=traceback.format_exc())
   if state is not None:
    state.status=RunStatus.INTERRUPTED
    controller._persist(state,'run_interrupted',{'reason':result['termination'],'controller_rewritten':False})
  finally:
   if state is not None:save(p/'state_snapshot.json',state.to_dict())
   result['workspace_unchanged']=inventory(p/'workspace')==before;result['elapsed_seconds']=time.time()-t;save(p/'RESULT.json',result);results.append(result);save(D/(stage+'_RESULTS.json'),results);print(item['id'],result['termination'],flush=True)
  if 'error' in result:break
if __name__=='__main__':run(sys.argv[1])
