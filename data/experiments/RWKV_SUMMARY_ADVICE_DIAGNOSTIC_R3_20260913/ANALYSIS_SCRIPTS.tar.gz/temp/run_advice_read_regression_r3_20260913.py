from pathlib import Path
import run_summary_advice_r3_20260913 as current
import run_single_read_diagnostic_r1_20260912 as reader
reader.D=current.D/'read_regression'
reader.run()
