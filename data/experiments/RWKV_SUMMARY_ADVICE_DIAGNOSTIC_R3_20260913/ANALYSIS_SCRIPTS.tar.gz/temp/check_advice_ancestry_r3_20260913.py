from pathlib import Path
import json
D=Path('/home/chase/GitHub/RWKV-LH/data/experiments/RWKV_SUMMARY_ADVICE_DIAGNOSTIC_R3_20260913');a=json.loads((D/'MECHANICAL_AUDIT.json').read_text());out=[]
for row in a:
 if row['stage']!='main':continue
 p=D/'runs'/row['run'];r=json.loads((p/'RESULT.json').read_text());states=json.loads((p/'state_snapshot.json').read_text())['model_states'];calls={x['candidate_checkpoint']:x for x in row['calls']};h=r['handoffs'][0];baseline=next(d for d in r['decisions'] if d['phase']=='baseline' and d['wire_command']['name']=='final_answer');final=next(d for d in r['decisions'] if d['phase']=='continuation');b=calls[baseline['checkpoint']];f=calls[final['checkpoint']];current=states[f['input_checkpoint']];anc=[]
 while current:anc.append(current['checkpoint_id']);current=states.get(current['parent_checkpoint_id'])
 messages=[json.loads(line.removeprefix('User: Function output: ')) for line in (p/'input_03.txt').read_text().splitlines() if line.startswith('User: Function output: ')]
 suggestions=[m for m in messages if m['event_type']=='summary_advice']
 out.append(dict(run=row['run'],read_observation_is_baseline_parent=b['input_checkpoint']==h['child'],read_observation_in_continuation_ancestry=h['child'] in anc,baseline_candidate_in_continuation_ancestry=baseline['checkpoint'] in anc,new_generation_candidate=baseline['checkpoint']!=final['checkpoint'],raw_candidate_outputs_equal=states[baseline['checkpoint']]['transcript']==states[final['checkpoint']]['transcript'],decoded_advice_exact_once=len(suggestions)==1 and suggestions[0]['payload']['advice']==r['advice']))
(D/'CONTINUATION_CHAIN_CHECK.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(out);assert all(all(v for k,v in x.items() if k!='run') for x in out)
