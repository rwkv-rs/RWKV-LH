from pathlib import Path
import json,hashlib,tarfile,subprocess
R=Path('/home/chase/GitHub/RWKV-LH');D=R/'data/experiments/RWKV_SUMMARY_ADVICE_DIAGNOSTIC_R3_20260913'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
v=json.loads((D/'VALIDATION.json').read_text());assert v['read_regression_finished'] and v['source_pins_unchanged'] and v['original_five_unchanged']
reg=json.loads((D/'REGISTRATION.json').read_text());assert all(sha(R/p)==h for p,h in reg['source_pins'].items())
scripts=sorted(set([p for p in (R/'temp').glob('*summary_advice*r3_20260913.py')]+[p for p in (R/'temp').glob('*advice*r3_20260913.py')]+[R/'temp'/n for n in ['run_plain_summary_r2_20260913.py','run_single_read_diagnostic_r1_20260912.py','test_assistance_handoff_preparation_r2_20260913.py','verify_pathway_input_envelope_r1_20260912.py','audit_single_read_repeatability_r1_20260912.py']]))
with tarfile.open(D/'ANALYSIS_SCRIPTS.tar.gz','w:gz') as tar:
 for p in scripts:tar.add(p,arcname=str(p.relative_to(R)))
rawfiles=[p for root in [D/'runs',D/'read_regression/runs'] for p in sorted(root.rglob('*')) if p.is_file()]
save(D/'RAW_FILE_MANIFEST.json',{'files':{str(p.relative_to(D)):sha(p) for p in rawfiles}})
with tarfile.open(D/'RAW_EVIDENCE.tar.gz','w:gz') as tar:
 for p in rawfiles:tar.add(p,arcname=str(p.relative_to(D)))
save(D/'SOURCE_MANIFEST.json',{'local_base_commit':reg['local_commit'],'frozen_registration_sha256':sha(D/'REGISTRATION.json'),'frozen_files':reg['source_pins'],'analysis_scripts':{str(p.relative_to(R)):sha(p) for p in scripts},'original_dirty_files':json.loads((D/'PREEXISTING_CHANGES.json').read_text())['files'],'notes':'All frozen bytes unchanged. Analysis scripts added after runs are external audits, not model inputs or modified scoring rules.'})
files=[p for p in D.iterdir() if p.is_file() and p.name!='SHA256SUMS.json']+[p for p in (D/'read_regression').iterdir() if p.is_file()]
save(D/'SHA256SUMS.json',{str(p.relative_to(D)):sha(p) for p in sorted(files)})
print('sealed raw',len(rawfiles),'files',sum(p.stat().st_size for p in rawfiles),'bytes','scripts',len(scripts),'report sha',sha(D/'REPORT.zh-CN.md'))
