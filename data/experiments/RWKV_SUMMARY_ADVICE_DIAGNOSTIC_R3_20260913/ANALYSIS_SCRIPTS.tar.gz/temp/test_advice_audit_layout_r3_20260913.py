from pathlib import Path
import json
import audit_summary_advice_r3_20260913 as audit

def test_current_trace_layout():
 audit.main()
 rows=json.loads((audit.D/'MECHANICAL_AUDIT.json').read_text())
 assert rows
 assert all(x['engineering_valid'] for x in rows)
 assert next(x for x in rows if x['run']=='trial-1')['advice']['valid']
