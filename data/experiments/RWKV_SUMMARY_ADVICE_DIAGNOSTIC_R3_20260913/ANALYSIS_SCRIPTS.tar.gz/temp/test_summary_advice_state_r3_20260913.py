from pathlib import Path
import sys
R=Path('/home/chase/GitHub/RWKV-LH');sys.path.insert(0,str(R));sys.path.insert(0,str(R/'temp'))
from test_assistance_handoff_preparation_r2_20260913 import setup
from rwkv_lh.summary_advice import make_advice_event

def test_optional_advice_continues_observation_state_without_rewriting(tmp_path):
 controller,store,state,model,client,parent,_=setup(tmp_path);event=make_advice_event('new-advice','仅核对可见证据。','external_strong_model','offline');decision=model.next_command(state,controller._persist_callback,event=event)
 assert decision.wire_command.arguments['text']=='ORIGINAL'
 cp=state.model_states[decision.checkpoint.parent_checkpoint_id];assert cp.parent_checkpoint_id==parent.checkpoint_id;assert cp.event_ids.count(event.event_id)==1
 assert 'not accepted' not in client.prompts[-1];assert 'is_execution_evidence' in client.prompts[-1]
