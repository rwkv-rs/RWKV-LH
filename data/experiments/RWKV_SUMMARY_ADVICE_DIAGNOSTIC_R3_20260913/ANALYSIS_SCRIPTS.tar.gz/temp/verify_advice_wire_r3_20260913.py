from pathlib import Path
import json,hashlib,sys
R=Path('/home/chase/GitHub/RWKV-LH');sys.path.insert(0,str(R))
from run_summary_advice_r3_20260913 import D,strong_settings
from rwkv_lh.summary_advice import ADVICE_SYSTEM,ADVICE_RESPONSE_SCHEMA,build_advice_request
from rwkv_lh.schema import GoalState
from rwkv_lh.supervisor_openai import OpenAICompatibleSupervisorClient,_render_user_payload

def sha(s):return hashlib.sha256(s.encode()).hexdigest()
reg=json.loads((D/'REGISTRATION.json').read_text());rows=[]
for name in ['trial-2','trial-3']:
 p=D/'runs'/name;r=json.loads((p/'RESULT.json').read_text());goal=GoalState.from_dict(json.loads((p/'goal.json').read_text()));c=reg['case'];source=(R/c['workspace_source']/c['path']).read_text();payload=build_advice_request(goal,{c['path']:source},r['baseline']);saved=json.loads((p/'STRONG_INPUT.json').read_text());assert payload==saved
 client=OpenAICompatibleSupervisorClient(settings=strong_settings())
 try:endpoint,body,transport=client._wire_request(phase='summary_advice',selected_model=reg['strong_settings']['model'],system_prompt=ADVICE_SYSTEM,payload_text=_render_user_payload(payload),max_tokens=reg['strong_max_tokens'],schema_revision='v1',schema=ADVICE_RESPONSE_SCHEMA)
 finally:client.close()
 trace=[json.loads(l) for l in (p/'strong_trace.jsonl').read_text().splitlines()];started=next(e for e in trace if e['type']=='supervisor_request_started');wire_sha=sha(json.dumps(body,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False));exact=wire_sha==started['wire_body_sha256'] and sha(_render_user_payload(payload))==started['input_sha256'];assert exact
 envelope=next(e for e in trace if e['type']=='supervisor_response_envelope_received');raw=envelope['raw_response']['choices'][0]['message']['content'];unchanged=json.loads(raw)['advice']==r['advice']==json.loads((p/'ADVICE_EVENT.json').read_text())['payload']['advice'];assert unchanged
 (p/'STRONG_WIRE_RECONSTRUCTED.json').write_text(json.dumps({'endpoint':endpoint,'body':body,'wire_body_sha256':wire_sha,'matches_recorded_wire_hash':exact},ensure_ascii=False,indent=2)+'\n')
 rows.append(dict(run=name,wire_reconstruction_exact=exact,original_goal_source_candidate_only=True,advice_unmodified=unchanged,one_attempt=sum(e['type']=='supervisor_http_attempt_started' for e in trace)==1,no_fallback_or_normalization=not any(e['type'] in ['supervisor_model_fallback_applied','supervisor_content_envelope_normalized'] for e in trace),finish_reason=envelope['finish_reason'],response_model=envelope['model'],usage=envelope['usage'],latency_ms=envelope['latency_ms']))
(D/'STRONG_WIRE_AUDIT.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n');print('exact strong requests and unchanged advice',len(rows))
