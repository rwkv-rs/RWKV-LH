from pathlib import Path
import json
D=Path('/home/chase/GitHub/RWKV-LH/data/experiments/RWKV_SUMMARY_ADVICE_DIAGNOSTIC_R3_20260913')
def save(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
# External semantic review of anonymous candidate packets. Never used by either executing model.
full={'461eddbc8b','98ef22f433'};unsupported={'94ae993b75','aed66820a7'}
rows=[]
for x in json.loads((D/'ANONYMOUS_REVIEW_INPUT.json').read_text()):
 k=x['id'];complete=k in full;bad=k in unsupported
 rows.append(dict(id=k,grade='satisfies' if complete else 'partial',coverage={'purpose':'covered' if complete else 'partial','get':'covered','db':'covered' if complete else 'omitted','cli':'covered','threads':'covered','json':'covered'},unsupported=['文件直接使用 threading 模块：源码仅从 http.server 导入 ThreadingHTTPServer；这不是完整答案失实，也不是虚假工作完成声明。'] if bad else [],contradictions=[],false_completion=False,reason='说明仅有HTTP基础框架、没有数据库连接/业务逻辑，结合前文仅解析db满足关键限制语义；不要求逐字出现未使用。' if complete else '健康检查、其他GET未实现、CLI及线程服务主旨正确；未说明初始待完成性质及db仅解析未用。按冻结诊断规则为部分满足，不等于不能总结或虚假完成。',rubric_alignment_note='db强制核心地位仍有用户目标粒度争议，保留本轮口径不回改分数。'))
save(D/'SEMANTIC_REVIEW.json',{'reviewer':'Codex single external semantic review; anonymous ids but surrounding context prevents full blinding','rows':rows})
mapping=json.loads((D/'ANONYMOUS_MAPPING.json').read_text());by={}
for x in rows:entry=mapping[x['id']];by[(entry['run'],entry['phase'])]=x
engineering={x['run']:x for x in json.loads((D/'MECHANICAL_AUDIT.json').read_text())};tasks=[]
for r in json.loads((D/'main_RESULTS.json').read_text()):
 tasks.append(dict(run=r['id'],arm=r['arm'],baseline=by[(r['id'],'baseline')],after=by[(r['id'],'final')],task_pass=by[(r['id'],'final')]['grade']=='satisfies' and engineering[r['id']]['engineering_valid'],completed=r['final'] is not None,mutation=0,termination=r['termination'],attribution='strong_advice_then_rwkv' if r['arm']=='advice' else 'rwkv_owner_self_check',same_answer=r['baseline']==r['final']))
save(D/'TASK_RESULTS.json',tasks)
save(D/'PROBE_REVIEW.json',{'scope':'Only parameter-use recognition, different question, not summary success or repair gain; no probe answers shown to subsequent models','rows':[{'run':'probe-1','unused_db_correct':True,'host_port_used_correct':True,'fidelity':'Host/port roles described informally but correct; no literal code quote required by frozen probe.'},{'run':'probe-2','unused_db_correct':True,'host_port_used_correct':True,'fidelity':'Localized incorrect call-position claim: host and port form the first tuple argument; the second ThreadingHTTPServer argument is Handler. The db conclusion remains correct.'}],'inference':'Two correct db identifications establish recognition in this fixed question. Prior summary omission more consistent with salience/coverage/task-granularity than inability to see the fact; cannot isolate those alternatives or claim general competence.'})
print([(t['run'],t['arm'],t['baseline']['grade'],t['after']['grade'],t['same_answer']) for t in tasks])
