from pathlib import Path
import json,hashlib,subprocess,tarfile
R=Path('/home/chase/GitHub/RWKV-LH');D=R/'data/experiments/RWKV_STRONG_MODEL_ROLE_ALIGNMENT_R1_20260912'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
text='''# RWKV 与强模型职责约定：待 owner 确认的定稿建议

状态：本轮只对齐角色定位，不视作owner已确认所有细节；不启动新推理评测、训练、并发压测或生产改造。Owner已明确允许强模型辅助，并要求先固定角色再真实做。该要求替代此前“模型只能是RWKV”的表述，但不恢复旧的逐动作Coordinator/Auditor流水线。旧源码与trace保留。

## 1. 固定职责，而非固定模型动作

**RWKV是默认执行主体和并行工作池；强模型是按需的任务级判断与困难处置者；Harness只做可复核的工程执行；最终验收独立于这两类模型。**

| 参与者 | 负责 | 不承担 |
|---|---|---|
| RWKV | 自主选择工具和参数；读取/理解/局部修改/验证；沿自己的State完成局部闭环；提交结果或明确求助 | 不要求独立包办所有难题，也不只当填参数器或接收逐工具命令的执行器 |
| 强模型 | 复杂目标的理解与可独立子目标划分；矛盾证据/真实困难的诊断；必要的跨结果综合；需要时直接接管 | 不默认逐步规划、逐调用批准或逐答案强制审核；不因步骤与设想不同就返工 |
| Harness | 工具合同和执行、State身份与exactly-once、持久化、资源预算、任务调度及冲突保护 | 不判断语义合格、不补参数/摘要/最终答案、不生成假成功 |
| 外部验收 | 依据原用户目标检查最终答案、文件或行为；保留重要遗漏/不实陈述证据 | 不强制固定工具路径，不因final_answer就推定宣称验收通过；默认不驱动在线补偿 |

## 2. 主循环和两种辅助边界

简单明确任务默认由RWKV直接做，不先消费一次强模型调用。复杂任务确有必要时，强模型在任务边界给出结果导向的子目标、明确约束、必要上下文与依赖；不下达固定工具序列，不人为设置最低动作次数，不为计划整齐切碎本可一次完成的工作。一个子任务可以有多步，结束由结果和模型选择决定。

RWKV收到真实观察继续生成，提交答案后保存原文。局部求助发生于明确不理解、工具真实失败后仍无法处理、证据相互冲突、产物/测试存在具体失败，或预算接近耗尽而尚无结果。不能以使用另一合法工具、重复读取一次、未提次要细节或没有达到评测者期望的步骤数触发求助。尚未定义的语义条件不能偷偷变成程序启发式；初期只使用显式求助和可核对的失败事实。

- **建议模式**：强模型看到原目标、实际尝试/错误、必要证据和剩余预算，解释问题或建议方向。建议本身不是工具执行证据。RWKV仍自己生成工具调用和答案。
- **接管模式**：强模型直接生成后续操作或最终产出，使用同一真实Harness边界并按来源记账。这是允许的混合成功，不伪装成RWKV独立完成。

辅助预算属于整项任务预算，不能通过求助重置资源。每次强模型请求都要有原因和可见证据；不存在固定的“Planner→Executor→Auditor→Finalizer→Auditor”必经链。辅助无效时允许按预算中断，不无限自动补偿。

模型间传递显式任务、事实、建议与结果；不能互换隐藏State或把强模型输出伪装成RWKV生成。RWKV恢复原合法checkpoint后，通过唯一生产输入构造路径接收明确标注来源的建议。何种事件/schema承载，留给后续实现冻结，不在temp中创造第二套协议。

## 3. 如何利用 RWKV 的 State、并发和成本特点

1. 同一RWKV工作单元的工具结果沿正确父State继续，不为每个读取/每个参数开启全新角色。保留现有身份/模型/初始化兼容性检查。
2. 并发放在相互独立的任务或子目标之间；每个工作单元有独立State、预算和结果归属。同一工作单元内的因果操作按依赖推进。
3. 先验证跨任务的独立只读并发，再谈单个大任务的拆分。不能为了并发而把一个130-token脚本分给多个模型猜摘要，也不默认多候选投票。
4. 未来写入阶段使用明确的工作区版本和冲突检测；不同State不能同时无保护地改同一文件。同目录不等于可安全并发。已有可用机制优先复用，不另建常驻第二架构。
5. 若后续使用公共前缀State/fork，必须先证明完整身份和输入相同；不能按相似任务共享任务State，更不能平均或拼接State。跨任务结果通过显式证据汇总。
6. 强模型不是串行关卡。独立RWKV结果不必逐条经过强模型；仅确有综合、困难判断或接管需求时调用。

“超并发、便宜”是本架构的优化方向，不是当前部署已兑现的数字。上一轮服务记录cache_capacity_per_worker=8，这是缓存配置，不是并发吞吐结论；旧supervisor有max_parallel_atoms等阶段限制，也不等于RWKV本身上限。本轮不修改这些值，未来应先实测内存/吞吐/尾延迟/State隔离，再设运行容量。原始日志和full-context token记录也有成本，不能用递归State特点宣称整套系统内存永不增长。

## 4. 成功归属与衡量方式

先报混合系统最终结果：是否满足用户目标，重要缺陷是什么，终止原因是什么。再报告贡献来源：

- RWKV独立产出并满足目标。
- 强模型只建议，最终操作/答案由RWKV生成。
- 强模型直接完成部分操作、改写或接管。

强模型检查但没有更改的情况也记录调用事实与成本，不能记成零辅助。外部验收如果使用强模型，其模型/输入/费用另记；不能把同一次自我评价当作独立验收。

效率衡量必须使用达到质量门的任务：每个合格任务总成本（RWKV推理、强模型调用、Harness及必要存储）、合格任务吞吐、端到端延迟/尾延迟、强模型建议/接管比例。不能以RWKV tokens/s或“完成”次数替代可用性，也不能通过大量廉价失败增加表面吞吐。不预设RWKV一定承担80%/90%或强模型固定介入次数，比例由同组证据决定。

## 5. 角色确认后的首个验证方向

角色定位确认后，仍只用现有明确路径短文件的读取→总结，不进入多文件或恢复项目级A/B。

先冻结符合“主要内容”的结果口径，区分主旨/关键规则/影响理解的限制和可省略细节，独立于执行次数。现有四个文件可复用，旧0/8不套新标准重评分当收益。

首轮建议只验证**强模型提供建议、RWKV继续完成**这一种辅助，目的是观察RWKV能否利用建议，而不是让强模型直接写好摘要证明混合任务成功。接管定位保留，但接管能力/效果分开登记，不混入建议模式的贡献数字。具体求助触发、辅助内容范围、模型选择、预算和门槛均在运行前冻结；本轮不调用模型、不新建数据集。

先把单工作单元因果链和结果做清楚，再用独立同类任务逐级测并发。只有当基线证明需要强模型预先拆分复杂目标时，才引入任务级拆分；不能把“加入强模型”默认实现成旧Coordinator的一次完整恢复。

## 6. 本轮确认项

建议owner固定的是四条职责边界：RWKV默认执行主体；强模型按需建议/任务级判断/接管；模型保持工具选择自主权；外部验收看用户结果，辅助和成本如实归属。

不在本轮锁死强模型厂商/型号、调度阈值、并发数量、每次调用token预算或下一版协议。这些是职责确认后的具体实验参数，不能反过来决定角色，更不能未经冻结就开始真实跑。
'''
(D/'ROLE_CONTRACT.zh-CN.md').write_text(text)
pre={p:sha(R/p) for p in subprocess.check_output(['git','diff','--name-only'],cwd=R,text=True).splitlines()};assert len(pre)==5
source_paths=['rwkv_lh/model.py','rwkv_lh/controller.py','rwkv_lh/supervisor.py','rwkv_lh/parallel_atoms.py','rwkv_lh/inference/vllm_rwkv_native_worker.py','data/experiments/RWKV_READ_SUMMARY_BASELINE_R5_20260912/SERVER_IDENTITY.json','data/experiments/RWKV_READ_SUMMARY_BASELINE_R5_20260912/PYTEST_FULL.log','data/experiments/DSH_MINIMAL_ARCHITECTURE_REVIEW_R1_20260912/REPORT.zh-CN.md']
save(D/'EVIDENCE.json',{'status':'role proposal awaiting owner confirmation; no real execution','preexisting_files':pre,'source_sha256':{p:sha(R/p) for p in source_paths},'new_model_calls':0,'new_training':False,'production_changes':False,'validation':'Existing 1514-passed full regression applies to unchanged runtime/test files; no test rerun for documentation-only role alignment.'})
h=R/'docs/HANDOFF.zh-CN.md';old=h.read_text();assert old.startswith('# 当前交接\n');digest=sha(D/'ROLE_CONTRACT.zh-CN.md')
entry=f'''\n## 2026-09-12 强模型辅助与RWKV角色定位（待owner确认后再真实执行）\n\nOwner明确加入强模型辅助，并要求先固定角色定位、利用RWKV并发与成本特点。本轮只对齐职责，没有模型调用或生产修改。建议固定：RWKV是默认并行执行主体，强模型在任务边界承担必要判断/困难建议/显式接管；Harness负责真实执行与State，外部验收看用户结果。不是逐动作Coordinator/Auditor必经链，简单任务不默认消费强模型调用。\n\n建议与接管分开归属，不能将强模型产出记为RWKV独立能力；同任务保持因果State，独立任务并发，不共享/混合任务State。超并发和低成本尚需当前部署实测，cache容量8不能当作并发能力结论。首轮方向仍是明确路径读总结，建议先验证强模型建议→RWKV继续，不启动复杂拆分或接管实验。\n\n[完整角色约定建议](../data/experiments/{D.name}/ROLE_CONTRACT.zh-CN.md)，SHA `{digest}`。状态为待owner确认，不视作角色细节已获确认；具体模型/预算/并发数/新协议留待确认后冻结。原5个修改保持，未训练、push或创建datasets版本。\n'''
h.write_text('# 当前交接\n'+entry+old[len('# 当前交接\n'):])
with tarfile.open(D/'RECORD_SCRIPT.tar.gz','w:gz') as t:t.add(Path(__file__),arcname='temp/'+Path(__file__).name)
save(D/'SHA256SUMS.json',{p.name:sha(p) for p in D.iterdir() if p.is_file() and p.name!='SHA256SUMS.json'})
print(digest)
