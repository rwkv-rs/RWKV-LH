from pathlib import Path
import json,hashlib,collections
R=Path('/home/chase/GitHub/RWKV-LH');D=R/'data/experiments/RWKV_ULTRADATA_CODE_PILOT_R2_20260915';B=R/'data/experiments/RWKV_ULTRADATA_VERIFIED_BOUNDARIES_R1_20260915'
def save(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
rows=json.loads((D/'RESULTS.json').read_text());a=json.loads((D/'runs/MECHANICAL_AUDIT.json').read_text());ext=json.loads((D/'ARTIFACT_RESULTS.json').read_text());assert len(rows)==len(a)==len(ext)==40
out={'runs':40,'distinct_registered_tasks':20,'artifact_pass':sum(x['artifact_pass'] for x in ext),'submitted':sum(x['result']['final'] is not None for x in rows),'qualified_delivery':0,'changed_source_file_occurrences':sum(len(x['result']['changed_files']) for x in rows),'terminations':dict(collections.Counter(x['result']['termination_reason'] for x in rows)),'generation_calls':sum(len(x['calls']) for x in a),'protocol_rejections':sum(x['result']['protocol_rejections'] for x in rows),'input_tokens':sum(c['input_tokens'] for x in a for c in x['calls']),'output_tokens':sum(c['output_tokens'] for x in a for c in x['calls']),'mechanical_audit_pass_runs':sum(x['passed_mechanical_audit'] for x in a),'engineering_interrupted_runs':sum(x['result']['termination']=='error' for x in rows),'source_quality_quarantined_task_ids':['Code_00009'],'unsupported_test_report_finals':['Code_00007-r1','Code_00009-r2'],'fresh_verified_write_candidates':3,'new_admitted_training_rows':0,'strong_calls':0,'training_steps':0,'interpretation':'Raw frozen fixture counts retained; Code_00009 is ambiguous. Artifact, final submission and faithful delivery scored separately; not project Strict or StateTune gain.'};save(D/'TASK_RESULTS.json',out)
reviews=[]
for x in rows:
 r=x['result']
 if r['final'] is not None:
  reviews.append({'id':x['id'],'raw_final':r['final'],'commands':[{'arguments':c['arguments'],'success':c['result']['success'],'output':c['result']['output']} for c in r['actions'] if c['action_type']=='run_command'],'faithful_test_report':False,'reason':'Final lists sample outputs as verification, but actual commands pass arguments rather than stdin and observed output does not match. External checker results were not visible to the model; cannot support its claim.'})
save(D/'FINAL_FACTUALITY_REVIEW.json',reviews)
(D/'REPORT.zh-CN.md').write_text('''# UltraData Code固定试采R2

## 任务级结果

固定20题各2遍，原始40次中程序外部测试通过3，提交回答2，完整忠实交付0；这不是项目Strict。Code_00007-r1程序25项外测通过，但4次模型自测实际输出均为0，最终却列出样例正确值；Code_00013-r1及Code_00019-r2程序通过但未提交回答。另一提交Code_00009-r2程序不通过且测试报告无真实输出支持，该题原文还存在AB/BA歧义，保留原分并隔离未来数据，不能解释为纯模型准确率。

终止：重复成功动作预算29、生成步数预算8、重复失败动作预算1、提交2。程序正确、自然提交、报告忠实分别判断，不要求固定工具路径，也不把final调用本身当作谎称合格。

## 工程修复与调用证据

R1换行归一化导致18/40工程中断，原分不重算。R2只改变冻结客户端Harness的原始换行保留逻辑，模型、zero State、任务、采样及预算相同；工程中断0/40，实际输入/观察及State父链核验40/40。没有据此声称全部工程缺陷已消除。

247次真实生成，1675744精确输入token、14223输出token，70次协议拒绝。强模型0、训练0。调用数增加主要因此前工程中断被消除，不能作为能力或成本收益。未测并发收益。

## 可收集内容与不能收集内容

三个通过程序的原始write_file分别从当时before快照重新执行：基线失败→原始模型工具写入→完整外测通过，输入和目标未改，未注入隐藏测试。形成3份fresh_execution_verified候选；不是3个完整成功任务，也尚未越过现有正式数据准入门。错误的最终测试描述不作为成功训练目标。正式训练数据仍60条。

Code_00009单独列来源矛盾；反复读取、非法工具调用、标准输入混同argv、依据样例编造测试结果分开归因。成功写入不能顺带给后续错误回答贴合格标签。

## 下一阶段

先建立客观执行证据适用的候选准入合同：绑定原始输入与动作、重建快照、隔离且不可改测试、失败到通过、真实入口、任务来源隔离和去重；拒绝伪成功、改测试、无效来源及未来信息，配红→绿回归。语义回答依然需要事实核验，不能用程序通过替代，也不伪造双审。

然后补齐命令后/修改后观察的纠正边界，按同类失败聚合，扩至100任务时先冻结来源质量与预算。当前40次不是500–1000条训练数据；不盲目复制失败扩量，也不重复训练旧60条。统一StateTune仍是主线，暂未启动新训练。

原始数据和完整trace留本地并登记SHA，不镜像公开来源及隐藏测试到GitHub。仅本地提交，owner修改保留，GPU仅0。
''')
for base in (D,B):
 manifest={str(p.relative_to(R)):sha(p) for folder in (['runs','external','service'] if base==D else [p.name for p in B.iterdir() if p.is_dir()]) for p in (base/folder).rglob('*') if p.is_file()};save(base/'RAW_MANIFEST.json',manifest)
(B/'REPORT.zh-CN.md').write_text('# 已验证原始写入候选\n\n3个不同来源的原始RWKV写入在新快照上重放，基线缺程序不通过，真实Harness写入后外测通过。未改目标，未调用强模型，未新建数据版本，正式准入0。程序验证不自动证明最终陈述忠实或来源语义无误。完整输入、目标、快照、工具结果及外测留本地；RESULTS与RAW_MANIFEST绑定证据。下一门是明确的自动执行证据准入合同，而不是虚构两份审核。\n')
for base in (D,B):save(base/'RESULT_SHA256.json',{p.name:sha(p) for p in base.iterdir() if p.is_file() and p.name not in ('RESULT_SHA256.json','RESULTS.json')})
p=R/'docs/HANDOFF.zh-CN.md';s=p.read_text();i=s.index('**最新：');j=s.index('\n\n',i);s=s[:i]+'**最新：UltraData首批20题×2遍已完成，修复换行证据缺陷后程序外测3/40、提交2、完整忠实交付0；真实输入/观察/State核验40/40，工程中断0。3份原始写入通过新快照重放，尚未正式准入；训练数据仍60，本轮强模型0/训练0。完整回归1822 passed、0 skipped，owner五文件保留、未push。详见[本轮结果](../data/experiments/RWKV_ULTRADATA_CODE_PILOT_R2_20260915/REPORT.zh-CN.md)。**'+s[j:];p.write_text(s)
print(json.dumps(out,ensure_ascii=False,indent=2))
