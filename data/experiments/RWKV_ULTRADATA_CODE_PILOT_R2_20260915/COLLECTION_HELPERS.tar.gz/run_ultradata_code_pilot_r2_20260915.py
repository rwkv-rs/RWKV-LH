from pathlib import Path
import sys,json,hashlib,time,urllib.request
from dataclasses import replace
R=Path('/home/chase/GitHub/RWKV-LH');S=R/'data/experiments/RWKV_ULTRADATA_CODE_PILOT_R2_20260915/source';sys.path.insert(0,str(S))
from rwkv_lh.runtime.settings import load_local_env,get_runtime_settings,direct_agent_settings
from rwkv_lh.coding_agent import CodingJob,run_coding_job
from rwkv_lh.model_session import create_model_session,SessionSampling
from rwkv_lh.correction_snapshots import generation_snapshot_audit
D=R/'data/experiments/RWKV_ULTRADATA_CODE_PILOT_R2_20260915';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def freeze():
 old=json.loads((R/'data/experiments/RWKV_FAILED_TEST_REPORT_COLLECTION_R1_20260915/REGISTRATION.json').read_text());cases=[];rejected=[];seen=[]
 for row in json.loads((D/'SOURCE_ROWS.json').read_text()):
  gt=row['ground_truth'];gt=json.loads(gt) if isinstance(gt,str) else gt
  q=row['query'];grams={q[i:i+5] for i in range(max(0,len(q)-4))};reason=None
  if gt.get('call_type')!='std' or gt.get('fn_name') is not None or not gt['inputs'] or len(gt['inputs'])!=len(gt['outputs']):reason='invalid stdio schema'
  elif len(gt['inputs'])>64 or max(len(v.encode()) for v in gt['inputs']+gt['outputs'])>1048576:reason='registered fixture resource cap'
  elif len(q)>12000:reason='prompt character cap before exact token validation'
  elif any(len(grams&prev)/max(1,len(grams|prev))>=.85 for prev in seen):reason='query character5gram Jaccard near duplicate >=.85'
  elif len(cases)>=20:reason='first20eligible quota filled'
  if reason:rejected.append({'id':row['uuid'],'reason':reason});continue
  seen.append(grams);work=D/'tasks'/row['uuid'];work.mkdir(parents=True);(work/'TASK.md').write_text(q+'\n');private=D/'private'/f"{row['uuid']}.json";save(private,gt)
  cases.append({'id':row['uuid'],'workspace':str(work),'task_sha256':sha(work/'TASK.md'),'private_tests_path':str(private),'private_tests_sha256':sha(private),'tests':len(gt['inputs'])})
 assert len(cases)==20
 reg={k:old[k] for k in ['source_pins','source_manifest_sha256','model','model_sha256','state_profile_id','state_profile_sha256','context_tokens','sampling']};reg.update(cases=cases,rejected=rejected,runner_sha256=sha(Path(__file__)),registered_before_run=True,dataset_version='none; approved external task collection in experiments',request='阅读 TASK.md，使用 Python 标准库实现题目要求，将可直接从标准输入读取并向标准输出作答的程序保存为 solution.py。可以自主检查、运行自己的验证并修改代码。最后简要说明实现与本次实际运行的验证；不要把未运行的测试说成通过。外部验收允许任何满足要求的算法。',budget={'calls_per_task':12,'seconds_per_task':240,'max_output_tokens':1800,'total_calls':480,'overall_seconds':10800,'concurrency':1,'strong_model_calls':0,'gpu':0},repeats=2,acceptance='External isolated stdio tests all pass plus faithful submission. Artifact correctness, submission and execution evidence separate. Hidden tests never enter model workspace or input; no automatic repair or forced tool order. 3 seconds CPU/wall per testcase, 1MiB streams, 1GiB address-space; report resource failures separately. No projectStrict.',source_model_code=str(S),verifier_sha256=sha(R/'rwkv_lh/stdio_verifier.py'))
 save(D/'REGISTRATION.json',reg)
def run():
 reg=json.loads((D/'REGISTRATION.json').read_text());assert sha(Path(__file__))==reg['runner_sha256'];load_local_env(R/'.env.local');config=direct_agent_settings(replace(get_runtime_settings(),base_url='http://127.0.0.1:29630/v1',model=reg['model'],model_sha256=reg['model_sha256'],max_model_len=24576,state_profile_id='zero',state_profile_sha256='0'*64,state_transport='native_required',return_token_ids=True,read_timeout_seconds=300,action_max_output_tokens=1800,default_temperature=.1,default_top_p=1,default_top_k=0,default_presence_penalty=0,default_frequency_penalty=0,default_penalty_decay=.996));save(D/'CAPABILITIES.json',json.load(urllib.request.urlopen(config.base_url+'/capabilities',timeout=15)));start=time.monotonic();rows=[]
 for repeat in [1,2]:
  for case in reg['cases']:
   if time.monotonic()-start>=10800:save(D/'BUDGET_STOP.json',{'elapsed':time.monotonic()-start});return
   assert all(sha(R/p)==h for p,h in reg['source_pins'].items()) and sha(Path(case['workspace'])/'TASK.md')==case['task_sha256']
   out=D/'runs'/f"{case['id']}-r{repeat}";expected=SessionSampling.from_settings(config).to_dict()
   def factory(*,settings,audit_hook):
    wrapped=generation_snapshot_audit(workspace=out/'workspace',output=out/'execution',audit_hook=audit_hook)
    def audit(e):
     if e.get('type')=='model_session_generation_started':assert e['sampling']==expected
     wrapped(e)
    return create_model_session(settings=settings,audit_hook=audit)
   result=run_coding_job(CodingJob(case['id'],reg['request'],case['workspace'],str(out),12,240),settings=config,session_factory=factory);save(out/'COLLECTION_RESULT.json',result);rows.append({'id':out.name,'case':case['id'],'repeat':repeat,'result':result});save(D/'RESULTS.json',rows);print(out.name,result['termination'],result.get('generation_started'),flush=True)
 save(D/'SOURCE_AFTER.json',{'all_match':all(sha(R/p)==h for p,h in reg['source_pins'].items()),'elapsed_seconds':time.monotonic()-start})
if __name__=='__main__':freeze() if sys.argv[1]=='freeze' else run()
