from pathlib import Path
import sys,json,time,hashlib
R=Path('/home/chase/GitHub/RWKV-LH');sys.path.insert(0,str(R))
from rwkv_lh.stdio_verifier import verify_python_submission
D=R/'data/experiments/RWKV_ULTRADATA_CODE_PILOT_R2_20260915';reg=json.loads((D/'REGISTRATION.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert sha(R/'rwkv_lh/stdio_verifier.py')==reg['verifier_sha256'];done={};start=time.monotonic()
while time.monotonic()-start<14400:
 try:rows=json.loads((D/'RESULTS.json').read_text())
 except (FileNotFoundError,json.JSONDecodeError):time.sleep(10);continue
 for row in rows:
  if row['id'] in done:continue
  case=next(c for c in reg['cases'] if c['id']==row['case']);private=Path(case['private_tests_path']);assert sha(private)==case['private_tests_sha256'];workspace=D/'runs'/row['id']/'workspace';before={str(p.relative_to(workspace)):sha(p) for p in workspace.rglob('*') if p.is_file()};checks=verify_python_submission(workspace,json.loads(private.read_text()));assert before=={str(p.relative_to(workspace)):sha(p) for p in workspace.rglob('*') if p.is_file()};path=D/'external'/row['id'];path.mkdir(parents=True);(path/'CHECK.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2)+'\n');done[row['id']]={'id':row['id'],'artifact_pass':checks['passed'],'test_cases_executed':len(checks['cases']),'termination':checks['termination'],'submitted':row['result']['termination']=='submitted','generation_calls':row['result']['generation_started'],'agent_termination_reason':row['result']['termination_reason'],'workspace_unchanged_by_verifier':True};(D/'ARTIFACT_RESULTS.json').write_text(json.dumps(list(done.values()),indent=2)+'\n');print(row['id'],checks['passed'],checks['termination'],flush=True)
 if len(done)==40 or (D/'BUDGET_STOP.json').exists():break
 time.sleep(10)
print('external done',len(done),flush=True)
