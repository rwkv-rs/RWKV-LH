#!/usr/bin/env python3
"""
backup.py snapshot SOURCE ARCHIVE
backup.py restore ARCHIVE DESTINATION

Only standard library. Each invocation is a separate process; no process-memory
state is available. Keep staging files beside their final target so replacement
can be atomic on the same filesystem.

Snapshot:
  - Include regular files recursively (including hidden, binary, Unicode names
    and zero-byte files).
  - Reject symbolic links and other non-regular entries.
  - Preserve empty directories.
  - Reject invalid SOURCE, ARCHIVE, or ARCHIVE already existing.
  - A failed snapshot must not replace a previous ARCHIVE.
  - Write ZIP archive with a UTF-8 manifest.json:
        version: 1
        directories: [relative POSIX directory paths]
        files: [{path, size, sha256}]
  - File payloads use ZIP member names files/<relative path>.
  - Do not add ZIP directory entries.

Restore:
  - Validate version, unique names, declared members, file sizes and digests
    before replacing DESTINATION.
  - Reject undeclared/duplicate members, absolute paths, parent traversal,
    backslashes, invalid normalized paths and file/directory conflicts.
  - Symlink destinations are invalid.
  - Existing directory contents are replaced only after complete validation;
    corrupt input or another failure must leave the previous destination intact.
  - Successful restore must not retain old files.
  - Invalid input must never write outside the destination staging area.
  - Support an empty directory snapshot and restore.

Each successful command writes one JSON object to stdout:
  {"files": int, "bytes": int}
  File count is regular files restored/snapshotted. Bytes is their total
  original byte size.

Unit tests are provided in the same directory.
",
    "path": "backup.py"
  }
