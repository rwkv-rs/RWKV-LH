#!/usr/bin/env python3

import argparse
import json
import sqlite3
import sys
from datetime import datetime, timezone, timedelta


def parse_iso(s):
    try:
        return datetime.strptime(s, "%Y-%m-%dT%H:%M:%S%z")
    except ValueError:
        raise ValueError(f"invalid ISO time: {s!r}")


def to_utc(dt):
    if dt.tzinfo is None:
        raise ValueError("time must have timezone")
    return dt.astimezone(timezone.utc)


def normalize_id(id_):
    if not id_:
        raise ValueError("id must be nonempty")
    return id_.strip()


def normalize_project(p):
    if not p:
        raise ValueError("project must be nonempty")
    return p.strip()


def normalize_time(t):
    if not t:
        raise ValueError("time must be nonempty")
    return t.strip()


def validate_event(e):
    required = ["id", "project", "start", "end"]
    missing = [k for k in required if k not in e]
    if missing:
        raise ValueError(f"missing fields: {missing}")
    id_ = normalize_id(e["id"])
    project = normalize_project(e["project"])
    start = normalize_time(e["start"])
    end = normalize_time(e["end"])
    try:
        start_dt = parse_iso(start)
        end_dt = parse_iso(end)
    except ValueError as exc:
        raise ValueError(f"invalid time: {exc}") from exc
    if end_dt <= start_dt:
        raise ValueError("end must be after start")
    if start_dt.tzinfo is None or end_dt.tzinfo is None:
        raise ValueError("times must have timezone")
    return id_, project, start_dt, end_dt


def insert_event(conn, id_, project, start_dt, end_dt):
    cur = conn.cursor()
    cur.execute(
        "SELECT id, project, start_dt, end_dt FROM events WHERE id = ?",
        (id_,),
    )
    row = cur.fetchone()
    if row:
        cur.execute(
            "SELECT start_dt, end_dt FROM events WHERE id = ?", (id_,)
        )
        existing = cur.fetchone()
        if existing:
            existing_start, existing_end = existing
            if existing_start == start_dt and existing_end == end_dt:
                return 0
            raise ValueError("duplicate event")
    cur.execute(
        "INSERT INTO events (id, project, start_dt, end_dt) VALUES (?, ?, ?, ?)",
        (id_, project, start_dt, end_dt),
    )
    conn.commit()
    return 1


def import_events(conn, events):
    inserted = 0
    for event in events:
        try:
            id_, project, start_dt, end_dt = validate_event(event)
        except ValueError as exc:
            raise ValueError(f"invalid event: {exc}") from exc
        try:
            inserted += insert_event(conn, id_, project, start_dt, end_dt)
        except ValueError as exc:
            raise ValueError(f"invalid event: {exc}") from exc
    return inserted


def add_events(conn, events):
    inserted = 0
    for event in events:
        try:
            id_, project, start_dt, end_dt = validate_event(event)
        except ValueError as exc:
            raise ValueError(f"invalid event: {exc}") from exc
        try:
            inserted += insert_event(conn, id_, project, start_dt, end_dt)
        except ValueError as exc:
            raise ValueError(f"invalid event: {exc}") from exc
    return inserted


def stats_range(conn, from_dt, to_dt):
    cur = conn.cursor()
    cur.execute(
        "SELECT project, SUM(total_seconds) FROM ("
        "SELECT project, start_dt, end_dt, "
        "    julianday(end_dt) - julianday(start_dt) AS total_seconds "
        "FROM events WHERE start_dt >= ? AND end_dt <= ? "
        "GROUP BY project, start_dt, end_dt) "
        "GROUP BY project",
        (from_dt, to_dt),
    )
    rows = cur.fetchall()
    days = []
    for row in rows:
        days.append({"date": row[0], "projects": row[1]})
    total = sum(row[1] for row in rows)
    return {"days": days, "total_seconds": total}


def main():
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="cmd", required=True)
    add = sub.add_parser("add")
    add.add_argument("db")
    add.add_argument("id")
    add.add_argument("project")
    add.add_argument("start")
    add.add_argument("end")
    import_cmd = sub.add_parser("import")
    import_cmd.add_argument("db")
    import_cmd.add_argument("input")
    stats = sub.add_parser("stats")
    stats.add_argument("db")
    stats.add_argument("--from", required=True)
    stats.add_argument("--to", required=True)
    args = parser.parse_args()
    conn = sqlite3.connect(args.db)
    conn.execute(
        "CREATE TABLE IF NOT EXISTS events (id TEXT PRIMARY KEY, project TEXT, start_dt TEXT, end_dt TEXT)"
    )
    if args.cmd == "add":
        try:
            inserted = add_events(conn, [(args.id, args.project, args.start, args.end)])
        except ValueError as exc:
            print(json.dumps({"error": str(exc)}))
            sys.exit(1)
        print(json.dumps({"inserted": inserted, "duplicates": 0}))
    elif args.cmd == "import":
        try:
            with open(args.input) as f:
                events = json.load(f)
        except Exception as exc:
            print(json.dumps({"error": str(exc)}))
            sys.exit(1)
        try:
            inserted = import_events(conn, events)
        except ValueError as exc:
            print(json.dumps({"error": str(exc)}))
            sys.exit(1)
        print(json.dumps({"inserted": inserted, "duplicates": 0}))
    elif args.cmd == "stats":
        try:
            result = stats_range(conn, args.from, args.to)
        except ValueError as exc:
            print(json.dumps({"error": str(exc)}))
            sys.exit(1)
        print(json.dumps(result))
    conn.close()


if __name__ == "__main__":
    main()
