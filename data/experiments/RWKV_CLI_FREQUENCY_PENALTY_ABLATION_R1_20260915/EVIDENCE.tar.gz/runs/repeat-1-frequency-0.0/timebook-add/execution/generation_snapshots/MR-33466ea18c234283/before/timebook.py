#!/usr/bin/env python3

import argparse
import json
import sqlite3
import sys
from datetime import datetime, timezone
from pathlib import Path


def _parse_iso(s: str) -> datetime:
    try:
        return datetime.fromisoformat(s)
    except ValueError as exc:
        raise ValueError(f"invalid ISO time: {s!r}") from exc


def _to_utc_iso(dt: datetime) -> str:
    if dt.tzinfo is None:
        raise ValueError("time must be timezone-aware")
    return dt.astimezone(timezone.utc).isoformat(timespec="seconds")


def _validate_event(e: dict) -> None:
    required = ["id", "project", "start", "end"]
    missing = [k for k in required if k not in e]
    if missing:
        raise ValueError(f"missing fields: {', '.join(missing)}")
    if not e["id"].strip():
        raise ValueError("id must be nonempty")
    if not e["project"].strip():
        raise ValueError("project must be nonempty")
    start = _parse_iso(e["start"])
    end = _parse_iso(e["end"])
    if start.tzinfo is None or end.tzinfo is None:
        raise ValueError("start and end must be timezone-aware")
    if start >= end:
        raise ValueError("end must be after start")


def _normalize_event(e: dict) -> dict:
    e = e.copy()
    e["id"] = e["id"].strip()
    e["project"] = e["project"].strip()
    e["start"] = _to_utc_iso(_parse_iso(e["start"]))
    e["end"] = _to_utc_iso(_parse_iso(e["end"]))
    return e


def _load_db(path: Path) -> sqlite3.Connection:
    conn = sqlite3.connect(str(path))
    conn.row_factory = sqlite3.Row
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS events (
            id TEXT PRIMARY KEY,
            project TEXT NOT NULL,
            start_iso TEXT NOT NULL,
            end_iso TEXT NOT NULL,
            duration_seconds INTEGER NOT NULL
        )
        """
    )
    conn.commit()
    return conn


def _add_events(conn: sqlite3.Connection, events: list[dict]) -> dict:
    inserted = 0
    duplicates = 0
    for e in events:
        try:
            _validate_event(e)
        except ValueError as exc:
            raise ValueError(f"invalid event: {exc}") from exc
        key = (e["id"], e["project"], e["start"], e["end"])
        cur = conn.execute(
            "SELECT 1 FROM events WHERE id=? AND project=? AND start_iso=? AND end_iso=?",
            (e["id"], e["project"], e["start"], e["end"]),
        )
        if cur.fetchone():
            duplicates += 1
            continue
        duration = (datetime.fromisoformat(e["end"]) - datetime.fromisoformat(e["start"])).total_seconds()
        conn.execute(
            "INSERT INTO events VALUES (?, ?, ?, ?, ?)",
            (e["id"], e["project"], e["start"], e["end"], int(duration)),
        )
        inserted += 1
    conn.commit()
    return {"inserted": inserted, "duplicates": duplicates}


def _import_events(conn: sqlite3.Connection, path: Path) -> dict:
    try:
        with path.open("r", encoding="utf-8") as f:
            events = json.load(f)
    except json.JSONDecodeError as exc:
        raise ValueError(f"invalid JSON: {exc}") from exc
    if not isinstance(events, list):
        raise ValueError("JSON root must be an array")
    for e in events:
        if not isinstance(e, dict):
            raise ValueError("each event must be an object")
    try:
        _validate_event(events[0])
    except ValueError as exc:
        raise ValueError(f"invalid event: {exc}") from exc
    for e in events:
        try:
            _validate_event(e)
        except ValueError as exc:
            raise ValueError(f"invalid event: {exc}") from exc
    added = 0
    duplicates = 0
    for e in events:
        try:
            result = _add_events(conn, [e])
            added += result["inserted"]
            duplicates += result["duplicates"]
        except ValueError as exc:
            raise ValueError(f"invalid event: {exc}") from exc
    conn.commit()
    return {"inserted": added, "duplicates": duplicates}


def _stats_range(conn: sqlite3.Connection, from_iso: str, to_iso: str) -> dict:
    from_dt = datetime.fromisoformat(from_iso)
    to_dt = datetime.fromisoformat(to_iso)
    if from_dt >= to_dt:
        raise ValueError("to must be after from")
    cur = conn.execute(
        """
        SELECT project, SUM(duration_seconds) AS seconds
        FROM events
        WHERE start_iso >= ? AND start_iso < ?
        GROUP BY project
        ORDER BY project
        """,
        (from_iso, to_iso),
    )
    rows = cur.fetchall()
    total = sum(r["seconds"] for r in rows)
    days = []
    for r in rows:
        days.append({"date": r["project"], "projects": {r["project"]: r["seconds"]}, "total_seconds": r["seconds"]})
    return {"days": days, "total_seconds": total}


def _main() -> None:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)
    add = sub.add_parser("add")
    add.add_argument("db")
    add.add_argument("id")
    add.add_argument("project")
    add.add_argument("start")
    add.add_argument("end")
    import_cmd = sub.add_parser("import")
    import_cmd.add_argument("db")
    import_cmd.add_argument("input")
    stats = sub.add_parser("stats")
    stats.add_argument("db")
    stats.add_argument("--from", required=True)
    stats.add_argument("--to", required=True)
    args = parser.parse_args()
    conn = _load_db(Path(args.db))
    try:
        if args.command == "add":
            result = _add_events(conn, [{"id": args.id, "project": args.project, "start": args.start, "end": args.end}])
            print(json.dumps(result))
        elif args.command == "import":
            result = _import_events(conn, Path(args.input))
            print(json.dumps(result))
        elif args.command == "stats":
            result = _stats_range(conn, args.from, args.to)
            print(json.dumps(result))
    finally:
        conn.close()


if __name__ == "__main__":
    _main()
