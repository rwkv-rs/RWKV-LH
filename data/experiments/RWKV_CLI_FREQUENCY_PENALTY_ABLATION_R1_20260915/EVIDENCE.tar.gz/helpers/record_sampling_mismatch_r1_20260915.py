from pathlib import Path
import json,hashlib
R=Path('/home/chase/GitHub/RWKV-LH');D=R/'data/experiments/RWKV_CLI_FREQUENCY_PENALTY_ABLATION_R1_20260915'
rows=[]
for p in sorted((D/'runs').rglob('model_trace.jsonl')):
 for line in p.read_text().splitlines():
  r=json.loads(line)
  if r.get('type')=='model_session_generation_started': rows.append({'trace':str(p.relative_to(D)),'trace_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'request_id':r['request_id'],'sampling':r.get('sampling')})
(D/'INVALID.json').write_text(json.dumps({'status':'INVALID','reason':'Nominal frequency0.2 arm actually uses frequency0.0, LongHorizonModel hard-coded sampling overrides RuntimeSettings. No valid causal comparison. Stopped remote experiment service, terminated only current two local experiment workers; incomplete trajectories retained. Original default service restored. No rescore or automatic relabel.','generations':rows},indent=2)+'\n')
E=R/'data/experiments/RWKV_SAMPLING_SETTINGS_FLOW_R1_20260915';E.mkdir(exist_ok=False)
(E/'PRECHANGE_MODEL.py.txt').write_bytes((R/'rwkv_lh/model.py').read_bytes());(E/'PRECHANGE_SESSION.py.txt').write_bytes((R/'rwkv_lh/model_session.py').read_bytes())
(E/'REGISTRATION.json').write_text(json.dumps({'issue':'Configured sampling ignored by hardcoded controller and ModelSession fallback','scope':'All sampling fields, prompt/native transport, explicit override and trace consistency. No default sampling tuning.','source_sha256':{p:hashlib.sha256((R/p).read_bytes()).hexdigest() for p in ['rwkv_lh/model.py','rwkv_lh/model_session.py']},'validation':'Reproduce production parameter mismatch, fix actual session defaults, targeted and full tests before new comparison.'},indent=2)+'\n')
