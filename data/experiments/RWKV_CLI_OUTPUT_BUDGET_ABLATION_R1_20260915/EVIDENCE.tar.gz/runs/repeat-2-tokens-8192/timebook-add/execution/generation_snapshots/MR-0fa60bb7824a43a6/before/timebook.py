import sqlite3
import json
import sys
from datetime import datetime, timezone, timedelta

DB_PATH = "timebook.db"

def _ensure_db():
    conn = sqlite3.connect(DB_PATH)
    conn.execute(
        """CREATE TABLE IF NOT EXISTS events (
            id TEXT PRIMARY KEY,
            project TEXT NOT NULL,
            start_iso TEXT NOT NULL,
            end_iso TEXT NOT NULL,
            duration_seconds INTEGER NOT NULL
        )"""
    )
    conn.commit()
    conn.close()

def _parse_iso(s):
    try:
        dt = datetime.fromisoformat(s)
    except Exception:
        raise ValueError(f"invalid ISO time: {s!r}")
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt

def _to_utc_midnight(dt):
    return dt.replace(hour=0, minute=0, second=0, microsecond=0)

def _duration_seconds(start, end):
    if end <= start:
        raise ValueError("end must be after start")
    return int((end - start).total_seconds())

def _add_event(id, project, start_iso, end_iso):
    conn = sqlite3.connect(DB_PATH)
    conn.execute(
        "SELECT id, project, start_iso, end_iso, duration_seconds FROM events WHERE id = ?",
        (id,),
    )
    row = conn.fetchone()
    conn.close()
    if row:
        raise ValueError(f"event id {id!r} already exists")
    start = _parse_iso(start_iso)
    end = _parse_iso(end_iso)
    if end <= start:
        raise ValueError("end must be after start")
    duration = _duration_seconds(start, end)
    conn = sqlite3.connect(DB_PATH)
    conn.execute(
        "INSERT INTO events (id, project, start_iso, end_iso, duration_seconds) VALUES (?, ?, ?, ?, ?)",
        (id, project, start_iso, end_iso, duration),
    )
    conn.commit()
    conn.close()
    return {"inserted": 1, "duplicates": 0}

def _import_events(events):
    conn = sqlite3.connect(DB_PATH)
    conn.execute("BEGIN TRANSACTION")
    try:
        for ev in events:
            id = ev["id"]
            project = ev["project"]
            start_iso = ev["start"]
            end_iso = ev["end"]
            _add_event(id, project, start_iso, end_iso)
        conn.commit()
        conn.close()
        return {"inserted": len(events), "duplicates": 0}
    except Exception:
        conn.rollback()
        conn.close()
        raise

def _stats_range(from_iso, to_iso):
    conn = sqlite3.connect(DB_PATH)
    conn.execute("BEGIN TRANSACTION")
    try:
        from_dt = _parse_iso(from_iso)
        to_dt = _parse_iso(to_iso)
        if to_dt <= from_dt:
            raise ValueError("to must be after from")
        from_midnight = _to_utc_midnight(from_dt)
        to_midnight = _to_utc_midnight(to_dt)
        conn.execute(
            "SELECT project, SUM(duration_seconds) FROM events WHERE start_iso >= ? AND end_iso < ? GROUP BY project",
            (from_midnight.isoformat(), to_midnight.isoformat()),
        )
        rows = conn.fetchall()
        conn.close()
        total = 0
        days = []
        for project, seconds in rows:
            total += seconds
            days.append({"project": project, "seconds": seconds})
        days.sort(key=lambda d: d["project"])
        return {"days": days, "total_seconds": total}
    except Exception:
        conn.rollback()
        conn.close()
        raise

def main():
    if len(sys.argv) < 2:
        print("usage: python timebook.py add|import|stats ...", file=sys.stderr)
        sys.exit(1)
    cmd = sys.argv[1]
    if cmd == "add":
        if len(sys.argv) != 6:
            print("usage: python timebook.py add DB --id ID --project PROJECT --start ISO --end ISO", file=sys.stderr)
            sys.exit(1)
        db = sys.argv[2]
        id = sys.argv[3]
        project = sys.argv[4]
        start = sys.argv[5]
        end = sys.argv[6]
        try:
            result = _add_event(id, project, start, end)
            print(json.dumps(result))
        except ValueError as e:
            print(json.dumps({"error": str(e)}), file=sys.stderr)
            sys.exit(1)
    elif cmd == "import":
        if len(sys.argv) != 4:
            print("usage: python timebook.py import DB INPUT_JSON", file=sys.stderr)
            sys.exit(1)
        db = sys.argv[2]
        try:
            events = json.loads(sys.stdin.read())
        except Exception:
            print("invalid JSON", file=sys.stderr)
            sys.exit(1)
        try:
            result = _import_events(events)
            print(json.dumps(result))
        except ValueError as e:
            print(json.dumps({"error": str(e)}), file=sys.stderr)
            sys.exit(1)
    elif cmd == "stats":
        if len(sys.argv) != 5:
            print("usage: python timebook.py stats DB --from ISO --to ISO", file=sys.stderr)
            sys.exit(1)
        db = sys.argv[2]
        from_iso = sys.argv[3]
        to_iso = sys.argv[4]
        try:
            result = _stats_range(from_iso, to_iso)
            print(json.dumps(result))
        except ValueError as e:
            print(json.dumps({"error": str(e)}), file=sys.stderr)
            sys.exit(1)
    else:
        print(f"unknown command: {cmd!r}", file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    main()
