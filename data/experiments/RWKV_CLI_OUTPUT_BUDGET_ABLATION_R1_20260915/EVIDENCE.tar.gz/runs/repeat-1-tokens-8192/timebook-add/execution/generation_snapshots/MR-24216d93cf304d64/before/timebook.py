import sqlite3
import json
import sys
from datetime import datetime, timezone, timedelta

DB_PATH = "timebook.db"

def _ensure_db():
    conn = sqlite3.connect(DB_PATH)
    conn.execute(
        "CREATE TABLE IF NOT EXISTS events ("
        "id TEXT PRIMARY KEY,"
        "project TEXT NOT NULL,"
        "start_utc TEXT NOT NULL,"
        "end_utc TEXT NOT NULL,"
        "CHECK (end_utc > start_utc)"
        ")"
    )
    conn.commit()
    conn.close()

def _parse_iso(s):
    try:
        return datetime.fromisoformat(s)
    except Exception:
        return None

def _to_utc_iso(dt):
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc).isoformat()

def _add(args):
    id = args.get("id")
    project = args.get("project")
    start = args.get("start")
    end = args.get("end")
    if not all([id, project, start, end]):
        print("error: missing required fields")
        sys.exit(1)
    if not id.strip():
        print("error: id cannot be empty")
        sys.exit(1)
    if not project.strip():
        print("error: project cannot be empty")
        sys.exit(1)
    start_dt = _parse_iso(start)
    end_dt = _parse_iso(end)
    if start_dt is None or end_dt is None:
        print("error: invalid ISO timestamp")
        sys.exit(1)
    if end_dt <= start_dt:
        print("error: end must be after start")
        sys.exit(1)
    conn = sqlite3.connect(DB_PATH)
    conn.execute(
        "INSERT OR REPLACE INTO events (id, project, start_utc, end_utc) VALUES (?, ?, ?, ?)",
        (id, project, _to_utc_iso(start_dt), _to_utc_iso(end_dt)),
    )
    conn.commit()
    conn.close()
    print("{""inserted": 1, "duplicates": 0""}")

def _import(args):
    path = args.get("path")
    if not path:
        print("error: missing path")
        sys.exit(1)
    try:
        with open(path, "r", encoding="utf-8") as f:
            events = json.load(f)
    except Exception:
        print("error: invalid JSON")
        sys.exit(1)
    if not isinstance(events, list):
        print("error: invalid JSON")
        sys.exit(1)
    conn = sqlite3.connect(DB_PATH)
    conn.execute(
        "CREATE TABLE IF NOT EXISTS events ("
        "id TEXT PRIMARY KEY,"
        "project TEXT NOT NULL,"
        "start_utc TEXT NOT NULL,"
        "end_utc TEXT NOT NULL,"
        "CHECK (end_utc > start_utc)"
        ")"
    )
    conn.commit()
    inserted = 0
    duplicates = 0
    for e in events:
        if not all([e.get("id"), e.get("project"), e.get("start"), e.get("end")]):
            continue
        id = e["id"]
        project = e["project"]
        start = e["start"]
        end = e["end"]
        if not id.strip() or not project.strip():
            continue
        start_dt = _parse_iso(start)
        end_dt = _parse_iso(end)
        if start_dt is None or end_dt is None:
            continue
        if end_dt <= start_dt:
            continue
        try:
            conn.execute(
                "INSERT OR REPLACE INTO events (id, project, start_utc, end_utc) VALUES (?, ?, ?, ?)",
                (id, project, _to_utc_iso(start_dt), _to_utc_iso(end_dt)),
            )
            inserted += 1
        except sqlite3.IntegrityError:
            duplicates += 1
    conn.commit()
    conn.close()
    print("{""inserted": " + str(inserted) + ", ""duplicates": " + str(duplicates) + ""}")

def _stats(args):
    from_str = args.get("from")
    to_str = args.get("to")
    if not from_str or not to_str:
        print("error: missing --from and --to")
        sys.exit(1)
    try:
        from_dt = datetime.fromisoformat(from_str)
        to_dt = datetime.fromisoformat(to_str)
    except Exception:
        print("error: invalid date")
        sys.exit(1)
    if to_dt <= from_dt:
        print("error: to must be after from")
        sys.exit(1)
    conn = sqlite3.connect(DB_PATH)
    conn.execute(
        "CREATE TABLE IF NOT EXISTS events ("
        "id TEXT PRIMARY KEY,"
        "project TEXT NOT NULL,"
        "start_utc TEXT NOT NULL,"
        "end_utc TEXT NOT NULL,"
        "CHECK (end_utc > start_utc)"
        ")"
    )
    conn.commit()
    cursor = conn.execute(
        "SELECT project, start_utc, end_utc FROM events WHERE start_utc >= ? AND end_utc <= ?",
        (_to_utc_iso(from_dt), _to_utc_iso(to_dt)),
    )
    rows = cursor.fetchall()
    conn.close()
    days = {}
    total = 0
    for project, start_utc, end_utc in rows:
        start = _parse_iso(start_utc)
        end = _parse_iso(end_utc)
        if start is None or end is None:
            continue
        if end <= start:
            continue
        start_dt = start.replace(tzinfo=timezone.utc)
        end_dt = end.replace(tzinfo=timezone.utc)
        if start_dt.date() != end_dt.date():
            continue
        if start_dt.date() < from_dt.date() or end_dt.date() > to_dt.date():
            continue
        days[start_dt.date().isoformat()] = days.get(start_dt.date().isoformat(), {})
        days[start_dt.date().isoformat()][project] = days[start_dt.date().isoformat()].get(project, 0) + int((end_dt - start_dt).total_seconds())
        total += int((end_dt - start_dt).total_seconds())
    sorted_days = sorted(days.keys())
    print("{""days": " + json.dumps(days) + ", ""total_seconds": " + str(total) + "}")

def main():
    if len(sys.argv) < 2:
        print("error: missing command")
        sys.exit(1)
    cmd = sys.argv[1]
    if cmd == "add":
        if len(sys.argv) < 6:
            print("error: missing required arguments")
            sys.exit(1)
        _add(vars(sys.argv[2:]))
    elif cmd == "import":
        if len(sys.argv) < 4:
            print("error: missing required arguments")
            sys.exit(1)
        _import(vars(sys.argv[2:]))
    elif cmd == "stats":
        if len(sys.argv) < 5:
            print("error: missing required arguments")
            sys.exit(1)
        _stats(vars(sys.argv[2:]))
    else:
        print("error: unknown command")
        sys.exit(1)

if __name__ == "__main__":
    main()
