#!/usr/bin/env python3

import argparse
import json
import sqlite3
import sys
from datetime import datetime, timezone, timedelta


def parse_iso(s):
    try:
        return datetime.strptime(s, "%Y-%m-%dT%H:%M:%S%z")
    except ValueError:
        raise ValueError(f"invalid ISO time: {s!r}")


def to_utc(dt):
    if dt.tzinfo is None:
        raise ValueError(f"missing timezone: {dt!r}")
    return dt.astimezone(timezone.utc)


def normalize_id(id_):
    if not id_:
        raise ValueError("empty ID")
    return id_.strip()


def normalize_project(p):
    if not p:
        raise ValueError("empty project")
    return p.strip()


def normalize_time(t):
    if not t:
        raise ValueError("empty time")
    return t.strip()


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("command")
    p.add_argument("--db", required=True)
    p.add_argument("--id", required=True)
    p.add_argument("--project", required=True)
    p.add_argument("--start", required=True)
    p.add_argument("--end", required=True)
    p.add_argument("--input", required=True)
    p.add_argument("--from", required=True)
    p.add_argument("--to", required=True)
    return p.parse_args()


def add(db, id_, project, start, end):
    id_ = normalize_id(id_)
    project = normalize_project(project)
    start = parse_iso(normalize_time(start))
    end = parse_iso(normalize_time(end))
    if end <= start:
        raise ValueError("end must be after start")
    conn = sqlite3.connect(db)
    cur = conn.cursor()
    cur.execute(
        "SELECT id, project, start, end FROM events WHERE id = ?", (id_,)
    )
    row = cur.fetchone()
    if row:
        if row[1] != project or row[2] != start or row[3] != end:
            raise ValueError("conflicting event")
        return {"inserted": 0, "duplicates": 1}
    cur.execute(
        "INSERT INTO events (id, project, start, end) VALUES (?, ?, ?, ?)",
        (id_, project, start, end),
    )
    conn.commit()
    return {"inserted": 1, "duplicates": 0}


def import_(db, events):
    conn = sqlite3.connect(db)
    cur = conn.cursor()
    inserted = 0
    duplicates = 0
    for ev in events:
        id_ = normalize_id(ev["id"])
        project = normalize_project(ev["project"])
        start = parse_iso(normalize_time(ev["start"]))
        end = parse_iso(normalize_time(ev["end"]))
        if end <= start:
            raise ValueError("event has invalid time range")
        cur.execute(
            "SELECT id, project, start, end FROM events WHERE id = ?", (id_,)
        )
        row = cur.fetchone()
        if row:
            if row[1] != project or row[2] != start or row[3] != end:
                raise ValueError("conflicting event")
            duplicates += 1
        else:
            cur.execute(
                "INSERT INTO events (id, project, start, end) VALUES (?, ?, ?, ?)",
                (id_, project, start, end),
            )
            inserted += 1
    conn.commit()
    return {"inserted": inserted, "duplicates": duplicates}


def stats(db, from_, to_):
    from_ = parse_iso(normalize_time(from_))
    to_ = parse_iso(normalize_time(to_))
    if to_ <= from_:
        raise ValueError("to must be after from")
    conn = sqlite3.connect(db)
    cur = conn.cursor()
    cur.execute(
        "SELECT id, project, start, end FROM events WHERE start >= ? AND end <= ?",
        (from_, to_),
    )
    rows = cur.fetchall()
    days = {}
    total = 0
    for id_, project, start, end in rows:
        day = start.date()
        if day not in days:
            days[day] = {}
        days[day][project] = days[day].get(project, 0) + (end - start).total_seconds()
        total += (end - start).total_seconds()
    sorted_days = sorted(days.keys())
    projects = sorted(days[sorted_days[0]].keys()) if sorted_days else []
    return {
        "days": [
            {
                "date": d.isoformat(),
                "projects": {p: int(round(seconds)) for p, seconds in days[d].items()},
                "total_seconds": int(round(sum(days[d].values()))),
            }
            for d in sorted_days
        ],
        "total_seconds": int(round(total)),
    }


def main():
    args = parse_args()
    conn = sqlite3.connect(args.db)
    cur = conn.cursor()
    cur.execute("CREATE TABLE IF NOT EXISTS events (id TEXT PRIMARY KEY, project TEXT, start TEXT, end TEXT)")
    conn.commit()
    conn.close()
    if args.command == "add":
        result = add(args.db, args.id, args.project, args.start, args.end)
    elif args.command == "import":
        with open(args.input) as f:
            events = json.load(f)
        result = import_(args.db, events)
    elif args.command == "stats":
        result = stats(args.db, args.from_, args.to_)
    else:
        raise ValueError(f"unknown command: {args.command!r}")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
