"""Exact traces and unchanged external artifact checks; semantic final review remains separate."""
from pathlib import Path
import sys,json,collections,subprocess,hashlib
R=Path('/home/chase/GitHub/RWKV-LH');sys.path.insert(0,str(R))
from rwkv_lh.direct_trace_data import replay_run
D=R/'data/experiments/RWKV_CLI_OUTPUT_BUDGET_ABLATION_R1_20260915'
reg=json.loads((D/'REGISTRATION.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert all(sha(R/p)==h for p,h in reg['source_pins'].items())
checker=reg['external_check'];assert sha(Path(checker['helper_path']))==checker['helper_sha256']
rows=[]
for item in json.loads((D/'RESULTS.json').read_text()):
 name=item['id'];rep=item['repeat'];limit=item['output_tokens_limit'];root=D/'runs'/f'repeat-{rep}-tokens-{limit}'/name
 result=json.loads((root/'COLLECTION_RESULT.json').read_text())
 data=replay_run(root/'execution',reg['model_sha256']);raw=[r['raw_generation'] for r in data.values()]
 checkpath=root/'EXTERNAL_CHECK.json'
 if not checkpath.exists():subprocess.run([sys.executable,checker['helper_path'],name,str(root/'workspace'),str(checkpath)],check=True)
 check=json.loads(checkpath.read_text());functions=collections.Counter()
 for r in raw:
  try:obj=json.loads(r['raw_output']);functions[obj.get('function','unknown')]+=1
  except (ValueError,AttributeError):functions['not_complete_json']+=1
 rows.append({'task':name,'repeat':rep,'output_limit':limit,'artifact_passed':check['exit_code']==0,'submitted':result.get('termination')=='submitted','termination':result.get('termination'),'termination_reason':result.get('termination_reason'),'changed_files':result.get('changed_files'),'generations':len(raw),'logical_input_tokens':sum(len(r['prompt_token_ids']) for r in raw),'output_tokens':sum(len(r['raw_token_ids']) for r in raw),'finish_reasons':dict(collections.Counter(r['finish_reason'] for r in raw)),'parsed_functions':dict(functions),'protocol_rejections':result.get('protocol_rejections'),'elapsed_seconds':result.get('elapsed_seconds'),'exact_replay':True,'final_review':'pending','external_check_sha256':sha(checkpath)})
(D/'TRACE_AND_ARTIFACT_AUDIT.json').write_text(json.dumps({'rows':rows,'scope':'Task acceptance requires independent final fidelity review in addition to artifact pass. Logical tokens are not incremental prefill or monetary cost.'},ensure_ascii=False,indent=2)+'\n')
print(json.dumps(rows,ensure_ascii=False,indent=2))
