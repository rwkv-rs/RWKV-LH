from pathlib import Path
import json,hashlib,tarfile,subprocess
R=Path('/home/chase/GitHub/RWKV-LH');D=R/'data/experiments/RWKV_TERMINAL_DELIVERY_STATUS_R1_20260914';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
owner=['rwkv_lh/controller.py','rwkv_lh/model.py','rwkv_lh/supervisor_openai.py','tests/test_hybrid_supervisor.py','tests/test_supervisor_openai.py'];assert hashlib.sha256(subprocess.check_output(['git','diff','--',*owner],cwd=R)).hexdigest()=='314ca524bbb1e4fc28460409f1068222f29f1819cb410d025edefe64c8f796e0'
(D/'REPORT.zh-CN.md').write_text('''# RWKV_TERMINAL_DELIVERY_STATUS_R1_20260914

Agent级：没有新真实模型任务成绩；本轮是E12工程修复，不把单元测试当作Code Agent通过率。训练R2已因梯度门失败且未进入两臂评测，随后才修改生产源码。

根因：共享_run_job捕获执行异常后，termination已为error，但status仍直接复制可续durable State的running；RWKV与strong_takeover均可复现。新结果status表示本次执行交付：submitted→completed、budget→interrupted、error→failed；原内部状态单独保存在state_status。原state_snapshot、State父链、final和工具结果均不改，completed仍仅表示答案提交，不是验收通过。

公共只读、coding及协助都使用此共享结果构造，coding交付保留字段；检查了批量/协助/集成/worker对status的消费，没有按旧running判断继续执行的分支。批量启动错误等无内部State的其他错误记录并未伪造state_status。

红→绿：RWKV/strong两种异常从running误报到failed；追加启动失败、预算中断及coding提交保持。针对性45 passed；GPU0完整1763 passed、0 skipped，329.47秒。最初临时测试误把内部参数传到公共包装入口而TypeError，保留RED.txt；真正业务红为RED_R2.txt，不能把错误测试入口算修复证据。

未解决的训练数值问题及模型停滞仍保留；E12修复不构成新State收益。Owner五处修改diff SHA 314ca524bbb1e4fc28460409f1068222f29f1819cb410d025edefe64c8f796e0，不混入提交，无push。
''')
with tarfile.open(D/'EVIDENCE.tar.gz','w:gz') as t:
 for p in sorted(D.iterdir()):
  if p.is_file() and p.name not in ('EVIDENCE.tar.gz','SHA256.json'):t.add(p,arcname=p.name)
 for name in ('test_terminal_delivery_status_r1_20260914.py','seal_terminal_delivery_status_r1_20260914.py'):t.add(R/'temp'/name,arcname='helpers/'+name)
(D/'SHA256.json').write_text(json.dumps({p.name:sha(p) for p in [D/'REPORT.zh-CN.md',D/'EVIDENCE.tar.gz']},indent=2)+'\n')
p=R/'docs/DEFECT_REGISTER.zh-CN.md';s=p.read_text().replace('当前只做红色回归，避免修改训练R2已冻结的两臂源码；待本轮固定对比完成后统一修复交付状态与内部可续State状态的区分。','R2训练失败且未评测后已修复：公开status按本次termination表示completed/interrupted/failed，内部可续状态另存state_status，原State及回答不改。真实业务红2项，扩展5项，全套1763 passed。见RWKV_TERMINAL_DELIVERY_STATUS_R1_20260914。');p.write_text(s)
p=R/'docs/HANDOFF.zh-CN.md';s=p.read_text();s+='\n\nE12已在训练R2失败、未进入对比后统一修复：status只表示本次终止交付，durable State另存state_status；异常不再显示running。RWKV/strong两种异常红→绿，45项针对性、GPU0完整1763 passed（329.47s），不改模型输入/最终回答/State。数值复现仍在GPU0运行，最多84额外实际步，原服务退出自动恢复。\n';p.write_text(s)
p=R/'docs/ARCHITECTURE.zh-CN.md';s=p.read_text().replace('`coding_agent.py`复制工作区并保存每次调用前后快照；只读权限限制由`ReadOnlyHarness`执行','`coding_agent.py`复制工作区，修改动作保存前后快照；只读动作保存真实观察，可选生成边界快照只用于离线纠正采集；只读权限由`ReadOnlyHarness`执行');s+='\n\n公开执行结果的`status`表示本次交付终止（completed/interrupted/failed），`state_status`保留内部durable State状态；可续State仍为running不意味着请求还在执行。`completed`与`submitted`均不代表外部验收合格，最终质量由独立验收决定。\n';p.write_text(s)
