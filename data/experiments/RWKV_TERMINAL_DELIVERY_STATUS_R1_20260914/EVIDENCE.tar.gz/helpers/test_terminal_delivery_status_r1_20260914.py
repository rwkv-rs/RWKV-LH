from pathlib import Path
import sys,json
R=Path('/home/chase/GitHub/RWKV-LH');sys.path[:0]=[str(R),str(R/'tests')]
import pytest
from rwkv_lh.read_only_agent import ReadOnlyJob,_run_job,ReadOnlyHarness,_ReadOnlyController
from test_read_only_agent import factory
from test_unified_controller import settings

@pytest.mark.parametrize('authority',['rwkv','strong_takeover'])
def test_execution_exception_is_terminal_delivery_not_running_state(tmp_path,authority):
    workspace=tmp_path/'workspace';workspace.mkdir()
    output=tmp_path/'run'
    result=_run_job(ReadOnlyJob('failed','Read workspace',str(workspace),str(output)),settings=settings(),session_factory=factory([]),execution_authority=authority,harness_factory=ReadOnlyHarness,controller_type=_ReadOnlyController,allowed_scopes=('files','inspect'))
    assert result['termination']=='error' and result['final'] is None
    assert result['status']=='failed'
    assert result['state_status']==json.loads((output/'state_snapshot.json').read_text())['status']
