from pathlib import Path
from dataclasses import replace
from concurrent.futures import ProcessPoolExecutor,as_completed
from multiprocessing import get_context
import sys,json,hashlib,time,subprocess,urllib.request
R=Path('/home/chase/GitHub/RWKV-LH');sys.path.insert(0,str(R))
from rwkv_lh.runtime.settings import get_runtime_settings,load_local_env,direct_agent_settings
from rwkv_lh.coding_agent import CodingJob,run_coding_job
from rwkv_lh.agent_batch import validate_agent_jobs
from rwkv_lh.model_session import create_model_session
from rwkv_lh.correction_snapshots import generation_snapshot_audit
D=R/'data/experiments/RWKV_CLI_ATOMIC_CREATION_R1_20260914'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def worker(job,settings,pins):
 try:
  assert all(sha(R/p)==h for p,h in pins.items())
  output=Path(job.output_dir);workspace=output/'workspace';execution=output/'execution'
  def factory(*,settings,audit_hook):
   wrapped=generation_snapshot_audit(workspace=workspace,output=execution,audit_hook=audit_hook)
   def timed(event):
    with (execution/'AUDIT_TIMINGS.jsonl').open('a') as f:f.write(json.dumps({'epoch':time.time(),'monotonic':time.monotonic(),'type':event.get('type'),'operation':event.get('operation'),'request_id':event.get('request_id')})+'\n')
    wrapped(event)
   return create_model_session(settings=settings,audit_hook=timed)
  result=run_coding_job(job,settings=settings,session_factory=factory)
 except Exception as exc:
  result={'id':job.task_id,'termination':'error','trace_complete':False,'error':type(exc).__name__+': '+str(exc)}
 save(Path(job.output_dir)/'COLLECTION_RESULT.json',result)
 return {'id':job.task_id,'result':result}
if __name__=='__main__':
 assert not (D/'REGISTRATION.json').exists();load_local_env(R/'.env.local')
 settings=direct_agent_settings(replace(get_runtime_settings(),base_url='http://127.0.0.1:29621/v1',model='rwkv-code-agent-gc-r1-ctx24576',model_sha256='559371f5b9aef13189ae54b345ac096af4ad2b689996c05d89de687612b3ae65',max_model_len=24576,state_profile_id='zero',state_profile_sha256='0'*64,read_timeout_seconds=180,default_temperature=.1,default_top_p=1,default_top_k=0,default_presence_penalty=0,default_frequency_penalty=0,default_penalty_decay=.996))
 cases=json.loads((D/'TASKS_PREPARATION.json').read_text())['jobs']
 check=json.loads((D/'EXTERNAL_CHECK_REGISTRATION.json').read_text());assert sha(Path(check['helper_path']))==check['helper_sha256']
 jobs=[]
 for c in cases:
  c.update(max_calls=24,max_seconds=600,files={str(p.relative_to(Path(c['workspace']))):sha(p) for p in Path(c['workspace']).rglob('*') if p.is_file()})
  jobs.append(CodingJob(c['id'],c['request'],c['workspace'],str(D/'runs'/c['id']),24,600))
 validate_agent_jobs(jobs,concurrency=2)
 pins={str(p.relative_to(R)):sha(p) for p in (R/'rwkv_lh').rglob('*.py')}
 save(D/'REGISTRATION.json',{'jobs':cases,'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'source_pins':pins,'helper_sha256':sha(Path(__file__)),'model':settings.model,'model_sha256':settings.model_sha256,'profile':['zero','0'*64],'context_tokens':24576,'output_tokens':1800,'sampling':{'temperature':.1,'top_p':1,'top_k':0,'presence_penalty':0,'frequency_penalty':0,'penalty_decay':.996},'budget':{'maximum_calls':48,'max_seconds_per_task':600,'concurrency':2},'external_check':json.loads((D/'EXTERNAL_CHECK_REGISTRATION.json').read_text()),'purpose':json.loads((D/'TASKS_PREPARATION.json').read_text())['acceptance'],'server_source_manifest_sha256':'2470f1fe98af1f9d01a709fdf1658e0cfa15b8cd0998de0735ce2b1396ee71ee'})
 for endpoint in ['models','capabilities']:save(D/(endpoint.upper()+'.json'),json.loads(urllib.request.urlopen(settings.base_url+'/'+endpoint,timeout=15).read()))
 rows=[];started=time.monotonic()
 with ProcessPoolExecutor(max_workers=2,mp_context=get_context('spawn')) as pool:
  futures={pool.submit(worker,j,settings,pins):j.task_id for j in jobs}
  for future in as_completed(futures):
   try:row=future.result()
   except Exception as exc:row={'id':futures[future],'result':{'termination':'worker_lost','error':type(exc).__name__+': '+str(exc)}}
   rows.append(row);save(D/'RESULTS.json',rows);print(row['id'],row['result']['termination'],row['result'].get('generation_started'),flush=True)
 save(D/'SOURCE_AFTER.json',{'all_match':all(sha(R/p)==h for p,h in pins.items()),'elapsed_seconds':time.monotonic()-started})
