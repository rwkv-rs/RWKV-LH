from pathlib import Path
import subprocess,time,shlex,urllib.request,json
R=Path('/home/chase/GitHub/RWKV-LH');D=R/'data/experiments/RWKV_CLI_ATOMIC_CREATION_R1_20260914';root='/home/chase/GitHub/RWKV-LH-native-gc-r1-20260914'
for _ in range(90):
 p=subprocess.run(['ssh','rwkv-8222',"curl -fsS http://127.0.0.1:18234/metrics | grep -E '^vllm:num_requests_(running|waiting)'"],capture_output=True,text=True)
 if p.returncode==0 and p.stdout and all(float(x.rsplit(' ',1)[1])==0 for x in p.stdout.splitlines()):break
 time.sleep(2)
else:raise RuntimeError('original service idle readiness not established')
(D/'ORIGINAL_IDLE_BEFORE.txt').write_text(p.stdout)
subprocess.run(['ssh','rwkv-8222','systemctl','--user','stop','rwkv-lh-native-current.service'],check=True)
args=['systemd-run','--user','--unit=rwkv-lh-native-gc-r1','--property=RuntimeMaxSec=3600','--property=ExecStopPost=/usr/bin/systemctl --user start rwkv-lh-native-current.service',f'--property=StandardOutput=append:{root}/cli_collection_service.log','--property=StandardError=inherit','bash',root+'/launch.sh']
try:
 subprocess.run(['ssh','rwkv-8222',shlex.join(args)],check=True)
 for _ in range(150):
  try:
   value=json.loads(urllib.request.urlopen('http://127.0.0.1:29621/v1/models',timeout=2).read());assert value['data'][0]['id']=='rwkv-code-agent-gc-r1-ctx24576';break
  except Exception:time.sleep(2)
 else:raise RuntimeError('dedicated service readiness budget exceeded')
 subprocess.run([str(R/'.venv/bin/python'),str(R/'temp/collect_cli_atomic_creation_r1_20260914.py')],cwd=R,check=True)
finally:
 subprocess.run(['ssh','rwkv-8222','systemctl','--user','stop','rwkv-lh-native-gc-r1.service'])
 subprocess.run(['ssh','rwkv-8222','systemctl','--user','start','rwkv-lh-native-current.service'])
