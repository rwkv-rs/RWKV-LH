"""External scoped CLI checks, independent of implementation and model inputs."""
BACKUP_CHECK=r'''
from pathlib import Path
import tempfile,subprocess,sys,json,hashlib,zipfile,os
script=Path('backup.py').resolve()
def invoke(*args,cwd):return subprocess.run([sys.executable,str(script),*map(str,args)],cwd=cwd,text=True,capture_output=True,timeout=20)
with tempfile.TemporaryDirectory() as td:
 p=Path(td);source=p/'source';source.mkdir();(source/'空目录').mkdir();(source/'nested').mkdir();expected={'.hidden':b'','nested/文字.bin':bytes(range(256)),'manifest.json':b'original file'}
 for name,data in expected.items():(source/name).write_bytes(data)
 archive=p/'backup.zip';run=invoke('snapshot',source,archive,cwd=p);assert run.returncode==0,(run.returncode,run.stderr)
 result=json.loads(run.stdout);assert result['files']==3 and result['bytes']==sum(map(len,expected.values())),result
 with zipfile.ZipFile(archive) as z:
  names=z.namelist();assert len(names)==len(set(names)) and not any(n.endswith('/') for n in names)
  m=json.loads(z.read('manifest.json').decode('utf-8'));assert type(m['version']) is int and m['version']==1
  assert set(m['directories'])=={'空目录','nested'} and len(m['directories'])==2,m
  f={r['path']:r for r in m['files']};assert len(f)==len(m['files'])==3 and set(f)==set(expected)
  assert set(names)=={'manifest.json',*('files/'+n for n in expected)}
  for name,data in expected.items():assert z.read('files/'+name)==data and f[name]['size']==len(data) and f[name]['sha256']==hashlib.sha256(data).hexdigest()
 old=archive.read_bytes()
 for kind in ('file_link','dir_link','fifo'):
  bad=source/'bad'
  if kind=='file_link':bad.symlink_to(source/'.hidden')
  elif kind=='dir_link':bad.symlink_to(source/'nested',target_is_directory=True)
  else:os.mkfifo(bad)
  try:
   run=invoke('snapshot',source,archive,cwd=p);assert run.returncode!=0 and run.stderr.strip(),(kind,run.returncode,run.stdout)
   assert archive.read_bytes()==old,'previous archive changed for '+kind
  finally:bad.unlink()
 inside=source/'existing.zip';inside.write_bytes(b'preserve inside target')
 run=invoke('snapshot',source,inside,cwd=p);assert run.returncode!=0 and inside.read_bytes()==b'preserve inside target'
 empty=p/'empty';empty.mkdir();empty_archive=p/'empty.zip';run=invoke('snapshot',empty,empty_archive,cwd=p);assert run.returncode==0,run.stderr;assert json.loads(run.stdout)['files']==0 and json.loads(run.stdout)['bytes']==0
 with zipfile.ZipFile(empty_archive) as z:
  assert z.namelist()==['manifest.json'];m=json.loads(z.read('manifest.json'));assert m['files']==[] and m['directories']==[]
 run=invoke('snapshot',source/'.hidden',archive,cwd=p);assert run.returncode!=0 and archive.read_bytes()==old
 print(json.dumps({'snapshot_format':True,'recursive_binary_unicode_empty':True,'reject_links_special_inside':True,'failed_snapshot_preserves_archive':True,'passed':True}))
'''
TIMEBOOK_CHECK=r'''
from pathlib import Path
import tempfile,subprocess,sys,json,sqlite3
script=Path('timebook.py').resolve()
with tempfile.TemporaryDirectory() as td:
 p=Path(td);db=p/'time.sqlite'
 def add(ident=' e1 ',project=' 项目 ',start='2024-02-29T08:00:00+08:00',end='2024-02-29T09:00:00+08:00'):
  return subprocess.run([sys.executable,str(script),'add',str(db),'--id',ident,'--project',project,'--start',start,'--end',end],cwd=p,text=True,capture_output=True,timeout=20)
 def good(run,inserted,duplicates):
  assert run.returncode==0,run.stderr
  value=json.loads(run.stdout);assert value['inserted']==inserted and value['duplicates']==duplicates,value
 good(add(),1,0);assert db.is_file()
 with sqlite3.connect(db) as c:
  assert c.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
  assert c.execute("SELECT count(*) FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'").fetchone()[0]>0
 good(add(start='2024-02-29T00:00:00Z',end='2024-02-29T01:00:00+00:00'),0,1)
 for kwargs in ({'project':'项目'},{'end':'2024-02-29T10:00:00+08:00'}):
  run=add(**kwargs);assert run.returncode!=0 and run.stderr.strip(),kwargs
 good(add(),0,1);good(add(ident='e1'),1,0)
 invalid=[{'ident':''},{'ident':'  '},{'project':''},{'project':'\t '},{'start':'2024-02-29T00:00:00'},{'end':'2024-02-29T09:00:00.5+08:00'},{'end':'2024-02-29T08:00:00+08:00'},{'end':'2024-02-29T07:00:00+08:00'},{'start':'2024-02-30T08:00:00+08:00'}]
 for index,kwargs in enumerate(invalid):
  args={'ident':'invalid-'+str(index),**kwargs};run=add(**args);assert run.returncode!=0 and run.stderr.strip(),(args,run.stdout)
  good(add(ident='after-'+str(index)),1,0)
 good(add(),0,1)
 print(json.dumps({'persistent_add':True,'utc_equivalent_duplicate':True,'conflict_rejected':True,'names_preserved':True,'validation_cases':len(invalid),'passed':True}))
'''
if __name__=='__main__':
 from pathlib import Path
 import sys,subprocess,json,hashlib
 kind,workspace,output=sys.argv[1:];check={'backup-snapshot':BACKUP_CHECK,'timebook-add':TIMEBOOK_CHECK}[kind]
 result=subprocess.run([sys.executable,'-B','-c',check],cwd=workspace,text=True,capture_output=True,timeout=180)
 p=Path(output);p.parent.mkdir(exist_ok=True,parents=True);p.write_text(json.dumps({'task':kind,'check_sha256':hashlib.sha256(check.encode()).hexdigest(),'exit_code':result.returncode,'stdout':result.stdout,'stderr':result.stderr},ensure_ascii=False,indent=2)+'\n');print(result.returncode)
