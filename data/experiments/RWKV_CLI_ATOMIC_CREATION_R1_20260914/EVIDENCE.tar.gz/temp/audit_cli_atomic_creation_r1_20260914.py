from pathlib import Path
import sys,json,collections,hashlib
R=Path('/home/chase/GitHub/RWKV-LH');sys.path.insert(0,str(R))
from rwkv_lh.direct_trace_data import replay_run
D=R/'data/experiments/RWKV_CLI_ATOMIC_CREATION_R1_20260914';tot={'generations':0,'logical_input_tokens':0,'output_tokens':0};tasks={}
for name in ('backup-snapshot','timebook-add'):
 root=D/'runs'/name/'execution';rows=replay_run(root,'559371f5b9aef13189ae54b345ac096af4ad2b689996c05d89de687612b3ae65');raw=[r['raw_generation'] for r in rows.values()];result=json.loads((D/'runs'/name/'COLLECTION_RESULT.json').read_text());finish=dict(collections.Counter(r['finish_reason'] for r in raw));types=collections.Counter()
 for r in raw:
  try:obj=json.loads(r['raw_output']);types[obj.get('function','unknown')]+=1
  except (ValueError,AttributeError):types['not_complete_json']+=1
 tasks[name]={'task_passed':False,'submitted':result['termination']=='submitted','changed_files':result['changed_files'],'termination_reason':result['termination_reason'],'exact_replay':True,'generations':len(raw),'logical_input_tokens':sum(len(r['prompt_token_ids']) for r in raw),'output_tokens':sum(len(r['raw_token_ids']) for r in raw),'finish_reasons':finish,'parsed_functions':dict(types),'protocol_rejections':result['protocol_rejections'],'elapsed_seconds':result['elapsed_seconds']}
 for k in tot:tot[k]+=tasks[name][k]
(D/'TASK_AUDIT.json').write_text(json.dumps({'tasks':tasks,'totals':tot,'scope':'Two scoped existing authored CLI tasks, zero State. Not project Strict or training benefit. Logical input token count includes complete prior State text; not incremental prefill or money.'},indent=2)+'\n')
(D/'REPORT.zh-CN.md').write_text('''# CLI创建来源采集 R1

任务级：0/2通过，0提交、0文件修改。两项都在12次协议拒绝后预算中断。实际28次生成均已返回，完整重放/输入/观察与State链可重建；工作区源码前后一致。已有事前外部检查在两项最终工作区均因入口文件不存在而失败。

已确认的新边界：RWKV主动选择write_file；备份4次、时间记录11次达到1800token生成上限，JSON未闭合，没有执行写入。备份之后还出现空/仅结束符生成，时间记录首个README调用含非法max_lines并随后恢复。不能把这些统称为不会选择修改，也不能把原MAINT重复读或旧摘要遗漏归因于本轮截断。

工具输出预算原只由LongHorizonModel.next_command的默认1800确定，产品RuntimeSettings没有可配置入口。工程整改维持默认1800，允许显式登记另一个输出预算，并沿同一协议、构造函数和State链传入生成与trace。配置修复本身没有证明更高预算任务会通过。

下一定位性对照：相同两文件/任务、zero、模型、采样和代码，对比1800与8192；两臂重新运行，相同调用及时间预算，评分保持原任务行为要求。原R1的24调用/600秒记录保留，不当作与未来不同调用/时间预算的公平对照。强模型不替RWKV选工具/补参数，截断不能自动修成成功写入。本轮未增加训练数据版本。
''')
print(json.dumps(tot))
