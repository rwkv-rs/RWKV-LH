from pathlib import Path
import sys,json,hashlib,subprocess,os
from dataclasses import asdict
R=Path('/home/chase/GitHub/RWKV-LH');sys.path.insert(0,str(R))
from rwkv_lh.assisted_agent import AssistedJob,load_parent
from rwkv_lh.direct_trace_data import replay_run
from rwkv_lh.workspace_snapshot import tree_identity
from rwkv_lh.runtime.settings import load_local_env
from rwkv_lh.supervisor_openai import SupervisorAPISettings
D=R/'data/experiments/RWKV_BOUNDED_CODE_RECOVERY_R2_20260915';D.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
load_local_env(R/'.env.local');strong=SupervisorAPISettings.from_env();pins={str(p.relative_to(R)):sha(p) for p in (R/'rwkv_lh').rglob('*.py')};sources=[];jobs=[]
for name,parent in [('offset',R/'data/experiments/RWKV_CLI_OFFSET_REPAIR_R1_20260915/runs/repeat-1/execution'),('query',R/'data/experiments/RWKV_UNIFIED_CORRECTION_TRAIN_R3_20260914/evaluation/coding/fix-query-zero-r1/execution')]:
 job=AssistedJob(name,str(parent),str(D/'runs'/name),'takeover',max_calls=12,max_seconds=900)
 previous,result,state,workspace=load_parent(job);replay=replay_run(parent,'559371f5b9aef13189ae54b345ac096af4ad2b689996c05d89de687612b3ae65')
 sources.append({'id':name,'parent':str(parent),'request':state.goal.request,'parent_pins':{n:sha(parent/n) for n in ('RESULT.json','model_trace.jsonl','state_snapshot.json')},'workspace':str(workspace),'tree':tree_identity(workspace),'replayed_generations':len(replay),'parent_termination':result['termination'],'parent_final':result['final']})
 jobs.append({'task_id':name,'parent_run':str(parent),'output_dir':job.output_dir,'assistance':'takeover','max_calls':12,'max_seconds':900})
save(D/'REGISTRATION.json',{'source_pins':pins,'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'helper_sha256':sha(Path(__file__)),'sources':sources,'strong_model':strong.model,'provider_options':{'thinking':{'type':'disabled'}},'budget':{'max_provider_calls':24,'per_task_seconds':900,'max_output_per_call':1800,'concurrency':2},'purpose':'Fresh explicit takeover from same two original zero-RWKV parents after Goal epoch budget scope repair and1787fulltests. OriginalR1 preserved. No new RWKV pass, no trained-State retention, not fixed benchmark rescoring. Check current product recovery and truthful complete delivery. No RWKV/GPU request during this stage.','acceptance':{'offset':'Original public offset test and scoped CLI checks pass; test source and unrelated files preserved; actual agent test run and truthful final.','query':'Original test_query_limit.py passes unchanged on final isolated artifact; actual agent test run and truthful final. Equivalent implementations allowed.'},'checks':{'cli_helper_sha256':sha(R/'temp/verify_cli_atomic_creation_r1_20260914.py'),'offset_test_sha256':sha(Path(sources[0]['workspace'])/'test_timestamp_offset.py'),'query_test_sha256':sha(Path(sources[1]['workspace'])/'test_query_limit.py')},'attribution':'strong_takeover; all preceding failed RWKV calls and strong retry costs included, no direct training admission.'})
save(D/'JOBS.json',jobs);env=dict(os.environ);env['RWKV_LH_PLANNER_REQUEST_OPTIONS']=json.dumps({'thinking':{'type':'disabled'}});env['CUDA_DEVICE_ORDER']='PCI_BUS_ID';env['CUDA_VISIBLE_DEVICES']='0'
with (D/'EXECUTION.log').open('w') as f:p=subprocess.run([str(R/'.venv/bin/python'),str(R/'scripts/run_rwkv_agent.py'),'--jobs',str(D/'JOBS.json'),'--concurrency','2'],cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT)
save(D/'PROCESS_RESULT.json',{'exit_code':p.returncode,'source_unchanged':all(sha(R/p)==h for p,h in pins.items())});print('Explicit recovery process exit',p.returncode)
