from pathlib import Path
import json,hashlib,tarfile,subprocess
R=Path('/home/chase/GitHub/RWKV-LH');D=R/'data/experiments/DSH_MINIMAL_ARCHITECTURE_REVIEW_R1_20260912';REF=R/'temp/dsh_reference_review_20260912'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
p=D/'REPORT.zh-CN.md';old=sha(p);note='\n参数合同也不能机械照搬：dsh的defineTool将参数编译为默认开放对象（core/tools/src/schema.ts:487），与本仓库additionalProperties=false的未知字段拒绝不同。其类型/必填及输出校验仍存在。本轮不改R4协议，也不假设dsh会拒绝同样49条未知参数。任何参数策略调整必须另登记，不能与删除强制完成混成收益。\n'
p.write_text(p.read_text().replace('## 2. 对现有补偿的具体处置',note+'\n## 2. 对现有补偿的具体处置'));h=R/'docs/HANDOFF.zh-CN.md';h.write_text(h.read_text().replace(old,sha(p)))
identity=json.loads((D/'DSH_SOURCE_IDENTITY.json').read_text())
for n in ['packages/core/tools/src/index.ts','packages/core/tools/src/schema.ts']:identity['files'][n]=sha(REF/n)
save(D/'DSH_SOURCE_IDENTITY.json',identity)
with tarfile.open(D/'DSH_REVIEWED_SOURCES.tar.gz','w:gz') as t:
 for n,v in identity['files'].items():assert sha(REF/n)==v;t.add(REF/n,arcname=n)
pre=json.loads((D/'PREEXISTING_CHANGES.json').read_text())['files'];assert len(pre)==5 and all(sha(R/n)==v for n,v in pre.items())
source=json.loads((D/'LOCAL_SOURCE_IDENTITY.json').read_text());assert all(sha(R/n)==v for n,v in source.items())
prior=R/'data/experiments/RWKV_READ_SUMMARY_BASELINE_R5_20260912';pins=json.loads((prior/'REGISTRATION.json').read_text())['source_pins'];assert all(sha(R/n)==v for n,v in pins.items())
assert '1514 passed' in (prior/'PYTEST_FULL.log').read_text()
validation={'kind':'read-only review and documentation; no production edits or new inference','reused_full_test':{'log':str((prior/'PYTEST_FULL.log').relative_to(R)),'sha256':sha(prior/'PYTEST_FULL.log'),'passed':1514,'skipped':0,'rerun':False,'same_runtime_source_pins':True,'same_preexisting_test_files':True},'preexisting_files_unchanged':pre,'dsh_executed':False,'training':False,'github_update':False,'new_dataset':False,'review_script_files':{str(q.relative_to(R)):sha(q) for q in [R/'temp/audit_dsh_architecture_review_20260912.py',R/'temp/write_dsh_architecture_review_20260912.py',Path(__file__)]}}
save(D/'VALIDATION.json',validation)
with tarfile.open(D/'REVIEW_SCRIPTS.tar.gz','w:gz') as t:
 for n in validation['review_script_files']:t.add(R/n,arcname=n)
save(D/'SHA256SUMS.json',{str(q.relative_to(D)):sha(q) for q in sorted(D.iterdir()) if q.is_file() and q.name!='SHA256SUMS.json'})
print('report SHA',sha(p));print('original five unchanged; same-source full 1514 test evidence verified')
