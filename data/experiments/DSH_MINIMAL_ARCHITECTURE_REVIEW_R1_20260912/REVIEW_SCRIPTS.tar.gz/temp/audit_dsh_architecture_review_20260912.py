from pathlib import Path
import json,hashlib,collections,subprocess,tarfile
R=Path('/home/chase/GitHub/RWKV-LH');D=R/'data/experiments/DSH_MINIMAL_ARCHITECTURE_REVIEW_R1_20260912';REF=R/'temp/dsh_reference_review_20260912'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
counts=collections.Counter();reasons=collections.Counter();examples=[];sources={};runs=[]
base=R/'data/experiments/COORDINATOR_ATOMIC_ACTOR_STATE_ABLATION_R5_20260912'
for arm in ['arm_b_atomic','arm_b_atomic_continuation']:
 for p in sorted((base/arm/'cases').glob('*/event_log.json')):
  sources[str(p.relative_to(R))]=sha(p);events=json.loads(p.read_text());rc=collections.Counter(e['type'] for e in events);runs.append({'arm':arm,'case':p.parent.name,'counts':dict(rc)})
  for e in events:
   counts[e['type']]+=1;v=e['data']
   if e['type']=='protocol_rejection_recorded':reasons[str(v.get('error') or v.get('reason'))]+=1
   if e['type'] in ['protocol_rejection_recorded','run_interrupted','run_completed','idempotent_mutation_repeat_boundary']:
    examples.append({'source':str(p.relative_to(R)),'event_id':e['event_id'],'type':e['type'],'error':v.get('error'),'reason':v.get('reason'),'next_required_function':v.get('next_required_function')})
save(D/'TRACE_REVIEW.json',{'runs':runs,'event_counts':dict(counts),'rejection_reasons':dict(reasons),'events':examples,'source_sha256':sources,'limit':'Only these R5 B parent event logs. Code presence is not evidence of activation. No new task pass rate or causal attribution.'})
paths=['README.md','LICENSE','docs/architecture.md','docs/agent-lifecycle.md','packages/core/agent-loop/src/agent.ts','packages/core/agent-loop/src/tool-calls.ts','packages/core/agent-loop/README.md','packages/core/session/src/types.ts','packages/core/session/src/repair.ts','packages/guard/repeat-tool-reminder/src/index.ts','packages/guard/repeat-tool-reminder/README.md','packages/bundle/base/cordis.patch.yml']
identity={'repository':'https://github.com/deepseek-ai/deepseek-harness','commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=REF,text=True).strip(),'files':{p:sha(REF/p) for p in paths},'method':'read-only local checkout; no install/run/API calls; no remote Git'}
save(D/'DSH_SOURCE_IDENTITY.json',identity)
with tarfile.open(D/'DSH_REVIEWED_SOURCES.tar.gz','w:gz') as t:
 for p in paths:t.add(REF/p,arcname=p)
modified=subprocess.check_output(['git','diff','--name-only'],cwd=R,text=True).splitlines();save(D/'PREEXISTING_CHANGES.json',{'files':{p:sha(R/p) for p in modified}})
save(D/'LOCAL_SOURCE_IDENTITY.json',{str(p.relative_to(R)):sha(p) for p in sorted((R/'rwkv_lh').rglob('*.py'))})
print('runs',len(runs),'counts',dict(counts));print('reasons',dict(reasons))
