from pathlib import Path
import sys,json,hashlib
R=Path('/home/chase/GitHub/RWKV-LH');sys.path.insert(0,str(R))
from rwkv_lh.schema import RunState
from rwkv_lh.model_io import render_event_append
from rwkv_lh.token_budget import tokenizer
D=R/'data/experiments/RWKV_ASSISTED_AGENT_R1_20260914';reg=json.loads((D/'REGISTRATION.json').read_text()); rows=[]
for path,sha in reg['source'].items():assert hashlib.sha256((R/path).read_bytes()).hexdigest()==sha,path
for job in reg['jobs']:
 root=Path(job['output_dir']);p=root/'execution';r=json.loads((p/'RESULT.json').read_text());s=RunState.from_dict(json.loads((p/'state_snapshot.json').read_text()))
 previous=Path(job['parent_run']);assert (p/'PARENT_STATE_SNAPSHOT.json').read_bytes()==(previous/'state_snapshot.json').read_bytes();assert (p/'PARENT_RESULT.json').read_bytes()==(previous/'RESULT.json').read_bytes()
 events=[json.loads(l) for l in (p/'model_trace.jsonl').read_text().splitlines()];hist=[json.loads(l) for l in (p/'PARENT_TRACE.jsonl').read_text().splitlines()]
 gens={e['candidate_checkpoint_id']:e['raw_generation'] for e in hist+events if e['type']=='model_session_generation_returned'};starts={e['request_id']:e for e in events if e['type']=='model_session_generation_started'};calls=[]
 for e in events:
  if e['type']!='model_session_generation_returned':continue
  raw=e['raw_generation'];cp=s.model_states[starts[e['request_id']]['input_checkpoint_id']];head=cp;chain=[]
  while cp:chain.append(cp);cp=s.model_states.get(cp.parent_checkpoint_id)
  if job['assistance']=='advice':
   ids=[]
   for cp in reversed(chain):
    if cp.checkpoint_id in gens:ids.extend(gens[cp.checkpoint_id]['raw_token_ids'])
    else:
     if cp.parent_checkpoint_id:
      par=s.model_states[cp.parent_checkpoint_id];delta=set(cp.event_ids)-set(par.event_ids);assert len(delta)==1;assert cp.transcript==render_event_append(s.model_events[next(iter(delta))],previous_transcript=par.transcript)
     ids.extend(tokenizer().encode(cp.transcript))
    if cp.parent_checkpoint_id:assert cp.native_state_metadata['cache_binding']['parent_state_digest']==s.model_states[cp.parent_checkpoint_id].native_state_digest
   assert raw['prompt_token_ids']==[0]+ids
   assert r['continuation']['parent_checkpoint_id'] in [c.checkpoint_id for c in chain]
   inp=tokenizer().decode(ids);tokens={'logical_input_tokens':len(raw['prompt_token_ids']),'output_tokens':len(raw['raw_token_ids'])}
  else:
   transfer=json.loads((p/'TRANSFER.json').read_text());assert chain[-1].checkpoint_id==transfer['target_checkpoint'];assert not chain[-1].parent_checkpoint_id;assert transfer['native_tensor_transfer'] is False
   inp=head.transcript;tokens={'token_ids_available':False}
  (p/'actual_inputs').mkdir(exist_ok=True);(p/'actual_inputs'/f'{e["request_id"]}.txt').write_text(inp)
  calls.append(dict(request_id=e['request_id'],input_sha256=hashlib.sha256(inp.encode()).hexdigest(),finish=raw['finish_reason'],**tokens))
 for a in r['actions']:
  ev=s.model_events.get('EV-ACTION-'+a['action_id']);assert ev
  if a['action_type']=='read_file':assert ''.join(x['content'] for x in ev.payload['result']['observation']['exact_spans'])==a['result']['output']
  if a['action_type']=='run_command':assert ''.join(x['content'] for stream in ev.payload['result']['command_streams'] for x in stream['exact_spans'])==a['result']['output']
 provider=root/'ADVICE_PROVIDER_TRACE.jsonl' if job['assistance']=='advice' else p/'strong_trace.jsonl'
 pe=[json.loads(l) for l in provider.read_text().splitlines()];envelopes=[e for e in pe if e['type']=='supervisor_response_envelope_received']
 if job['assistance']=='takeover':
  returned=[e for e in events if e['type']=='model_session_generation_returned'];assert len(returned)==len(envelopes)
  for e,env in zip(returned,envelopes):assert e['raw_output']==env['raw_response']['choices'][0]['message']['content']
 rows.append(dict(id=job['task_id'],calls=calls,provider_usage=[e['raw_response'].get('usage') for e in envelopes],assistance=r['assistance'],termination=r['termination'],new_actions=len(r['actions'])-r['continuation']['historical_actions'],protocol_rejections=r['protocol_rejections'],parent_unchanged=True,state_and_observations_verified=True,final=r['final']))
(D/'MECHANICAL.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n');print(json.dumps([{k:v for k,v in r.items() if k!='final'} for r in rows],ensure_ascii=False,indent=2))
