from pathlib import Path
import sys,json,hashlib,datetime
from dataclasses import asdict,replace
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from rwkv_lh.runtime.settings import get_runtime_settings
from rwkv_lh.supervisor_openai import SupervisorAPISettings
root=Path('/home/chase/GitHub/RWKV-LH'); exp=root/'data/experiments/RWKV_ASSISTED_AGENT_R1_20260914'
parent=root/'data/experiments/RWKV_AGENT_ARCHITECTURE_BATCH_R1_20260914/live'
jobs=[dict(task_id='advice-health',parent_run=str(parent/'read-health'),output_dir=str(exp/'live/advice-health'),assistance='advice',max_calls=3,max_seconds=300),dict(task_id='takeover-recursive',parent_run=str(parent/'run-recursive/execution'),output_dir=str(exp/'live/takeover-recursive'),assistance='takeover',max_calls=4,max_seconds=600)]
settings=replace(get_runtime_settings(),return_token_ids=True,state_transport='native_required',state_profile_id='zero',state_profile_sha256='0'*64,tool_disclosure_mode='full')
safe={k:v for k,v in asdict(settings).items() if not any(t in k for t in ('key','secret','client_id','proxy'))}
sources={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for folder in ['rwkv_lh','scripts','tests'] for p in sorted((root/folder).rglob('*.py'))}
reg=dict(timestamp=datetime.datetime.now(datetime.timezone.utc).isoformat(),purpose='Explicit assistance interface smoke on two previously successful approved tasks; not a recovery gain comparison.',jobs=jobs,rwkv=safe,strong_model=SupervisorAPISettings.from_env().model,source=sources,criteria={'advice-health':'Faithful GET /health status200 and ok=true summary; excludes booking/order certification; no invented execution. Native parent continuity, observation before advice, original final preserved.','takeover-recursive':'Actual new check_recursive.py execution with exit0 and passed=true, or accurate nonexecution reported as task failure; no file changes; new text root and strong_takeover attribution.'},budget={'strong_advice_requests':1,'advice_output_tokens':1800,'execution_output_tokens':1800,'concurrency':1},acceptance='Both task criteria and handoff evidence required; submitted alone is not acceptance.')
for name,obj in [('REGISTRATION.json',reg),('JOBS.json',jobs)]:
 with (exp/name).open('x') as f:json.dump(obj,f,ensure_ascii=False,indent=2)
print('frozen',len(sources),'source files')
