from pathlib import Path
import json,hashlib,tarfile,subprocess,collections
R=Path('/home/chase/GitHub/RWKV-LH');D=R/'data/experiments/RWKV_ULTRADATA_COLLECTION_R3_20260915';F=R/'data/experiments/RWKV_CODEX_UNIFIED_DATA_FREEZE_R1_20260915';B=R/'data/experiments/RWKV_CODEX_BATCH_CORRECTIONS_R3_20260915';E=R/'data/experiments/RWKV_STDIO_ADMISSION_R1_20260915';data=R/'data/datasets/rwkv_direct_unified_corrections_v4'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
result=json.loads((F/'FREEZE_RESULT.json').read_text());assert result['counts']['train']==85
rows=[json.loads(l) for l in (data/'train.jsonl').read_text().splitlines()];assert len(rows)==85
coverage=collections.Counter(r['label_authority'] for r in rows);save(F/'COVERAGE.json',{'by_authority':dict(coverage),'new_task_count':25,'new_teacher':'current Codex assistant','new_boundaries':'after complete source read, before corrected write','remaining_gaps':['new post-command factual answers not admitted','new command corrections still awaiting original command review contract','multi-file integration and long feedback chains not covered','remaining26 compatible new tasks await teacher correction; five comparator tasks quarantined'],'training_steps':0})
queue=[];admitted={r['source_id'].removeprefix('ultradata-codex-') for r in rows if r['label_authority']=='verified_stdio'};quality={r['id']:r['reason'] for r in json.loads((D/'OUTPUT_CONTRACT_AUDIT.json').read_text())['quarantined']}
for c in json.loads((D/'REGISTRATION.json').read_text())['cases']:
 queue.append({'task_id':c['id'],'status':'admitted_corrected_write' if c['id'] in admitted else ('quarantined_output_contract' if c['id'] in quality else 'awaiting_teacher_correction'),'reason':quality.get(c['id']),'source_run':str(D/'runs'/(c['id']+'-r1')/'execution')})
save(D/'CONTINUATION_QUEUE.json',queue)
check=subprocess.run(['ssh','rwkv-8222','systemctl --user is-active rwkv-lh-native-current.service; curl -fsS http://127.0.0.1:18234/metrics | grep -E "^vllm:num_requests_(running|waiting)"'],capture_output=True,text=True);assert check.returncode==0 and 'active' in check.stdout
(D/'RUNTIME_RESTORED.txt').write_text(check.stdout)
(F/'REPORT.zh-CN.md').write_text('''# 真实采集—Codex纠正—执行验证—统一数据冻结阶段

## 任务结果

新增53题的RWKV原始试采已完成：程序原始外测0/53、提交1、完整任务交付0，改动文件次数4；重复成功预算41、生成次数预算11、提交1。唯一提交Code_00059只有普通背包说明，没有solution.py，且遗漏最后一道菜允许超时吃完的关键条件；没有运行测试，也没有宣称测试已运行，不误记为虚构测试通过。

5题原输出要求不支持精确字符串比较：Code_00026/29/36/89要求数值容差，Code_00077允许多种合法见证和大小写。原始分数不重算，隔离后续准入，不能把其exact失败全部解释为模型失败。其余题也不因通过静态筛选就声称来源普遍无误。

## 原始轨迹与分类

本批307次生成，2018150精确输入token、20281输出token，99次协议拒绝；53/53原始输入、工具观察与State父链核验。46运行有相同工具参数重复，50运行没有执行代码修改，52未提交；这是可观测分类，不将它们全部归因于提示词、State或训练数据。

连同R2原固定组，本地整理93次运行、73题ID、554个真实生成边界。不同组与重复次数只作库存汇总，不混为新评测准确率。外部教师API调用0；当前Codex会话的token与费用未以API账单取得，不能称教师总成本0。GPU仅0，原服务已恢复空闲，临时采集关闭。

## 已落地的数据

当前Codex从公开原题编写22份新纠正程序，运行前冻结；在RWKV完整观察题目后的真实生成快照上执行，22/22基线失败→工具写入→原外部测试通过。加上上一批3题纠正写入，共25不同题目，明确归属教师纠正，不算RWKV独立完成。

新stdio准入合同为具名来源/算法审核加隔离执行，并非虚构双LLM。只适用唯一精确输出、实际solution.py入口、源题无已知矛盾的代码；不放宽总结或命令的原审核。所有输入由唯一生产builder重建，完整题目可见、源/目标/快照/测试SHA绑定；正式冻结再次运行每份证明。新11回归先失败后通过，完整1833测试通过、0跳过。

统一v4正式冻结85条：保留v3全部60条，新增25纠正写入。合计28读取、24回答、29代码修改、4命令；固定回归及切分未换，相似度审计通过，无输入截断。新训练0步，没有新增每缺陷专属State。

## 保留与下一批

3份已执行验证的命令纠正保留在候选队列，未绕过原命令审核。新53题还有26题待教师纠正、5题判题合同需适配；这些均有CONTINUATION_QUEUE，不说全修复。旧失败、R1错误快照假设、首次冻结因全测未结束而拒绝发布的原记录均保留。新增25条集中在阅读后写入，命令后观察、事实忠实回答、反馈修复与多文件集成覆盖仍不足。

本阶段已完成采集、逐运行分类、25题教师纠正与真实验证、准入工程回归和正式统一数据冻结。下一批优先填执行后观察和忠实报告，不立即为这一个问题再训练一份State。现有三个StateTune项目的参考范围和rwkv-peft适配证据保持，训练时再冻结预算并做统一回归。
''')
(E/'FULL_TESTS.log').write_bytes((R/'temp/stdio_admission_full_20260915.log').read_bytes())
subprocess.run(['git','diff','--','rwkv_lh/direct_trace_data.py'],stdout=(E/'INTEGRATION.diff').open('w'),check=True)
with tarfile.open(E/'REGRESSION_SOURCE.tar.gz','w:gz') as t:
 for p in [R/'rwkv_lh/stdio_corrections.py',R/'rwkv_lh/direct_trace_data.py',R/'tests/test_stdio_corrections.py']:t.add(p,arcname=str(p.relative_to(R)))
with tarfile.open(F/'HELPERS.tar.gz','w:gz') as t:
 for n in ['author_codex_batch_r3_20260915.py','validate_codex_batch_r3_20260915.py','freeze_codex_unified_v4_20260915.py','resume_codex_unified_v4_20260915.py','classify_ultradata_phase_r3_20260915.py','seal_ultradata_data_phase_r3_20260915.py']:
  t.add(R/'temp'/n,arcname=n)
 for n in ['validate_codex_batch_r3_20260915.log','freeze_codex_unified_v4_20260915.log','resume_codex_unified_v4_20260915.log']:
  t.add(R/'temp'/n,arcname=n)
for base,folders in [(D,['runs','external','tasks','private','service']),(B,['teacher_sources','validation']),(F,['sources','validation'])]:
 save(base/'RAW_MANIFEST.json',{str(p.relative_to(R)):sha(p) for folder in folders for p in (base/folder).rglob('*') if p.is_file()})
for base in (D,B,F,E):
 files=[p for p in base.iterdir() if p.is_file() and p.name not in ('SOURCE_ROWS.json','RESULTS.json','REVIEWED_ROWS.json','SHA256.json','REGISTRATION_SHA256.json')]
 save(base/'SHA256.json',{p.name:sha(p) for p in files})
p=R/'docs/HANDOFF.zh-CN.md';s=p.read_text();i=s.index('**最新：');j=s.index('\n\n',i);s=s[:i]+'**最新：本批53新题采集与分类完成，307生成/53链路核验通过，原任务交付0。Codex纠正25不同题目并完成隔离红绿和冻结时复验，统一v4正式85条（旧60+新25）；1833完整回归通过、0跳过。新训练0、原服务恢复空闲、owner修改保留、未push。详见[阶段报告](../data/experiments/RWKV_CODEX_UNIFIED_DATA_FREEZE_R1_20260915/REPORT.zh-CN.md)。**'+s[j:];s=s.replace('## owner授权Codex纠错与扩量（运行中）','## owner授权Codex纠错与扩量（已完成本数据阶段）');start=s.index('53个新UltraData Code任务已冻结启动');end=s.index('\n\n',start);s=s[:start]+'53个新任务全部完成，原始轨迹逐运行分类；25题纠正写入正式纳入统一v4，3份命令纠正仍待原审核门。5个不支持exact判题的来源隔离，26新题待教师纠正，队列位于RWKV_ULTRADATA_COLLECTION_R3_20260915/CONTINUATION_QUEUE.json。此前“运行中”状态已结束，原服务恢复空闲。'+s[end:];p.write_text(s)
p=R/'docs/STATETUNE_10000_PLAN.zh-CN.md';s=p.read_text();s=s.replace('当前冻结训练60条。','此前冻结训练60条。',1);pos=s.index('\n## 最新优先级');s=s[:pos]+'\n## 2026-09-15已完成首批扩量准入\n\n统一v4现为85条，旧60保留，新增25不同题目的Codex纠正写入；来源为真实RWKV生成边界，隔离原测试红绿并冻结复验。确定性stdio使用具名来源语义审核加真实执行合同，自由文本和命令不套用此门。当前新训练0；新增数据仍缺命令后/修改后反馈和事实回答覆盖，先补齐再规划统一训练，不按每个问题单独State。详见RWKV_CODEX_UNIFIED_DATA_FREEZE_R1_20260915。\n'+s[pos:];p.write_text(s)
print('sealed data phase',result)
