from pathlib import Path
import json,hashlib,textwrap
D=Path('/home/chase/GitHub/RWKV-LH/data/experiments/RWKV_CODEX_BATCH_CORRECTIONS_R3_20260915');codes={}
codes[23]='''
from collections import defaultdict
n = int(input())
mod = 10**9 + 7
def valid(s):
    if 'AGC' in s: return False
    for i in range(len(s)-1):
        t = list(s)
        t[i], t[i+1] = t[i+1], t[i]
        if 'AGC' in ''.join(t): return False
    return True
dp = {'TTT': 1}
for _ in range(n):
    nd = defaultdict(int)
    for s, v in dp.items():
        for c in 'ACGT':
            if valid(s+c): nd[(s+c)[-3:]] = (nd[(s+c)[-3:]] + v) % mod
    dp = nd
print(sum(dp.values()) % mod)
'''
codes[33]='''
import sys, heapq
a = iter(map(int, sys.stdin.buffer.read().split()))
n, m = next(a), next(a)
jobs = sorted((next(a), next(a)) for _ in range(n))
i = ans = 0
heap = []
for day in range(1, m+1):
    while i < n and jobs[i][0] <= day:
        heapq.heappush(heap, -jobs[i][1]); i += 1
    if heap: ans -= heapq.heappop(heap)
print(ans)
'''
codes[42]='''
n, k, c = map(int, input().split())
s = input().strip()
left = []; i = 0
while i < n and len(left) < k:
    if s[i] == 'o': left.append(i); i += c+1
    else: i += 1
right = []; i = n-1
while i >= 0 and len(right) < k:
    if s[i] == 'o': right.append(i); i -= c+1
    else: i -= 1
for a, b in zip(left, reversed(right)):
    if a == b: print(a+1)
'''
codes[44]='''
import sys
a = list(map(int, sys.stdin.buffer.read().split()))
n, s = a[:2]; mod = 998244353
dp = [0]*(s+1); ans = 0
for x in a[2:]:
    dp[0] += 1
    for j in range(s, x-1, -1): dp[j] = (dp[j] + dp[j-x]) % mod
    ans = (ans + dp[s]) % mod
print(ans)
'''
codes[45]='''
n = int(input()); ans = 0; l = 1
while l <= n:
    q = n // l; r = n // q
    ans += (l+r)*(r-l+1)//2 * (q*(q+1)//2)
    l = r+1
print(ans)
'''
codes[56]='''
import sys
a = list(map(int, sys.stdin.buffer.read().split())); n = a[0]
items = sorted(((v,i) for i,v in enumerate(a[1:])), reverse=True)
dp = [0]
for used,(v,pos) in enumerate(items):
    nd = [-1]*(used+2)
    for left, old in enumerate(dp):
        right = used-left
        nd[left+1] = max(nd[left+1], old+v*abs(pos-left))
        nd[left] = max(nd[left], old+v*abs(pos-(n-1-right)))
    dp = nd
print(max(dp))
'''
codes[59]='''
import sys
a = iter(map(int, sys.stdin.buffer.read().split())); n,t = next(a),next(a)
items = sorted((next(a),next(a)) for _ in range(n))
dp = [-10**18]*t; dp[0]=0; ans=0
for duration,value in items:
    ans = max(ans, max(dp)+value)
    for j in range(t-1,duration-1,-1): dp[j] = max(dp[j],dp[j-duration]+value)
print(ans)
'''
codes[60]='''
import sys
from collections import deque
a=iter(map(int,sys.stdin.buffer.read().split())); n,m,l=next(a),next(a),next(a)
inf=10**30; dist=[[inf]*n for _ in range(n)]
for i in range(n): dist[i][i]=0
for _ in range(m):
    u,v,c=next(a)-1,next(a)-1,next(a); dist[u][v]=dist[v][u]=c
for k in range(n):
    dk=dist[k]
    for i in range(n):
        di=dist[i]; ik=di[k]
        if ik==inf: continue
        for j in range(n):
            if ik+dk[j]<di[j]: di[j]=ik+dk[j]
adj=[[j for j in range(n) if j!=i and dist[i][j]<=l] for i in range(n)]
cache={}; out=[]
for _ in range(next(a)):
    s,t=next(a)-1,next(a)-1
    if s not in cache:
        d=[-1]*n; d[s]=0; q=deque([s])
        while q:
            u=q.popleft()
            for v in adj[u]:
                if d[v]<0: d[v]=d[u]+1; q.append(v)
        cache[s]=d
    out.append(str(max(-1,cache[s][t]-1)))
print('\\n'.join(out))
'''
codes[64]='''
n=int(input()); s=input().strip()
def possible(k):
    first={}
    for i in range(n-k+1):
        part=s[i:i+k]
        if part in first:
            if i-first[part]>=k: return True
        else: first[part]=i
    return False
lo,hi=0,n//2+1
while hi-lo>1:
    mid=(lo+hi)//2
    if possible(mid): lo=mid
    else: hi=mid
print(lo)
'''
codes[66]='''
import sys,bisect
a=list(map(int,sys.stdin.buffer.read().split())); n,t=a[:2]; a=a[2:]
def sums(items):
    values=[0]
    for x in items: values += [v+x for v in values if v+x<=t]
    return values
left=sums(a[:n//2]); right=sorted(sums(a[n//2:]))
print(max(x+right[bisect.bisect_right(right,t-x)-1] for x in left))
'''
codes[69]='''
from functools import lru_cache
h,w,a,b=map(int,input().split()); full=(1<<(h*w))-1
@lru_cache(None)
def solve(mask,a,b):
    if mask==full: return int(a==0 and b==0)
    i=0
    while mask>>i&1: i+=1
    ans=solve(mask|1<<i,a,b-1) if b else 0
    if a:
        if i%w+1<w and not mask>>(i+1)&1: ans+=solve(mask|1<<i|1<<(i+1),a-1,b)
        if i+w<h*w and not mask>>(i+w)&1: ans+=solve(mask|1<<i|1<<(i+w),a-1,b)
    return ans
print(solve(0,a,b))
'''
codes[70]='''
from functools import lru_cache
x,y=map(int,input().split())
@lru_cache(None)
def solve(v):
    if v<=x: return x-v
    ans=v-x
    if v%2==0: return min(ans,1+solve(v//2))
    return min(ans,2+solve(v//2),2+solve(v//2+1))
print(solve(y))
'''
codes[72]='''
import sys,heapq
a=iter(map(int,sys.stdin.buffer.read().split())); n,m,q=next(a),next(a),next(a)
items=sorted((next(a),next(a)) for _ in range(n)); boxes=[next(a) for _ in range(m)]
for _ in range(q):
    l,r=next(a)-1,next(a); available=sorted(boxes[:l]+boxes[r:]); heap=[]; i=ans=0
    for size in available:
        while i<n and items[i][0]<=size: heapq.heappush(heap,-items[i][1]); i+=1
        if heap: ans-=heapq.heappop(heap)
    print(ans)
'''
codes[78]='''
import math
for _ in range(int(input())):
    x,y,p,q=map(int,input().split()); m=2*(x+y); n=p+q; g=math.gcd(m,n)
    inverse=pow(m//g,-1,n//g) if n//g>1 else 0; ans=None
    for a in range(x,x+y):
        for b in range(p,p+q):
            if (b-a)%g: continue
            t=a+m*((b-a)//g*inverse%(n//g))
            if ans is None or t<ans: ans=t
    print('infinity' if ans is None else ans)
'''
codes[82]='''
k=int(input()); n=len(input().strip()); mod=10**9+7
limit=n+k; fac=[1]*(limit+1)
for i in range(1,limit+1): fac[i]=fac[i-1]*i%mod
inv=[1]*(limit+1); inv[limit]=pow(fac[limit],mod-2,mod)
for i in range(limit,0,-1): inv[i-1]=inv[i]*i%mod
p25=1; p26=pow(26,k,mod); inv26=pow(26,mod-2,mod); ans=0
for i in range(k+1):
    ans=(ans+fac[n+i-1]*inv[n-1]%mod*inv[i]%mod*p25%mod*p26)%mod
    p25=p25*25%mod; p26=p26*inv26%mod
print(ans)
'''
codes[84]='''
n,k=map(int,input().split())
def choose3(v): return v*(v-1)*(v-2)//6 if v>=3 else 0
def cumulative(s):
    return choose3(s)-3*choose3(s-n)+3*choose3(s-2*n)-choose3(s-3*n)
lo,hi=2,3*n
while hi-lo>1:
    mid=(lo+hi)//2
    if cumulative(mid)>=k: hi=mid
    else: lo=mid
s=hi; k-=cumulative(s-1)
for i in range(1,n+1):
    low=max(1,s-i-n); high=min(n,s-i-1); count=max(0,high-low+1)
    if k>count: k-=count
    else:
        j=low+k-1; print(i,j,s-i-j); break
'''
codes[85]='''
import sys
a=iter(map(int,sys.stdin.buffer.read().split())); n=next(a)
s=[(next(a),next(a)) for _ in range(n)]; t=[(next(a),next(a)) for _ in range(n)]
def center(points):
    sx=sum(x for x,y in points); sy=sum(y for x,y in points)
    return [(n*x-sx,n*y-sy) for x,y in points]
s=center(s); t=center(t)
if n==1: print('Yes'); raise SystemExit
ax,ay=next((x,y) for x,y in s if x or y); norm=ax*ax+ay*ay
expected={(x*norm,y*norm) for x,y in t}; answer=False
for bx,by in t:
    if bx*bx+by*by!=norm: continue
    dot=ax*bx+ay*by; cross=ax*by-ay*bx
    if {(x*dot-y*cross,x*cross+y*dot) for x,y in s}==expected: answer=True; break
print('Yes' if answer else 'No')
'''
codes[86]='''
import sys
a=list(map(int,sys.stdin.buffer.read().split())); n=a[0]; a=a[1:]; best=1<<60
def visit(i,done,current):
    global best
    if i==n:
        best=min(best,done^current); return
    visit(i+1,done,current|a[i])
    visit(i+1,done^current,a[i])
visit(1,0,a[0]); print(best)
'''
codes[87]='''
import sys
a=iter(map(int,sys.stdin.buffer.read().split())); n,m=next(a),next(a); adj=[[] for _ in range(n)]
for _ in range(m):
    u,v=next(a)-1,next(a)-1; adj[u].append(v); adj[v].append(u)
seen=set(); colors=[-1]*n; answer=1
for root in range(n):
    if root in seen: continue
    order=[root]; seen.add(root)
    for u in order:
        for v in adj[u]:
            if v not in seen: seen.add(v); order.append(v)
    colors[root]=0
    def dfs(i):
        if i==len(order): return 1
        u=order[i]; forbidden={colors[v] for v in adj[u]}; ans=0
        for c in range(3):
            if c not in forbidden: colors[u]=c; ans+=dfs(i+1)
        colors[u]=-1; return ans
    answer*=3*dfs(1); colors[root]=-1
print(answer)
'''
codes[88]='''
n=int(input()); k=int(input()); grid=[input().strip() for _ in range(n)]; adj={}
for r in range(n):
    for c in range(n):
        if grid[r][c]!='.': continue
        mask=0
        for dr,dc in [(1,0),(-1,0),(0,1),(0,-1)]:
            x,y=r+dr,c+dc
            if 0<=x<n and 0<=y<n and grid[x][y]=='.': mask|=1<<(x*n+y)
        adj[r*n+c]=mask
states={1<<i for i in adj}
for _ in range(k-1):
    new=set()
    for mask in states:
        frontier=0; rest=mask
        while rest:
            bit=rest&-rest; rest-=bit; frontier|=adj[bit.bit_length()-1]
        frontier &= ~mask
        while frontier:
            bit=frontier&-frontier; frontier-=bit; new.add(mask|bit)
    states=new
print(len(states))
'''
codes[92]='''
a,b=map(int,input().split()); primes=[p for p in range(2,73) if all(p%d for d in range(2,int(p**0.5)+1))]
dp={0:1}
for value in range(a,b+1):
    mask=sum(1<<i for i,p in enumerate(primes) if value%p==0)
    nd=dp.copy()
    for used,count in dp.items():
        if not used&mask: nd[used|mask]=nd.get(used|mask,0)+count
    dp=nd
print(sum(dp.values()))
'''
codes[95]='''
from collections import defaultdict
n,k=map(int,input().split()); dp={(0,False,True):1}
for ch in str(n):
    digit=int(ch); nd=defaultdict(int)
    for (product,started,tight),count in dp.items():
        for d in range((digit if tight else 9)+1):
            nt=tight and d==digit
            if not started and d==0: nd[(0,False,nt)]+=count
            else:
                value=(product if started else 1)*d
                nd[(min(value,k+1),True,nt)]+=count
    dp=nd
print(sum(count for (product,started,tight),count in dp.items() if started and product<=k))
'''
manifest=[]
for number,code in codes.items():
 p=D/'teacher_sources'/f'Code_{number:05d}.py';p.write_text(textwrap.dedent(code).lstrip());manifest.append({'id':f'Code_{number:05d}','path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'teacher':'current Codex assistant','authored_from':'public original TASK.md only','hidden_test_read_before_authoring':False})
(D/'TEACHER_TARGETS.json').write_text(json.dumps(manifest,indent=2)+'\n');print('authored',len(codes))
