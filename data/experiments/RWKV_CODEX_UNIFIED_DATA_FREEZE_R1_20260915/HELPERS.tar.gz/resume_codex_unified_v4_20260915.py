from pathlib import Path
import sys,json,hashlib,time
R=Path('/home/chase/GitHub/RWKV-LH');sys.path.insert(0,str(R))
from rwkv_lh.direct_trace_data import freeze_direct_dataset
D=R/'data/experiments/RWKV_CODEX_UNIFIED_DATA_FREEZE_R1_20260915';log=R/'temp/stdio_admission_full_20260915.log';start=time.monotonic()
while time.monotonic()-start<900:
 text=log.read_text()
 if '1833 passed' in text:
  assert 'skipped' not in text and 'failed' not in text;break
 if ' failed' in text or 'ERRORS' in text:raise RuntimeError('full tests failed; no dataset publication')
 time.sleep(10)
else:raise TimeoutError('full regression not completed')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();p=D/'FREEZE_REGISTRATION.json';reg=json.loads(p.read_text());ref={'path':str(p),'sha256':sha(p)};manifest=freeze_direct_dataset(reg,registration_reference=ref,output=R/'data/datasets/rwkv_direct_unified_corrections_v4');rows=json.loads((D/'REVIEWED_ROWS.json').read_text())['rows'];result={'counts':manifest['counts'],'manifest_sha256':sha(R/'data/datasets/rwkv_direct_unified_corrections_v4/manifest.json'),'new_unique_tasks':25,'new_corrected_write_boundaries':25,'training_steps':0,'max_sequence_tokens':max(len(r['input_token_ids'])+len(r['target_token_ids'])-1 for r in rows),'prepublication_guard':'Initial helper refused publication until full1833regression green; original refusal retained. Resume uses unchanged registered rows and reexecutes all proofs.'};(D/'FREEZE_RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
