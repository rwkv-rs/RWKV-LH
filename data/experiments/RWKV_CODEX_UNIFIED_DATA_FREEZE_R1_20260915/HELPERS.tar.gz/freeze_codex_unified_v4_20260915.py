from pathlib import Path
import sys,json,hashlib,copy
R=Path('/home/chase/GitHub/RWKV-LH');sys.path.insert(0,str(R))
from rwkv_lh.direct_trace_data import ROW_SCHEMA,ROLE,protocol_identity,normalize_direct_row,audit_source_similarity,freeze_direct_dataset
from rwkv_lh.statetune_data import FREEZE_SCHEMA
from rwkv_lh.stdio_corrections import validate_stdio_correction
from rwkv_lh.token_budget import tokenizer,VOCAB_PATH
D=R/'data/experiments/RWKV_CODEX_UNIFIED_DATA_FREEZE_R1_20260915';D.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,x):
 p=D/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n');return {'path':str(p),'sha256':sha(p)}
oldroot=R/'data/datasets/rwkv_direct_unified_corrections_v3';old=json.loads((oldroot/'manifest.json').read_text());oldreg=json.loads(Path(old['freeze_registration']['path']).read_text());rows=[json.loads(l) for l in (oldroot/'train.jsonl').read_text().splitlines()];assert len(rows)==60;sources=copy.deepcopy(old['sources']);protocol,protocolsha=protocol_identity()
auth=D/'AUTHORIZATION.zh-CN.md';auth.write_text('Owner本会话已书面授权按计划扩大真实失败采集、由Codex纠正并持续积累优质统一StateTune数据，本轮完成该数据阶段。创建rwkv_direct_unified_corrections_v4，保留旧60条，新增25个不同问题的Codex纠正写入；仍使用生产唯一协议和真实输入。新准入合同为来源一致性/可见语义审核加隔离原测试真实失败到通过，不虚构两个独立LLM。合同只覆盖确定性唯一输出stdio程序，不含浮点误差、多解输出、自由文本回答。此前已知歧义题Code_00009排除。训练steps0，不在本数据阶段启动训练；不push。\n')
entries=[]
B=R/'data/experiments/RWKV_CODEX_BATCH_CORRECTIONS_R3_20260915';P=R/'data/experiments/RWKV_ULTRADATA_COLLECTION_R3_20260915'
for x in json.loads((B/'RESULTS.json').read_text()):
 assert x['status']=='execution_verified_candidate';entries.append((x['id'],Path(x['source_run']),x['checkpoint_id'],x['target_text'],B/'validation'/x['id']/'ACTUAL_INPUT.json',P))
B=R/'data/experiments/RWKV_CODEX_PROGRESS_CORRECTIONS_R2_20260915';P=R/'data/experiments/RWKV_ULTRADATA_CODE_PILOT_R2_20260915'
for x in json.loads((B/'RESULTS.json').read_text()):
 assert x['status']=='execution_verified_candidate';entries.append((x['run'].rsplit('-',1)[0],P/'runs'/x['run']/'execution',x['checkpoint_id'],x['target_text'],B/x['run']/'ACTUAL_INPUT.json',P))
assert len(entries)==len({e[0] for e in entries})==25
for ident,root,cp,target,actual_path,collection in entries:
 reg=json.loads((collection/'REGISTRATION.json').read_text());case=next(c for c in reg['cases'] if c['id']==ident);actual=json.loads(actual_path.read_text());task=Path(case['workspace'])/'TASK.md';task_sha=sha(task);source_id='ultradata-codex-'+ident
 files={str(p.relative_to(root)):sha(p) for p in root.rglob('*') if p.is_file()}
 review={'reviewer':'current Codex assistant: explicit source and algorithm review','accepted':True,'visible_evidence_only':True,'source_consistent':True,'output_contract':'exact_unique','task_sha256':task_sha,'input_sha256':hashlib.sha256(actual['input_text'].encode()).hexdigest(),'target_sha256':hashlib.sha256(target.encode()).hexdigest(),'teacher_model_identity':'not exposed as a verifiable API identity; current conversation assistant','teacher_context_token_usage':'not available; not claimed zero','scope':'Public TASK.md requirements reviewed before authoring target; algorithm uses input generally, no hidden-test-specific constants. Real external acceptance separately verifies frozen code.'}
 proof=validate_stdio_correction(run_root=root,checkpoint_id=cp,target_text=target,model_sha256=old['model_sha256'],source_files=files,cases_reference={'path':case['private_tests_path'],'sha256':case['private_tests_sha256']},review=review,output=D/'validation'/ident)
 assert proof['status']=='validated_candidate', (ident,proof['status'])
 collector=save(Path('sources')/ident/'COLLECTOR_SOURCE.json',{'original_registration':{'path':str(collection/'REGISTRATION.json'),'sha256':sha(collection/'REGISTRATION.json')},'files':reg['source_pins']})
 state=json.loads((root/'state_snapshot.json').read_text());metadata=[x['native_state_metadata'] for x in state['model_states'].values()];keys=('model_sha256','server_build','tokenizer_build','protocol_version','state_format_version');identity={k:metadata[0][k] for k in keys};assert all({k:m[k] for k in keys}==identity for m in metadata)
 server=save(Path('sources')/ident/'RECORDED_SERVER_IDENTITY.json',{'identity':identity,'state_snapshot_sha256':sha(root/'state_snapshot.json'),'scope':'sealed recorded server metadata, not new deployment attestation'})
 manifest=save(Path('sources')/ident/'SOURCE_MANIFEST.json',{'source_type':'native_production_trace','model_sha256':old['model_sha256'],'collector_source_manifest_sha256':collector['sha256'],'collector_source_reference':collector,'server_identity_sha256':server['sha256'],'server_identity_reference':server,'files':files})
 sources.append({'id':source_id,'source_id':source_id,'original_task_id':ident,'family':'ULTRADATA_CODE','split':'train','run_root':str(root),'path':'TASK.md','source_content_sha256':task_sha,'content_reference':{'path':str(task),'sha256':task_sha},'manifest':manifest})
 path=D/'validation'/ident/'VALIDATION.json'
 rows.append({'schema_version':ROW_SCHEMA,'role':ROLE,'split':'train','recomputed':True,'sample_id':source_id,'source_id':source_id,'family':'ULTRADATA_CODE','input_protocol':protocol,'protocol_sha256':protocolsha,'model_sha256':old['model_sha256'],'tokenizer_sha256':sha(VOCAB_PATH),'source_manifest_sha256':manifest['sha256'],'source_content_sha256':task_sha,'candidate_checkpoint_id':cp,'input_checkpoint_id':actual['input_checkpoint_id'],'request_id':actual['request_id'],'input_text':actual['input_text'],'input_token_ids':actual['input_token_ids'],'input_token_source':'server_returned_full','target_text':target,'target_token_ids':tokenizer().encode(target),'label_authority':'verified_stdio','stdio_review':review,'stdio_validation':{'path':str(path),'sha256':sha(path)},'teacher':'current Codex assistant'})
 print('admission evidence',ident,flush=True)
for row in rows:normalize_direct_row(row,model_sha256=old['model_sha256'],context_tokens=24576,vocab_size=oldreg['vocab_size'],bos_token_id=oldreg['bos_token_id'])
regref=oldreg['regression_registration'];regression=json.loads(Path(regref['path']).read_text());similarity=audit_source_similarity([*sources,*regression['cases']],threshold=oldreg['similarity_threshold']);assert similarity['passed']
registration={'schema_version':FREEZE_SCHEMA,'role':ROLE,'authorization':{'path':str(auth),'sha256':sha(auth)},'reviewed_rows':save('REVIEWED_ROWS.json',{'rows':rows}),'regression_registration':regref,'regression_fingerprint':regref['sha256'],'sources':sources,'similarity_threshold':oldreg['similarity_threshold'],'similarity_audit':save('SIMILARITY_AUDIT.json',similarity),'model_sha256':old['model_sha256'],'context_tokens':24576,'vocab_size':oldreg['vocab_size'],'bos_token_id':oldreg['bos_token_id'],'minimum_counts':{'train':85,'dev':4,'confirmation':4},'minimum_coverage':{'source_files':61,'families':5,'read_boundaries':28,'summary_boundaries':24,'coding_boundaries':4,'command_boundaries':4,'stdio_boundaries':25},'generator_sha256':sha(Path(__file__)),'admission_source_sha256':sha(R/'rwkv_lh/stdio_corrections.py'),'split_algorithm':'preserve immutable prior regression; new UltraData family train only; source hash/family isolation plus registered similarity audit','teacher_context_usage':'Codex conversation usage unavailable; external teacher API calls zero is not total teacher cost zero'}
ref=save('FREEZE_REGISTRATION.json',registration)
# Full regression must be green before publishing a formal dataset.
log=R/'temp/stdio_admission_full_20260915.log';text=log.read_text();assert '1833 passed' in text and 'skipped' not in text, 'full engineering regression not yet complete'
manifest=freeze_direct_dataset(registration,registration_reference=ref,output=R/'data/datasets/rwkv_direct_unified_corrections_v4');save('FREEZE_RESULT.json',{'counts':manifest['counts'],'manifest_sha256':sha(R/'data/datasets/rwkv_direct_unified_corrections_v4/manifest.json'),'new_unique_tasks':25,'new_corrected_write_boundaries':25,'training_steps':0,'max_sequence_tokens':max(len(r['input_token_ids'])+len(r['target_token_ids'])-1 for r in rows)});print('frozen',manifest['counts'],flush=True)
