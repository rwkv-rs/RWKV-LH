from pathlib import Path
import sys,json,hashlib,collections
R=Path('/home/chase/GitHub/RWKV-LH');sys.path.insert(0,str(R))
from rwkv_lh.model_io import parse_model_command
D=R/'data/experiments/RWKV_ULTRADATA_COLLECTION_R3_20260915';reg=json.loads((D/'REGISTRATION.json').read_text());rows=json.loads((D/'RESULTS.json').read_text());audit=json.loads((D/'runs/MECHANICAL_AUDIT.json').read_text());index={r['id']:r for r in audit}
quality={'Code_00026':'numeric tolerance 1e-9; raw exact-output mismatch cannot establish failure','Code_00029':'numeric tolerance 1e-10; raw exact-output mismatch cannot establish failure','Code_00036':'numeric tolerance 1e-6; raw exact-output mismatch cannot establish failure','Code_00077':'multiple valid sequence witnesses and case-insensitive Yes/No; requires semantic checker','Code_00089':'numeric tolerance 1e-6; raw exact-output mismatch cannot establish failure'}
def save(name,x):(D/name).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
save('OUTPUT_CONTRACT_AUDIT.json',{'scope':'All 53 public output contracts inspected after raw run; no original results rescored. Five contracts unsupported by exact-output verifier; exclusions for subsequent admission. Does not prove every remaining hidden case semantically correct.','quarantined':[{'id':k,'reason':v,'task_sha256':next(c['task_sha256'] for c in reg['cases'] if c['id']==k)} for k,v in quality.items()]})
classified=[];boundaries=[]
for item in rows:
 r=item['result'];a=index[item['id']];operations=collections.Counter(x['action_type'] for x in r['actions']);repeated=len(r['actions'])-len({json.dumps([x['action_type'],x['arguments']],sort_keys=True) for x in r['actions']});tags=[]
 if r['protocol_rejections']:tags.append('protocol_rejected')
 if repeated:tags.append('repeated_identical_tool_arguments')
 if not operations['write_file'] and not operations['replace_text']:tags.append('no_code_edit_executed')
 if r['final'] is None:tags.append('no_final_submission')
 if item['case'] in quality:tags.append('external_output_contract_unsupported')
 if item['id']=='Code_00059-r1':tags+=['final_only_algorithm_without_required_file','algorithm_omits_last_dish_may_finish_after_deadline']
 classified.append({'id':item['id'],'source_task':item['case'],'termination_reason':r['termination_reason'],'changed_files':r['changed_files'],'actions':dict(operations),'exact_repeat_count':repeated,'protocol_rejections':r['protocol_rejections'],'mechanical_pass':a['passed_mechanical_audit'],'observed_failure_tags':tags,'causal_interpretation':'Observable symptoms; not proof prompt/StateTune/architecture caused model behavior'})
 for c in a['calls']:
  try:cmd=parse_model_command(c['raw_output']);valid=True;error=None;op=cmd.name
  except Exception as e:valid=False;error={'type':type(e).__name__,'message':str(e)};op=None
  boundaries.append({'run':item['id'],'request_id':c['request_id'],'input_checkpoint':c['input_checkpoint'],'candidate_checkpoint':c['candidate_checkpoint'],'input_sha256':c['input_sha256'],'input_tokens':c['input_tokens'],'output_tokens':c['output_tokens'],'protocol_valid':valid,'parser_error':error,'operation':op,'raw_output':c['raw_output'],'source_quarantine':quality.get(item['case']),'status':'original boundary preserved; target labels require separate validated correction'})
save('FAILURE_CLASSIFICATION.json',classified);save('BOUNDARY_TRIAGE.json',boundaries)
save('TASK_REVIEW.json',{'runs':53,'qualified_delivery':0,'submitted':1,'raw_artifact_pass':0,'unsupported_output_contract_tasks':5,'changed_source_file_occurrences':sum(len(r['result']['changed_files']) for r in rows),'final_review':{'run':'Code_00059-r1','delivered_file':False,'actual_test_commands':0,'test_success_claim':False,'finding':'Plain knapsack description omits final-dish overrun allowance and creates no required solution.py. Not a fabricated test-success claim.'},'terminations':dict(collections.Counter(r['result']['termination_reason'] for r in rows)),'tag_counts':dict(collections.Counter(t for r in classified for t in r['observed_failure_tags']))})
print('classified',len(classified),'runs',len(boundaries),'boundaries')
