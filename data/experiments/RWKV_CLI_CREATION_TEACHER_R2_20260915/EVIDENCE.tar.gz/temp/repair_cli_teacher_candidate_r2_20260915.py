"""One source-grounded teacher revision; no hidden check input or automatic repair."""
from pathlib import Path
from dataclasses import replace
import sys,json,hashlib,time
R=Path('/home/chase/GitHub/RWKV-LH');sys.path.insert(0,str(R))
from rwkv_lh.strong_session import StrongCompletion
from rwkv_lh.supervisor_openai import SupervisorAPISettings
from rwkv_lh.runtime.settings import load_local_env
from rwkv_lh import model_io
from rwkv_lh.usage_accounting import audit_run_usage
D=R/'data/experiments/RWKV_CLI_CREATION_TEACHER_R2_20260915';D.mkdir();old=R/'data/experiments/RWKV_CLI_CREATION_TEACHER_R1_20260915';reg=json.loads((old/'REGISTRATION.json').read_text());source=next(s for s in reg['sources'] if s['id']=='timebook-add');prior=json.loads((old/'runs/timebook-add/CANDIDATE.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
critique='原始可见README要求 whole-second precision。你的候选正则允许可选小数部分，但构造datetime时只取整数秒，会把不满足精度约束的输入静默改写成整秒。这与可见需求冲突。请修正这一缺陷，同时重新检查原可见要求；只返回一个完整合法的工具调用。不声称已经运行测试，不补充后续观察；保持本轮只实现add的范围。'
prompt=source['actual']['input_text']+'\n\n离线纠正阶段（不进入RWKV训练输入）：\n'+critique+'\n你上一份尚未准入的候选：\n'+prior['raw_output']
load_local_env(R/'.env.local');settings=replace(SupervisorAPISettings.from_env(),retry_attempts=1,semantic_repair_attempts=0,fallback_models=(),plan_cache_enabled=False,planner_request_options={'thinking':{'type':'disabled'}},read_timeout_seconds=180)
registration={'round':D.name,'sources':[source],'helper_sha256':sha(Path(__file__)),'prior_candidate':{'path':str(old/'runs/timebook-add/CANDIDATE.json'),'sha256':sha(old/'runs/timebook-add/CANDIDATE.json')},'teacher_prompt_sha256':hashlib.sha256(prompt.encode()).hexdigest(),'critique_source':'Original visible README precision requirement plus the teacher own candidate regex/parser, not external checker cases/results. Original RWKV training input remains exactly source.actual.input_text. No future tool observation or reference implementation supplied.','budget':{'generation_calls':1,'max_output_tokens':1800,'review_calls_if_valid':2,'training_steps':0},'settings':settings.public_dict()}
(D/'REGISTRATION.json').write_text(json.dumps(registration,ensure_ascii=False,indent=2)+'\n');folder=D/'runs/timebook-add';folder.mkdir(parents=True);(folder/'TEACHER_PROMPT.txt').write_text(prompt);completion=StrongCompletion(settings,folder,1);record={'id':'timebook-add','source_checkpoint':source['checkpoint'],'status':'started'}
try:
 response=completion.text_completion(prompt,max_tokens=1800);record.update(raw_output=response.content,finish_reason=response.finish_reason,model=response.model,response_id=response.response_id);command=model_io.parse_model_command(response.content);json.loads(response.content);record.update(status='candidate',tool=command.name,arguments=command.arguments)
except Exception as exc:record.update(status='error',error=type(exc).__name__+': '+str(exc))
finally:completion.client.close()
(folder/'CANDIDATE.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n');(D/'USAGE.json').write_text(json.dumps(audit_run_usage(D),ensure_ascii=False,indent=2)+'\n');print(record['status'],record.get('tool'))
