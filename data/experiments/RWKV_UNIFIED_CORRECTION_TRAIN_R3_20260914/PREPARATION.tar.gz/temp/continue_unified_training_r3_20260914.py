from pathlib import Path
import subprocess,time,json,hashlib,shlex
R=Path('/home/chase/GitHub/RWKV-LH');D=R/'data/experiments/RWKV_UNIFIED_CORRECTION_TRAIN_R3_20260914';remote='/home/chase/GitHub/RWKV-LH-unified-train-r3-20260914';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def ssh(args,**kw):return subprocess.run(['ssh','rwkv-8222',shlex.join(args)],**kw)
def idle_stop():
 for _ in range(120):
  p=subprocess.run(['ssh','rwkv-8222',"curl -fsS http://127.0.0.1:18234/metrics | grep -E '^vllm:num_requests_(running|waiting)'"],capture_output=True,text=True)
  if p.returncode==0 and p.stdout and all(float(s.rsplit(' ',1)[1])==0 for s in p.stdout.splitlines()):break
  time.sleep(2)
 else:raise RuntimeError('idle original inference not established')
 ssh(['systemctl','--user','stop','rwkv-lh-native-current.service'],check=True)
def launch(unit,script,seconds,log):
 idle_stop()
 try:ssh(['systemd-run','--user','--unit='+unit,'--property=RuntimeMaxSec='+str(seconds),'--property=ExecStopPost=/usr/bin/systemctl --user start rwkv-lh-native-current.service','--property=StandardOutput=append:'+log,'--property=StandardError=inherit','bash',script],check=True)
 except BaseException:ssh(['systemctl','--user','start','rwkv-lh-native-current.service']);raise
start=time.monotonic()
while not (R/'data/experiments/RWKV_CLI_ATOMIC_CREATION_R1_20260914/SOURCE_AFTER.json').exists():
 assert time.monotonic()-start<1500,'collection readiness timeout; do not interrupt an unknown model job'
 time.sleep(10)
while ssh(['systemctl','--user','is-active','rwkv-lh-native-gc-r1.service'],capture_output=True).returncode==0:
 assert time.monotonic()-start<1500
 time.sleep(2)
launch('rwkv-lh-unified-compat-r3',remote+'/validation/validate.sh',3800,remote+'/validation/run.log');print('compatibility launched, zero optimizer updates',flush=True)
start=time.monotonic()
while ssh(['systemctl','--user','is-active','rwkv-lh-unified-compat-r3.service'],capture_output=True).returncode==0:
 assert time.monotonic()-start<3900
 time.sleep(20)
subprocess.run(['scp','-q',f'rwkv-8222:{remote}/validation/compat/RESULT.json',str(D/'runtime/COMPAT_RESULT.json')],check=True)
result=json.loads((D/'runtime/COMPAT_RESULT.json').read_text());assert result['passed'] is True and result['optimizer_steps']==0,result
T=D/'training';reg=json.loads((T/'PREPARATION.json').read_text());reg['compatibility_result']['sha256']=sha(D/'runtime/COMPAT_RESULT.json');f=T/'REGISTRATION.json';assert not f.exists();f.write_text(json.dumps(reg,indent=2)+'\n')
header=(D/'runtime/validate.sh').read_text().split('exec timeout')[0];script=T/'train.sh';script.write_text(header+f'exec timeout 15000 /home/chase/GitHub/RWKV-LH/data/runtime/engines/vllm-rwkv-67f0c5996c50/.venv/bin/python -B {remote}/source/scripts/run_state_tune.py train --registration {remote}/training_registration/REGISTRATION.json --registration-sha256 {sha(f)} --output {remote}/training_runs/{reg["run_id"]}\n')
subprocess.run(['rsync','-a',str(f),str(script),f'rwkv-8222:{remote}/training_registration/'],check=True)
launch('rwkv-lh-unified-training-r3',remote+'/training_registration/train.sh',15100,remote+'/training_registration/train.log');print('training registered and launched:342 planned updates, same57rows, zero, failure diagnostics enabled',flush=True)
start=time.monotonic();last=None
while time.monotonic()-start<15200:
 p=subprocess.run(['scp','-q',f'rwkv-8222:{remote}/training_runs/{reg["run_id"]}/RESULT.json',str(T/'PROGRESS.json')],capture_output=True)
 if p.returncode==0:
  item=json.loads((T/'PROGRESS.json').read_text());key=(item.get('optimizer_steps',0)//20,item['last_event'])
  if key!=last:print(json.dumps({k:item.get(k) for k in ['optimizer_steps','last_event','status','error','failure_context']}),flush=True);last=key
  if item['last_event'] in ('run_finished','run_failed'):
   subprocess.run(['rsync','-a','--exclude=*.pth',f'rwkv-8222:{remote}/training_runs/{reg["run_id"]}/',str(T/'run')+'/'],check=True)
   subprocess.run(['scp','-q',f'rwkv-8222:{remote}/training_registration/train.log',str(T/'train.log')],check=True)
   print('training terminal; no automatic retention or task score',flush=True);break
 time.sleep(20)
else:raise RuntimeError('training monitor elapsed; inspect service and actual ledger')
