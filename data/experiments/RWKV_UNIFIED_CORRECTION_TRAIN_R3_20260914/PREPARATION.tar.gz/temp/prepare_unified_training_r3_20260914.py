from pathlib import Path
import sys,json,hashlib,shutil,subprocess,datetime
R=Path('/home/chase/GitHub/RWKV-LH');sys.path.insert(0,str(R))
from rwkv_lh.inference.uploaded_sources import source_inventory,PROJECT_SCHEMA
D=R/'data/experiments/RWKV_UNIFIED_CORRECTION_TRAIN_R3_20260914';D.mkdir();P=D/'runtime';P.mkdir();S=P/'source';S.mkdir();remote='/home/chase/GitHub/RWKV-LH-unified-train-r3-20260914';old=R/'data/experiments/RWKV_UNIFIED_CORRECTION_TRAIN_R1_20260914';r2=R/'data/experiments/RWKV_UNIFIED_CORRECTION_TRAIN_R2_20260914';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
assert '1766 passed' in (R/'temp/training_failure_full_r1_20260914.txt').read_text()
for n in ('rwkv_lh','scripts'):shutil.copytree(R/n,S/n,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
for n in ('pyproject.toml','uv.lock'):shutil.copyfile(R/n,S/n)
save(P/'PROJECT_SOURCE.json',{'schema_version':PROJECT_SCHEMA,'project_root':remote+'/source','source_root':'.','files':[{'path':p,'sha256':h,'bytes':n} for p,(h,n) in sorted(source_inventory(S).items())]})
identity=sha(P/'PROJECT_SOURCE.json');runtime=json.loads((old/'runtime/NATIVE_RUNTIME_R3.json').read_text());runtime['source_manifest']={'path':remote+'/validation/PROJECT_SOURCE.json','sha256':identity};save(P/'NATIVE_RUNTIME.json',runtime)
compat=json.loads((old/'runtime/COMPAT_REGISTRATION_R3.json').read_text());compat.update(round_id=D.name,source_manifest_sha256=identity);compat.pop('previous_failure_sha256',None);compat['attempt']='Revalidate exact current source after failure observability-only engineering change. No mathematical or precision change; fixed zero/nonzero forward/backward and State-loader gates unchanged.';save(P/'COMPAT_REGISTRATION.json',compat)
shutil.copyfile(r2/'AUTHORIZATION.zh-CN.md',D/'AUTHORIZATION.zh-CN.md')
evalreg=json.loads((r2/'EVALUATION_REGISTRATION.json').read_text());evalreg.update(round_id=D.name,registered_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_manifest_sha256=identity);save(D/'EVALUATION_REGISTRATION.json',evalreg)
E=D/'evaluation';E.mkdir()
for n in ('REGRESSION_REGISTRATION.json','GATE_INTERPRETATION_PRE_RUN.zh-CN.md'):shutil.copyfile(r2/'evaluation'/n,E/n)
shutil.copyfile(D/'EVALUATION_REGISTRATION.json',E/'EVALUATION_REGISTRATION.json')
T=D/'training';T.mkdir();reg=json.loads((r2/'training/REGISTRATION.json').read_text());reg.update(run_id='direct-unified-r3-20260914',source_manifest_sha256=identity,ledger_root=remote+'/training_runs')
for k,p,rel in [('runtime',P/'NATIVE_RUNTIME.json','validation/NATIVE_RUNTIME.json'),('compatibility_registration',P/'COMPAT_REGISTRATION.json','validation/COMPAT_REGISTRATION.json'),('authorization',D/'AUTHORIZATION.zh-CN.md','training_registration/AUTHORIZATION.zh-CN.md'),('evaluation_registration',D/'EVALUATION_REGISTRATION.json','training_registration/EVALUATION_REGISTRATION.json')]:reg[k]={'path':remote+'/'+rel,'sha256':sha(p)}
reg['compatibility_result']={'path':remote+'/validation/compat/RESULT.json','sha256':'PENDING_NOT_A_TRAINING_REGISTRATION'}
reg['limits_note']='Same57 immutable admitted rows/zero/seed/lr1e-4/sixepochs342 planned updates as failed R2. New source adds exact failure State and named bad-gradient context only, no numeric repair. 400step/4h/80GiB caps remain. No sample skipping or automatic retries; failed run remains NO_KEEP. Capture original fault directly instead of assuming deterministic replay. Confirmation remains unopened unless all dev gates pass.'
save(T/'PREPARATION.json',reg)
header=(old/'runtime/validate_r3.sh').read_text().split('exec timeout')[0].replace('/home/chase/GitHub/RWKV-LH-unified-corrections-r1-20260914/source',remote+'/source')
(P/'validate.sh').write_text(header+f'exec timeout 3700 /home/chase/GitHub/RWKV-LH/data/runtime/engines/vllm-rwkv-67f0c5996c50/.venv/bin/python -B {remote}/source/scripts/validate_statetune_native.py --runtime {remote}/validation/NATIVE_RUNTIME.json --runtime-sha256 {sha(P/"NATIVE_RUNTIME.json")} --registration {remote}/validation/COMPAT_REGISTRATION.json --registration-sha256 {sha(P/"COMPAT_REGISTRATION.json")} --output {remote}/validation/compat\n')
save(D/'PREPARATION_IDENTITY.json',{'local_head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'source_manifest_sha256':identity,'helper_sha256':sha(Path(__file__)),'full_tests':'1766 passed, 0 skipped','owner_changes_in_frozen_runtime':True,'dataset_changed':False,'numeric_optimizer_changed':False,'run_status':'prepared_not_launched'})
subprocess.run(['ssh','rwkv-8222','mkdir','-p',remote+'/source',remote+'/validation',remote+'/training_registration'],check=True)
subprocess.run(['rsync','-a',str(S)+'/',f'rwkv-8222:{remote}/source/'],check=True)
subprocess.run(['rsync','-a',str(P/'PROJECT_SOURCE.json'),str(P/'NATIVE_RUNTIME.json'),str(P/'COMPAT_REGISTRATION.json'),str(P/'validate.sh'),f'rwkv-8222:{remote}/validation/'],check=True)
subprocess.run(['rsync','-a',str(D/'AUTHORIZATION.zh-CN.md'),str(D/'EVALUATION_REGISTRATION.json'),f'rwkv-8222:{remote}/training_registration/'],check=True)
print(identity)
