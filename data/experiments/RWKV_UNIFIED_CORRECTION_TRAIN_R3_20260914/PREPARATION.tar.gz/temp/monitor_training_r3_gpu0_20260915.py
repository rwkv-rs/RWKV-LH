from pathlib import Path
import json,time,subprocess
D=Path('/home/chase/GitHub/RWKV-LH/data/experiments/RWKV_UNIFIED_CORRECTION_TRAIN_R3_20260914');start=time.monotonic()
while time.monotonic()-start<15200:
 p=subprocess.run(['ssh','rwkv-8222','nvidia-smi','-i','0','--query-gpu=uuid,memory.used,utilization.gpu,power.draw','--format=csv,noheader,nounits'],capture_output=True,text=True)
 with (D/'training/GPU0_TELEMETRY.jsonl').open('a') as f:f.write(json.dumps({'epoch':time.time(),'returncode':p.returncode,'raw':p.stdout.strip(),'error':p.stderr.strip()})+'\n')
 file=D/'training/PROGRESS.json'
 if file.exists() and json.loads(file.read_text()).get('last_event') in ('run_failed','run_finished'):break
 time.sleep(20)
