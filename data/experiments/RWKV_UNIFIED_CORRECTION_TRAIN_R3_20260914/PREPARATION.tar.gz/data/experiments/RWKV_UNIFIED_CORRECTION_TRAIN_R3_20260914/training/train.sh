#!/bin/bash
set -euo pipefail
export PYTHONPATH=/home/chase/GitHub/RWKV-LH-unified-train-r3-20260914/source:/home/chase/GitHub/RWKV-LH-full-trace-runtime-r2-20260911/engine
export PYTHONDONTWRITEBYTECODE=1
export OMP_NUM_THREADS=4
export VLLM_RWKV7_WKV_MODE=fp32io16
export CUDA_DEVICE_ORDER=PCI_BUS_ID
export CUDA_VISIBLE_DEVICES=0
exec timeout 15000 /home/chase/GitHub/RWKV-LH/data/runtime/engines/vllm-rwkv-67f0c5996c50/.venv/bin/python -B /home/chase/GitHub/RWKV-LH-unified-train-r3-20260914/source/scripts/run_state_tune.py train --registration /home/chase/GitHub/RWKV-LH-unified-train-r3-20260914/training_registration/REGISTRATION.json --registration-sha256 98ccab03a9a9c0487f11d255b2b790d0d46c4784c8877c49c959a3a79ee761e6 --output /home/chase/GitHub/RWKV-LH-unified-train-r3-20260914/training_runs/direct-unified-r3-20260914
