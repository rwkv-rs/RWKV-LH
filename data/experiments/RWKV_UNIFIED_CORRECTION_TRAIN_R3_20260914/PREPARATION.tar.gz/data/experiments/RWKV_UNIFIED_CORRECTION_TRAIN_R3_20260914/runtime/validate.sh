#!/bin/bash
set -euo pipefail
export PYTHONPATH=/home/chase/GitHub/RWKV-LH-unified-train-r3-20260914/source:/home/chase/GitHub/RWKV-LH-full-trace-runtime-r2-20260911/engine
export PYTHONDONTWRITEBYTECODE=1
export OMP_NUM_THREADS=4
export VLLM_RWKV7_WKV_MODE=fp32io16
export CUDA_DEVICE_ORDER=PCI_BUS_ID
export CUDA_VISIBLE_DEVICES=0
exec timeout 3700 /home/chase/GitHub/RWKV-LH/data/runtime/engines/vllm-rwkv-67f0c5996c50/.venv/bin/python -B /home/chase/GitHub/RWKV-LH-unified-train-r3-20260914/source/scripts/validate_statetune_native.py --runtime /home/chase/GitHub/RWKV-LH-unified-train-r3-20260914/validation/NATIVE_RUNTIME.json --runtime-sha256 be6d94888d1412fae9ba7e230f5c7e1f6134ab09f43e5b33ffb60a064d733b77 --registration /home/chase/GitHub/RWKV-LH-unified-train-r3-20260914/validation/COMPAT_REGISTRATION.json --registration-sha256 78e63736833b860a79194762e3206818891874ab8175da1700f752d54f57119c --output /home/chase/GitHub/RWKV-LH-unified-train-r3-20260914/validation/compat
