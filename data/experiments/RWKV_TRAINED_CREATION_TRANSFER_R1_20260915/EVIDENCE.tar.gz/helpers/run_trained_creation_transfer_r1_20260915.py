from pathlib import Path
from dataclasses import replace
import sys,json,hashlib,time,subprocess,urllib.request
R=Path('/home/chase/GitHub/RWKV-LH');S=R/'data/experiments/RWKV_UNIFIED_CORRECTION_TRAIN_R4_20260915/runtime/source';sys.path.insert(0,str(S))
from rwkv_lh.runtime.settings import load_local_env,get_runtime_settings,direct_agent_settings
from rwkv_lh.coding_agent import CodingJob,run_coding_job
from rwkv_lh.model_session import create_model_session,SessionSampling
from rwkv_lh.correction_snapshots import generation_snapshot_audit
D=R/'data/experiments/RWKV_TRAINED_CREATION_TRANSFER_R1_20260915';P=R/'data/experiments/RWKV_UNIFIED_CORRECTION_TRAIN_R4_20260915';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def freeze():
 D.mkdir(exist_ok=False);old=R/'data/experiments/RWKV_CLI_ATOMIC_CREATION_R1_20260914';prep=json.loads((old/'TASKS_PREPARATION.json').read_text());case=next(x for x in prep['jobs'] if x['id']=='timebook-add');assert all(sha(Path(case['workspace'])/p)==h for p,h in case['files'].items());check=json.loads((old/'EXTERNAL_CHECK_REGISTRATION.json').read_text());assert sha(Path(check['helper_path']))==check['helper_sha256'];profile=json.loads((P/'evaluation_service/STATE_PROFILES_SERVING.json').read_text())['profiles'][0]
 offset=R/'data/experiments/RWKV_CLI_OFFSET_REPAIR_R1_20260915/source/test_timestamp_offset.py'
 if not offset.exists():
  reg=json.loads((R/'data/experiments/RWKV_BOUNDED_CODE_RECOVERY_R3_20260915/REGISTRATION.json').read_text());offset=Path(reg['sources'][0]['workspace'])/'test_timestamp_offset.py'
 assert offset.exists()
 save(D/'REGISTRATION.json',{'purpose':'After the independent fixed gate, diagnose whether one complete-write training correction transfers to autonomous whole-task creation on the same seen CLI task. Not unseen generalization, not candidate retention, not new dataset; previous fixed scores unchanged. No source/code/input change or forced tool order.','case':case,'acceptance':prep['acceptance'],'external_check':check,'additional_existing_offset_test':{'path':str(offset),'sha256':sha(offset),'rule':'Existing explicit timezone-invalid offset test runs externally on an isolated output copy; not placed in executor input. Correct handling required by original explicit ISO timestamp task.'},'profiles':{'zero':{'id':'zero','sha256':'0'*64},'candidate':{'id':profile['id'],'sha256':profile['sha256']}},'source_pins':{str(p.relative_to(R)):sha(p) for p in (S/'rwkv_lh').rglob('*.py')},'source_manifest_sha256':sha(P/'runtime/PROJECT_SOURCE.json'),'runner_sha256':sha(Path(__file__)),'sampling':{'temperature':.1,'top_p':1,'top_k':0,'presence_penalty':0,'frequency_penalty':0,'penalty_decay':.996},'model':'rwkv-direct-unified-r4-ctx24576','model_sha256':'559371f5b9aef13189ae54b345ac096af4ad2b689996c05d89de687612b3ae65','context_tokens':24576,'budget':{'calls_per_task':8,'seconds_per_task':600,'output_tokens':1800,'total_calls':32,'total_seconds':2700,'concurrency':1},'order':[[1,'zero'],[1,'candidate'],[2,'candidate'],[2,'zero']],'task_pass_rule':'Original scoped external CLI checks plus existing offset check pass, actual agent-selected checks include success/repeat/rejection as requested, final faithful about implementedadd and unimplementedimport/stats; submission and artifact correctness scored separately. Any equivalent implementation and tool path allowed.','interpretation':'Failure cannot be repaired by post-run scoring or extra calls; success only proves this seen fixed task within recorded budgets. No confirmation or holdout.'})
def run():
 reg=json.loads((D/'REGISTRATION.json').read_text());assert sha(Path(__file__))==reg['runner_sha256'];assert all(sha(R/p)==h for p,h in reg['source_pins'].items());load_local_env(R/'.env.local');cap=json.load(urllib.request.urlopen('http://127.0.0.1:29626/v1/capabilities',timeout=15));assert cap['model']==reg['model'];save(D/'CAPABILITIES.json',cap);rows=[];started=time.monotonic()
 for repeat,arm in reg['order']:
  assert time.monotonic()-started<2700 and all(sha(R/p)==h for p,h in reg['source_pins'].items());profile=reg['profiles'][arm];case=reg['case'];out=D/'runs'/f'{arm}-r{repeat}'
  settings=direct_agent_settings(replace(get_runtime_settings(),base_url='http://127.0.0.1:29626/v1',model=reg['model'],model_sha256=reg['model_sha256'],max_model_len=24576,state_profile_id=profile['id'],state_profile_sha256=profile['sha256'],state_transport='native_required',return_token_ids=True,read_timeout_seconds=300,action_max_output_tokens=1800,default_temperature=.1,default_top_p=1,default_top_k=0,default_presence_penalty=0,default_frequency_penalty=0,default_penalty_decay=.996));expected=SessionSampling.from_settings(settings).to_dict()
  def factory(*,settings,audit_hook):
   wrapped=generation_snapshot_audit(workspace=out/'workspace',output=out/'execution',audit_hook=audit_hook)
   def audit(e):
    if e.get('type')=='model_session_generation_started':assert e['sampling']==expected,'sampling differs before actual generation'
    wrapped(e)
   return create_model_session(settings=settings,audit_hook=audit)
  result=run_coding_job(CodingJob(case['id'],case['request'],case['workspace'],str(out),8,600),settings=settings,session_factory=factory);save(out/'COLLECTION_RESULT.json',result);rows.append({'id':f'{arm}-r{repeat}','arm':arm,'repeat':repeat,'result':result});save(D/'RESULTS.json',rows);print(arm,repeat,result['termination'],result.get('generation_started'),flush=True)
 save(D/'SOURCE_AFTER.json',{'all_match':all(sha(R/p)==h for p,h in reg['source_pins'].items()),'elapsed_seconds':time.monotonic()-started})
if __name__=='__main__':freeze() if sys.argv[1]=='freeze' else run()
