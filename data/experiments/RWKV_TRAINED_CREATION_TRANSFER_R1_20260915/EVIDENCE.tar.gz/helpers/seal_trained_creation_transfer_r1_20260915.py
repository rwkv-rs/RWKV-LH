from pathlib import Path
import json,hashlib,tarfile,collections,subprocess
R=Path('/home/chase/GitHub/RWKV-LH');D=R/'data/experiments/RWKV_TRAINED_CREATION_TRANSFER_R1_20260915';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();reg=json.loads((D/'REGISTRATION.json').read_text());assert all(sha(R/p)==h for p,h in reg['source_pins'].items());mech={x['id']:x for x in json.loads((D/'runs/MECHANICAL_AUDIT.json').read_text())};checks={x['id']:x for x in json.loads((D/'ARTIFACT_CHECKS.json').read_text())};rows=[]
for x in json.loads((D/'RESULTS.json').read_text()):
 r=x['result'];m=mech[x['id']];assert m['passed_mechanical_audit'];assert r['final'] is None and r['changed_files']==[] and not checks[x['id']]['artifact_pass'];rows.append({'id':x['id'],'arm':x['arm'],'repeat':x['repeat'],'task_pass':False,'artifact_pass':False,'submitted':False,'mutated_files':0,'termination':r['termination'],'termination_reason':r['termination_reason'],'protocol_rejections':r['protocol_rejections'],'false_work_claims':0,'false_work_claim_scope':'No final submitted; absence of false claims is not positive completion evidence.','calls':len(m['calls']),'logical_input_tokens':sum(c['input_tokens'] for c in m['calls']),'output_tokens':sum(c['output_tokens'] for c in m['calls']),'finish_reasons':dict(collections.Counter(c['finish'] for c in m['calls'])),'actual_action_counts':dict(collections.Counter(o['operation'] for o in m['observations'])),'successful_actions':sum(o['success'] for o in m['observations']),'elapsed_seconds':r['elapsed_seconds'],'exact_input_state_sampling_observation_audit':True,'review':'No timebook.py delivered; originalCLI/offsetexternalchecks fail. Candidate attemptedMarkdown-asJSON or syntacticallyinvalidPythonwithstatement, repeatsfailedcommand; zero5lengthoutputsperrun. No final to rewrite.'})
metrics={a:{'task_pass':0,'tasks':2,'artifact_pass':0,'submitted':0,'mutated_files':0,'calls':sum(x['calls'] for x in rows if x['arm']==a),'protocol_rejections':sum(x['protocol_rejections'] for x in rows if x['arm']==a),'logical_input_tokens':sum(x['logical_input_tokens'] for x in rows if x['arm']==a),'output_tokens':sum(x['output_tokens'] for x in rows if x['arm']==a)} for a in ['zero','candidate']};out={'decision':'NO_TRANSFER_ON_FIXED_SEEN_TASK','metrics':metrics,'rows':rows,'candidate_state_sha256':reg['profiles']['candidate']['sha256'],'retention':'R4NO_KEEP unchanged; no confirmation/holdout or new dataset/training.','limits':'Same seen task andsamefile as complete-write correction. Not unseen generalization or projectStrict. One task two repeats each, not four independentprojects. Loweroutputcost withoutsuccessfuldeliveryisnotqualifiedtaskcostimprovement.'};(D/'TASK_RESULTS.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
(D/'REPORT.zh-CN.md').write_text(f'''# 见过任务的代码创建迁移 R1

任务级：zero0/2，候选0/2；两臂均0提交、0修改、无timebook.py交付。原CLI外部检查及既有时区偏移边界检查均失败。不是项目Strict，不能据此计算每个合格任务成本。

同一已获准timebook add任务、同README、同模型/源码/采样，zero与R4候选两遍交错，独立State/工作区；每任务8调用/600秒、每次1800输出，评分在运行前冻结。候选训练中确有一条本来源的完整代码写入纠正，但此次完整目标执行没有复现正确写入，不能说训练样本存在就等于任务学会。

zero两遍均先真实列目录/读README，随后写入候选因长度截断被拒绝：每遍5次length，合计{metrics['zero']['protocol_rejections']}次协议拒绝；未落地代码。候选首遍尝试json.loads(README全文)而失败，第二遍生成分号后直接with语句的非法Python；每遍重复同一失败命令5次，触发失败预算。其调用schema合法、0协议拒绝，但操作语义错误，不能把零非法参数记为编码成功。

全26次实际生成的完整输入、State/profile父链、观察和sampling核验通过。zero逻辑输入{metrics['zero']['logical_input_tokens']}、输出{metrics['zero']['output_tokens']}token；候选逻辑输入{metrics['candidate']['logical_input_tokens']}、输出{metrics['candidate']['output_tokens']}token。候选更早中断/更少token不代表合格交付更便宜。原输出未修改，外部检查只在隔离副本运行，未把测试答案放进模型输入。

下一步依据全量训练覆盖审计补真实命令/修改之后的监督边界；目前60行恰无这些输入，4个命令目标的执行验证结果也不能作为其未来输入倒灌。覆盖缺口已确认，是否导致命令偏向还需下一轮同口径验证，不能凭此直接重构Harness。R4仍NO_KEEP，不新增训练、不读取最终holdout。

本轮无生产代码变化，沿用1787 passed完整回归。临时服务已退出并要求恢复原zero服务；最终健康核验另记。所有来源/注册/原始轨迹/真实检查打包于EVIDENCE.tar.gz，SHA见SHA256.json，仅本地提交。
''')
with tarfile.open(D/'EVIDENCE.tar.gz','w:gz') as t:
 for base in (D/'runs',D/'service'):
  for p in sorted(base.rglob('*')):
   if p.is_file():t.add(p,arcname=str(p.relative_to(D)))
 for name in ('REGISTRATION.json','AUDIT_HELPER_REGISTRATION.json','RESULTS.json','SOURCE_AFTER.json','CAPABILITIES.json','ARTIFACT_CHECKS.json'):t.add(D/name,arcname=name)
 for p in sorted((R/'temp').glob('*trained_creation_transfer_r1_20260915.py')):t.add(p,arcname='helpers/'+p.name)
files=[D/x for x in ['REPORT.zh-CN.md','TASK_RESULTS.json','EVIDENCE.tar.gz']];(D/'SHA256.json').write_text(json.dumps({p.name:sha(p) for p in files},indent=2)+'\n');files += [D/'SHA256.json',D/'AUDIT_HELPER_REGISTRATION.json'];subprocess.run(['git','add',*[str(p) for p in files]],check=True);subprocess.run(['git','commit','-m','R1: preserve failed seen-task creation transfer after exact State and artifact audits'],check=True);print(json.dumps(metrics,indent=2))
