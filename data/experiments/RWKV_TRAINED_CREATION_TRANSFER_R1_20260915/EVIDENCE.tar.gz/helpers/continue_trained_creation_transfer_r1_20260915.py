from pathlib import Path
import subprocess,shlex,json,time,hashlib,sys,urllib.request
R=Path('/home/chase/GitHub/RWKV-LH');P=R/'data/experiments/RWKV_UNIFIED_CORRECTION_TRAIN_R4_20260915';D=R/'data/experiments/RWKV_TRAINED_CREATION_TRANSFER_R1_20260915';remote='/home/chase/GitHub/RWKV-LH-unified-train-r4-20260915';unit='rwkv-lh-trained-creation-transfer-r1.service';socket=str(R/'temp/trained_creation_transfer_r1_tunnel.sock');start=time.monotonic();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def ssh(args,**kw):return subprocess.run(['ssh','rwkv-8222',shlex.join(args)],**kw)
while True:
 p=ssh(['systemctl','--user','is-active','rwkv-lh-unified-train4-eval-r1.service'],capture_output=True,text=True)
 if (P/'evaluation/coding/ARTIFACT_CHECKS.json').exists() and p.stdout.strip() not in ('active','activating','deactivating'):break
 if time.monotonic()-start>5400:raise TimeoutError('fixed evaluation not completed; no overlapping probe')
 time.sleep(15)
for _ in range(180):
 p=subprocess.run(['ssh','rwkv-8222',"curl -fsS http://127.0.0.1:18234/metrics | grep -E '^vllm:num_requests_(running|waiting)'"],capture_output=True,text=True)
 if p.returncode==0 and p.stdout and all(float(s.rsplit(' ',1)[1])==0 for s in p.stdout.splitlines()):break
 time.sleep(2)
else:raise RuntimeError('original idle not established')
F=D/'service';F.mkdir();launcher=(P/'evaluation_service/launch.sh').read_text().replace('--port 18250','--port 18251').replace('/evaluation_state/','/creation_transfer_state/');(F/'launch.sh').write_text(launcher);(F/'IDENTITY.json').write_text(json.dumps({'launcher_sha256':sha(F/'launch.sh'),'base_launcher_sha256':sha(P/'evaluation_service/launch.sh'),'source_manifest_sha256':sha(P/'runtime/PROJECT_SOURCE.json'),'state_profiles_sha256':sha(P/'evaluation_service/STATE_PROFILES_SERVING.json'),'runner_sha256':sha(R/'temp/run_trained_creation_transfer_r1_20260915.py'),'orchestrator_sha256':sha(Path(__file__)),'port':18251,'local_port':29626,'gpu':0,'change':'only serviceport and independentState journal; samefrozenR4source/artifact/profiles'},indent=2)+'\n');ssh(['mkdir','-p',remote+'/creation_transfer_service'],check=True);subprocess.run(['rsync','-a',str(F/'launch.sh'),str(F/'IDENTITY.json'),f'rwkv-8222:{remote}/creation_transfer_service/'],check=True)
ssh(['systemctl','--user','stop','rwkv-lh-native-current.service'],check=True)
try:
 ssh(['systemd-run','--user','--unit='+unit,'--property=RuntimeMaxSec=3500','--property=ExecStopPost=/usr/bin/systemctl --user start rwkv-lh-native-current.service','--property=StandardOutput=append:'+remote+'/creation_transfer_service/service.log','--property=StandardError=inherit','bash',remote+'/creation_transfer_service/launch.sh'],check=True)
 subprocess.run(['ssh','-o','BatchMode=yes','-o','ExitOnForwardFailure=yes','-o','ControlMaster=yes','-o','ControlPath='+socket,'-o','ControlPersist=no','-fNT','-L','127.0.0.1:29626:127.0.0.1:18251','rwkv-8222'],check=True)
 for _ in range(90):
  try:
   with urllib.request.urlopen('http://127.0.0.1:29626/v1/capabilities',timeout=10) as f:cap=json.load(f)
   assert cap['model']=='rwkv-direct-unified-r4-ctx24576';break
  except OSError:time.sleep(5)
 else:raise RuntimeError('transfer service not ready')
 subprocess.run([sys.executable,str(R/'temp/run_trained_creation_transfer_r1_20260915.py'),'run'],check=True)
finally:
 ssh(['systemctl','--user','stop',unit]);ssh(['systemctl','--user','start','rwkv-lh-native-current.service'])
 if Path(socket).exists():subprocess.run(['ssh','-S',socket,'-O','exit','rwkv-8222'])
print('Transfer executions completed; external artifacts/manual review still required',flush=True)
