from pathlib import Path
import json,hashlib,subprocess,tarfile
R=Path('/home/chase/GitHub/RWKV-LH');D=R/'data/experiments/RWKV_EXPLICIT_EDIT_R1_20260914';reg=json.loads((D/'REGISTRATION.json').read_text())
for name,sha in reg['source'].items():assert hashlib.sha256((R/name).read_bytes()).hexdigest()==sha
S=Path(reg['jobs'][0]['workspace']);assert {str(p.relative_to(S)):hashlib.sha256(p.read_bytes()).hexdigest() for p in S.rglob('*') if p.is_file()}==reg['input_files']
owner=['rwkv_lh/controller.py','rwkv_lh/model.py','rwkv_lh/supervisor_openai.py','tests/test_hybrid_supervisor.py','tests/test_supervisor_openai.py'];diff=subprocess.check_output(['git','diff','--',*owner],cwd=R);assert diff==(R/'data/experiments/RWKV_ATOMIC_CHANGE_R1_20260914/OWNER_BEFORE.diff').read_bytes();(D/'OWNER_PRESERVED.json').write_text(json.dumps({p:hashlib.sha256((R/p).read_bytes()).hexdigest() for p in owner},indent=2))
assert '1650 passed' in (D/'FULL_TESTS.log').read_text() and 'skipped' not in (D/'FULL_TESTS.log').read_text()
p=D/'REPORT.zh-CN.md';s=p.read_text().replace('清理后完整回归结果见FULL_TESTS.log','清理后完整回归1650 passed in 313.08s，零跳过（含Torch/State及浏览器）；结果见FULL_TESTS.log');p.write_text(s)
with tarfile.open(D/'EVIDENCE.tar.gz','w:gz') as tar:
 for name in ['runs','external']:tar.add(D/name,arcname=name)
 for name in ['run_explicit_edit_r1_20260914.py','audit_explicit_edit_20260914.py','register_defects_20260914.py','extend_current_defects_20260914.py','plan_deep_temp_cleanup_20260914.py','close_explicit_edit_20260914.py']:tar.add(R/'temp'/name,arcname='analysis_scripts/'+name)
(D/'SHA256.json').write_text(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in D.iterdir() if p.is_file() and p.name!='SHA256.json'},indent=2))
print('report sha',hashlib.sha256((D/'REPORT.zh-CN.md').read_bytes()).hexdigest())
