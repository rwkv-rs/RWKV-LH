from pathlib import Path
import json,hashlib
R=Path('/home/chase/GitHub/RWKV-LH');D=R/'data/experiments/RWKV_EXPLICIT_EDIT_R1_20260914';p=D/'DEFECT_REGISTER.json';rows=json.loads(p.read_text());source=D/'runs/atomic-2/execution/RESULT.json';r=json.loads(source.read_text())
q=D/'FALSE_MODIFICATION_CANDIDATE.json';q.write_text(json.dumps(dict(original_result=r,external=json.loads((D/'external/atomic-2/CHECK.json').read_text()),original_source='data/experiments/RWKV_QUERY_REPAIR_FEEDBACK_R1_20260914/source/document_index/query.py',observation='write_file succeeded but delivered bytes unchanged; final claimed requested modification. Test not run was correctly disclosed.'),ensure_ascii=False,indent=2))
rows.append(dict(id='M11',title='写入成功被误当作完成要求的修改',category='model_observation',status='confirmed_unfixed',evidence=str(q.relative_to(R)),evidence_sha256=hashlib.sha256(q.read_bytes()).hexdigest(),label_rule='I/O成功不等于语义修改；依据文件真实内容及差异报告，不能将任务要求复述为已完成事实。未运行测试的正确披露单独保留。',training_admission='not_admitted; verified correction still required'))
p.write_text(json.dumps(rows,ensure_ascii=False,indent=2))
f=R/'docs/DEFECT_REGISTER.zh-CN.md';s=f.read_text();needle='\n模型问题的正向纠正';s=s.replace(needle,'\n|M11|写入成功被误当作完成要求的修改|model_observation / confirmed_unfixed|本轮文件未变却声称改好；正确披露未运行测试应单独保留。|\n'+needle);f.write_text(s)
