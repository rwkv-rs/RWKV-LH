from pathlib import Path
import hashlib,json,subprocess,urllib.parse
R=Path('/home/chase/GitHub/RWKV-LH');D=R/'data/experiments/RWKV_EXPLICIT_EDIT_R1_20260914';rows=[];repos=[]
for name in ['ai00_x_client_reference_20260907','ai00_x_client_routing_review_20260907']:
 p=R/'temp'/name
 assert subprocess.check_output(['git','-C',str(p),'status','--porcelain'])==b''
 head=subprocess.check_output(['git','-C',str(p),'rev-parse','HEAD'],text=True).strip()
 url=subprocess.check_output(['git','-C',str(p),'remote','get-url','origin'],text=True).strip();u=urllib.parse.urlsplit(url)
 if u.scheme:url=urllib.parse.urlunsplit((u.scheme,u.hostname or '',u.path,'',''))
 repos.append(dict(path=str(p.relative_to(R)),commit=head,origin=url,clean=True))
 for f in p.rglob('*'):
  if f.is_symlink():rows.append(dict(path=str(f.relative_to(R)),symlink=str(f.readlink()),bytes=0))
  elif f.is_file():rows.append(dict(path=str(f.relative_to(R)),sha256=hashlib.sha256(f.read_bytes()).hexdigest(),bytes=f.stat().st_size))
tracked=subprocess.check_output(['git','ls-files','data/experiments'],cwd=R,text=True).splitlines();duplicates=[]
for path in tracked:
 if not path.endswith('.py.txt') or 'holdout' in path.lower() or 'acceptance' in path.lower():continue
 p=R/path;target=R/'temp'/p.name[:-4]
 if not target.is_file() or target.is_symlink():continue
 a=target.read_bytes()
 if a!=p.read_bytes():continue
 duplicates.append(dict(path=str(target.relative_to(R)),sha256=hashlib.sha256(a).hexdigest(),bytes=len(a),tracked_evidence=path))
duplicates=list({e['path']:e for e in duplicates}.values())
(D/'CLEANUP_PLAN.json').write_text(json.dumps(dict(repositories=repos,repository_files=rows,duplicate_scripts=duplicates),indent=2))
print('clean repo files',len(rows),'bytes',sum(e['bytes'] for e in rows),'duplicate scripts',len(duplicates))
