#!/usr/bin/env python3
"""Team timebook: durable SQLite-backed time tracking CLI."""

import argparse
import json
import re
import sqlite3
import sys
from datetime import datetime, timedelta, timezone


ISO_RE = re.compile(
    r"^(\d{4})-(\d{2})-(\d{2})[Tt ](\d{2}):(\d{2}):(\d{2})(Z|z|[+-]\d{2}:\d{2})$"
)


class TimebookError(Exception):
    pass


def parse_timestamp(value, field):
    if not isinstance(value, str) or not value.strip():
        raise TimebookError(f"{field} must be a nonempty string")
    match = ISO_RE.match(value.strip())
    if not match:
        raise TimebookError(
            f"{field} must be ISO 8601 with an explicit UTC offset or Z and whole-second precision"
        )
    year, month, day, hour, minute, second, offset = match.groups()
    try:
        base = datetime(
            int(year), int(month), int(day), int(hour), int(minute), int(second),
            tzinfo=timezone.utc,
        )
    except ValueError as exc:
        raise TimebookError(f"{field} is not a valid calendar timestamp: {exc}")
    if offset.upper() == "Z":
        delta_seconds = 0
    else:
        sign = 1 if offset[0] == "+" else -1
        hours = int(offset[1:3])
        minutes = int(offset[4:6])
        if hours > 23 or minutes > 59:
            raise TimebookError(f"{field} has an invalid UTC offset")
        delta_seconds = sign * (hours * 3600 + minutes * 60)
    return base - timedelta(seconds=delta_seconds)


def normalize_instant(dt):
    return dt.astimezone(timezone.utc).replace(microsecond=0)


def validate_event(raw):
    if not isinstance(raw, dict):
        raise TimebookError("event must be an object")
    for key in ("id", "project", "start", "end"):
        if key not in raw:
            raise TimebookError(f"event missing required field '{key}'")
        value = raw[key]
        if not isinstance(value, str) or not value.strip():
            raise TimebookError(f"field '{key}' must be a nonempty string")
    event_id = raw["id"]
    project = raw["project"]
    start = normalize_instant(parse_timestamp(raw["start"], "start"))
    end = normalize_instant(parse_timestamp(raw["end"], "end"))
    if end <= start:
        raise TimebookError("end must be strictly after start")
    duration = int((end - start).total_seconds())
    return {
        "id": event_id,
        "project": project,
        "start": start.isoformat(),
        "end": end.isoformat(),
        "duration": duration,
    }


def connect(db_path):
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS events (
            id TEXT PRIMARY KEY,
            project TEXT NOT NULL,
            start_utc TEXT NOT NULL,
            end_utc TEXT NOT NULL,
            duration INTEGER NOT NULL
        )
        """
    )
    conn.commit()
    return conn


def existing_event(conn, event_id):
    return conn.execute(
        "SELECT id, project, start_utc, end_utc, duration FROM events WHERE id = ?",
        (event_id,),
    ).fetchone()


def insert_events(conn, events):
    """Insert validated events atomically. Returns (inserted, duplicates)."""
    conn.execute("BEGIN IMMEDIATE")
    try:
        inserted = 0
        duplicates = 0
        for event in events:
            row = existing_event(conn, event["id"])
            if row is not None:
                same = (
                    row["project"] == event["project"]
                    and row["start_utc"] == event["start"]
                    and row["end_utc"] == event["end"]
                    and row["duration"] == event["duration"]
                )
                if same:
                    duplicates += 1
                    continue
                raise TimebookError(
                    f"conflicting event for id '{event['id']}': existing record differs"
                )
            conn.execute(
                "INSERT INTO events (id, project, start_utc, end_utc, duration) "
                "VALUES (?, ?, ?, ?, ?)",
                (event["id"], event["project"], event["start"], event["end"], event["duration"]),
            )
            inserted += 1
        conn.commit()
        return inserted, duplicates
    except Exception:
        conn.rollback()
        raise


def cmd_add(args):
    event = validate_event(
        {"id": args.id, "project": args.project, "start": args.start, "end": args.end}
    )
    conn = connect(args.db)
    try:
        inserted, duplicates = insert_events(conn, [event])
    finally:
        conn.close()
    print(json.dumps({"inserted": inserted, "duplicates": duplicates}))
    return 0


def build_parser():
    parser = argparse.ArgumentParser(prog="timebook.py")
    sub = parser.add_subparsers(dest="command", required=True)

    add = sub.add_parser("add", help="record a single event")
    add.add_argument("db")
    add.add_argument("--id", required=True)
    add.add_argument("--project", required=True)
    add.add_argument("--start", required=True)
    add.add_argument("--end", required=True)
    add.set_defaults(func=cmd_add)

    return parser


def main(argv=None):
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        return args.func(args)
    except TimebookError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
