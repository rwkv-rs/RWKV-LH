#!/bin/bash
set -euo pipefail
export PYTHONPATH=/home/chase/GitHub/RWKV-LH-unified-corrections-r1-20260914/source:/home/chase/GitHub/RWKV-LH-full-trace-runtime-r2-20260911/engine
export PYTHONDONTWRITEBYTECODE=1
export OMP_NUM_THREADS=4
export VLLM_RWKV7_WKV_MODE=fp32io16
export CUDA_DEVICE_ORDER=PCI_BUS_ID
export CUDA_VISIBLE_DEVICES=0
exec timeout 3700 /home/chase/GitHub/RWKV-LH/data/runtime/engines/vllm-rwkv-67f0c5996c50/.venv/bin/python -B /home/chase/GitHub/RWKV-LH-unified-corrections-r1-20260914/gradient_diagnostic_r1/reproduce_native_gradient_failure_r1_20260914.py /home/chase/GitHub/RWKV-LH-unified-corrections-r1-20260914/gradient_diagnostic_r1/REGISTRATION.json 71e321c0ebadf8926a9bf6388bd74246e8de6206c14799a076d7daf441e65e27 /home/chase/GitHub/RWKV-LH-unified-corrections-r1-20260914/gradient_diagnostic_r1/DIAGNOSTIC_REGISTRATION.json 77d875a448f898ebea8c44c68fc06de01cb71fd6e268022c6464a47fbd9a2468
