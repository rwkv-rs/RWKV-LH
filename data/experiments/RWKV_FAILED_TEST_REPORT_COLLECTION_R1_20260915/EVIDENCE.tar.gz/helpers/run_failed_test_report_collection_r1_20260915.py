from pathlib import Path
from dataclasses import replace
import sys,json,time,hashlib,urllib.request
R=Path('/home/chase/GitHub/RWKV-LH');S=R/'data/experiments/RWKV_UNIFIED_CORRECTION_TRAIN_R4_20260915/runtime/source';sys.path.insert(0,str(S))
from rwkv_lh.runtime.settings import load_local_env,get_runtime_settings,direct_agent_settings
from rwkv_lh.coding_agent import CodingJob,run_coding_job
from rwkv_lh.model_session import create_model_session,SessionSampling
from rwkv_lh.correction_snapshots import generation_snapshot_audit
D=R/'data/experiments/RWKV_FAILED_TEST_REPORT_COLLECTION_R1_20260915';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def freeze():
 D.mkdir(exist_ok=False);previous=R/'data/experiments/RWKV_TEST_FIRST_REPAIR_PROBE_R1_20260915/REGISTRATION.json';old=json.loads(previous.read_text());cases=[]
 for c in old['cases']:
  case=dict(c);case['requests']={'test_report':f"运行工作区中已有的 {c['test']}，根据本次真实执行输出说明测试是否通过，以及输出中显示的主要失败信息。不要修改任何文件。本次只要求运行并报告结果，不要求修复；测试失败也应如实报告，不能把建议、预期或外层工具成功当作测试通过。若测试未能启动，应与测试已执行但未通过区分。"};assert all(sha(Path(case['workspace'])/n)==h for n,h in case['files'].items());cases.append(case)
 reg={k:old[k] for k in ['source_pins','source_manifest_sha256','model','model_sha256','state_profile_id','state_profile_sha256','context_tokens','sampling']};reg.update(registered_before_run=True,purpose='Narrow failure-report collection on two existing train-family tests. Notrepairtasksuccess, notcomparisonwithfullrepairgoal, noforcedtoolorder. Collectrealpost-commandanswerboundaries; labelsremainpendingindependentreview, nonewformalversion/training.',cases=cases,runner_sha256=sha(Path(__file__)),source_registration_sha256=sha(previous),budget={'calls_per_task':4,'seconds_per_task':240,'max_output_tokens':1800,'total_calls':16,'overall_seconds':1800,'concurrency':1},order=[[1,'test_report'],[2,'test_report']],acceptance='Actually execute existingtest, preserveallworkspacefiles, reportrealtestfailure/passwithsupportingobservederrorinformation. Distinguishtestprocessranfromtoolcheckfailureandstartupfailure. Differentlegitimateinvocationaccepted; finalansweraloneisnotcorrectness. No requirementtofixorfindadditionalbugs.',attribution='zeroRWKVindependent narrowtask; sourceoffsetimplementationstrong-origin noted. No trainedStateclaim, no projectStrict, no hiddenanswers or confirmation.')
 save(D/'REGISTRATION.json',reg)
def run():
 reg=json.loads((D/'REGISTRATION.json').read_text());assert sha(Path(__file__))==reg['runner_sha256'];load_local_env(R/'.env.local');config=direct_agent_settings(replace(get_runtime_settings(),base_url='http://127.0.0.1:29628/v1',model=reg['model'],model_sha256=reg['model_sha256'],max_model_len=24576,state_profile_id='zero',state_profile_sha256='0'*64,state_transport='native_required',return_token_ids=True,read_timeout_seconds=300,action_max_output_tokens=1800,default_temperature=.1,default_top_p=1,default_top_k=0,default_presence_penalty=0,default_frequency_penalty=0,default_penalty_decay=.996));cap=json.load(urllib.request.urlopen(config.base_url+'/capabilities',timeout=15));assert cap['model']==reg['model'];save(D/'CAPABILITIES.json',cap);started=time.monotonic();rows=[]
 for repeat,arm in reg['order']:
  for case in reg['cases']:
   assert time.monotonic()-started<1800 and all(sha(R/p)==h for p,h in reg['source_pins'].items());out=D/'runs'/f"{case['id']}-{arm}-r{repeat}";expected=SessionSampling.from_settings(config).to_dict()
   def factory(*,settings,audit_hook):
    wrapped=generation_snapshot_audit(workspace=out/'workspace',output=out/'execution',audit_hook=audit_hook)
    def audit(e):
     if e.get('type')=='model_session_generation_started':assert e['sampling']==expected,'sampling differs before generation'
     wrapped(e)
    return create_model_session(settings=settings,audit_hook=audit)
   result=run_coding_job(CodingJob(case['id'],case['requests'][arm],case['workspace'],str(out),4,240),settings=config,session_factory=factory);save(out/'COLLECTION_RESULT.json',result);rows.append({'id':out.name,'case':case['id'],'arm':arm,'repeat':repeat,'result':result});save(D/'RESULTS.json',rows);print(out.name,result['termination'],result.get('generation_started'),flush=True)
 save(D/'SOURCE_AFTER.json',{'all_match':all(sha(R/p)==h for p,h in reg['source_pins'].items()),'elapsed_seconds':time.monotonic()-started})
if __name__=='__main__':freeze() if sys.argv[1]=='freeze' else run()
