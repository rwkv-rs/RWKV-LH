from pathlib import Path
import json,hashlib,tarfile,subprocess
R=Path('/home/chase/GitHub/RWKV-LH');D=R/'data/experiments/RWKV_FAILED_TEST_REPORT_COLLECTION_R1_20260915'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
reg=json.loads((D/'REGISTRATION.json').read_text());assert all(sha(R/p)==h for p,h in reg['source_pins'].items())
mech={x['id']:x for x in json.loads((D/'runs/MECHANICAL_AUDIT.json').read_text())};rows=[];packets=[]
for item in json.loads((D/'RESULTS.json').read_text()):
 r=item['result'];m=mech[item['id']];assert m['passed_mechanical_audit'] and len(m['calls'])==2 and r['termination_reason']=='answer_submitted' and r['protocol_rejections']==0
 assert len(r['actions'])==1 and r['actions'][0]['action_type']=='run_command' and r['actions'][0]['result']['exit_code']==1
 assert all(o['consumed_by_answer'] for o in m['observations'])
 assert all('__pycache__' in p for p in r['changed_files'])
 source=Path(r['source_workspace']);workspace=Path(r['workspace'])
 case=next(c for c in reg['cases'] if item['id'].startswith(c['id']+'-'))
 assert all(sha(workspace/n)==h for n,h in case['files'].items())
 rows.append({'id':item['id'],'task_pass':True,'submitted':True,'source_test_files_modified':0,'raw_changed_paths':r['changed_files'],'runtime_cache_paths':len(r['changed_files']),'actual_test_exit_code':1,'calls':2,'protocol_rejections':0,'false_execution_claims':0,'termination_reason':r['termination_reason'],'logical_input_tokens':sum(c['input_tokens'] for c in m['calls']),'output_tokens':sum(c['output_tokens'] for c in m['calls']),'end_to_end_seconds':r['end_to_end_seconds'],'review_note':'Reports actual failed test and main error; query closing explanation imprecisely calls fetchmany failure SQL execution failure. Not an ideal training label; narrow reporting objective met.' if item['id'].startswith('query') else 'Reports actual assertion failure and invalid offsets; does not claim repair.'})
 if item['id'] not in ['query-test_report-r1','offset-test_report-r2']:continue
 call=m['calls'][-1];p=D/'runs'/item['id']/'execution';inp=p/'actual_inputs'/f"{call['request_id']}.txt";assert sha(inp)==call['input_sha256']
 correction='本次运行了 test_query_limit.py，测试已启动但未通过：1 个测试出现 1 个错误，进程退出码为 1。堆栈定位到 document_index/query.py 第 14 行的 fetchmany(...) 调用，报错 ValueError: value must be positive。未修改源代码；本次未尝试修复。' if item['id'].startswith('query') else r['final']
 packets.append({'status':'pending_independent_review','training_admitted':False,'source_run':item['id'],'source_input_path':str(inp.relative_to(R)),'source_input_sha256':sha(inp),'input_checkpoint':call['input_checkpoint'],'request_id':call['request_id'],'original_raw_output':call['raw_output'],'original_final':r['final'],'candidate_text':correction,'candidate_author':'Codex offline correction' if item['id'].startswith('query') else 'RWKV original answer retained for review','actual_tool_result':r['actions'][0]['result'],'reviews':[],'required_next':'Two independent source-bound reviews and normal production replay/data admission; no hidden answers or future observations. This packet is not a dataset row.'})
out={'task_pass':4,'tasks':4,'submitted':4,'source_test_files_modified':0,'runtime_cache_changed_paths':10,'calls':8,'protocol_rejections':0,'false_execution_claims':0,'logical_input_tokens':sum(x['logical_input_tokens'] for x in rows),'output_tokens':sum(x['output_tokens'] for x in rows),'rows':rows,'scope':'Zero State narrow failed-test reporting, not repair, trained benefit, or project Strict.'}
(D/'TASK_RESULTS.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');(D/'PENDING_REVIEW_PACKETS.json').write_text(json.dumps(packets,ensure_ascii=False,indent=2)+'\n')
(D/'REPORT.zh-CN.md').write_text('''# 真实失败测试报告采集 R1

任务级4/4、4次提交；既有源代码与测试修改0，原始变更路径10（两个查询运行各新增1个缓存目录和4个pyc文件），没有写入/替换动作。全部自然answer_submitted。这里的成功是“实际运行已有测试并报告失败”，不是修复成功，也不是项目Strict。

角色级：zero RWKV共8次生成、4次真实run_command，4次实际退出码1；协议拒绝0、虚称修好或通过0。每次回答确实接收了该次工具观察，精确token、输入重建、State父链与采样通过机械核验。明细见TASK_RESULTS与封存轨迹。

两份已获准工作区各两遍。查询报告忠实复现真实ValueError及堆栈，但最后一句将fetchmany阶段笼统称为SQL执行失败，措辞不够精确。按事前的主要失败信息报告目标通过，不另加运行后根因精度门；它也不因此自动成为优质训练标签。偏移报告准确指出三个无效偏移被接受及真实断言失败，没有声称已经修复。

这证明固定窄任务的“测试→观察→如实回答”能运行，不能推断完整修复目标已成立。此前原任务/先测试前缀均0/4的修复对照仍保留原分数，不与本轮混为提示词或训练收益。

保留两个代表性待审材料，重复运行不算独立场景：查询由Codex离线提出更准确候选，偏移保留RWKV原答案。原始输出不改；候选仅绑定当时可见输入和真实命令结果。尚无两份独立审核，training_admitted=false，不新建数据版本、不训练。供应商生成持续超时，没有冒充强模型已审核或已接管。

生产代码未改；最新工程全回归1802 passed、0 skipped。本轮按既有冻结R4推理源码执行，不混入后续离线数据准入修复。证据包包括真实请求、输出、token、工具结果、State、注册和运行器。
''')
with tarfile.open(D/'EVIDENCE.tar.gz','w:gz') as t:
 for base in [D/'runs',D/'service']:
  for p in sorted(base.rglob('*')):
   if p.is_file():t.add(p,arcname=str(p.relative_to(D)))
 for n in ['REGISTRATION.json','RESULTS.json','SOURCE_AFTER.json','CAPABILITIES.json']:t.add(D/n,arcname=n)
 for p in sorted((R/'temp').glob('*failed_test_report_collection_r1_20260915.py')):t.add(p,arcname='helpers/'+p.name)
files=[D/n for n in ['REPORT.zh-CN.md','TASK_RESULTS.json','PENDING_REVIEW_PACKETS.json','EVIDENCE.tar.gz']]
(D/'SHA256.json').write_text(json.dumps({p.name:sha(p) for p in files},indent=2)+'\n');files.append(D/'SHA256.json')
subprocess.run(['git','add',*[str(p) for p in files]],check=True);subprocess.run(['git','commit','-m','R1: preserve real failed-test reporting and source-bound pending correction packets'],check=True);print(json.dumps({k:v for k,v in out.items() if k!='rows'}))
